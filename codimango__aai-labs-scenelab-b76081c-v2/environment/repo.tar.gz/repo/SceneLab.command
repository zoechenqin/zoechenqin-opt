#!/bin/bash
set -e
cd "/Users/brandonsorg/SceneLab"
echo "=== SceneLab ==="
echo "[1/3] Stopping previous..."
pnpm exec tsx skills/editor/stop.ts 2>&1 | head -3 || true
pkill -9 -f vite 2>&1 | head -1 || true
rm -f .metacode/scenelab-editor.json /tmp/scenelab-electron-window.log
sleep 0.5
if [ ! -f apps/editor-electron/dist/main.cjs ]; then
  pnpm --filter @scenelab/editor-electron build
fi
echo "[2/3] Starting server (API 7317 + vite 5173)..."
rm -f .metacode/scenelab-electron.log
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo "server pid $!"
for i in $(seq 1 20); do curl -s http://localhost:5173 > /dev/null && break; sleep 0.5; done
API_URL="http://localhost:7317"
echo "[3/3] Opening SceneLab window..."
rm -f /tmp/scenelab-electron-window.log
CUSTOM_APP="/Users/brandonsorg/SceneLab/apps/editor-electron/dist/SceneLab.app"
if [ -n "$CUSTOM_APP" ] && [ -x "$CUSTOM_APP/Contents/MacOS/Electron" ]; then
  nohup "$CUSTOM_APP/Contents/MacOS/Electron" --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=$API_URL > /tmp/scenelab-electron-window.log 2>&1 & ELECTRON_PID=$!
else
  nohup /Users/brandonsorg/SceneLab/apps/editor-electron/dist/SceneLab.app/Contents/MacOS/Electron --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=$API_URL > /tmp/scenelab-electron-window.log 2>&1 & ELECTRON_PID=$!
fi
sleep 2
# Record the window pid so stop.ts can close it. The wrapper pid is the fallback when the
# real Electron process cannot be identified.
REAL_ELECTRON_PID=$(pgrep -f "main.cjs --window --api=$API_URL" | head -1)
node -e "
const fs=require('fs'); const f='.metacode/scenelab-editor.json';
try{ const d=JSON.parse(fs.readFileSync(f,'utf-8'));
  d.electronPid=Number(process.argv[1]||process.argv[2])||null; d.launcher='SceneLab.command';
  fs.writeFileSync(f,JSON.stringify(d,null,2)); }catch(e){}
" "$REAL_ELECTRON_PID" "$ELECTRON_PID" 2>/dev/null || true
echo ""
echo "SceneLab is live — API $API_URL · UI http://localhost:5173"
echo "Ask the agent for a scene in the editor's Agent tab."
