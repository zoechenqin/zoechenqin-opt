import { constant } from './animatable'
import { assignBehaviorIds } from './btid'
import { arrangementOf, behaviorOf, findEntity, identityTransform, isPlainGroup } from './builders'
import type { BTNode, CorrectionEvent, Entity, Keyframe, Projection, Scene, Style, Transform } from './types'

/** A transform that neither moves, rotates nor scales — so removing it cannot move a child. */
function isIdentityTransform(t: Transform): boolean {
  const isConst = <T>(a: { kind: string; value?: T }): a is { kind: 'const'; value: T } => a.kind === 'const'
  if (!isConst(t.position) || !isConst(t.rotation) || !isConst(t.scale)) return false
  const p = t.position.value as { x: number; y: number; z: number }
  const sc = t.scale.value as { x: number; y: number; z: number }
  const r = t.rotation.value as { angle: number }
  return p.x === 0 && p.y === 0 && p.z === 0 && sc.x === 1 && sc.y === 1 && sc.z === 1 && r.angle === 0
}

/** Replaces `targetId` in its parent's child list with that group's own children. */
function spliceGroupOut(root: Entity, targetId: string): Entity {
  const children = root.children.flatMap((c) =>
    c.id === targetId && isPlainGroup(c) ? c.children : [spliceGroupOut(c, targetId)],
  )
  return { ...root, children } as Entity
}

function mapEntityById(root: Entity, id: string, updater: (n: Entity) => Entity): Entity {
  if (root.id === id) return updater(root)
  return { ...root, children: root.children.map((c) => mapEntityById(c as Entity, id, updater)) } as Entity
}

function insertEntity(root: Entity, parentId: string, entity: Entity, index: number): Entity {
  if (root.id === parentId) {
    const children = [...root.children]
    children.splice(index, 0, entity as any)
    return { ...root, children } as Entity
  }
  return { ...root, children: root.children.map((c) => insertEntity(c as Entity, parentId, entity, index)) } as Entity
}

function removeEntity(root: Entity, targetId: string): { root: Entity; removed: Entity | null } {
  const idx = root.children.findIndex((c) => c.id === targetId)
  if (idx !== -1) {
    const removed = root.children[idx] as Entity
    const children = [...root.children]
    children.splice(idx, 1)
    return { root: { ...root, children } as Entity, removed }
  }
  let removed: Entity | null = null
  const children = root.children.map((c) => {
    const result = removeEntity(c as Entity, targetId)
    if (result.removed) removed = result.removed
    return result.root
  })
  return { root: { ...root, children } as Entity, removed }
}

function setNestedProp(obj: Record<string, unknown>, path: string, value: unknown): Record<string, unknown> {
  const parts = path.split('.')
  const out = { ...obj }
  let cur: Record<string, unknown> = out
  for (let i = 0; i < parts.length - 1; i++) {
    const key = parts[i]!
    const next = cur[key]
    const nextObj = typeof next === 'object' && next !== null ? { ...(next as Record<string, unknown>) } : {}
    cur[key] = nextObj
    cur = nextObj
  }
  cur[parts[parts.length - 1]!] = value
  return out
}

function updateBaseEntity(scene: Scene, id: string, updater: (n: Entity) => Entity): Scene {
  // A correction naming an entity that is not there must fail loudly rather than return the scene
  // unchanged. It matters most where a log is most useful: replaying history against a scene that
  // has since drifted, where a missing target is the thing you need told about.
  if (!findEntity(scene.root as Entity, id)) {
    throw new Error(`scene-ir: event targets entity "${id}", which does not exist in this scene`)
  }
  return { ...scene, root: mapEntityById(scene.root as Entity, id, updater) as any }
}

function updateTransform(scene: Scene, id: string, updater: (t: Transform) => Transform): Scene {
  if (id === scene.camera.id) {
    return { ...scene, camera: { ...scene.camera, transform: updater(scene.camera.transform) } }
  }
  return updateBaseEntity(scene, id, (n) => ({ ...n, transform: updater(n.transform) }))
}


/**
 * Map a behavior-tree entity by its `id`, anywhere in any tree in the scene.
 *
 * BT ids are a separate namespace from entity ids: `lift` names an action, not a ring. Editing a
 * template action reaches every row the forEach stamps, which is exactly the property that makes a
 * procedural scene cheap to change — and now recordable as one event.
 */
function mapBTById(bt: BTNode, id: string, updater: (n: BTNode) => BTNode, hit: { found: boolean }): BTNode {
  if ((bt as { id?: string }).id === id) {
    hit.found = true
    return updater(bt)
  }
  const rec = bt as unknown as Record<string, unknown>
  const out: Record<string, unknown> = { ...rec }
  if (Array.isArray(rec['children'])) {
    out['children'] = (rec['children'] as BTNode[]).map((c) => mapBTById(c, id, updater, hit))
  }
  for (const key of ['child', 'template'] as const) {
    if (rec[key] && typeof rec[key] === 'object') out[key] = mapBTById(rec[key] as BTNode, id, updater, hit)
  }
  return out as unknown as BTNode
}

function updateBehavior(scene: Scene, btId: string, updater: (n: BTNode) => BTNode): Scene {
  const hit = { found: false }
  const walk = (n: Entity): Entity => {
    const next =
      behaviorOf(n) !== undefined
        ? ({ ...n, components: { ...n.components, behavior: constant(mapBTById(behaviorOf(n)!, btId, updater, hit)) } } as Entity)
        : n
    return { ...next, children: next.children.map((c) => walk(c as Entity)) } as Entity
  }
  const root = walk(scene.root as Entity)
  if (!hit.found) {
    throw new Error(`scene-ir: event targets behavior tree node "${btId}", which no node in this scene declares — note that a node without an id cannot be addressed at all, and parseScene assigns one to every node (§4.6)`)
  }
  return { ...scene, root: root as Scene['root'] }
}

/** Edit the keyframes of the `curve` leaf with this id. Throws if no such leaf exists. */
function updateCurve(scene: Scene, curveId: string, updater: (kfs: Keyframe<unknown>[]) => Keyframe<unknown>[]): Scene {
  return updateBehavior(scene, curveId, (n) => {
    if (n.type !== 'curve') {
      throw new Error(`scene-ir: keyframe event targets "${curveId}", which is a ${n.type}, not a curve`)
    }
    return { ...n, keyframes: updater(n.keyframes) }
  })
}

/**
 * Behavior-tree surgery (§6). A BT node holds children in one of three shapes — `children[]` on a
 * composite, `child` on a decorator or condition, `template` on a forEach — so every structural
 * edit has to speak all three rather than assuming an array.
 */
type BTSlot = 'children' | 'child' | 'template'

function slotOf(node: BTNode): BTSlot | null {
  const n = node as unknown as Record<string, unknown>
  if (Array.isArray(n['children'])) return 'children'
  if (n['child'] !== undefined) return 'child'
  if (n['template'] !== undefined) return 'template'
  // A decorator or forEach whose slot is momentarily empty still accepts one.
  if (node.type === 'decorator' || node.type === 'condition') return 'child'
  if (node.type === 'forEach') return 'template'
  return null
}

function findBTNode(bt: BTNode, id: string): BTNode | undefined {
  if ((bt as { id?: string }).id === id) return bt
  const n = bt as unknown as Record<string, unknown>
  for (const c of (n['children'] as BTNode[] | undefined) ?? []) {
    const found = findBTNode(c, id)
    if (found) return found
  }
  for (const key of ['child', 'template'] as const) {
    if (n[key]) {
      const found = findBTNode(n[key] as BTNode, id)
      if (found) return found
    }
  }
  return undefined
}

/** Rebuild `bt` without the node named `id`, recording what was dropped. */
function removeBTNode(bt: BTNode, id: string, out: { removed?: BTNode }): BTNode {
  const n = bt as unknown as Record<string, unknown>
  const next: Record<string, unknown> = { ...n }

  if (Array.isArray(n['children'])) {
    const kids = n['children'] as BTNode[]
    const idx = kids.findIndex((c) => (c as { id?: string }).id === id)
    if (idx !== -1) {
      out.removed = kids[idx]
      next['children'] = [...kids.slice(0, idx), ...kids.slice(idx + 1)]
      return next as unknown as BTNode
    }
    next['children'] = kids.map((c) => removeBTNode(c, id, out))
  }

  for (const key of ['child', 'template'] as const) {
    const slotValue = n[key] as BTNode | undefined
    if (!slotValue) continue
    if ((slotValue as { id?: string }).id === id) {
      if (bt.type === 'decorator' || bt.type === 'forEach') {
        throw new Error(
          `scene-ir: behavior.removeNode would leave ${bt.type} "${(bt as { id?: string }).id ?? '?'}" with an empty ` +
            `${key}, which it requires — remove the ${bt.type} itself, or reparent something into the slot first`,
        )
      }
      out.removed = slotValue
      delete next[key]
      return next as unknown as BTNode
    }
    next[key] = removeBTNode(slotValue, id, out)
  }

  return next as unknown as BTNode
}

/** Rebuild `bt` with `node` inserted under `parentId`. */
function insertBTNode(bt: BTNode, parentId: string, node: BTNode, index: number, hit: { found: boolean }): BTNode {
  const n = bt as unknown as Record<string, unknown>
  const next: Record<string, unknown> = { ...n }

  if ((bt as { id?: string }).id === parentId) {
    hit.found = true
    const slot = slotOf(bt)
    if (slot === 'children') {
      const kids = (n['children'] as BTNode[] | undefined) ?? []
      const at = Math.max(0, Math.min(index, kids.length))
      next['children'] = [...kids.slice(0, at), node, ...kids.slice(at)]
      return next as unknown as BTNode
    }
    if (slot === null) {
      throw new Error(`scene-ir: behavior node "${parentId}" is a ${bt.type} leaf and cannot hold children`)
    }
    if (n[slot] !== undefined) {
      throw new Error(
        `scene-ir: behavior node "${parentId}" already holds a ${slot}; a ${bt.type} has exactly one slot, ` +
          `so remove or reparent the existing node first`,
      )
    }
    next[slot] = node
    return next as unknown as BTNode
  }

  if (Array.isArray(n['children'])) {
    next['children'] = (n['children'] as BTNode[]).map((c) => insertBTNode(c, parentId, node, index, hit))
  }
  for (const key of ['child', 'template'] as const) {
    if (n[key]) next[key] = insertBTNode(n[key] as BTNode, parentId, node, index, hit)
  }
  return next as unknown as BTNode
}

/** Apply a rewrite to whichever behavior entity owns the tree containing `id`. */
function editTreeContaining(scene: Scene, id: string, rewrite: (root: BTNode) => BTNode): Scene {
  let found = false
  const walk = (e: Entity): Entity => {
    let next = e
    const tree = behaviorOf(e)
    if (tree && findBTNode(tree, id)) {
      found = true
      next = { ...e, components: { ...e.components, behavior: constant(rewrite(tree)) } } as Entity
    }
    return { ...next, children: next.children.map((c) => walk(c as Entity)) } as Entity
  }
  const root = walk(scene.root as Entity)
  if (!found) {
    throw new Error(`scene-ir: event targets behavior tree node "${id}", which no node in this scene declares`)
  }
  return assignBehaviorIds({ ...scene, root: root as Scene['root'] })
}

export function applyEvent(scene: Scene, event: CorrectionEvent): Scene {
  switch (event.type) {
    case 'behavior.setParams':
      return updateBehavior(scene, event.target, (n) => ({ ...n, params: event.to }) as BTNode)
    case 'behavior.setDuration':
      return updateBehavior(scene, event.target, (n) => ({ ...n, duration: event.to }) as BTNode)
    case 'forEach.setOverride':
      return updateBehavior(scene, event.target, (n) => {
        if (n.type !== 'forEach') throw new Error(`scene-ir: forEach.setOverride targets "${event.target}", which is a ${n.type}`)
        return { ...n, overrides: { ...(n.overrides ?? {}), [event.index]: event.to } }
      })
    case 'forEach.removeOverride':
      return updateBehavior(scene, event.target, (n) => {
        if (n.type !== 'forEach') throw new Error(`scene-ir: forEach.removeOverride targets "${event.target}", which is a ${n.type}`)
        const next = { ...(n.overrides ?? {}) }
        delete next[event.index]
        return { ...n, overrides: next }
      })
    case 'entity.translate':
      return updateTransform(scene, event.target, (t) => ({ ...t, position: constant(event.to) }))
    case 'entity.scale':
      return updateTransform(scene, event.target, (t) => ({ ...t, scale: constant(event.to) }))
    case 'entity.rotate':
      return updateTransform(scene, event.target, (t) => ({ ...t, rotation: constant(event.to) }))
    case 'entity.setLocked':
      return updateBaseEntity(scene, event.target, (n) => ({ ...n, locked: event.to }) as Entity)
    case 'entity.setEnabled':
      return updateBaseEntity(scene, event.target, (n) => ({ ...n, enabled: event.to }) as Entity)
    case 'component.upsert': {
      return updateBaseEntity(scene, event.target, (n) => {
        const existing = (n as any).components ?? {}
        return { ...n, components: { ...existing, [event.componentType]: constant(event.to) } } as Entity
      })
    }
    case 'component.remove': {
      return updateBaseEntity(scene, event.target, (n) => {
        const comps = { ...((n as any).components ?? {}) }
        delete comps[event.componentType]
        return { ...n, components: Object.keys(comps).length > 0 ? comps : undefined } as Entity
      })
    }
    case 'component.setProp': {
      return updateBaseEntity(scene, event.target, (n) => {
        const comps = { ...((n as any).components ?? {}) }
        const existingAnim = comps[event.componentType]
        const baseValue =
          existingAnim && typeof existingAnim === 'object' && 'kind' in (existingAnim as any) && (existingAnim as any).kind === 'const'
            ? (existingAnim as any).value
            : existingAnim ?? {}
        const updatedValue = setNestedProp(baseValue as Record<string, unknown>, event.path, event.to)
        comps[event.componentType] = constant(updatedValue)
        return { ...n, components: comps } as Entity
      })
    }
    case 'override.set':
    case 'override.remove': {
      // Overrides live on the instance op inside the arrangement, not on the entity.
      return updateBaseEntity(scene, event.target, (n) => {
        const graph = arrangementOf(n)
        if (!graph) return n
        const ops = graph.ops.map((op) => {
          if (op.type !== 'instance') return op
          if (event.op !== undefined && op.id !== event.op) return op
          const overrides = { ...(op.overrides ?? {}) }
          if (event.type === 'override.set') overrides[event.index] = event.to
          else delete overrides[event.index]
          return Object.keys(overrides).length > 0
            ? { ...op, overrides }
            : (({ overrides: _drop, ...rest }) => rest)(op)
        })
        return { ...n, components: { ...n.components, arrangement: constant({ ...graph, ops }) } }
      })
    }
    case 'entity.add':
      return { ...scene, root: insertEntity(scene.root as Entity, event.parent, event.entity, event.index) as any }
    case 'entity.remove':
      return { ...scene, root: removeEntity(scene.root as Entity, event.target).root as any }
    case 'entity.reparent': {
      const { root, removed } = removeEntity(scene.root as Entity, event.target)
      if (removed === null) return scene
      return { ...scene, root: insertEntity(root, event.newParent, removed, event.index) as any }
    }
    case 'entity.group': {
      // The wrapper is identity, so every moved child keeps its world position by construction.
      let root = scene.root as Entity
      const moved: Entity[] = []
      for (const id of event.targets) {
        const res = removeEntity(root, id)
        if (res.removed === null) continue
        root = res.root
        moved.push(res.removed)
      }
      if (moved.length === 0) return scene
      const wrapper: Entity = {
        id: event.newId,
        word: event.word ?? 'group',
        transform: identityTransform(),
        children: moved,
      }
      return { ...scene, root: insertEntity(root, event.parent, wrapper, event.index ?? Number.MAX_SAFE_INTEGER) as any }
    }
    case 'entity.ungroup': {
      const group = findEntity(scene.root as Entity, event.target)
      if (!group || !isPlainGroup(group)) return scene
      if (!isIdentityTransform(group.transform)) {
        // Composing a non-identity wrapper into each child would have to fold animated tracks
        // together; not attempted rather than done wrongly.
        throw new Error(`scene-ir: entity.ungroup on "${event.target}" would move its children (non-identity transform)`)
      }
      return { ...scene, root: spliceGroupOut(scene.root as Entity, event.target) as any }
    }
    // Keyframes live in `curve` leaves and are addressed by the leaf's id (§4.2). `index` picks a
    // keyframe within that leaf; times are LOCAL to it, which is what keeps these edits valid when
    // the surrounding tree is restructured.
    case 'behavior.addNode': {
      const hit = { found: false }
      // A hand-written node may arrive without ids; editTreeContaining re-runs the parse-gate pass
      // so everything it inserted is addressable by the next correction (§4.6).
      return editTreeContaining(scene, event.parent, (root) =>
        insertBTNode(root, event.parent, event.node, event.index, hit),
      )
    }
    case 'behavior.removeNode': {
      return editTreeContaining(scene, event.target, (root) => {
        if ((root as { id?: string }).id === event.target) {
          throw new Error(
            `scene-ir: behavior.removeNode cannot remove "${event.target}", the root of its tree — ` +
              `a behavior entity must have one, so remove the entity instead`,
          )
        }
        return removeBTNode(root, event.target, {})
      })
    }
    case 'behavior.reparentNode': {
      return editTreeContaining(scene, event.target, (root) => {
        if ((root as { id?: string }).id === event.target) {
          throw new Error(`scene-ir: behavior.reparentNode cannot move "${event.target}", the root of its tree`)
        }
        const moving = findBTNode(root, event.target)
        if (!moving) throw new Error(`scene-ir: behavior.reparentNode: "${event.target}" is not in this tree`)
        // The tree must stay a tree: a node cannot be moved inside itself.
        if (findBTNode(moving, event.newParent)) {
          throw new Error(
            `scene-ir: behavior.reparentNode would put "${event.target}" inside its own subtree ` +
              `("${event.newParent}" is a descendant of it)`,
          )
        }
        const out: { removed?: BTNode } = {}
        const without = removeBTNode(root, event.target, out)
        if (!out.removed) throw new Error(`scene-ir: behavior.reparentNode: "${event.target}" is not in this tree`)
        const hit = { found: false }
        const next = insertBTNode(without, event.newParent, out.removed, event.index, hit)
        if (!hit.found) {
          throw new Error(`scene-ir: behavior.reparentNode: new parent "${event.newParent}" is not in this tree`)
        }
        return next
      })
    }
    case 'behavior.setType': {
      return updateBehavior(scene, event.target, (n) => {
        if (n.type !== 'sequence' && n.type !== 'selector' && n.type !== 'parallel') {
          throw new Error(
            `scene-ir: behavior.setType targets "${event.target}", which is a ${n.type}; only composites ` +
              `(sequence, selector, parallel) are interchangeable`,
          )
        }
        // Composites differ in control flow, not in shape, so the children carry over untouched.
        // Fields that belong to the old type only (a parallel's policy, a sequence's repeat) do not.
        const { type: _t, id, children } = n as { type: string; id?: string; children: BTNode[] }
        return { type: event.to, ...(id !== undefined ? { id } : {}), children } as BTNode
      })
    }
    case 'keyframe.move': {
      return updateCurve(scene, event.target, (kfs) => {
        if (event.index < 0 || event.index >= kfs.length) return kfs
        const next = kfs.slice()
        next[event.index] = { ...next[event.index]!, t: event.to }
        // A drag can carry a keyframe past its neighbour; the list is defined as ascending.
        next.sort((a, b) => a.t - b.t)
        return next
      })
    }
    case 'keyframe.setValue': {
      return updateCurve(scene, event.target, (kfs) => {
        if (event.index < 0 || event.index >= kfs.length) return kfs
        const next = kfs.slice()
        next[event.index] = { ...next[event.index]!, value: event.to }
        return next
      })
    }
    case 'keyframe.setEasing': {
      return updateCurve(scene, event.target, (kfs) => {
        if (event.index < 0 || event.index >= kfs.length) return kfs
        const next = kfs.slice()
        next[event.index] = { ...next[event.index]!, easing: event.to }
        return next
      })
    }
    case 'keyframe.add': {
      return updateCurve(scene, event.target, (kfs) => [...kfs, event.keyframe].sort((a, b) => a.t - b.t))
    }
    default: {
      const _exhaustive: never = event
      return _exhaustive
    }
  }
}
