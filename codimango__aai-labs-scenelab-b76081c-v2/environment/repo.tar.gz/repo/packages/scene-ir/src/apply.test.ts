
import { describe, it, expect } from 'vitest'
import { applyEvent, arrangementOf, behaviorOf, constant, findEntity, identityTransform, resolveScene, sampleBoard, sampleScene, sampleScene3D, simulate, transformPoint } from './index'
import type { CorrectionEvent, Entity, Scene } from './index'

const circleWorldX = (scene: ReturnType<typeof sampleScene>): number => {
  const c = resolveScene(scene).primitives.find((p) => p.id === 'circle_1')
  return transformPoint(c!.worldMatrix, { x: 0, y: 0, z: 0 }).x
}

describe('applyEvent (§5.3)', () => {
  it('entity.translate sets the target position and is immutable', () => {
    const scene = sampleScene()
    const event: CorrectionEvent = {
      type: 'entity.translate',
      target: 'circle_1',
      from: { x: 100, y: 0, z: 0 },
      to: { x: 130, y: 0, z: 0 },
    }
    const next = applyEvent(scene, event)
    expect(circleWorldX(next)).toBe(130)
    expect(circleWorldX(scene)).toBe(100)
  })

  it('component.setProp updates a drawable component field (radius)', () => {
    const next = applyEvent(sampleScene(), {
      type: 'component.setProp',
      target: 'circle_1',
      componentType: 'circle',
      path: 'radius',
      from: 50,
      to: 70,
    })
    const c = resolveScene(next).primitives.find((p) => p.id === 'circle_1')
    expect(c?.shape.type === 'circle' && (c.shape as any).radius === 70).toBe(true)
  })

  it('component.setProp updates style via component path', () => {
    const next = applyEvent(sampleScene(), {
      type: 'component.setProp',
      target: 'circle_1',
      componentType: 'circle',
      path: 'style.fill',
      from: { r: 0.2, g: 0.4, b: 0.9, a: 1 },
      to: { r: 1, g: 0, b: 0, a: 1 },
    })
    const c = resolveScene(next).primitives.find((p) => p.id === 'circle_1')
    expect((c?.shape as any).style.fill?.r).toBe(1)
  })

  it('camera edits target the camera id', () => {
    const next = applyEvent(sampleScene(), {
      type: 'entity.translate',
      target: 'camera',
      from: { x: 0, y: 0, z: 1000 },
      to: { x: 5, y: 0, z: 1000 },
    })
    expect(transformPoint(resolveScene(next).camera.worldMatrix, { x: 0, y: 0, z: 0 }).x).toBe(5)
  })

  it('entity.add / entity.remove round-trips and findEntity works', () => {
    let scene = sampleScene()
    const newEntity: Entity = {
      id: 'new_entity',
      word: 'box',
      transform: identityTransform(),
      components: { rect: { kind: 'const', value: { size: { x: 10, y: 10 }, style: {} } } } as any,
      children: [],
    }
    scene = applyEvent(scene, { type: 'entity.add', parent: 'root', entity: newEntity, index: 0 })
    expect(findEntity(scene.root as any, 'new_entity')).toBeDefined()
    scene = applyEvent(scene, { type: 'entity.remove', target: 'new_entity' })
    expect(findEntity(scene.root as any, 'new_entity')).toBeUndefined()
  })

  it('entity.reparent preserves the moved entity', () => {
    const moved = applyEvent(sampleScene(), {
      type: 'entity.reparent',
      target: 'circle_1',
      newParent: 'root',
      index: 1,
    })
    expect(findEntity(moved.root, 'circle_1')).toBeDefined()
  })

  // The 3D fixture's sphere bounce is a `curve` leaf, `motion.bounce`, with keyframes at
  // t = 0, 1, 2, 4 — local to the leaf, which starts at scene 0 under a `parallel`. The tree is a
  // component on root; there is no entity holding it.
  const bounceKfs = (scene: Scene): Array<{ t: number; value: unknown; easing?: unknown }> =>
    (behaviorOf(scene.root as any) as any).children.find((c: any) => c.id === 'motion.bounce').keyframes

  it('keyframe.move retimes one keyframe of a curve, immutably', () => {
    const scene = sampleScene3D()
    expect(bounceKfs(scene)[0]!.t).toBe(0)

    const next = applyEvent(scene, { type: 'keyframe.move', target: 'motion.bounce', index: 0, from: 0, to: 0.5 })
    expect(bounceKfs(next).map((k) => k.t)).toEqual([0.5, 1, 2, 4])
    expect(bounceKfs(scene)[0]!.t).toBe(0)
  })

  it('keyframe.move re-sorts when dragged past a neighbour', () => {
    const next = applyEvent(sampleScene3D(), { type: 'keyframe.move', target: 'motion.bounce', index: 0, from: 0, to: 3 })
    expect(bounceKfs(next).map((k) => k.t)).toEqual([1, 2, 3, 4])
  })

  it('keyframe.move no-ops on an out-of-range index', () => {
    const scene = sampleScene3D()
    const next = applyEvent(scene, { type: 'keyframe.move', target: 'motion.bounce', index: 99, from: 0, to: 1 })
    expect(bounceKfs(next)).toEqual(bounceKfs(scene))
  })

  it('keyframe.setValue and setEasing edit in place', () => {
    let scene = applyEvent(sampleScene3D(), {
      type: 'keyframe.setValue',
      target: 'motion.bounce',
      index: 1,
      from: { x: 3, y: 2.5, z: 0 },
      to: { x: 3, y: 9, z: 0 },
    })
    expect(bounceKfs(scene)[1]!.value).toEqual({ x: 3, y: 9, z: 0 })

    scene = applyEvent(scene, {
      type: 'keyframe.setEasing',
      target: 'motion.bounce',
      index: 0,
      from: 'linear',
      to: 'easeInOut',
    })
    expect(bounceKfs(scene)[0]!.easing).toBe('easeInOut')
  })

  it('keyframe.add inserts in time order', () => {
    const next = applyEvent(sampleScene3D(), {
      type: 'keyframe.add',
      target: 'motion.bounce',
      keyframe: { t: 1.5, value: { x: 3, y: 4, z: 0 } },
    })
    expect(bounceKfs(next).map((k) => k.t)).toEqual([0, 1, 1.5, 2, 4])
  })

  it('names the node when a keyframe event targets something that is not a curve', () => {
    expect(() =>
      applyEvent(sampleScene3D(), { type: 'keyframe.move', target: 'motion', index: 0, from: 0, to: 1 }),
    ).toThrow(/which is a parallel, not a curve/)
  })

  it('names the id when a keyframe event targets nothing at all', () => {
    expect(() =>
      applyEvent(sampleScene3D(), { type: 'keyframe.move', target: 'nope', index: 0, from: 0, to: 1 }),
    ).toThrow(/behavior tree node "nope"/)
  })

  it('locked/visible toggles', () => {
    let scene = sampleScene()
    scene = applyEvent(scene, { type: 'entity.setLocked', target: 'circle_1', from: false, to: true })
    expect((findEntity(scene.root as any, 'circle_1') as any).locked).toBe(true)
    scene = applyEvent(scene, { type: 'entity.setEnabled', target: 'circle_1', from: true, to: false })
    expect((findEntity(scene.root as any, 'circle_1') as any).enabled).toBe(false)
  })


  it('override.set writes onto the instance op and moves only that stamp', () => {
    const scene = sampleBoard()
    const board = findEntity(scene.root as any, 'board') as any
    const before = resolveScene(scene).primitives.find((p) => p.id === 'board:square_template:1,0')!
    const next = applyEvent(scene, {
      type: 'override.set',
      target: board.id,
      index: '1,0',
      from: undefined,
      to: { transform: { ...identityTransform(), position: { kind: 'const', value: { x: 10, y: 0, z: 0 } } } },
    })
    // the patch is stored on the instance op, not on the entity
    const op = arrangementOf(findEntity(next.root as any, 'board')!)!.ops.find((o) => o.type === 'instance') as any
    expect(op.overrides['1,0']).toBeDefined()
    // and only that stamp moves
    const after = resolveScene(next).primitives.find((p) => p.id === 'board:square_template:1,0')!
    expect(transformPoint(after.worldMatrix, { x: 0, y: 0, z: 0 }).x)
      .not.toBe(transformPoint(before.worldMatrix, { x: 0, y: 0, z: 0 }).x)
    const other = resolveScene(next).primitives.find((p) => p.id === 'board:square_template:0,0')!
    const otherBefore = resolveScene(scene).primitives.find((p) => p.id === 'board:square_template:0,0')!
    expect(transformPoint(other.worldMatrix, { x: 0, y: 0, z: 0 }).x)
      .toBe(transformPoint(otherBefore.worldMatrix, { x: 0, y: 0, z: 0 }).x)
  })

  it('entity.group wraps targets and entity.ungroup splices them back', () => {
    const scene = sampleScene()
    const grouped = applyEvent(scene, {
      type: 'entity.group',
      targets: ['circle_1', 'label_1'],
      parent: 'root',
      newId: 'wrapper',
      word: 'pair',
    })
    const wrapper = findEntity(grouped.root as any, 'wrapper') as any
    expect(wrapper.children.map((c: any) => c.id)).toEqual(['circle_1', 'label_1'])
    // the wrapper is identity, so world positions are unchanged
    const before = resolveScene(scene).primitives.find((p) => p.id === 'circle_1')!
    const after = resolveScene(grouped).primitives.find((p) => p.id === 'circle_1')!
    expect(transformPoint(after.worldMatrix, { x: 0, y: 0, z: 0 }))
      .toEqual(transformPoint(before.worldMatrix, { x: 0, y: 0, z: 0 }))

    const flat = applyEvent(grouped, { type: 'entity.ungroup', target: 'wrapper' })
    expect(findEntity(flat.root as any, 'wrapper')).toBeUndefined()
    expect(findEntity(flat.root as any, 'circle_1')).toBeDefined()
    expect(resolveScene(flat).primitives.map((p) => p.id)).toEqual(resolveScene(scene).primitives.map((p) => p.id))
  })

  it('entity.ungroup refuses to silently move children', () => {
    const scene = applyEvent(sampleScene(), {
      type: 'entity.group', targets: ['circle_1'], parent: 'root', newId: 'w',
    })
    const moved = applyEvent(scene, { type: 'entity.translate', target: 'w', from: { x: 0, y: 0, z: 0 }, to: { x: 50, y: 0, z: 0 } })
    expect(() => applyEvent(moved, { type: 'entity.ungroup', target: 'w' })).toThrow(/would move its children/)
  })
})

describe('program edits (§3.6)', () => {
  const tree = (): unknown => ({
    type: 'forEach', id: 'moves',
    source: { kind: 'rows', rows: [{ toX: 10 }, { toX: 20 }] },
    template: { type: 'sequence', id: 'move', children: [
      { type: 'action', id: 'lift', action: 'translate', target: 'dot', duration: 1, params: { to: { x: { $: 'toX' }, y: 100, z: 0 } } },
    ] },
  })
  const scene = (): Scene => ({
    schemaVersion: '0.1.0', id: 'prog', space: '2d', canvas: { width: 10, height: 10 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(10) } },
    root: { id: 'root', word: 's', transform: identityTransform(), children: [
      { id: 'bt', word: 't', transform: identityTransform(), children: [], components: { behavior: constant(tree()) } },
      { id: 'dot', word: 'dot', transform: identityTransform(),
        components: { circle: constant({ radius: 1, style: {} }) }, children: [] },
    ] },
  }) as Scene

  it('one event retimes every row, because it edits the template', () => {
    // The cheap-edit property, now recordable: 1 event instead of one per row.
    const out = applyEvent(scene(), { type: 'behavior.setParams', target: 'lift', from: {}, to: { to: { x: { $: 'toX' }, y: 420, z: 0 } } } as CorrectionEvent)
    const ys = simulate(out).schedule.map((e) => (e.params['to'] as { y: number }).y)
    expect(ys).toEqual([420, 420])
  })

  it('a forEach override corrects a single row', () => {
    const out = applyEvent(scene(), { type: 'forEach.setOverride', target: 'moves', index: '1', from: undefined, to: { toX: 999 } } as CorrectionEvent)
    const xs = simulate(out).schedule.map((e) => (e.params['to'] as { x: number }).x)
    expect(xs).toEqual([10, 999])
  })

  it('removing the override restores the generated row', () => {
    let out = applyEvent(scene(), { type: 'forEach.setOverride', target: 'moves', index: '1', from: undefined, to: { toX: 999 } } as CorrectionEvent)
    out = applyEvent(out, { type: 'forEach.removeOverride', target: 'moves', index: '1' } as CorrectionEvent)
    const xs = simulate(out).schedule.map((e) => (e.params['to'] as { x: number }).x)
    expect(xs).toEqual([10, 20])
  })

  it('setDuration retimes an action', () => {
    const out = applyEvent(scene(), { type: 'behavior.setDuration', target: 'lift', from: 1, to: 3 } as CorrectionEvent)
    expect(simulate(out).duration).toBe(6)
  })

  it('names a behaviour id that does not exist rather than doing nothing', () => {
    expect(() => applyEvent(scene(), { type: 'behavior.setParams', target: 'nope', from: {}, to: {} } as CorrectionEvent))
      .toThrow(/behavior tree node "nope", which no node in this scene declares/)
  })

  it('refuses an override on something that is not a forEach', () => {
    expect(() => applyEvent(scene(), { type: 'forEach.setOverride', target: 'lift', index: '0', from: undefined, to: {} } as CorrectionEvent))
      .toThrow(/which is a action/)
  })
})
