export type EntityId = string

export interface Vec3 {
  x: number
  y: number
  z: number
}

export interface Vec2 {
  x: number
  y: number
}

export interface AxisAngle {
  axis: Vec3
  angle: number
}

export interface Color {
  r: number
  g: number
  b: number
  a: number
}

export type Seconds = number

export type Easing = 'linear' | 'easeIn' | 'easeOut' | 'easeInOut' | { cubicBezier: [number, number, number, number] }

export interface Keyframe<T> {
  t: Seconds
  value: T
  easing?: Easing
}

/**
 * The value slot (§4.3). One variant: time does not live here. A property that changes over time
 * is driven by a `curve` leaf in the behavior tree, which holds the keyframes and names the
 * property it drives. The wrapper preserves a uniform `resolve(value, t)` seam for renderers.
 */
export type Animatable<T> = { kind: 'const'; value: T }

export interface Transform {
  position: Animatable<Vec3>
  rotation: Animatable<AxisAngle>
  scale: Animatable<Vec3>
  anchor: Vec3
}

export type Projection =
  | { type: 'orthographic'; height: Animatable<number> }
  | { type: 'perspective'; fovY: Animatable<number>; near: number; far: number }

export interface Camera {
  id: EntityId
  transform: Transform
  projection: Projection
}

export interface BaseEntity {
  id: EntityId
  word: string
  name?: string
  transform: Transform
  locked?: boolean
  /**
   * Whether the entity participates at all: drawn, hit-tested and (once there is one) simulated.
   * False culls the whole subtree. This is the GameObject-level flag — Unity's SetActive — not a
   * renderer's `enabled`, which is why it lives on the entity rather than on a drawable component:
   * groups, arrangements and behavior entities have nothing to draw and still need it. Default true.
   */
  enabled?: boolean
  /**
   * Not drawn or hit-tested where it sits; exists to be stamped out by `instance` ops that
   * reference its id. Its own transform is the per-copy offset applied at each point, and its
   * children are stamped with it. Unlike `enabled: false`, which culls everywhere, a template
   * IS drawn — just only at its instantiation points (Design §2.2).
   */
  template?: boolean
  /**
   * Set when this entity is interpreter output rather than something a human or model authored
   * directly (Design §2.7). The description that produced it stays attached, so the entity can be
   * corrected with the ordinary editing vocabulary and still re-synthesized later.
   */
  synthesized?: import('./synthesize').SynthesisProvenance
  components?: ComponentMap
}

export interface Style {
  fill?: Animatable<Color>
  stroke?: Animatable<Color>
  strokeWidth?: Animatable<number>
}

export type PathSegment =
  | { type: 'move'; to: Vec3 }
  | { type: 'line'; to: Vec3 }
  | { type: 'cubicBezier'; to: Vec3; cp1: Vec3; cp2: Vec3 }
  | { type: 'quadraticBezier'; to: Vec3; cp: Vec3 }

export interface PathComponent {
  segments: PathSegment[]
  closed?: boolean
  style: Style
}

export type TextAlign = 'left' | 'center' | 'right'

/**
 * How to obtain an embedding — never a raw vector. A phrase can be read in a diff,
 * reviewed, and edited by a correction event; a thousand floats can be none of those.
 * The vector is a build artifact (Design §2.7).
 */
export type EmbeddingDecl =
  | { phrase: string }
  | { inversion: { images: string[]; steps?: number; model: string } }

/**
 * A reference into `scene.embeddings`, not a value. The source holds a phrase; the vector is a
 * build artifact, and which encoder produces it is the interpreter's business (Design §2.7).
 */
export interface EmbeddingComponent {
  ref: string
}

export interface SkeletonComponent {
  bones: Array<{ id: string; parent?: string; bindTransform: Transform; length?: number }>
}

export interface SkinnedMeshComponent {
  skeletonId: EntityId
  boneWeights?: Array<{ vertexIndex: number; influences: Array<{ boneId: string; weight: number }> }>
  bone?: string
}

export type LightComponent =
  | { type: 'ambient'; color: Color; intensity: number }
  | { type: 'directional'; color: Color; intensity: number; direction?: Vec3 }
  | { type: 'point'; color: Color; intensity: number; range?: number; decay?: number }
  | { type: 'spot'; color: Color; intensity: number; range?: number; angle: number; penumbra?: number }

export interface RigidbodyComponent {
  mass: number
  linearDamping?: number
  angularDamping?: number
}

export type ColliderComponent =
  | { type: 'box'; size: Vec3 }
  | { type: 'sphere'; radius: number }
  | { type: 'capsule'; radius: number; height: number }
  | { type: 'mesh'; asset: string }

export type ConstraintComponent =
  | { type: 'lookAt'; targetId: EntityId; up?: Vec3 }
  | { type: 'followPath'; pathId: EntityId; offset?: number }
  | { type: 'ik'; chain: string[]; target: Vec3; pole?: Vec3 }

export type EntityRef =
  | EntityId
  | { id: EntityId }
  | { parentId: EntityId; index: string; templateId?: EntityId; anchor?: 'center' | 'top' | 'bottom' | 'left' | 'right' | 'origin'; offset?: Vec3 }

export interface LinkComponent {
  /**
   * The endpoints this link pins to other entities. Either may be omitted, which anchors only one end
   * and leaves the other wherever the shape's own geometry puts it — an arrow that points at a
   * target from nowhere in particular anchors `to` alone.
   */
  from?: EntityRef
  to?: EntityRef
  fromAnchor?: 'center' | 'top' | 'bottom' | 'left' | 'right' | 'origin'
  toAnchor?: 'center' | 'top' | 'bottom' | 'left' | 'right' | 'origin'
  fromOffset?: Vec3
  toOffset?: Vec3
}

export type ComponentMap = {
  circle?: Animatable<{ radius: number; style: Style }>
  rect?: Animatable<{ size: Vec2; cornerRadius?: number; style: Style }>
  polygon?: Animatable<{ points: Vec3[]; style: Style }>
  line?: Animatable<{ from: Vec3; to: Vec3; style: Style }>
  path?: Animatable<PathComponent>
  /**
   * `content` may contain newlines; each line is laid out below the last at `lineHeight` (a
   * multiple of `fontSize`, default 1.2).
   */
  text?: Animatable<{
    content: string
    fontSize: number
    align?: TextAlign
    fontFamily?: string
    fontWeight?: number | 'normal' | 'bold'
    lineHeight?: number
    style: Style
  }>
  box?: Animatable<{ size: Vec3; style: Style }>
  sphere?: Animatable<{ radius: number; style: Style }>
  cylinder?: Animatable<{ radius: number; height: number; style: Style }>
  cone?: Animatable<{ radius: number; height: number; style: Style }>
  torus?: Animatable<{ radius: number; tube: number; style: Style }>
  mesh?: Animatable<{ asset: string; style: Style }>
  embedding?: Animatable<EmbeddingComponent>
  motionEmbedding?: Animatable<EmbeddingComponent>
  skeleton?: Animatable<SkeletonComponent>
  skinnedMesh?: Animatable<SkinnedMeshComponent>
  light?: Animatable<LightComponent>
  rigidbody?: Animatable<RigidbodyComponent>
  collider?: Animatable<ColliderComponent>
  constraint?: Animatable<ConstraintComponent>
  link?: Animatable<LinkComponent>
  /**
   * Stamps copies of template entities at generated points (§3.6). Structural: `resolveScene`
   * expands it inline, and the stamped copies compose transforms from the entity that holds it.
   */
  arrangement?: Animatable<Arrangement>
  /**
   * The program that drives entities over time (§4.1). Consumed by `simulate`, not by the
   * structural walk — a behavior never changes what exists, only where it is.
   */
  behavior?: Animatable<BTNode>
  /** Subtree-wide fade, compounding down the tree. Continuous counterpart to `visible`. Default 1. */
  opacity?: Animatable<number>
  [customType: string]: Animatable<unknown> | undefined
}

export type InstanceOverride = {
  transform?: Transform
  enabled?: boolean
  locked?: boolean
  components?: ComponentMap
}

export type PointGenerator =
  | { type: 'grid'; countX: number; countY: number; spacingX: number; spacingY: number; start?: Vec3 }
  | { type: 'line'; count: number; step: Transform }
  | { type: 'radial'; count: number; radius: number; axis?: Vec3 }
  | { type: 'poisson'; count: number; minDist: number; seed: number; bounds?: { min: Vec3; max: Vec3 } }
  | { type: 'pathFollow'; pathId: EntityId; count: number; spacing: number }
  | { type: 'script'; language: 'typescript' | 'javascript'; code: string; entry?: string }

export type ArrangementOp =
  | { id: string; type: 'points'; generator: PointGenerator }
  | { id: string; type: 'instance'; templates: EntityId[]; points: string; overrides?: Record<string, InstanceOverride> }

export interface Arrangement {
  ops: ArrangementOp[]
  edges: Array<{ from: string; to: string }>
}

/**
 * What a tick returns. This is what makes the composites mean anything: a condition fails
 * when its predicate does not hold, an action fails when its target cannot be resolved or its
 * script throws, and everything else propagates (Design §2.8).
 */
export type BTStatus = 'running' | 'success' | 'failure'

export type BTNode = BTComposite | BTDecorator | BTCondition | BTAction | BTScript | BTForEach | BTCurve

/**
 * A keyframe track, as a leaf (§4.2). This is where all keyframed motion lives: `Animatable` is a
 * value slot with no timeline of its own, so "animate this property" is a node in the program
 * rather than a second, parallel way to express motion.
 *
 * `t` on each keyframe is LOCAL to this leaf — 0 is when the curve starts, not when the scene
 * does. That is what lets a curve compose under `sequence`, `repeat` and `loop`, and what keeps a
 * correction recorded against it valid when the surrounding tree is restructured. To pin a curve
 * to an absolute moment, wrap it in `{ type: 'condition', on: 'time', params: { at } }`.
 */
export interface BTCurve {
  type: 'curve'
  id?: string
  target: BTTarget
  /**
   * What to drive. Either a transform channel — `transform.position`, `transform.scale`,
   * `transform.rotation` — or a component path such as `components.rect.style.fill`, the same
   * addressing `component.setProp` uses.
   */
  property: string
  keyframes: Keyframe<unknown>[]
}

export type BTComposite =
  /** Runs children in order, stopping on the first failure; succeeds when all succeed. */
  | {
      type: 'sequence'
      id?: string
      children: BTNode[]
      speed?: number
      /**
       * Repeat a fixed number of times. Fully resolvable, so prefer this when the count is known.
       */
      repeat?: number
      /**
       * Repeat until the scene's declared `duration` is filled — the shape ambient motion wants
       * (a sun bobbing, a grid scrolling). Without a declared duration there is nothing to repeat
       * *to*, so one pass is scheduled and the loop is reported unresolved rather than guessed at.
       */
      loop?: boolean
    }
  /** Fallback: runs children in order until one does not fail. Fails only if all do. */
  | { type: 'selector'; id?: string; children: BTNode[] }
  /** `all` succeeds when every child does and fails if any does; `any` succeeds on the first success. */
  | { type: 'parallel'; id?: string; children: BTNode[]; policy?: 'all' | 'any' }

export type BTDecorator = {
  type: 'decorator'
  id?: string
  decorator: 'timeScale' | 'invert' | 'enabled' | 'locked' | 'motionStyle' | 'script'
  params: Record<string, unknown> // motionStyle: { style: careful|hurried|shaky, embedding }, timeScale: { scale }, visible/locked gating
  child: BTNode
}

export type BTCondition = {
  type: 'condition'
  id?: string
  on: 'contact' | 'collision' | 'proximity' | 'time' | 'always' | 'beat' | 'script'
  source?: EntityId[]
  threshold?: number
  beat?: number
  params?: Record<string, unknown>
  child?: BTNode
}

/**
 * Who an action moves.
 *
 * A bare id names an entity, or — when it names a template — every copy an instance op stamps from
 * it, which is what makes "all the rings rise" one action. The object form names ONE stamped copy,
 * the temporal counterpart of an instance `overrides` entry. Without it, space could correct a
 * single instance and time could not, so the most ordinary correction there is — "no, move *that*
 * one" — had no expression (Design §2.2, §2.8).
 */
export type BTTarget = EntityId | { templateId: EntityId; index: string }

/** Identifies a behavior-tree node. A separate namespace from EntityId (§4.6). */
export type BTNodeId = string

/** The composites, which are interchangeable: they differ in control flow, not in shape. */
export type BTCompositeType = BTComposite['type']

export type BTAction = {
  type: 'action'
  id?: string
  action: 'translate' | 'scale' | 'rotate' | 'setEnabled' | 'setLocked' | 'upsertComponent' | 'emitParticles' | 'script'
  target: BTTarget
  /**
   * Seconds. Reports `running` until it elapses; state changes such as setEnabled use 0.
   * Enclosing sequence `speed` and `timeScale` decorators scale it, which is what makes the
   * durations that simulation accumulates well-defined (Design §2.8).
   */
  duration: Seconds
  params: Record<string, unknown>
}

export type BTScript = {
  type: 'script'
  id?: string
  language: 'typescript' | 'javascript'
  code: string
  entry?: string
}

/**
 * Rows for a `forEach` to stamp over — the temporal counterpart of a `points` op.
 * A script source returns DATA, never actions, exactly as a `script` point generator returns
 * `Vec3[]` rather than finished entities (§2.2). That constraint is the whole point: data can be
 * inspected, indexed and corrected, whereas emitted actions are opaque output.
 */
export type BTEventSource =
  | { kind: 'rows'; rows: Array<Record<string, unknown>> }
  | { kind: 'script'; language: 'typescript' | 'javascript'; code: string; entry?: string }

/**
 * The temporal mirror of an `instance` op: one template subtree stamped once per row.
 *
 * A raw `script` leaf reaches the same schedule but fuses the generator and the motion into one
 * opaque blob, so the only edit surface is the source text. Splitting them keeps the promise in
 * §2.7 — structure and values stay draggable and assertable: retime the template once and every
 * row follows, or correct a single row through `overrides` and have it recorded against the
 * generator instead of rewriting the program.
 *
 * Row fields reach the template two ways: `"ring_${disk}"` interpolates into any string, and
 * `{ $: 'restY' }` in a value position is replaced by that field's value.
 */
export type BTForEach = {
  type: 'forEach'
  id?: string
  source: BTEventSource
  template: BTNode
  /** Row index (as a string key) → fields merged over that row before stamping. */
  overrides?: Record<string, Record<string, unknown>>
  /** `sequence` (default) lays rows end to end; `parallel` starts them together. */
  mode?: 'sequence' | 'parallel'
}

/**
 * One entity type, no discriminant. What an entity IS follows from what it HAS: an entity with an
 * `arrangement` component stamps copies, one with a `behavior` component drives things over time,
 * one with a drawable draws, one with none of those is a plain group. This is the entity-component
 * model the IR already used for drawables, applied the rest of the way — glTF distinguishes its
 * nodes the same way, by which of `mesh`/`camera`/`skin` is present.
 *
 * There used to be a `kind` field over a three-member union. It carried redundant state that could
 * disagree with the payload beside it, and it bought less than it looked: the dominant use was
 * `kind === 'group' || kind === 'arrangement' || kind === 'behavior'`, which enumerates every case
 * and so asks nothing at all.
 */
export interface Entity extends BaseEntity {
  children: Entity[]
}

export interface Scene {
  schemaVersion: string
  id: string
  space: '2d' | '3d'
  canvas: { width: number; height: number; background?: Color }
  /** Explicit total length; absent means it is emergent and simulation estimates it (Design §2.8). */
  duration?: Seconds
  /** Export frame rate. */
  fps?: number
  /** Named embedding declarations, referenced by name from entities (Design §2.7). */
  embeddings?: Record<string, EmbeddingDecl>
  camera: Camera
  root: Entity
  units?: string
  meta?: Record<string, unknown>
}

export type CorrectionEvent =
  | { type: 'entity.translate'; target: EntityId; from: Vec3; to: Vec3 }
  | { type: 'entity.scale'; target: EntityId; from: Vec3; to: Vec3 }
  | { type: 'entity.rotate'; target: EntityId; from: AxisAngle; to: AxisAngle }
  | { type: 'entity.setLocked'; target: EntityId; from: boolean; to: boolean }
  | { type: 'entity.setEnabled'; target: EntityId; from: boolean; to: boolean }
  | { type: 'component.upsert'; target: EntityId; componentType: string; from: unknown; to: unknown }
  | { type: 'component.remove'; target: EntityId; componentType: string }
  | { type: 'component.setProp'; target: EntityId; componentType: string; path: string; from: unknown; to: unknown }
  /** Sparse per-instance patch on an instance op. `op` selects which one; omit when the graph has a single instance op. */
  | { type: 'override.set'; target: EntityId; op?: string; index: string; from: InstanceOverride | undefined; to: InstanceOverride }
  | { type: 'override.remove'; target: EntityId; op?: string; index: string }
  | { type: 'entity.add'; parent: EntityId; entity: Entity; index: number }
  | { type: 'entity.remove'; target: EntityId }
  | { type: 'entity.reparent'; target: EntityId; newParent: EntityId; index: number; keepWorld?: boolean }
  /** Wraps `targets` in a new group under `parent`. The wrapper is identity, so world positions are preserved. */
  | { type: 'entity.group'; targets: EntityId[]; parent: EntityId; newId: EntityId; word?: string; index?: number }
  /** Splices a group's children into its parent and removes the group. */
  | { type: 'entity.ungroup'; target: EntityId }
  // Keyframes are addressed by the `curve` leaf that holds them, not by an entity property (§4.2).
  // `from`/`to` times are LOCAL to that leaf, which is what keeps a recorded correction valid when
  // the surrounding tree is restructured.
  | { type: 'keyframe.add'; target: BTNodeId; keyframe: Keyframe<unknown> }
  | { type: 'keyframe.move'; target: BTNodeId; index: number; from: Seconds; to: Seconds }
  | { type: 'keyframe.setValue'; target: BTNodeId; index: number; from: unknown; to: unknown }
  | { type: 'keyframe.setEasing'; target: BTNodeId; index: number; from: Easing; to: Easing }
  /**
   * Edits to the program represented by behavior-tree nodes rather than to baked values.
   *
   * `target` is a behavior-tree entity's `id`, not a scene entity's. Editing one action inside a
   * forEach TEMPLATE changes every row at once, which is the cheap-edit property made recordable.
   */
  | { type: 'behavior.setParams'; target: BTNodeId; from: Record<string, unknown>; to: Record<string, unknown> }
  | { type: 'behavior.setDuration'; target: BTNodeId; from: Seconds; to: Seconds }
  // Behavior-tree structure, mirroring the entity structural edits above because both are trees
  // of typed containers. Reordering within one parent is the same-parent case of reparentNode,
  // exactly as it is for entities.
  | { type: 'behavior.addNode'; parent: BTNodeId; node: BTNode; index: number }
  | { type: 'behavior.removeNode'; target: BTNodeId }
  | { type: 'behavior.reparentNode'; target: BTNodeId; newParent: BTNodeId; index: number }
  /**
   * Swap one composite for another — "do not stop on failure, fall back". This has no entity
   * counterpart, and it is the correction that records a fix to the *procedure* rather than to a
   * number, which is the kind this format exists to capture.
   */
  | { type: 'behavior.setType'; target: BTNodeId; from: BTCompositeType; to: BTCompositeType }
  /** Per-row correction on a forEach — the temporal counterpart of `override.set`. */
  | { type: 'forEach.setOverride'; target: string; index: string; from: Record<string, unknown> | undefined; to: Record<string, unknown> }
  | { type: 'forEach.removeOverride'; target: string; index: string }

export type EventSurface = 'chat' | 'inspector' | 'viewport' | 'outliner'

export interface EventEnvelope {
  event: CorrectionEvent
  /** Who authored it. */
  source: 'human' | 'agent'
  /** Through what. A typed number and a drag are the same event with different provenance. */
  surface?: EventSurface
  agent?: string
  timestamp: number
  sessionId: string
  sceneTime?: number
  /** Groups a multi-target or structural edit so it retracts as a unit (Overview §5.5). */
  transactionId?: string
}

export interface CorrectionPair {
  schemaVersion: string
  id: string
  prompt?: string
  before: Scene
  after: Scene
  events: EventEnvelope[]
  adapter?: { renderer: string; beforeCode: string; afterCode: string }
  provenance: { model?: string; createdAt: string; stage: 'pre-render' | 'post-render'; annotator?: string }
}
