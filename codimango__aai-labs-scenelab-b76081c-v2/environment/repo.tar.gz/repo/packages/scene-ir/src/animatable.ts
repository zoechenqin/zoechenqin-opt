/**
 * Resolving constant value slots (§4.3) and sampling the keyframe lists held by `curve` leaves
 * (§4.2).
 */
import type { Animatable, AxisAngle, Color, Easing, Keyframe, Seconds, Vec2, Vec3 } from './types'
import { axisAngleToQuat, lerpVec2, lerpVec3, quatToAxisAngle, slerp } from './math'
import { lerpColor } from './color'

export const constant = <T>(value: T): Animatable<T> => ({ kind: 'const', value })

function sampleCubicBezier(p: [number, number, number, number], x: number): number {
  const [x1, y1, x2, y2] = p
  const bez = (t: number, a: number, b: number): number => {
    const mt = 1 - t
    return 3 * mt * mt * t * a + 3 * mt * t * t * b + t * t * t
  }
  // Solve bez_x(t) = x for t via Newton-Raphson, then return bez_y(t).
  let t = x
  for (let i = 0; i < 8; i++) {
    const xEst = bez(t, x1, x2) - x
    const d = 3 * (1 - t) * (1 - t) * x1 + 6 * (1 - t) * t * (x2 - x1) + 3 * t * t * (1 - x2)
    if (Math.abs(d) < 1e-6) break
    t -= xEst / d
  }
  t = Math.min(1, Math.max(0, t))
  return bez(t, y1, y2)
}

export function easeU(easing: Easing, u: number): number {
  if (u <= 0) return 0
  if (u >= 1) return 1
  if (typeof easing === 'object') return sampleCubicBezier(easing.cubicBezier, u)
  switch (easing) {
    case 'linear':
      return u
    case 'easeIn':
      return u * u
    case 'easeOut':
      return 1 - (1 - u) * (1 - u)
    case 'easeInOut':
      return u < 0.5 ? 2 * u * u : 1 - ((-2 * u + 2) * (-2 * u + 2)) / 2
  }
}

/**
 * Collapse an `Animatable<T>` to a concrete value. Value slots hold no timeline (§4.3); `t` and
 * `lerp` remain part of the shared renderer-facing resolution interface.
 */
export function resolve<T>(value: Animatable<T>, t: Seconds, _lerp: (a: T, b: T, u: number) => T): T {
  return value.value
}

/**
 * Sample an ordered keyframe list at a time in the list's OWN timebase. A curve's keyframes are
 * local to its leaf (§4.2), so the caller converts from scene time before calling. Outside the
 * span the endpoints hold — a curve that has finished keeps its final value rather than snapping.
 */
export function sampleKeyframesWith<T>(
  keyframes: Array<Keyframe<T>>,
  localT: Seconds,
  lerp: (a: T, b: T, u: number) => T,
): T {
  const n = keyframes.length
  if (n === 0) throw new Error('scene-ir: curve has no keyframes')
  const first = keyframes[0]!
  if (n === 1 || localT <= first.t) return first.value
  const last = keyframes[n - 1]!
  if (localT >= last.t) return last.value
  for (let i = 0; i < n - 1; i++) {
    const a = keyframes[i]!
    const b = keyframes[i + 1]!
    if (localT >= a.t && localT <= b.t) {
      const span = b.t - a.t
      const raw = span === 0 ? 0 : (localT - a.t) / span
      return lerp(a.value, b.value, easeU(a.easing ?? 'linear', raw))
    }
  }
  return last.value
}

/**
 * Interpolate two values of unknown type by their shape. A `curve` leaf (§4.2) drives an arbitrary
 * property path, so the value could be a number, a Vec3, a Color, an orientation or something with
 * no meaningful midpoint — and the leaf declares a path, not a type. Anything unrecognised steps
 * rather than blends: holding `a` until the segment completes is wrong-looking but honest, where
 * inventing a blend for, say, a string would be neither.
 */
export function lerpAuto(a: unknown, b: unknown, u: number): unknown {
  if (typeof a === 'number' && typeof b === 'number') return a + (b - a) * u
  if (Array.isArray(a) && Array.isArray(b)) return a.map((x, i) => lerpAuto(x, b[i] ?? x, u))
  if (typeof a === 'object' && a !== null && typeof b === 'object' && b !== null) {
    const ao = a as Record<string, unknown>
    const bo = b as Record<string, unknown>
    if (isAxisAngleLike(ao) && isAxisAngleLike(bo)) return lerpAxisAngle(a as AxisAngle, b as AxisAngle, u)
    // Componentwise on the shared numeric keys — covers Vec2/Vec3/Color without naming them.
    const out: Record<string, unknown> = { ...bo }
    let blended = false
    for (const k of Object.keys(ao)) {
      const av = ao[k]
      const bv = bo[k]
      if (typeof av === 'number' && typeof bv === 'number') {
        out[k] = av + (bv - av) * u
        blended = true
      } else if (av !== undefined && bv !== undefined) {
        out[k] = lerpAuto(av, bv, u)
      }
    }
    return blended || Object.keys(ao).length === 0 ? out : u >= 1 ? b : a
  }
  return u >= 1 ? b : a
}

const isAxisAngleLike = (v: Record<string, unknown>): boolean =>
  typeof v['angle'] === 'number' && typeof v['axis'] === 'object' && v['axis'] !== null

/**
 * Sample a keyframe list at a time expressed in the list's OWN timebase. A curve's keyframes are
 * local to its leaf (§4.2), so the caller converts from scene time before calling.
 */
export function sampleKeyframes(keyframes: Array<Keyframe<unknown>>, localT: Seconds): unknown {
  return sampleKeyframesWith(keyframes, localT, lerpAuto)
}

/** End of a keyframe list in its own timebase — i.e. how long the curve runs. */
export function keyframeSpan(keyframes: Array<Keyframe<unknown>>): Seconds {
  return keyframes.length === 0 ? 0 : Math.max(...keyframes.map((k) => k.t))
}

const lerpNumber = (a: number, b: number, u: number): number => a + (b - a) * u
const lerpVec3Array = (a: Vec3[], b: Vec3[], u: number): Vec3[] =>
  a.map((p, i) => lerpVec3(p, b[i] ?? p, u))
const lerpAxisAngle = (a: AxisAngle, b: AxisAngle, u: number): AxisAngle =>
  quatToAxisAngle(slerp(axisAngleToQuat(a), axisAngleToQuat(b), u))

export const resolveNumber = (v: Animatable<number>, t: Seconds): number => resolve(v, t, lerpNumber)
export const resolveVec2 = (v: Animatable<Vec2>, t: Seconds): Vec2 => resolve(v, t, lerpVec2)
export const resolveVec3 = (v: Animatable<Vec3>, t: Seconds): Vec3 => resolve(v, t, lerpVec3)
export const resolvePoints = (v: Animatable<Vec3[]>, t: Seconds): Vec3[] => resolve(v, t, lerpVec3Array)
export const resolveColor = (v: Animatable<Color>, t: Seconds): Color => resolve(v, t, lerpColor)
export const resolveAxisAngle = (v: Animatable<AxisAngle>, t: Seconds): AxisAngle =>
  resolve(v, t, lerpAxisAngle)
