
import { describe, it, expect } from 'vitest'
import { constant } from './animatable'
import { identityTransform } from './builders'
import type { Scene } from './types'
import { keyframeTimes, sceneTimeline } from './timeline'

const base = (children: Scene['root']['children'], overrides?: Partial<Scene>): Scene => ({
  schemaVersion: '0.1.0',
  id: 's',
  space: '2d',
  canvas: { width: 1920, height: 1080 },
  ...overrides,
  camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
  root: { id: 'root', word: 'scene', transform: identityTransform(), children } as any,
})

const dot = (id: string) => ({
  id,
  word: 'dot',
  transform: identityTransform(),
  components: { circle: constant({ radius: 10, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) } as any,
  children: [],
})

/**
 * Keyframes live in curve leaves (§4.2). The curves sit under a `parallel`, so each starts at
 * scene 0 and its local times are also its global ones — which is what keeps these expectations
 * about tick positions readable.
 */
const motion = (specs: Array<[string, number[]]>) => ({
  id: 'motion',
  word: 'motion',
  transform: identityTransform(),
  children: [],
  components: { behavior: constant({
    type: 'parallel' as const,
    id: 'motion.root',
    children: specs
      .filter(([, times]) => times.length > 0)
      .map(([id, times]) => ({
        type: 'curve' as const,
        id: `${id}.move`,
        target: id,
        property: 'transform.position',
        keyframes: times.map((t) => ({ t, value: { x: t * 10, y: 0, z: 0 } })),
      })),
  }) },
})

/** A scene whose entities are driven by curves, given `[id, keyframeTimes]` pairs. */
const moving = (specs: Array<[string, number[]]>, overrides?: Partial<Scene>): Scene =>
  base([motion(specs) as never, ...specs.map(([id]) => dot(id) as never)], overrides)

describe('sceneTimeline', () => {
  it('static scene: duration 0, only t=0, default 30 fps', () => {
    const tl = sceneTimeline(moving([['a', []]]))
    expect(tl.keyframeTimes).toEqual([0])
    expect(tl.duration).toBe(0)
    expect(tl.fps).toBe(30)
  })

  it('collects + sorts + dedupes keyframe times across entities', () => {
    const s = moving([['a', [0, 2]], ['b', [1, 2]]])
    expect(keyframeTimes(s)).toEqual([0, 1, 2])
  })

  it('duration falls back to last keyframe when scene.duration unset', () => {
    expect(sceneTimeline(moving([['a', [0, 1.5]]])).duration).toBe(1.5)
  })

  it('honors explicit scene.duration and fps', () => {
    const tl = sceneTimeline(moving([['a', [0, 1]]], { duration: 5, fps: 60 }))
    expect(tl.duration).toBe(5)
    expect(tl.fps).toBe(60)
  })
})
