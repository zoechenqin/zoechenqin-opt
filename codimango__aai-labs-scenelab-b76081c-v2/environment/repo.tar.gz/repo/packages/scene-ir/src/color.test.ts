import { describe, it, expect } from 'vitest'
import { linearToOklab, lerpColor, oklabToLinear, srgbToLinear } from './color'
import type { Color } from './types'

const close = (a: number, b: number, eps = 1e-6): boolean => Math.abs(a - b) < eps

describe('color', () => {
  it('sRGB↔linear endpoints', () => {
    expect(close(srgbToLinear(0), 0)).toBe(true)
    expect(close(srgbToLinear(1), 1)).toBe(true)
  })

  it('linear→OKLab→linear round-trips', () => {
    const lin: [number, number, number] = [0.3, 0.6, 0.1]
    const back = oklabToLinear(linearToOklab(lin))
    expect(close(back[0], lin[0])).toBe(true)
    expect(close(back[1], lin[1])).toBe(true)
    expect(close(back[2], lin[2])).toBe(true)
  })

  it('lerpColor hits endpoints and interpolates alpha linearly', () => {
    const a: Color = { r: 1, g: 0, b: 0, a: 1 }
    const b: Color = { r: 0, g: 0, b: 1, a: 0 }
    const at0 = lerpColor(a, b, 0)
    const at1 = lerpColor(a, b, 1)
    expect(close(at0.r, 1, 1e-4) && close(at0.a, 1)).toBe(true)
    expect(close(at1.b, 1, 1e-4) && close(at1.a, 0)).toBe(true)
    expect(close(lerpColor(a, b, 0.5).a, 0.5)).toBe(true)
  })
})
