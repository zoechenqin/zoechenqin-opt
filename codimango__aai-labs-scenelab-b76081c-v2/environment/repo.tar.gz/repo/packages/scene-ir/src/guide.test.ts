import { describe, it, expect } from 'vitest'
import { readFileSync } from 'node:fs'
import { IR_GUIDE, IR_RULES } from './guide'

const schemaSrc = readFileSync(new URL('./schema.ts', import.meta.url), 'utf-8')

/**
 * Every `type: z.literal('x')` inside the BT union — i.e. every node kind a tree may contain.
 * Scoped to zBTNode on purpose: the same pattern appears in path segments (`cubicBezier`) and
 * projections (`orthographic`), which are not behavior-tree nodes and have no business here.
 */
const btUnionSrc = schemaSrc.slice(
  schemaSrc.indexOf('const zBTNode'),
  schemaSrc.indexOf('const zEntity'),
)
const btNodeTypes = [...btUnionSrc.matchAll(/type:\s*z\.literal\('([a-zA-Z]+)'\)/g)].map((m) => m[1]!)
/**
 * The structural components — the two that change what a scene DOES. Entities have no `kind`
 * field any more (types.ts), so what a model must be told is which components carry meaning.
 */
const structuralComponents = ['arrangement', 'behavior']

describe('IR_GUIDE covers the schema', () => {
  it('found the schema literals to check against', () => {
    expect(btNodeTypes.length).toBeGreaterThan(5)
  })

  // The drift check this module exists for: adding a node type to the schema without telling a
  // model about it should be a red build, not something to remember. Two surfaces already drifted
  // by hand — one kept teaching a removed value shape for a week after the parser rejected it.
  it.each([...new Set(btNodeTypes)])('mentions the %s node type', (t) => {
    expect(IR_GUIDE).toContain(t)
  })

  it.each(structuralComponents)('explains the %s component', (c) => {
    expect(IR_GUIDE).toContain(`"${c}" component`)
  })

  // `kind` was removed; teaching it would send a model to a field the parser ignores.
  it('does not teach an entity "kind" field', () => {
    expect(IR_GUIDE).toContain('no "kind" field')
    expect(IR_GUIDE).not.toMatch(/kind"? ?: ?"?(group|arrangement|behavior)/)
  })
})

describe('IR_GUIDE states the rules that fail silently when broken', () => {
  it('says a value has one shape and keyframes are rejected in one', () => {
    expect(IR_GUIDE).toContain('There is no "track" variant')
    expect(IR_GUIDE).toContain('{"kind":"const","value":V}')
  })

  it('says keyframe times are local, and warns about the double-delay it invites', () => {
    expect(IR_GUIDE).toContain('KEYFRAME TIMES ARE LOCAL TO THE CURVE')
    expect(IR_GUIDE).toMatch(/delays it twice|that delays it twice/)
  })

  it('gives the absolute-time escape hatch', () => {
    expect(IR_GUIDE).toContain('"on":"time"')
  })

  // A 0 -> 2pi pair slerps to no rotation because quat(2pi) is antipodal to quat(0).
  it('warns about the full-turn rotation trap', () => {
    expect(IR_GUIDE).toMatch(/full turn/i)
    expect(IR_GUIDE).toContain('NO rotation at all')
  })

  it('requires a behavior component for a motion request', () => {
    expect(IR_GUIDE).toContain('MUST carry a "behavior" component')
  })
})

describe('IR_RULES is spliceable', () => {
  it('is a non-empty list of single lines', () => {
    expect(IR_RULES.length).toBeGreaterThan(20)
    expect(IR_RULES.every((l) => !l.includes('\n'))).toBe(true)
  })

  it('joins to exactly IR_GUIDE', () => {
    expect(IR_RULES.join('\n')).toBe(IR_GUIDE)
  })
})

/**
 * Every model-facing surface must splice the canonical rules rather than restate them.
 */
const PROMPTING_SURFACES = [
  '../../agent/src/prompt.ts',
  '../../../skills/batch-compare/batch-compare.ts',
]

describe('every prompting surface uses the canonical rules', () => {
  it.each(PROMPTING_SURFACES)('%s splices IR_RULES or IR_GUIDE', (rel) => {
    const src = readFileSync(new URL(rel, import.meta.url), 'utf-8')
    expect(src).toMatch(/IR_RULES|IR_GUIDE/)
  })

  it.each(PROMPTING_SURFACES)('%s does not define keyframes in value slots', (rel) => {
    const src = readFileSync(new URL(rel, import.meta.url), 'utf-8')
    expect(src).not.toMatch(/"kind"\s*:\s*\\?"track/)
  })
})
