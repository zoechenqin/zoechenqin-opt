import { describe, it, expect } from 'vitest'
import {
  assertAcyclic,
  collectRefEdges,
  constant,
  identityTransform,
  resolveScene,
  sampleArrowToBoard,
  sampleCharacter,
  sampleHanoiBehaviorTree,
  sampleArrangement,
  validateSceneGraph,
} from './index'
import type { Entity, Scene, ArrangementOp } from './index'

const rect = () =>
  ({ rect: constant({ size: { x: 1, y: 1 }, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) }) as never

const group = (id: string, children: Entity[] = [], extra: Record<string, unknown> = {}): Entity =>
  ({ id, word: id, transform: identityTransform(), children, ...extra }) as Entity

const arrangementEntity = (id: string, ops: ArrangementOp[], children: Entity[] = [], edges: Array<{ from: string; to: string }> = []): Entity =>
  ({
    id,
    word: id,
    transform: identityTransform(),
    children,
    components: { arrangement: constant({ ops, edges }) },
  }) as Entity

const sceneOf = (root: Entity): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'graph_test',
    space: '2d',
    canvas: { width: 100, height: 100 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root,
  }) as Scene

const points = (id: string, count = 2): ArrangementOp => ({
  id,
  type: 'points',
  generator: { type: 'line', count, step: identityTransform() },
})

const instance = (id: string, templates: string[], pts: string): ArrangementOp => ({ id, type: 'instance', templates, points: pts })

describe('collectRefEdges', () => {
  it('records containment and instancing as distinct edge kinds', () => {
    const scene = sceneOf(
      group('root', [
        group('tpl', [], { template: true, components: rect() }),
        arrangementEntity('scatter', [points('p'), instance('i', ['tpl'], 'p')]),
      ]),
    )
    const edges = collectRefEdges(scene)
    expect(edges).toContainEqual({ from: 'root', to: 'tpl', kind: 'contains', via: 'children' })
    expect(edges).toContainEqual({ from: 'scatter', to: 'tpl', kind: 'instantiates', via: 'arrangement.ops[i].templates' })
  })

  it('finds references buried in behavior trees', () => {
    const edges = collectRefEdges(sampleHanoiBehaviorTree())
    const btEdges = edges.filter((e) => e.via.startsWith('components.behavior'))
    expect(btEdges.length).toBeGreaterThan(0)
    expect(btEdges.every((e) => e.kind === 'constrains')).toBe(true)
  })
})

describe('validateSceneGraph', () => {
  it('passes every shipped fixture', () => {
    for (const scene of [sampleArrangement(), sampleCharacter(), sampleArrowToBoard(), sampleHanoiBehaviorTree()]) {
      expect(validateSceneGraph(scene)).toEqual([])
    }
  })

  it('records an edge for whichever link ends are anchored', () => {
    const linkEdges = collectRefEdges(sampleArrowToBoard()).filter((e) => e.via.startsWith('components.link'))
    // sampleArrowToBoard pins only its head, so the addressed `to` contributes both its stamping
    // parent and its template, and the omitted `from` contributes nothing.
    expect(linkEdges.map((e) => e.to).sort()).toEqual(['board', 'square_template'])
    expect(linkEdges.every((e) => e.via === 'components.link.to')).toBe(true)
  })

  it('flags a arrangement that instances itself', () => {
    const scene = sceneOf(group('root', [arrangementEntity('loop', [points('p'), instance('i', ['loop'], 'p')])]))
    const errors = validateSceneGraph(scene).filter((d) => d.level === 'error')
    expect(errors).toHaveLength(1)
    expect(errors[0]!.code).toBe('expansion-cycle')
    expect(errors[0]!.message).toContain('"loop"')
    expect(() => assertAcyclic(scene)).toThrow(/cyclic instance expansion/)
  })

  it('flags a cycle that spans containment and instancing', () => {
    // a contains inner_graph, which stamps b; b contains another graph, which stamps a.
    const scene = sceneOf(
      group('root', [
        group('a', [arrangementEntity('a_graph', [points('p'), instance('i', ['b'], 'p')])], { template: true }),
        group('b', [arrangementEntity('b_graph', [points('p'), instance('i', ['a'], 'p')])], { template: true }),
        arrangementEntity('entry', [points('p'), instance('i', ['a'], 'p')]),
      ]),
    )
    const errors = validateSceneGraph(scene).filter((d) => d.level === 'error')
    expect(errors).toHaveLength(1)
    expect(errors[0]!.code).toBe('expansion-cycle')
    expect(errors[0]!.message).toMatch(/contains|instantiates/)
  })

  it('warns but does not fail on mutually-aimed constraints', () => {
    const lookAt = (targetId: string) => ({ constraint: constant({ type: 'lookAt', targetId }) }) as never
    const scene = sceneOf(
      group('root', [group('a', [], { components: lookAt('b') }), group('b', [], { components: lookAt('a') })]),
    )
    const diags = validateSceneGraph(scene)
    expect(diags.filter((d) => d.level === 'error')).toEqual([])
    expect(diags.filter((d) => d.code === 'constraint-cycle')).toHaveLength(1)
    expect(() => assertAcyclic(scene)).not.toThrow()
  })

  it('does not treat a child aiming at its own parent as circular', () => {
    const scene = sceneOf(
      group('root', [
        group('parent', [
          group('child', [], { components: { constraint: constant({ type: 'lookAt', targetId: 'parent' }) } as never }),
        ]),
      ]),
    )
    expect(validateSceneGraph(scene)).toEqual([])
  })

  it('warns when an instance op names a template that does not exist', () => {
    const scene = sceneOf(group('root', [arrangementEntity('scatter', [points('p'), instance('i', ['nope'], 'p')])]))
    const diags = validateSceneGraph(scene)
    expect(diags.filter((d) => d.level === 'error')).toEqual([])
    const dangling = diags.filter((d) => d.code === 'dangling-ref')
    expect(dangling).toHaveLength(1)
    expect(dangling[0]!.message).toContain('silently stamp nothing')
  })

  it('flags a cycle in the op-level dataflow graph', () => {
    const scene = sceneOf(
      group('root', [
        arrangementEntity('scatter', [points('p'), instance('i', [], 'p')], [], [
          { from: 'p', to: 'i' },
          { from: 'i', to: 'p' },
        ]),
      ]),
    )
    const errors = validateSceneGraph(scene).filter((d) => d.level === 'error')
    expect(errors).toHaveLength(1)
    expect(errors[0]!.code).toBe('op-cycle')
  })
})

describe('resolveScene expansion guard', () => {
  it('throws instead of recursing forever on a self-instancing graph', () => {
    const scene = sceneOf(
      group('root', [
        arrangementEntity('loop', [points('p'), instance('i', ['loop'], 'p')], [group('leaf', [], { components: rect() })]),
      ]),
    )
    expect(() => resolveScene(scene, 0)).toThrow(/cyclic instance expansion/)
  })

  it('throws on a two-entity template cycle', () => {
    const scene = sceneOf(
      group('root', [
        group('a', [arrangementEntity('a_graph', [points('p'), instance('i', ['b'], 'p')])], { template: true }),
        group('b', [arrangementEntity('b_graph', [points('p'), instance('i', ['a'], 'p')])], { template: true }),
        arrangementEntity('entry', [points('p'), instance('i', ['a'], 'p')]),
      ]),
    )
    expect(() => resolveScene(scene, 0)).toThrow(/cyclic instance expansion/)
  })

  it('still resolves legitimate nested instancing', () => {
    // outer stamps `row`; `row` itself contains a graph that stamps `cell`. Deep, but acyclic.
    const scene = sceneOf(
      group('root', [
        group('cell', [], { template: true, components: rect() }),
        group('row', [arrangementEntity('row_graph', [points('rp', 3), instance('ri', ['cell'], 'rp')])], { template: true }),
        arrangementEntity('outer', [points('op', 2), instance('oi', ['row'], 'op')]),
      ]),
    )
    expect(validateSceneGraph(scene)).toEqual([])
    expect(resolveScene(scene, 0).primitives).toHaveLength(6)
  })
})
