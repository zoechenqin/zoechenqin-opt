import { describe, it, expect } from 'vitest'
import { applyEvent, constant, emptyScene, identityTransform, parseScene, resolveScene, SCHEMA_VERSION } from './index'
import type { CorrectionEvent } from './index'

describe('scene-ir', () => {
  it('exposes the schema version', () => {
    expect(SCHEMA_VERSION).toBe('0.1.0')
  })
})

describe('emptyScene', () => {
  it('is a valid scene with nothing in it', () => {
    const s = emptyScene()
    expect(() => parseScene(JSON.parse(JSON.stringify(s)))).not.toThrow()
    expect(s.root.children).toHaveLength(0)
    expect(resolveScene(s, 0).primitives).toHaveLength(0)
  })

  it('matches the ortho camera to the canvas in 2D', () => {
    const s = emptyScene({ height: 720 })
    expect(s.camera.projection.type).toBe('orthographic')
    expect(resolveScene(s, 0).camera.projection).toMatchObject({ height: 720 })
  })

  it('gives 3D a perspective camera set back from the origin', () => {
    const s = emptyScene({ space: '3d' })
    expect(s.camera.projection.type).toBe('perspective')
    expect(resolveScene(s, 0).camera.worldMatrix[14]).toBeGreaterThan(0)
  })

  it('accepts entities added to it', () => {
    // The point of starting empty: build it up through correction events.
    const added = applyEvent(emptyScene(), {
      type: 'entity.add',
      parent: 'root',
      index: 0,
      entity: {
        id: 'dot', word: 'dot', transform: identityTransform(), children: [],
        components: { circle: constant({ radius: 5, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) },
      },
    } as CorrectionEvent)
    expect(resolveScene(added, 0).primitives.map((p) => p.id)).toEqual(['dot'])
  })
})
