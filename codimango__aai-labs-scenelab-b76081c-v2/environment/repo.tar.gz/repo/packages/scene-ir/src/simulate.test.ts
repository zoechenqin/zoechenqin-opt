import { describe, it, expect } from 'vitest'
import { constant, identityTransform, keyframeTimes, sampleHanoiBehaviorTree, sceneTimeline, simulate } from './index'
import type { BTNode, Scene } from './index'

const sceneWith = (behavior: BTNode, duration?: number): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'sim',
    space: '3d',
    canvas: { width: 100, height: 100 },
    ...(duration !== undefined ? { duration } : {}),
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: { kind: 'const', value: 10 } } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        { id: 'bt', word: 'timeline', transform: identityTransform(), children: [], components: { behavior: constant(behavior) } },
      ],
    },
  }) as unknown as Scene

const act = (id: string, duration: number): BTNode => ({
  type: 'action',
  id,
  action: 'translate',
  target: 'thing',
  duration,
  params: {},
})

describe('simulate (§2.8)', () => {
  it('lays a sequence out end to end', () => {
    const sim = simulate(sceneWith({ type: 'sequence', children: [act('a', 1), act('b', 2)] }))
    expect(sim.schedule.map((e) => [e.btId, e.start, e.duration])).toEqual([
      ['a', 0, 1],
      ['b', 1, 2],
    ])
    expect(sim.duration).toBe(3)
    expect(sim.unresolved).toEqual([])
  })

  it('starts parallel children together and ends with the longest', () => {
    const sim = simulate(sceneWith({ type: 'parallel', children: [act('a', 1), act('b', 3)] }))
    expect(sim.schedule.every((e) => e.start === 0)).toBe(true)
    expect(sim.duration).toBe(3)
  })

  it('an `any` parallel ends with the first child to finish', () => {
    const sim = simulate(sceneWith({ type: 'parallel', policy: 'any', children: [act('a', 1), act('b', 3)] }))
    expect(sim.duration).toBe(1)
  })

  it('sequence speed and timeScale scale durations', () => {
    const fast = simulate(sceneWith({ type: 'sequence', speed: 2, children: [act('a', 4)] }))
    expect(fast.duration).toBe(2)
    const slow = simulate(
      sceneWith({ type: 'decorator', decorator: 'timeScale', params: { scale: 0.5 }, child: act('a', 4) }),
    )
    expect(slow.duration).toBe(8)
  })

  it('reports an emergent condition instead of inventing a time', () => {
    const sim = simulate(
      sceneWith({ type: 'condition', id: 'onContact', on: 'contact', source: ['hand', 'table'], child: act('fx', 1) }),
    )
    expect(sim.unresolved).toEqual([
      { btId: 'onContact', reason: 'condition', detail: '"contact" is emergent and cannot be resolved by a static walk' },
    ])
    // the gated work is still scheduled, so the duration is a lower bound rather than nothing
    expect(sim.duration).toBe(1)
  })

  it('runs a script leaf and schedules what it emits', () => {
    // Script leaves execute during simulation (§2.8); see script.test.ts for the sandbox itself.
    const sim = simulate(
      sceneWith({
        type: 'script',
        id: 'hanoi',
        language: 'typescript',
        code: `function* main() { yield { action: 'translate', target: 'thing', duration: 2, params: { to: { x: 1, y: 0, z: 0 } } } }`,
      }),
    )
    expect(sim.schedule).toHaveLength(1)
    expect(sim.duration).toBe(2)
    expect(sim.unresolved).toEqual([])
  })

  it('reports a script it cannot run rather than dropping it silently', () => {
    const sim = simulate(sceneWith({ type: 'script', id: 'hanoi', language: 'typescript', code: 'function* f() {}' }))
    expect(sim.unresolved[0]?.reason).toBe('script')
    expect(sim.schedule).toEqual([])
  })

  it('repeats a looping sequence up to the declared scene duration', () => {
    // Ambient motion (a sun bobbing, a grid scrolling) wants to fill the clip; scheduling one
    // pass leaves the remainder frozen.
    const sim = simulate(sceneWith({ type: 'sequence', id: 'bob', loop: true, children: [act('step', 1)] }, 5))
    expect(sim.schedule).toHaveLength(5)
    expect(sim.unresolved).toEqual([])
  })

  it('reports a loop it cannot bound rather than guessing', () => {
    // With no declared duration there is nothing to repeat *to*.
    const sim = simulate(sceneWith({ type: 'sequence', id: 'walk', loop: true, children: [act('step', 1)] }))
    expect(sim.unresolved[0]?.reason).toBe('loop')
    expect(sim.duration).toBe(1)
  })

  it('honours an explicit repeat count with no ambiguity', () => {
    const sim = simulate(sceneWith({ type: 'sequence', id: 'thrice', repeat: 3, children: [act('step', 2)] }))
    expect(sim.schedule.map((e) => e.start)).toEqual([0, 2, 4])
    expect(sim.duration).toBe(6)
    expect(sim.unresolved).toEqual([])
  })

  it('does not spin on a zero-length loop body', () => {
    const sim = simulate(sceneWith({ type: 'sequence', id: 'empty', loop: true, children: [] }, 10))
    expect(sim.unresolved.filter((u) => /exceeded/.test(u.detail))).toEqual([])
  })

  it('an explicit scene duration overrides the estimate', () => {
    const sim = simulate(sceneWith({ type: 'sequence', children: [act('a', 1)] }, 9))
    expect(sim.duration).toBe(9)
  })

  it('moments are the entry boundaries, including 0', () => {
    const sim = simulate(sceneWith({ type: 'sequence', children: [act('a', 1), act('b', 2)] }))
    expect(sim.moments).toEqual([0, 1, 3])
  })

  it('walks a real fixture', () => {
    const sim = simulate(sampleHanoiBehaviorTree())
    expect(sim.schedule.length).toBeGreaterThan(0)
    expect(sim.duration).toBeGreaterThan(0)
    // every entry names an entity and sits inside the reported span
    for (const e of sim.schedule) {
      expect(e.target).toBeTruthy()
      expect(e.start).toBeGreaterThanOrEqual(0)
    }
  })

  it('behaviour-derived moments reach the timeline', () => {
    const scene = sceneWith({ type: 'sequence', children: [act('a', 1), act('b', 2)] })
    // this scene has no keyframes at all; its ticks and length come from the behaviour tree
    expect(keyframeTimes(scene)).toEqual([0, 1, 3])
    expect(sceneTimeline(scene).duration).toBe(3)
  })
})
