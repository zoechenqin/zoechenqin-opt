/**
 * Synthesis (Design §2.7): `(word, embedding) → style, and possibly structure`.
 *
 * An embedding is a description — a request a renderer may legitimately ignore — so until it is
 * synthesized there is nothing in the scene to drag, assert on or correct, which is why §4.3 says
 * never to grade one. This is the machinery around that boundary; the interpreter itself is not
 * built, and `setSynthesisProvider` is the seam a real one plugs into. With none registered,
 * `synthesize` changes nothing and reports it, rather than letting a description pass for a
 * specification.
 *
 * Four properties from §2.7 that the implementation preserves: synthesis is EXPLICIT (never part
 * of resolve, since it commits one interpreter's answer), REPRODUCIBLE (pinned by provider,
 * version and seed, keyed by content hash), CORRECTABLE (output is ordinary entities marked
 * `synthesized`), and REVERSIBLE (the description stays attached, so it can be re-synthesized).
 */
import type { EmbeddingDecl, Entity, EntityId, Scene, Style } from './types'

export interface SynthesisProvenance {
  /** The `scene.embeddings` key this content came from. */
  from: string
  provider: string
  version: string
  seed: number
  /** Of (word, ref, declaration, provider, version, seed) — the cache key, and the pin. */
  hash: string
}

export interface SynthesisRequest {
  entityId: EntityId
  /** The entity's `word` — synthesis is `(word, embedding) → …`, so the noun matters. */
  word: string
  ref: string
  decl: EmbeddingDecl
  entity: Entity
  seed: number
}

export interface SynthesisResponse {
  /** Structure to place under the entity. */
  children?: Entity[]
  /** Style to apply to the entity itself. */
  style?: Style
}

export interface SynthesisProvider {
  name: string
  version: string
  /** Return null to decline — an interpreter with no opinion is not an error. */
  synthesize(req: SynthesisRequest): SynthesisResponse | null
}

let provider: SynthesisProvider | null = null

/** Install the interpreter. Pass null to remove it. */
export function setSynthesisProvider(p: SynthesisProvider | null): void {
  provider = p
}

export function currentSynthesisProvider(): SynthesisProvider | null {
  return provider
}

/** FNV-1a. Deterministic and dependency-free, which matters more here than collision resistance. */
export function contentHash(input: string): string {
  let h = 0x811c9dc5
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i)
    h = Math.imul(h, 0x01000193) >>> 0
  }
  return h.toString(16).padStart(8, '0')
}

export interface SynthesisSkip {
  entityId: EntityId
  ref: string
  reason: 'no-provider' | 'declined' | 'undeclared'
}

export interface SynthesisResult {
  scene: Scene
  synthesized: number
  /** Descriptions still unsynthesized, and why. These have nothing to grade or correct yet. */
  skipped: SynthesisSkip[]
}

const DRAWABLES = new Set(['circle', 'rect', 'polygon', 'line', 'path', 'text', 'box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh'])

/**
 * Merge synthesized style into an entity's drawable. Synthesis is `(word, embedding) -> style, and
 * possibly structure`, so style is its primary output; an entity with nothing to draw has nowhere to
 * put it, and the caller applies it to the generated children instead.
 */
function withStyle(entity: Entity, style: Style): Entity {
  const comps = entity.components
  if (!comps) return entity
  const key = Object.keys(comps).find((k) => DRAWABLES.has(k))
  if (key === undefined) return entity
  const anim = comps[key] as { kind?: string; value?: { style?: Style } } | undefined
  if (!anim || anim.kind !== 'const' || !anim.value) return entity
  return {
    ...entity,
    components: { ...comps, [key]: { kind: 'const', value: { ...anim.value, style: { ...anim.value.style, ...style } } } },
  } as Entity
}

function hasDrawable(entity: Entity): boolean {
  return Object.keys(entity.components ?? {}).some((k) => DRAWABLES.has(k))
}

function embeddingRef(entity: Entity): string | undefined {
  const comp = entity.components?.['embedding'] as { kind?: string; value?: { ref?: string } } | undefined
  if (!comp || comp.kind !== 'const') return undefined
  return comp.value?.ref
}

/**
 * Write synthesis into the scene: the correctable destination of the two the design names.
 * Entities that already carry provenance are left alone, so running it twice is a no-op.
 */
export function synthesize(scene: Scene, opts: { seed?: number } = {}): SynthesisResult {
  const seed = opts.seed ?? 0
  const skipped: SynthesisSkip[] = []
  let synthesized = 0

  const visit = (entity: Entity): Entity => {
    const withChildren = { ...entity, children: entity.children.map((c) => visit(c as Entity)) } as Entity
    const ref = embeddingRef(entity)
    if (ref === undefined || entity.synthesized !== undefined) return withChildren

    const decl = scene.embeddings?.[ref]
    if (decl === undefined) {
      skipped.push({ entityId: entity.id, ref, reason: 'undeclared' })
      return withChildren
    }
    if (!provider) {
      skipped.push({ entityId: entity.id, ref, reason: 'no-provider' })
      return withChildren
    }

    const hash = contentHash(JSON.stringify([entity.word, ref, decl, provider.name, provider.version, seed]))
    const res = provider.synthesize({ entityId: entity.id, word: entity.word, ref, decl, entity, seed })
    if (res === null) {
      skipped.push({ entityId: entity.id, ref, reason: 'declined' })
      return withChildren
    }

    synthesized++
    const provenance: SynthesisProvenance = { from: ref, provider: provider.name, version: provider.version, seed, hash }
    const styled = res.style && hasDrawable(withChildren) ? withStyle(withChildren, res.style) : withChildren
    const generated = (res.children ?? []).map((c) => {
      const marked = { ...c, synthesized: provenance } as Entity
      // Style lands on this entity's drawable when it has one, otherwise on what was generated.
      return res.style && !hasDrawable(withChildren) ? withStyle(marked, res.style) : marked
    })
    return {
      ...styled,
      // The description stays attached: synthesis does not consume the embedding, so the scene
      // never loses the request that produced the content and can be re-synthesized later.
      synthesized: provenance,
      children: [...styled.children, ...generated],
    } as Entity
  }

  return { scene: { ...scene, root: visit(scene.root as Entity) as Scene['root'] }, synthesized, skipped }
}

/** Every entity produced by, or marked by, synthesis. What a UI would badge as interpreter output. */
export function synthesizedEntities(scene: Scene): Array<{ id: EntityId; provenance: SynthesisProvenance }> {
  const out: Array<{ id: EntityId; provenance: SynthesisProvenance }> = []
  const walk = (n: Entity): void => {
    if (n.synthesized) out.push({ id: n.id, provenance: n.synthesized })
    for (const c of n.children) walk(c as Entity)
  }
  walk(scene.root as Entity)
  return out
}
