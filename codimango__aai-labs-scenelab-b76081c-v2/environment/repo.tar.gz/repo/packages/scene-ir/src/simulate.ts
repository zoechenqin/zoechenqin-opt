/**
 * Simulation (Design §2.8): walk the behavior trees without drawing anything and produce a
 * schedule — the flattened, ordered list of what happens when.
 *
 * This is a distinct step from resolve. Resolve produces structure and does not depend on time;
 * simulation produces a timeline and does not produce a scene. The schedule is what a
 * keyframe-sampling adapter uses to pick sample points, and what a translating adapter maps onto
 * its target's own animation primitives (Design §2.9).
 *
 * Anything that depends on runtime state — a contact time, what a script emits, which branch a
 * selector takes — cannot be worked out by a static walk. Rather than invent a number, those are
 * recorded in `unresolved`, and the reported duration is then a lower bound.
 */
import { keyframeSpan } from './animatable'
import { bindTemplate } from './bind'
import { behaviorOf } from './builders'
import { DEFAULT_SCRIPT_LIMITS, runScriptLeaf, runScriptRows, type ScriptLimits } from './script'
import type { BTAction, BTNode, Entity, EntityId, Scene, Seconds } from './types'

export interface ScheduleEntry {
  /** Seconds from scene start. */
  start: Seconds
  /** Seconds. Zero for an instantaneous state change. */
  duration: Seconds
  /** The behavior-tree entity that produced this entry, when it has an id. */
  btId?: string
  /** The entity, or the template whose stamped copies this applies to. */
  target: EntityId
  /** Set when the action names ONE stamped copy rather than every copy of a template. */
  targetIndex?: string
  /** `'curve'` is a keyframe leaf (§4.2); its params carry `property`, `keyframes` and `span`. */
  action: BTAction['action'] | 'curve'
  params: Record<string, unknown>
}

/** Canonical key for a behaviour target: an entity/template id, or one stamped copy of it. */
export function targetKey(target: EntityId, index?: string): string {
  return index === undefined ? target : `${target}#${index}`
}

export interface UnresolvedPoint {
  btId?: string
  reason: 'condition' | 'script' | 'loop' | 'selector'
  detail: string
}

export interface Simulation {
  /** Ordered by start time. */
  schedule: ScheduleEntry[]
  /** End of the last entry. A lower bound whenever `unresolved` is non-empty. */
  duration: Seconds
  /** Everything a static walk could not determine, and why. */
  unresolved: UnresolvedPoint[]
  /** Moments the timeline should tick: entry starts and ends, plus 0. */
  moments: Seconds[]
}

interface Ctx {
  schedule: ScheduleEntry[]
  unresolved: UnresolvedPoint[]
  limits: ScriptLimits
  depth: number
  /** The scene's declared duration, which is what a `loop: true` sequence repeats up to. */
  sceneDuration?: Seconds
}

/** Returns the time at which `bt` finishes, given it starts at `start` under `speed`. */
function walk(bt: BTNode, start: Seconds, speed: number, ctx: Ctx): Seconds {
  switch (bt.type) {
    case 'action': {
      const duration = speed > 0 ? bt.duration / speed : bt.duration
      const target = typeof bt.target === 'string' ? bt.target : bt.target.templateId
      const targetIndex = typeof bt.target === 'string' ? undefined : bt.target.index
      ctx.schedule.push({
        start,
        duration,
        ...(bt.id !== undefined ? { btId: bt.id } : {}),
        target,
        ...(targetIndex !== undefined ? { targetIndex } : {}),
        action: bt.action,
        params: bt.params,
      })
      return start + duration
    }

    case 'curve': {
      // A curve runs for its own keyframe span (§4.2). Because the span is local, `speed` scales
      // it exactly as it scales an action's duration, and playback maps global time back onto the
      // local axis — so a curve under a timeScale decorator stretches rather than truncates.
      const span = keyframeSpan(bt.keyframes)
      const duration = speed > 0 ? span / speed : span
      const target = typeof bt.target === 'string' ? bt.target : bt.target.templateId
      const targetIndex = typeof bt.target === 'string' ? undefined : bt.target.index
      ctx.schedule.push({
        start,
        duration,
        ...(bt.id !== undefined ? { btId: bt.id } : {}),
        target,
        ...(targetIndex !== undefined ? { targetIndex } : {}),
        action: 'curve',
        params: { property: bt.property, keyframes: bt.keyframes, span },
      })
      return start + duration
    }

    case 'sequence': {
      const inner = speed * (bt.speed ?? 1)
      const onePass = (from: Seconds): Seconds => {
        let t = from
        for (const child of bt.children) t = walk(child, t, inner, ctx)
        return t
      }

      // An explicit count is fully resolvable.
      if (bt.repeat !== undefined && bt.repeat > 1) {
        let t = start
        for (let i = 0; i < bt.repeat; i++) {
          const next = onePass(t)
          if (next <= t) break // zero-length body; repeating it would not advance
          t = next
        }
        return t
      }

      if (bt.loop !== true) return onePass(start)

      // `loop: true` means "keep going until the clip ends", which is only answerable when the
      // scene declares a duration. Otherwise ambient motion (a sun bobbing, a grid scrolling)
      // stops after one pass and leaves the rest of the clip frozen.
      const budget = ctx.sceneDuration
      if (budget === undefined) {
        ctx.unresolved.push({
          ...(bt.id !== undefined ? { btId: bt.id } : {}),
          reason: 'loop',
          detail: 'looping sequence has no finite end and the scene declares no duration; one pass is scheduled',
        })
        return onePass(start)
      }
      let t = start
      let passes = 0
      while (t < budget) {
        const next = onePass(t)
        passes++
        if (next <= t) break
        t = next
        if (passes >= ctx.limits.maxActions) {
          ctx.unresolved.push({
            ...(bt.id !== undefined ? { btId: bt.id } : {}),
            reason: 'loop',
            detail: `looping sequence exceeded ${ctx.limits.maxActions} passes before filling the scene duration`,
          })
          break
        }
      }
      return t
    }

    case 'selector': {
      // Nothing fails during a static walk, so the first child is the one that would run.
      const first = bt.children[0]
      if (first === undefined) return start
      if (bt.children.length > 1) {
        ctx.unresolved.push({
          ...(bt.id !== undefined ? { btId: bt.id } : {}),
          reason: 'selector',
          detail: `selector has ${bt.children.length} branches; the first is assumed without runtime state`,
        })
      }
      return walk(first, start, speed, ctx)
    }

    case 'parallel': {
      let end = start
      let first = true
      for (const child of bt.children) {
        const childEnd = walk(child, start, speed, ctx)
        if (bt.policy === 'any') end = first ? childEnd : Math.min(end, childEnd)
        else end = Math.max(end, childEnd)
        first = false
      }
      return end
    }

    case 'decorator': {
      const scale = bt.decorator === 'timeScale' ? Number(bt.params['scale'] ?? 1) : 1
      return walk(bt.child, start, speed * (Number.isFinite(scale) && scale > 0 ? scale : 1), ctx)
    }

    case 'condition': {
      // `always` gates nothing; `time` fires at a stated moment. Everything else is emergent.
      if (bt.on === 'always') return bt.child ? walk(bt.child, start, speed, ctx) : start
      if (bt.on === 'time') {
        const at = Number(bt.params?.['at'] ?? start)
        const from = Number.isFinite(at) ? Math.max(start, at) : start
        return bt.child ? walk(bt.child, from, speed, ctx) : from
      }
      ctx.unresolved.push({
        ...(bt.id !== undefined ? { btId: bt.id } : {}),
        reason: 'condition',
        detail: `"${bt.on}" is emergent and cannot be resolved by a static walk`,
      })
      return bt.child ? walk(bt.child, start, speed, ctx) : start
    }

    case 'script': {
      // §2.8: simulation runs the leaf and resolves what it emitted, so the schedule an adapter
      // consumes already contains the generated actions and nobody re-runs the program.
      if (ctx.depth >= ctx.limits.maxDepth) {
        ctx.unresolved.push({
          ...(bt.id !== undefined ? { btId: bt.id } : {}),
          reason: 'script',
          detail: `script leaves nested deeper than ${ctx.limits.maxDepth}; not expanded further`,
        })
        return start
      }
      let emitted: BTNode[]
      try {
        emitted = runScriptLeaf(bt, ctx.limits)
      } catch (err) {
        // A script that cannot run is reported, not silently dropped — a leaf contributing nothing
        // is how a correct 127-move program renders as a still image.
        ctx.unresolved.push({
          ...(bt.id !== undefined ? { btId: bt.id } : {}),
          reason: 'script',
          detail: (err as Error).message,
        })
        return start
      }
      ctx.depth++
      let t = start
      for (const child of emitted) t = walk(child, t, speed, ctx)
      ctx.depth--
      return t
    }

    case 'forEach': {
      // The temporal `instance` op: one template, stamped per row (§2.8).
      if (ctx.depth >= ctx.limits.maxDepth) {
        ctx.unresolved.push({
          ...(bt.id !== undefined ? { btId: bt.id } : {}),
          reason: 'script',
          detail: `forEach nested deeper than ${ctx.limits.maxDepth}; not expanded further`,
        })
        return start
      }
      let rows: Array<Record<string, unknown>>
      try {
        rows = bt.source.kind === 'rows' ? bt.source.rows : runScriptRows(bt.source, ctx.limits)
      } catch (err) {
        ctx.unresolved.push({
          ...(bt.id !== undefined ? { btId: bt.id } : {}),
          reason: 'script',
          detail: (err as Error).message,
        })
        return start
      }

      ctx.depth++
      let end = start
      let cursor = start
      for (let i = 0; i < rows.length; i++) {
        // An override is a correction recorded against the generator, not a rewrite of it.
        const row = { ...rows[i], ...(bt.overrides?.[String(i)] ?? {}) }
        let stamped: BTNode
        try {
          stamped = bindTemplate(bt.template, row, i)
        } catch (err) {
          ctx.unresolved.push({
            ...(bt.id !== undefined ? { btId: bt.id } : {}),
            reason: 'script',
            detail: (err as Error).message,
          })
          break
        }
        if (bt.mode === 'parallel') {
          end = Math.max(end, walk(stamped, start, speed, ctx))
        } else {
          cursor = walk(stamped, cursor, speed, ctx)
          end = cursor
        }
      }
      ctx.depth--
      return end
    }
  }
}

function collectBehaviors(entity: Entity, out: BTNode[]): void {
  const behavior = behaviorOf(entity)
  if (behavior) out.push(behavior)
  for (const child of entity.children) collectBehaviors(child, out)
}

/**
 * Simulation is pure in the scene, and resolving for playback calls it once per frame — with a
 * script leaf in the tree that would re-execute the program thousands of times per render.
 * Cached on scene identity; build a new scene object (as `applyEvent` does) to invalidate.
 */
const cache = new WeakMap<Scene, Simulation>()

/**
 * Walks every behavior tree in the scene. Trees are independent and all start at 0.
 */
export function simulate(scene: Scene): Simulation {
  const hit = cache.get(scene)
  if (hit) return hit
  const sim = simulateUncached(scene)
  cache.set(scene, sim)
  return sim
}

function simulateUncached(scene: Scene): Simulation {
  const ctx: Ctx = { schedule: [], unresolved: [], limits: DEFAULT_SCRIPT_LIMITS, depth: 0, ...(scene.duration !== undefined ? { sceneDuration: scene.duration } : {}) }
  const trees: BTNode[] = []
  collectBehaviors(scene.root as Entity, trees)

  let end = 0
  for (const tree of trees) end = Math.max(end, walk(tree, 0, 1, ctx))

  ctx.schedule.sort((a, b) => a.start - b.start || a.duration - b.duration)

  const moments = new Set<number>([0])
  for (const e of ctx.schedule) {
    moments.add(e.start)
    moments.add(e.start + e.duration)
  }

  return {
    schedule: ctx.schedule,
    duration: scene.duration ?? end,
    unresolved: ctx.unresolved,
    moments: [...moments].sort((a, b) => a - b),
  }
}
