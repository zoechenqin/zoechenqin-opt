import { describe, it, expect } from 'vitest'
import {
  BT_ID_PATTERN,
  assignBehaviorIds,
  collectBehaviorIds,
  constant,
  identityTransform,
  parseScene,
  sampleHanoiBehaviorTree,
  validateSceneGraph,
} from './index'
import type { BTNode, Scene } from './index'

const sceneWith = (behavior: BTNode, btEntityId = 'bt'): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'btid',
    space: '2d',
    canvas: { width: 100, height: 100 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        { id: btEntityId, word: 'motion', transform: identityTransform(), children: [], components: { behavior: constant(behavior) } },
        { id: 'box', word: 'box', transform: identityTransform(), children: [], components: { rect: constant({ size: { x: 1, y: 1 }, style: {} }) } as never },
      ],
    },
  }) as Scene

const move = (id?: string): BTNode =>
  ({ ...(id ? { id } : {}), type: 'action', action: 'translate', target: 'box', duration: 1, params: { to: { x: 1, y: 0, z: 0 } } }) as BTNode

describe('assignBehaviorIds', () => {
  it('gives every node a positional id derived from its owning entity', () => {
    const scene = assignBehaviorIds(sceneWith({ type: 'sequence', children: [move(), move()] } as BTNode))
    expect(collectBehaviorIds(scene).map((b) => b.id)).toEqual(['bt.bt', 'bt.bt.0', 'bt.bt.1'])
  })

  it('never overwrites an authored id', () => {
    const scene = assignBehaviorIds(sceneWith({ type: 'sequence', id: 'main', children: [move('lift'), move()] } as BTNode))
    expect(collectBehaviorIds(scene).map((b) => b.id)).toEqual(['main', 'lift', 'bt.bt.1'])
  })

  it('reaches decorator children and forEach templates, not just composite children', () => {
    const scene = assignBehaviorIds(
      sceneWith({
        type: 'decorator',
        decorator: 'timeScale',
        params: { scale: 2 },
        child: { type: 'forEach', source: { kind: 'rows', rows: [{ n: 1 }] }, template: move() } as BTNode,
      } as BTNode),
    )
    expect(collectBehaviorIds(scene).map((b) => b.id)).toEqual(['bt.bt', 'bt.bt.c', 'bt.bt.c.t'])
  })

  it('is stable — parsing the same scene twice yields the same ids', () => {
    const build = () => sceneWith({ type: 'sequence', children: [move(), move()] } as BTNode)
    expect(collectBehaviorIds(assignBehaviorIds(build()))).toEqual(collectBehaviorIds(assignBehaviorIds(build())))
  })

  it('returns the same object when nothing needs assigning', () => {
    const scene = assignBehaviorIds(sceneWith({ type: 'sequence', id: 'a', children: [move('b')] } as BTNode))
    expect(assignBehaviorIds(scene)).toBe(scene)
  })

  it('assigns ids that satisfy the id charset', () => {
    for (const { id } of collectBehaviorIds(assignBehaviorIds(sampleHanoiBehaviorTree()))) {
      expect(id).toMatch(BT_ID_PATTERN)
    }
  })
})

describe('parseScene establishes the id guarantee', () => {
  it('fills in ids the author omitted', () => {
    const raw = JSON.parse(JSON.stringify(sceneWith({ type: 'sequence', children: [move(), move()] } as BTNode)))
    expect(collectBehaviorIds(parseScene(raw)).every((b) => b.id.length > 0)).toBe(true)
    expect(collectBehaviorIds(parseScene(raw))).toHaveLength(3)
  })
})

describe('validateSceneGraph checks behavior tree ids', () => {
  it('accepts the shipped behavior fixture', () => {
    expect(validateSceneGraph(assignBehaviorIds(sampleHanoiBehaviorTree()))).toEqual([])
  })

  it('flags two nodes sharing an id', () => {
    const scene = sceneWith({ type: 'sequence', id: 'dup', children: [move('dup')] } as BTNode)
    const errors = validateSceneGraph(scene).filter((d) => d.code === 'duplicate-bt-id')
    expect(errors).toHaveLength(1)
    expect(errors[0]!.level).toBe('error')
    expect(errors[0]!.message).toContain('"dup"')
  })

  it('flags an id that would collide with procedural expansion', () => {
    const scene = sceneWith({ type: 'sequence', id: 'a:0', children: [] } as BTNode)
    const errors = validateSceneGraph(scene).filter((d) => d.code === 'invalid-bt-id')
    expect(errors).toHaveLength(1)
    expect(errors[0]!.message).toContain("reserved for procedural expansion")
  })
})
