/**
 * Its own module so anything can import it without going through the package index, which
 * re-exports everything and would make that a cycle.
 */
export const SCHEMA_VERSION = '0.1.0'
