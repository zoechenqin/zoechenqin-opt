import type { Animatable, Camera, Color, EntityId, Entity, PathSegment, Scene, Seconds, Vec3, Transform, Vec2 } from './types'
import { axisAngleToQuat, composeMat4, identityMat4, invertMat4, multiplyMat4, transformPoint, translationMat4, type Mat4 } from './math'
import { resolveAxisAngle, resolveColor, resolveNumber, resolveVec2, resolveVec3 } from './animatable'
import { arrangementOf } from './builders'
import { behaviorStateAt, type BehaviorState } from './behavior'
import { targetKey } from './simulate'

export interface ResolvedStyle {
  fill?: Color
  stroke?: Color
  strokeWidth?: number
}

export type ResolvedShape =
  | { type: 'circle'; radius: number; style: ResolvedStyle }
  | { type: 'rect'; size: Vec2; cornerRadius?: number; style: ResolvedStyle }
  | { type: 'polygon'; points: Vec3[]; style: ResolvedStyle }
  | { type: 'line'; from: Vec3; to: Vec3; style: ResolvedStyle }
  | { type: 'path'; segments: PathSegment[]; closed?: boolean; style: ResolvedStyle }
  | { type: 'text'; content: string; fontSize: number; align: import('./types').TextAlign; fontFamily?: string; fontWeight?: number | 'normal' | 'bold'; lineHeight?: number; style: ResolvedStyle }
  | { type: 'box'; size: Vec3; style: ResolvedStyle }
  | { type: 'sphere'; radius: number; style: ResolvedStyle }
  | { type: 'cylinder'; radius: number; height: number; style: ResolvedStyle }
  | { type: 'cone'; radius: number; height: number; style: ResolvedStyle }
  | { type: 'torus'; radius: number; tube: number; style: ResolvedStyle }
  | { type: 'mesh'; asset: string; style: ResolvedStyle }

export interface ResolvedPrimitive {
  id: EntityId
  word: string
  worldMatrix: Mat4
  opacity: number
  shape: ResolvedShape
  locked: boolean
  enabled: boolean
  components?: Record<string, unknown>
  templateId?: EntityId
  repeatParentId?: EntityId
  repeatIndex?: string
}

export interface ResolvedCamera {
  worldMatrix: Mat4
  projection: { type: 'orthographic'; height: number } | { type: 'perspective'; fovY: number; near: number; far: number }
}

/**
 * A light, placed. Lights sit on entities that draw nothing, so they never reach `primitives`;
 * surfacing them separately is what makes them available to a renderer that can use them.
 */
export interface ResolvedLight {
  id: EntityId
  worldMatrix: Mat4
  light: import('./types').LightComponent
}

export interface ResolvedScene {
  space: '2d' | '3d'
  canvas: { width: number; height: number; background?: Color }
  camera: ResolvedCamera
  primitives: ResolvedPrimitive[]
  lights: ResolvedLight[]
}

function resolveStyle(style: any, t: Seconds): ResolvedStyle {
  if (!style) return {}
  const out: ResolvedStyle = {}
  if (style.fill) {
    const f = style.fill as any
    if (f.kind === 'const') out.fill = f.value
    else if (f.r !== undefined) out.fill = f as Color
  }
  if (style.stroke) {
    const s = style.stroke as any
    if (s.kind === 'const') out.stroke = s.value
    else if (s.r !== undefined) out.stroke = s as Color
  }
  if (style.strokeWidth) {
    const w = style.strokeWidth as any
    if (w.kind === 'const') out.strokeWidth = w.value
    else if (typeof w === 'number') out.strokeWidth = w
  }
  return out
}

export function localMatrix(tr: Transform, t: Seconds): Mat4 {
  return composeMat4(resolveVec3(tr.position, t), axisAngleToQuat(resolveAxisAngle(tr.rotation, t)), resolveVec3(tr.scale, t), tr.anchor)
}

/**
 * As `localMatrix`, with behavior state taking precedence over the authored transform
 * (Design §2.8).
 */
function localMatrixWithBehavior(tr: Transform, t: Seconds, bt: BehaviorState | undefined): Mat4 {
  if (!bt) return localMatrix(tr, t)
  return composeMat4(
    bt.position ?? resolveVec3(tr.position, t),
    axisAngleToQuat(bt.rotation ?? resolveAxisAngle(tr.rotation, t)),
    bt.scale ?? resolveVec3(tr.scale, t),
    tr.anchor,
  )
}

function resolveCamera(cam: Camera, t: Seconds, bt?: BehaviorState): ResolvedCamera {
  // The camera is outside the entity tree but can still be addressed by behavior through its id.
  const worldMatrix = localMatrixWithBehavior(cam.transform, t, bt)
  if (cam.projection.type === 'orthographic') {
    return { worldMatrix, projection: { type: 'orthographic', height: resolveNumber(cam.projection.height, t) } }
  }
  return {
    worldMatrix,
    projection: { type: 'perspective', fovY: resolveNumber(cam.projection.fovY, t), near: cam.projection.near, far: cam.projection.far },
  }
}

function resolveEntityComponents(components: Entity['components'], t: Seconds): Record<string, unknown> | undefined {
  if (!components) return undefined
  const out: Record<string, unknown> = {}
  for (const [key, anim] of Object.entries(components)) {
    if (!anim) continue
    if (typeof anim === 'object' && anim !== null && 'kind' in anim) {
      const k = anim as { kind: string; value?: unknown }
      if (k.kind === 'const') out[key] = k.value
    }
  }
  return Object.keys(out).length > 0 ? out : undefined
}

/**
 * Overlay what `curve` leaves drove onto the resolved components (§4.4). Paths are
 * `components.<type>.<...>`; transform channels never reach here, since `behaviorStateAt` puts
 * those in `position`/`scale`/`rotation` where every existing consumer already looks.
 */
function applyBehaviorProperties(
  resolved: Record<string, unknown> | undefined,
  properties: Record<string, unknown> | undefined,
): Record<string, unknown> | undefined {
  if (!properties || Object.keys(properties).length === 0) return resolved
  const out: Record<string, unknown> = { ...(resolved ?? {}) }

  for (const [path, value] of Object.entries(properties)) {
    const segments = path.split('.')
    if (segments[0] === 'components') segments.shift()
    if (segments.length === 0) continue
    // Copy down the path rather than mutating: `resolved` holds values shared with the source
    // scene, and a curve on one stamped copy must not rewrite the template every copy reads.
    let cursor: Record<string, unknown> = out
    for (let i = 0; i < segments.length - 1; i++) {
      const key = segments[i]!
      const child = cursor[key]
      const next = typeof child === 'object' && child !== null ? { ...(child as Record<string, unknown>) } : {}
      cursor[key] = next
      cursor = next
    }
    cursor[segments[segments.length - 1]!] = value
  }
  return out
}

function cloneEntityWithSuffix(entity: Entity, suffix: string, parentChain?: string): Entity {
  const baseId = parentChain ? `${parentChain}:${entity.id}` : entity.id
  const newId = suffix ? `${baseId}:${suffix.replace(/^:/, '')}` : baseId
  return { ...entity, id: newId, children: entity.children.map((c) => cloneEntityWithSuffix(c as Entity, suffix, baseId)) } as Entity
}

/** Backstop for nested instancing; real scenes nest a handful of levels, not hundreds. */
const MAX_EXPANSION_DEPTH = 256

export function resolveScene(scene: Scene, t: Seconds = 0): ResolvedScene {
  const primitives: ResolvedPrimitive[] = []
  const lights: ResolvedLight[] = []
  const usedIds = new Set<EntityId>()
  const sourceIds = new Set<EntityId>()

  const checkSource = (n: Entity) => {
    if (!/^[A-Za-z0-9_.]+$/.test(n.id)) throw new Error(`scene-ir: id "${n.id}" must be alphanumeric + '_' and '.' only (A-Za-z0-9_.). ':' reserved for procedural expansion and '-' not allowed`)
    if (sourceIds.has(n.id)) throw new Error(`scene-ir: duplicate explicit id "${n.id}" in source scene`)
    sourceIds.add(n.id)
    for (const c of n.children) checkSource(c as Entity)
  }
  checkSource(scene.root as Entity)

  // What the behavior trees have decided by time t. Empty for a scene with no trees, so a purely
  // keyframed scene costs one simulate() walk and is otherwise untouched.
  const btState = behaviorStateAt(scene, t)

  const walk = (entity: Entity, parentWorld: Mat4, parentOpacity: number, parentLocked: boolean, parentEnabled: boolean, repeatContext?: { templateId: EntityId; repeatParentId: EntityId; repeatIndex: string }, expansion: EntityId[] = []): void => {
    // Containment is finite — it is a literal object tree — but instancing is not: an op resolves
    // its template from `scene.root`, so it can name an ancestor of the entity doing the stamping and
    // recurse forever. `expansion` is the stack of template ids currently being stamped, in their
    // pre-clone form (`cloneEntityWithSuffix` rewrites ids, `findTemplateById` returns originals), so
    // re-entering one is exactly the cycle. `validateSceneGraph` reports these up front; this is the
    // backstop for a scene that reaches resolve unvalidated.
    if (expansion.length > MAX_EXPANSION_DEPTH) {
      throw new Error(`scene-ir: instance expansion exceeded ${MAX_EXPANSION_DEPTH} levels (via ${expansion.join(' → ')}) — templates nested this deep are almost certainly a cycle the id rewriting hid`)
    }
    // A template is not drawn where it sits; it is drawn only when an instance op stamps it,
    // which is exactly when repeatContext is set (Design §2.2).
    if (entity.template === true && !repeatContext) return
    // Resolution order, most specific first: this entity by its own id; then THIS stamped copy
    // (`template#index`), which is how a correction reaches one instance; then the template as a
    // whole, which is how "all the rings rise" stays a single action.
    const bt =
      btState.get(entity.id) ??
      (repeatContext
        ? (btState.get(targetKey(repeatContext.templateId, repeatContext.repeatIndex)) ??
           btState.get(repeatContext.templateId))
        : undefined)
    const selfEnabled = bt?.enabled ?? entity.enabled !== false
    const enabled = parentEnabled && selfEnabled
    if (!enabled) return

    const world = multiplyMat4(parentWorld, localMatrixWithBehavior(entity.transform, t, bt))
    const entityOpacity = entity.components?.opacity
    const opacity = parentOpacity * (entityOpacity ? resolveNumber(entityOpacity as Animatable<number>, t) : 1)
    const locked = parentLocked || entity.locked === true
    const resolvedComponents = applyBehaviorProperties(resolveEntityComponents(entity.components, t), bt?.properties)

    if (resolvedComponents?.['light']) {
      lights.push({ id: entity.id, worldMatrix: world, light: resolvedComponents['light'] as import('./types').LightComponent })
    }

    if (resolvedComponents) {
      const drawableTypes = new Set(['circle', 'rect', 'polygon', 'line', 'path', 'text', 'box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh'])
      const presentDrawables = Object.keys(resolvedComponents).filter((k) => drawableTypes.has(k))
      if (presentDrawables.length > 1) {
        throw new Error(`scene-ir: entity "${entity.id}" has multiple drawable components ${presentDrawables.join(', ')} — components unique per entity, only one drawable type allowed. Guidance: make multiple child entities, each with single shape component, e.g., group children=[ {id:entity_fill, components:{rect:{...}}}, {id:entity_outline, components:{path:{...}}} ]`)
      }
      const pushDrawable = (type: string, payload: any) => {
        if (!drawableTypes.has(type)) return
        try {
          let shape: ResolvedShape | null = null
          const style = payload.style ? resolveStyle(payload.style, t) : {}
          if (type === 'circle') shape = { type: 'circle', radius: payload.radius, style }
          else if (type === 'rect') shape = { type: 'rect', size: payload.size, ...(payload.cornerRadius !== undefined ? { cornerRadius: payload.cornerRadius } : {}), style }
          else if (type === 'polygon') shape = { type: 'polygon', points: payload.points, style }
          else if (type === 'line') shape = { type: 'line', from: payload.from, to: payload.to, style }
          else if (type === 'path') shape = { type: 'path', segments: payload.segments, closed: payload.closed, style }
          else if (type === 'text') shape = { type: 'text', content: payload.content, fontSize: payload.fontSize, align: payload.align ?? 'center', ...(payload.fontFamily !== undefined ? { fontFamily: payload.fontFamily } : {}), ...(payload.fontWeight !== undefined ? { fontWeight: payload.fontWeight } : {}), ...(payload.lineHeight !== undefined ? { lineHeight: payload.lineHeight } : {}), style }
          else if (type === 'box') shape = { type: 'box', size: payload.size, style }
          else if (type === 'sphere') shape = { type: 'sphere', radius: payload.radius, style }
          else if (type === 'cylinder') shape = { type: 'cylinder', radius: payload.radius, height: payload.height, style }
          else if (type === 'cone') shape = { type: 'cone', radius: payload.radius, height: payload.height, style }
          else if (type === 'torus') shape = { type: 'torus', radius: payload.radius, tube: payload.tube, style }
          else if (type === 'mesh') shape = { type: 'mesh', asset: payload.asset, style }
          if (shape) {
            // A drawable uses its entity id; multiple drawables require child entities.
            const primId = entity.id
            if (!usedIds.has(primId) && !sourceIds.has(primId)) {
              usedIds.add(primId)
            }
            // Prevent a procedural and explicit entity from emitting the same primitive twice.
            if (!primitives.some((p) => p.id === primId)) {
              primitives.push({
                id: primId,
                word: entity.word,
                worldMatrix: world,
                opacity,
                shape,
                locked,
                enabled,
                components: resolvedComponents,
                ...(repeatContext ? { templateId: repeatContext.templateId, repeatParentId: repeatContext.repeatParentId, repeatIndex: repeatContext.repeatIndex } : {}),
              })
            } else {
              // Keep unchecked inputs deterministic if they contain more than one drawable component.
              const idx = primitives.findIndex((p) => p.id === primId)
              if (idx !== -1) primitives[idx] = { ...primitives[idx]!, shape }
            }
          }
        } catch {}
      }
      for (const [cType, cPayload] of Object.entries(resolvedComponents)) {
        pushDrawable(cType, cPayload)
      }
    }

    {
      const g = entity as any
      const templateChildren = g.children as Entity[]
      const arrangement = arrangementOf(entity)

      const walkChildren = (pw: Mat4, suffix: string, overrideKey: string | null, sgOverrides?: Record<string, any>, templatesOverride?: Entity[]) => {
        const templatesForThis = templatesOverride ?? templateChildren
        const ov = overrideKey ? sgOverrides?.[overrideKey] : undefined
        if (ov?.enabled === false) return
        let repeatWorld = pw
        let overrideLocked = false
        let overrideComponents: Record<string, unknown> | undefined
        if (ov) {
          if (ov.transform) {
            const ovMat = localMatrix(ov.transform, t)
            repeatWorld = multiplyMat4(pw, ovMat)
          }
          if (ov.locked === true) overrideLocked = true
          if (ov.components) overrideComponents = resolveEntityComponents(ov.components as any, t)
        }
        // Templates named by id (rather than taken as the entity's own children) are the only ones
        // that can reach back up the tree, so they are the only ones that need guarding.
        const stampsById = templatesOverride !== undefined
        for (const child of templatesForThis) {
          const originalTemplateId = child.id
          if (stampsById && expansion.includes(originalTemplateId)) {
            throw new Error(`scene-ir: cyclic instance expansion — template "${originalTemplateId}" is stamped inside its own expansion (${[...expansion, originalTemplateId].join(' → ')}). An arrangement op cannot instance an entity that contains the op.`)
          }
          const parentChain = g.id
          const toWalkBase = suffix ? cloneEntityWithSuffix(child, suffix, parentChain) : child
          let toWalk: Entity = toWalkBase
          if (overrideComponents || overrideLocked) {
            const baseComps = (toWalk as any).components ?? {}
            const mergedComps = overrideComponents ? { ...baseComps, ...Object.fromEntries(Object.entries(overrideComponents).map(([k, v]) => [k, { kind: 'const', value: v } as any])) } : baseComps
            toWalk = { ...toWalk, ...(Object.keys(mergedComps).length > 0 ? { components: mergedComps } : {}), ...(overrideLocked ? { locked: true } : {}) } as Entity
          }
          const ctx = arrangement || overrideKey ? { templateId: originalTemplateId, repeatParentId: g.id, repeatIndex: overrideKey ?? '' } : repeatContext
          walk(toWalk, repeatWorld, opacity, locked || overrideLocked, enabled, ctx, stampsById ? [...expansion, originalTemplateId] : expansion)
        }
      }

      if (arrangement) {
        const generatePoints = (gen: any): Mat4[] => {
          if (gen.type === 'grid') {
            const start = gen.start ?? { x: 0, y: 0, z: 0 }
            const startMat = translationMat4(start)
            const mats: Mat4[] = []
            for (let y = 0; y < gen.countY; y++) {
              for (let x = 0; x < gen.countX; x++) {
                const offset = translationMat4({ x: x * gen.spacingX, y: y * gen.spacingY, z: 0 })
                mats.push(multiplyMat4(offset, startMat))
              }
            }
            return mats
          } else if (gen.type === 'line') {
            const stepMat = localMatrix(gen.step, t)
            const mats: Mat4[] = []
            let accum = identityMat4()
            for (let i = 0; i < gen.count; i++) {
              mats.push(accum)
              accum = multiplyMat4(accum, stepMat)
            }
            return mats
          } else if (gen.type === 'radial') {
            const mats: Mat4[] = []
            for (let i = 0; i < gen.count; i++) {
              const theta = (2 * Math.PI * i) / gen.count
              mats.push(translationMat4({ x: gen.radius * Math.cos(theta), y: gen.radius * Math.sin(theta), z: 0 }))
            }
            return mats
          } else if (gen.type === 'poisson') {
            const mats: Mat4[] = []
            let attempts = 0
            const boundsMin = gen.bounds?.min ?? { x: -5, y: -5, z: 0 }
            const boundsMax = gen.bounds?.max ?? { x: 5, y: 5, z: 0 }
            while (mats.length < gen.count && attempts < gen.count * 20) {
              const x = boundsMin.x + Math.random() * (boundsMax.x - boundsMin.x)
              const y = boundsMin.y + Math.random() * (boundsMax.y - boundsMin.y)
              const z = boundsMin.z + Math.random() * (boundsMax.z - boundsMin.z)
              const candidate = { x, y, z }
              let ok = true
              for (const existing of mats) {
                const existingPos = { x: existing[12], y: existing[13], z: existing[14] }
                const d = Math.hypot(candidate.x - existingPos.x, candidate.y - existingPos.y, candidate.z - existingPos.z)
                if (d < gen.minDist) { ok = false; break }
              }
              if (ok) mats.push(translationMat4(candidate))
              attempts++
            }
            return mats
          } else if (gen.type === 'pathFollow') {
            const mats: Mat4[] = []
            for (let i = 0; i < gen.count; i++) {
              const p = (i / Math.max(1, gen.count - 1)) * gen.spacing * gen.count
              mats.push(translationMat4({ x: p, y: 0, z: 0 }))
            }
            return mats
          }
          return []
        }
        const pointClouds = new Map<string, Mat4[]>()
        for (const op of arrangement.ops) {
          if (op.type === 'points') pointClouds.set(op.id, generatePoints((op as any).generator))
        }
        const findTemplateById = (id: string): Entity | undefined => {
          const search = (n: Entity): Entity | undefined => {
            if (n.id === id) return n
            {
              for (const c of n.children) {
                const found = search(c as Entity)
                if (found) return found
              }
            }
            return undefined
          }
          return search(scene.root as Entity)
        }
        for (const op of arrangement.ops) {
          if (op.type !== 'instance') continue
          const mats = pointClouds.get((op as any).points)
          if (!mats) continue
          const overrides = (op as any).overrides ?? {}
          const templatesToUse: Entity[] =
            (op as any).templates && (op as any).templates.length > 0
              ? (op as any).templates.map(findTemplateById).filter((n: any): n is Entity => !!n)
              : templateChildren
          for (let i = 0; i < mats.length; i++) {
            const pointsOp = arrangement.ops.find((n) => n.id === (op as any).points && n.type === 'points') as any
            let key = `${i}`
            if (pointsOp?.generator?.type === 'grid') {
              const gx = pointsOp.generator.countX
              const x = i % gx
              const y = Math.floor(i / gx)
              key = `${x},${y}`
            } else if (pointsOp?.generator?.type === 'radial') {
              key = `r${i}`
            }
            const repeatWorld = multiplyMat4(world, mats[i]!)
            walkChildren(repeatWorld, `:${key}`, key, overrides, templatesToUse)
          }
        }
      } else {
        walkChildren(world, '', null)
      }
    }
  }

  walk(scene.root as Entity, identityMat4(), 1, false, true)

  // An embedding reference must name something declared on the scene (Design §2.7).
  for (const prim of primitives) {
    for (const key of ['embedding', 'motionEmbedding'] as const) {
      const c = prim.components?.[key] as { ref?: string } | undefined
      if (c?.ref && !scene.embeddings?.[c.ref]) {
        throw new Error(`scene-ir: entity "${prim.id}" references undeclared embedding "${c.ref}"`)
      }
    }
  }

  const findRef = (ref: any): ResolvedPrimitive | undefined => {
    if (!ref) return undefined
    if (typeof ref === 'string') return primitives.find((p) => p.id === ref || (p as any).templateId === ref)
    if (typeof ref === 'object') {
      const parentId = ref.parentId
      const index = ref.index
      const templateId = ref.templateId
      if (parentId && index !== undefined) {
        return primitives.find((p) => {
          const rp = p as ResolvedPrimitive
          return rp.repeatParentId === parentId && rp.repeatIndex === index && (templateId ? rp.templateId === templateId || rp.id === templateId : true)
        })
      }
      if (ref.id) return primitives.find((p) => p.id === ref.id)
    }
    return undefined
  }

  for (const prim of primitives) {
    const comps = (prim as any).components as Record<string, any> | undefined
    const link = comps?.link as { from?: any; to?: any; fromOffset?: Vec3; toOffset?: Vec3 } | undefined
    if (!link) continue
    const fromRef = findRef(link.from)
    const toRef = findRef(link.to)
    if (!fromRef && !toRef) continue
    const invWorld = invertMat4(prim.worldMatrix)
    const getRefWorldPos = (refPrim: ResolvedPrimitive | undefined, offset?: Vec3): Vec3 | null => {
      if (!refPrim) return null
      const base = transformPoint(refPrim.worldMatrix, { x: 0, y: 0, z: 0 })
      if (!offset) return base
      return { x: base.x + offset.x, y: base.y + offset.y, z: base.z + offset.z }
    }
    if (prim.shape.type === 'line') {
      if (fromRef) {
        const wp = getRefWorldPos(fromRef, link.fromOffset)
        if (wp) (prim.shape as any).from = transformPoint(invWorld, wp)
      }
      if (toRef) {
        const wp = getRefWorldPos(toRef, link.toOffset)
        if (wp) (prim.shape as any).to = transformPoint(invWorld, wp)
      }
    } else if (prim.shape.type === 'path') {
      const segs = (prim.shape as any).segments as PathSegment[]
      if (segs.length > 0) {
        if (fromRef && segs[0]) {
          const wp = getRefWorldPos(fromRef, link.fromOffset)
          if (wp && segs[0]!.type === 'move') segs[0]!.to = transformPoint(invWorld, wp)
        }
        if (toRef && segs[segs.length - 1]) {
          const wp = getRefWorldPos(toRef, link.toOffset)
          if (wp) segs[segs.length - 1]!.to = transformPoint(invWorld, wp)
        }
      }
    }
  }

  return {
    space: scene.space,
    canvas: { width: scene.canvas.width, height: scene.canvas.height, ...(scene.canvas.background !== undefined ? { background: scene.canvas.background } : {}) },
    camera: resolveCamera(scene.camera, t, btState.get(scene.camera.id)),
    primitives,
    lights,
  }
}
