import { describe, it, expect, afterEach } from 'vitest'
import { constant, identityTransform, resolveScene, setScriptRunner, simulate } from './index'
import type { BTNode, Scene } from './index'

const sceneWith = (behavior: BTNode, targets: string[] = ['ring_1']): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'script',
    space: '2d',
    canvas: { width: 100, height: 100 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        { id: 'bt', word: 'timeline', transform: identityTransform(), children: [], components: { behavior: constant(behavior) } },
        ...targets.map((id) => ({
          id,
          word: 'ring',
          transform: identityTransform(),
          components: { rect: constant({ size: { x: 1, y: 1 }, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) },
          children: [],
        })),
      ],
    },
  }) as Scene

const script = (code: string, entry?: string): BTNode =>
  ({ type: 'script', id: 'gen', language: 'typescript', code, ...(entry ? { entry } : {}) }) as BTNode

afterEach(() => setScriptRunner(null))

describe('script leaves (§2.8)', () => {
  it('splices emitted actions into the schedule', () => {
    const sim = simulate(
      sceneWith(
        script(`function* main() {
          for (let i = 0; i < 3; i++) yield { action: 'translate', target: 'ring_1', duration: 1, params: { to: { x: i, y: 0, z: 0 } } }
        }`),
      ),
    )
    expect(sim.schedule.map((e) => [e.start, e.duration])).toEqual([
      [0, 1],
      [1, 1],
      [2, 1],
    ])
    expect(sim.duration).toBe(3)
    expect(sim.unresolved).toEqual([])
  })

  it('a recursive hanoi generator is ONE entity that produces 127 moves', () => {
    // The point of the construct (§4.3 procedurality): `hanoi disks=7` against 127 spelled-out
    // children. If this ever regresses, the format is back to enumeration.
    const sim = simulate(
      sceneWith(
        script(`function* solve(n, from, to, via) {
          if (n === 0) return
          yield* solve(n - 1, from, via, to)
          yield { action: 'translate', target: 'ring_' + n, duration: 0.25, params: { to: { x: to * 100, y: 0, z: 0 } } }
          yield* solve(n - 1, via, to, from)
        }
        function* main() { yield* solve(7, 0, 2, 1) }`),
        ['ring_1', 'ring_2', 'ring_3', 'ring_4', 'ring_5', 'ring_6', 'ring_7'],
      ),
    )
    expect(sim.schedule.length).toBe(127)
    expect(sim.unresolved).toEqual([])
    // the largest disk moves exactly once, at the midpoint of an optimal solve
    const largest = sim.schedule.filter((e) => e.target === 'ring_7')
    expect(largest.length).toBe(1)
    expect(sim.schedule.indexOf(largest[0]!)).toBe(63)
  })

  it('the generated schedule actually moves geometry', () => {
    const scene = sceneWith(
      script(`function* main() { yield { action: 'translate', target: 'ring_1', duration: 2, params: { to: { x: 10, y: 0, z: 0 } } } }`),
    )
    const x = (t: number): number => resolveScene(scene, t).primitives.find((p) => p.id === 'ring_1')!.worldMatrix[12]!
    expect(x(0)).toBe(0)
    expect(x(1)).toBe(5)
    expect(x(2)).toBe(10)
  })

  it('accepts a plain function returning an array', () => {
    const sim = simulate(
      sceneWith(script(`function build() { return [{ action: 'translate', target: 'ring_1', duration: 1, params: { to: { x: 1, y: 0, z: 0 } } }] }`, 'build')),
    )
    expect(sim.schedule.length).toBe(1)
  })

  it('reports a missing entry function instead of silently scheduling nothing', () => {
    const sim = simulate(sceneWith(script(`function notMain() {}`)))
    expect(sim.schedule).toEqual([])
    expect(sim.unresolved[0]?.detail).toMatch(/defines no function named "main"/)
  })

  it('surfaces a throwing script as an unresolved point, not a crash', () => {
    const sim = simulate(sceneWith(script(`function* main() { throw new Error('boom') }`)))
    expect(sim.unresolved[0]?.reason).toBe('script')
    expect(sim.unresolved[0]?.detail).toMatch(/boom/)
  })

  it('bounds a non-terminating generator', () => {
    const sim = simulate(
      sceneWith(script(`function* main() { while (true) yield { action: 'translate', target: 'ring_1', duration: 0, params: { to: { x: 0, y: 0, z: 0 } } } }`)),
    )
    expect(sim.unresolved[0]?.detail).toMatch(/not terminating/)
  })

  it('refuses nondeterminism so a scene grades the same every run', () => {
    const sim = simulate(sceneWith(script(`function* main() { yield { action: 'translate', target: 'ring_1', duration: Math.random(), params: {} } }`)))
    expect(sim.unresolved[0]?.detail).toMatch(/Math.random/)
  })

  it('does not hand the script the host environment', () => {
    const sim = simulate(sceneWith(script(`function* main() { yield { action: 'translate', target: String(typeof process) + String(typeof globalThis), duration: 0, params: { to: { x: 0, y: 0, z: 0 } } } }`)))
    expect(sim.schedule[0]?.target).toBe('undefinedundefined')
  })

  it('a host can install a stricter runner', () => {
    setScriptRunner({
      run: () => [{ action: 'translate', target: 'ring_1', duration: 5, params: { to: { x: 1, y: 0, z: 0 } } }],
    })
    const sim = simulate(sceneWith(script(`function* main() { yield 'ignored' }`)))
    expect(sim.schedule).toHaveLength(1)
    expect(sim.schedule[0]?.duration).toBe(5)
  })
})
