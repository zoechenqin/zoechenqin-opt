/**
 * Spatial math: Vec3, quaternions, and column-major 4x4 matrices.
 * Composition happens in matrix space (§3.3), so rotation encoding never leaks in here.
 */
import type { AxisAngle, Vec2, Vec3 } from './types'

// ----- Vec2 (planar extent only, never a world coordinate) -----
export const lerpVec2 = (a: Vec2, b: Vec2, u: number): Vec2 => ({
  x: a.x + (b.x - a.x) * u,
  y: a.y + (b.y - a.y) * u,
})

// ----- Vec3 -----
export const vec3 = (x: number, y: number, z: number): Vec3 => ({ x, y, z })
export const addVec3 = (a: Vec3, b: Vec3): Vec3 => ({ x: a.x + b.x, y: a.y + b.y, z: a.z + b.z })
export const subVec3 = (a: Vec3, b: Vec3): Vec3 => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z })
export const scaleVec3 = (a: Vec3, s: number): Vec3 => ({ x: a.x * s, y: a.y * s, z: a.z * s })
export const lengthVec3 = (a: Vec3): number => Math.hypot(a.x, a.y, a.z)
export function normalizeVec3(a: Vec3): Vec3 {
  const len = lengthVec3(a)
  return len === 0 ? { x: 0, y: 0, z: 0 } : { x: a.x / len, y: a.y / len, z: a.z / len }
}
export const lerpVec3 = (a: Vec3, b: Vec3, u: number): Vec3 => ({
  x: a.x + (b.x - a.x) * u,
  y: a.y + (b.y - a.y) * u,
  z: a.z + (b.z - a.z) * u,
})

// ----- Quaternion [x, y, z, w] -----
export type Quat = [number, number, number, number]

/** q = (sin(θ/2)·axis, cos(θ/2)); the cleanest axis-angle→quat conversion (§3.9). */
export function axisAngleToQuat(aa: AxisAngle): Quat {
  const axis = normalizeVec3(aa.axis)
  const half = aa.angle / 2
  const s = Math.sin(half)
  return [axis.x * s, axis.y * s, axis.z * s, Math.cos(half)]
}

export function quatToAxisAngle(q: Quat): AxisAngle {
  const [x, y, z, wRaw] = q
  const w = Math.min(1, Math.max(-1, wRaw))
  const angle = 2 * Math.acos(w)
  const s = Math.sqrt(1 - w * w)
  if (s < 1e-8) return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
  return { axis: { x: x / s, y: y / s, z: z / s }, angle }
}

/** Spherical linear interpolation for smooth rotation tracks (§3.9). */
export function slerp(a: Quat, b: Quat, u: number): Quat {
  let [ax, ay, az, aw] = a
  const [bx, by, bz, bw] = b
  let dot = ax * bx + ay * by + az * bz + aw * bw
  if (dot < 0) {
    ax = -ax
    ay = -ay
    az = -az
    aw = -aw
    dot = -dot
  }
  if (dot > 0.9995) {
    // Nearly parallel — linear interpolate + normalize.
    const rx = ax + (bx - ax) * u
    const ry = ay + (by - ay) * u
    const rz = az + (bz - az) * u
    const rw = aw + (bw - aw) * u
    const len = Math.hypot(rx, ry, rz, rw) || 1
    return [rx / len, ry / len, rz / len, rw / len]
  }
  const theta0 = Math.acos(dot)
  const theta = theta0 * u
  const sinTheta0 = Math.sin(theta0)
  const s0 = Math.sin(theta0 - theta) / sinTheta0
  const s1 = Math.sin(theta) / sinTheta0
  return [ax * s0 + bx * s1, ay * s0 + by * s1, az * s0 + bz * s1, aw * s0 + bw * s1]
}

// ----- Mat4 (column-major, WebGL/glTF convention) -----
export type Mat4 = [
  number, number, number, number,
  number, number, number, number,
  number, number, number, number,
  number, number, number, number,
]

export const identityMat4 = (): Mat4 => [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]

export const translationMat4 = (v: Vec3): Mat4 => [
  1, 0, 0, 0,
  0, 1, 0, 0,
  0, 0, 1, 0,
  v.x, v.y, v.z, 1,
]

export const scalingMat4 = (v: Vec3): Mat4 => [
  v.x, 0, 0, 0,
  0, v.y, 0, 0,
  0, 0, v.z, 0,
  0, 0, 0, 1,
]

export function rotationMat4(q: Quat): Mat4 {
  const [x, y, z, w] = q
  const x2 = x + x
  const y2 = y + y
  const z2 = z + z
  const xx = x * x2
  const xy = x * y2
  const xz = x * z2
  const yy = y * y2
  const yz = y * z2
  const zz = z * z2
  const wx = w * x2
  const wy = w * y2
  const wz = w * z2
  return [
    1 - (yy + zz), xy + wz, xz - wy, 0,
    xy - wz, 1 - (xx + zz), yz + wx, 0,
    xz + wy, yz - wx, 1 - (xx + yy), 0,
    0, 0, 0, 1,
  ]
}

/** out = a * b (column-major), applied to a point as a·(b·v). */
export function multiplyMat4(a: Mat4, b: Mat4): Mat4 {
  const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3]
  const a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7]
  const a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11]
  const a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15]
  const out = identityMat4()
  let b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3]
  out[0] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30
  out[1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31
  out[2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32
  out[3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33
  b0 = b[4]; b1 = b[5]; b2 = b[6]; b3 = b[7]
  out[4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30
  out[5] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31
  out[6] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32
  out[7] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33
  b0 = b[8]; b1 = b[9]; b2 = b[10]; b3 = b[11]
  out[8] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30
  out[9] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31
  out[10] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32
  out[11] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33
  b0 = b[12]; b1 = b[13]; b2 = b[14]; b3 = b[15]
  out[12] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30
  out[13] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31
  out[14] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32
  out[15] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33
  return out
}

/** Local transform: M = T(position) · R · S · T(-anchor). The anchor maps to `position`. */
export function composeMat4(position: Vec3, q: Quat, scale: Vec3, anchor: Vec3): Mat4 {
  const t = translationMat4(position)
  const r = rotationMat4(q)
  const s = scalingMat4(scale)
  const negAnchor = translationMat4({ x: -anchor.x, y: -anchor.y, z: -anchor.z })
  return multiplyMat4(multiplyMat4(multiplyMat4(t, r), s), negAnchor)
}

/** Inverse of a 4x4 matrix (returns identity if singular). Used for camera view (§4). */
export function invertMat4(m: Mat4): Mat4 {
  const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3]
  const a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7]
  const a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11]
  const a30 = m[12], a31 = m[13], a32 = m[14], a33 = m[15]
  const b00 = a00 * a11 - a01 * a10
  const b01 = a00 * a12 - a02 * a10
  const b02 = a00 * a13 - a03 * a10
  const b03 = a01 * a12 - a02 * a11
  const b04 = a01 * a13 - a03 * a11
  const b05 = a02 * a13 - a03 * a12
  const b06 = a20 * a31 - a21 * a30
  const b07 = a20 * a32 - a22 * a30
  const b08 = a20 * a33 - a23 * a30
  const b09 = a21 * a32 - a22 * a31
  const b10 = a21 * a33 - a23 * a31
  const b11 = a22 * a33 - a23 * a32
  const det = b00 * b11 - b01 * b10 + b02 * b09 + b03 * b08 - b04 * b07 + b05 * b06
  if (det === 0) return identityMat4()
  const d = 1 / det
  return [
    (a11 * b11 - a12 * b10 + a13 * b09) * d,
    (a02 * b10 - a01 * b11 - a03 * b09) * d,
    (a31 * b05 - a32 * b04 + a33 * b03) * d,
    (a22 * b04 - a21 * b05 - a23 * b03) * d,
    (a12 * b08 - a10 * b11 - a13 * b07) * d,
    (a00 * b11 - a02 * b08 + a03 * b07) * d,
    (a32 * b02 - a30 * b05 - a33 * b01) * d,
    (a20 * b05 - a22 * b02 + a23 * b01) * d,
    (a10 * b10 - a11 * b08 + a13 * b06) * d,
    (a01 * b08 - a00 * b10 - a03 * b06) * d,
    (a30 * b04 - a31 * b02 + a33 * b00) * d,
    (a21 * b02 - a20 * b04 - a23 * b00) * d,
    (a11 * b07 - a10 * b09 - a12 * b06) * d,
    (a00 * b09 - a01 * b07 + a02 * b06) * d,
    (a31 * b01 - a30 * b03 - a32 * b00) * d,
    (a20 * b03 - a21 * b01 + a22 * b00) * d,
  ]
}

/** Apply an affine matrix to a point (w assumed 1). */
export function transformPoint(m: Mat4, p: Vec3): Vec3 {
  return {
    x: m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12],
    y: m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13],
    z: m[2] * p.x + m[6] * p.y + m[10] * p.z + m[14],
  }
}
