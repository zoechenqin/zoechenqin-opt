/** Small constructors/queries for building and navigating scenes. */
import type { Arrangement, BTNode, Entity, EntityId, Scene, Transform, Vec3 } from './types'
import { constant } from './animatable'
import { SCHEMA_VERSION } from './version'

export const identityTransform = (): Transform => ({
  position: constant({ x: 0, y: 0, z: 0 }),
  rotation: constant({ axis: { x: 0, y: 0, z: 1 }, angle: 0 }),
  scale: constant({ x: 1, y: 1, z: 1 }),
  anchor: { x: 0, y: 0, z: 0 },
})

export const translateTransform = (p: Vec3): Transform => ({
  ...identityTransform(),
  position: constant(p),
})

/** Depth-first search for an entity by id. */
/**
 * A valid scene with nothing in it — the starting point for building one up by correction events,
 * so the whole construction is on the record rather than only the edits made after a first draft.
 */
export function emptyScene(opts: { id?: string; space?: '2d' | '3d'; width?: number; height?: number } = {}): Scene {
  const space = opts.space ?? '2d'
  const width = opts.width ?? 1920
  const height = opts.height ?? 1080
  return {
    schemaVersion: SCHEMA_VERSION,
    id: opts.id ?? 'untitled',
    space,
    canvas: { width, height, background: { r: 0.06, g: 0.06, b: 0.09, a: 1 } },
    camera: {
      id: 'camera',
      transform:
        space === '3d'
          ? { ...identityTransform(), position: constant({ x: 0, y: 0, z: 900 }) }
          : identityTransform(),
      projection:
        space === '3d'
          ? { type: 'perspective', fovY: constant(50), near: 0.1, far: 10_000 }
          : { type: 'orthographic', height: constant(height) },
    },
    root: { id: 'root', word: 'scene', transform: identityTransform(), children: [] },
  }
}

export function findEntity(entity: Entity, id: EntityId): Entity | undefined {
  if (entity.id === id) return entity
  {
    for (const child of entity.children) {
      const found = findEntity(child, id)
      if (found) return found
    }
  }
  return undefined
}

/**
 * What an entity IS follows from what it HAS (types.ts). These read the two structural components
 * so callers do not repeat the unwrapping — and so the one place that knows a component is stored
 * as `{ kind: 'const', value }` is here rather than in every consumer.
 */
export const arrangementOf = (entity: Entity): Arrangement | undefined => {
  const slot = entity.components?.arrangement
  return slot?.kind === 'const' ? slot.value : undefined
}

export const behaviorOf = (entity: Entity): BTNode | undefined => {
  const slot = entity.components?.behavior
  return slot?.kind === 'const' ? slot.value : undefined
}

/** True when this entity stamps copies — the old `kind === 'arrangement'`. */
export const isArrangement = (entity: Entity): boolean => arrangementOf(entity) !== undefined

/** True when this entity carries a program — the old `kind === 'behavior'`. */
export const hasBehavior = (entity: Entity): boolean => behaviorOf(entity) !== undefined

/**
 * An entity that only contains — no arrangement, no behavior, nothing drawable. This is what the
 * old `kind === 'group'` meant, and it is the precondition for splicing an entity out of the tree:
 * dissolving one that stamped copies or drove a tree would silently drop what it did.
 */
export const isPlainGroup = (entity: Entity): boolean => {
  if (arrangementOf(entity) !== undefined || behaviorOf(entity) !== undefined) return false
  const drawables = new Set(['circle','rect','polygon','line','path','text','box','sphere','cylinder','cone','torus','mesh'])
  return !Object.keys(entity.components ?? {}).some((k) => drawables.has(k))
}
