/**
 * Script leaves (Design §2.8): the construct that makes a behavior tree Turing-complete.
 *
 * Composites are finite and inline — no call, no recursion, no parameterized reuse — so without
 * this a procedure can only be written out move by move. A leaf runs during simulation and its
 * emitted actions are spliced into the schedule in its place, so adapters consume the resolved
 * schedule rather than each re-running the program and disagreeing about it.
 *
 * The default runner compiles with `new Function` under `"use strict"`, shadowing ambient names,
 * because scene-ir also runs in the browser and cannot use `node:vm`. Two limits worth knowing:
 * it is a capability fence rather than a security boundary (`eval` in particular cannot be
 * shadowed), and a loop that never yields cannot be interrupted, since there is no instruction
 * counter to hook. Install a stricter runner with `setScriptRunner` for untrusted input.
 *
 * Nondeterminism is refused rather than sandboxed: a scene must resolve to the same schedule every
 * run to be renderable and gradable, so `Math.random` and `Date` are unavailable.
 */
import type { BTNode } from './types'

export interface ScriptLimits {
  /** Upper bound on emitted items. Bounds a yielding infinite generator. */
  maxActions: number
  /** How deep a script may emit further script leaves. */
  maxDepth: number
}

export const DEFAULT_SCRIPT_LIMITS: ScriptLimits = { maxActions: 20_000, maxDepth: 8 }

export interface ScriptRunner {
  /** Run `code`, call `entry`, and return whatever it yields, un-normalized. */
  run(code: string, entry: string, limits: ScriptLimits): unknown[]
}

/** Names a script leaf must not see. `Function`/`eval` are shadowed to close the obvious escape. */
const SHADOWED = [
  'globalThis',
  'window',
  'self',
  'global',
  'process',
  'require',
  'module',
  'exports',
  'fetch',
  'XMLHttpRequest',
  'WebSocket',
  'Worker',
  'importScripts',
  // `eval` is deliberately absent: strict mode forbids it as a binding name, so it cannot be
  // shadowed this way. It stays reachable, which is one of the reasons the doc comment calls this
  // a capability fence rather than a security boundary. Note that an `eval` call still runs in
  // this shadowed scope, so it inherits every substitution above.
  'Function',
  'setTimeout',
  'setInterval',
  'setImmediate',
  'queueMicrotask',
  'Promise',
  'Proxy',
  'Reflect',
  'Date',
]

function deterministicMath(): unknown {
  const out: Record<string, unknown> = Object.create(null)
  for (const key of Object.getOwnPropertyNames(Math)) out[key] = (Math as unknown as Record<string, unknown>)[key]
  out['random'] = (): never => {
    throw new Error(
      'scene-ir: Math.random() is unavailable in a script leaf — a scene must resolve to the same ' +
        'schedule on every run to be renderable and gradable. Derive variation from the loop index.',
    )
  }
  return Object.freeze(out)
}

/**
 * The portable default. Compiles with `new Function`, so it works in Node and the browser alike.
 */
export const defaultScriptRunner: ScriptRunner = {
  run(code, entry, limits) {
    let factory: (...args: unknown[]) => unknown
    try {
      factory = new Function(
        ...SHADOWED,
        'Math',
        `"use strict";\n${code}\n;return typeof ${entry} === "function" ? ${entry} : undefined;`,
      ) as (...args: unknown[]) => unknown
    } catch (err) {
      throw new Error(`scene-ir: script leaf failed to compile — ${(err as Error).message}`)
    }

    const fn = factory(...SHADOWED.map(() => undefined), deterministicMath())
    if (typeof fn !== 'function') {
      throw new Error(
        `scene-ir: script leaf defines no function named "${entry}". Declare it as ` +
          `\`function* ${entry}() { yield … }\` (or a plain function returning an array); ` +
          `\`export\` is not available inside a script leaf.`,
      )
    }

    let iterable: unknown
    try {
      iterable = (fn as () => unknown)()
    } catch (err) {
      throw new Error(`scene-ir: script leaf "${entry}" threw — ${(err as Error).message}`)
    }
    if (iterable === undefined || iterable === null) return []
    if (typeof (iterable as Iterable<unknown>)[Symbol.iterator] !== 'function') {
      throw new Error(
        `scene-ir: script leaf "${entry}" returned ${typeof iterable}; it must yield or return an ` +
          `iterable of actions.`,
      )
    }

    const out: unknown[] = []
    try {
      for (const item of iterable as Iterable<unknown>) {
        out.push(item)
        if (out.length > limits.maxActions) {
          throw new Error(
            `scene-ir: script leaf "${entry}" emitted more than ${limits.maxActions} actions — ` +
              `it is probably not terminating.`,
          )
        }
      }
    } catch (err) {
      if ((err as Error).message.startsWith('scene-ir:')) throw err
      throw new Error(`scene-ir: script leaf "${entry}" threw while emitting — ${(err as Error).message}`)
    }
    return out
  },
}

let activeRunner: ScriptRunner = defaultScriptRunner

/** Swap in a stricter host runner (`node:vm` with a timeout, a Worker, …). Pass null to restore. */
export function setScriptRunner(runner: ScriptRunner | null): void {
  activeRunner = runner ?? defaultScriptRunner
}

const BT_TYPES = new Set(['sequence', 'selector', 'parallel', 'decorator', 'condition', 'action', 'script', 'forEach'])

/**
 * A script may yield a whole BT entity, or the common case: a bare action without its `type`.
 * Accepting both keeps `yield { action: 'translate', target, duration, params }` readable.
 */
function normalize(item: unknown, entry: string, index: number): BTNode {
  if (typeof item !== 'object' || item === null) {
    throw new Error(`scene-ir: script leaf "${entry}" yielded ${typeof item} at index ${index}; expected an action object.`)
  }
  const rec = item as Record<string, unknown>
  if (typeof rec['type'] === 'string') {
    if (!BT_TYPES.has(rec['type'] as string)) {
      throw new Error(`scene-ir: script leaf "${entry}" yielded unknown entity type "${String(rec['type'])}" at index ${index}.`)
    }
    return rec as unknown as BTNode
  }
  if (typeof rec['action'] === 'string') {
    if (typeof rec['target'] !== 'string') {
      throw new Error(`scene-ir: script leaf "${entry}" yielded an action with no target at index ${index}.`)
    }
    return {
      type: 'action',
      ...(typeof rec['id'] === 'string' ? { id: rec['id'] } : {}),
      action: rec['action'],
      target: rec['target'],
      duration: typeof rec['duration'] === 'number' ? rec['duration'] : 0,
      params: (rec['params'] as Record<string, unknown>) ?? {},
    } as BTNode
  }
  throw new Error(
    `scene-ir: script leaf "${entry}" yielded an object with neither "type" nor "action" at index ${index}.`,
  )
}

/**
 * Execute a script leaf and return the BT entities it emits, to be walked in its place.
 */
export function runScriptLeaf(
  script: { code: string; entry?: string; id?: string },
  limits: ScriptLimits = DEFAULT_SCRIPT_LIMITS,
): BTNode[] {
  const entry = script.entry ?? 'main'
  const raw = activeRunner.run(script.code, entry, limits)
  return raw.map((item, i) => normalize(item, entry, i))
}

/**
 * Run a `forEach` row source. Unlike a script LEAF, this must return plain data rows — the same
 * constraint an arrangement's `script` point generator lives under, where it returns `Vec3[]` rather
 * than finished entities (§2.2). Rows stay indexable and correctable; emitted actions would not.
 */
export function runScriptRows(
  source: { code: string; entry?: string },
  limits: ScriptLimits = DEFAULT_SCRIPT_LIMITS,
): Array<Record<string, unknown>> {
  const entry = source.entry ?? 'main'
  const raw = activeRunner.run(source.code, entry, limits)
  return raw.map((item, i) => {
    if (typeof item !== 'object' || item === null || Array.isArray(item)) {
      throw new Error(`scene-ir: forEach source "${entry}" yielded ${typeof item} at index ${i}; expected a data row object.`)
    }
    const rec = item as Record<string, unknown>
    if (typeof rec['action'] === 'string' || typeof rec['type'] === 'string') {
      throw new Error(
        `scene-ir: forEach source "${entry}" yielded an action at index ${i}. A source produces ` +
          `DATA; the motion belongs in the template, which is what keeps it editable. Yield ` +
          `plain rows such as { disk: 3, toX: 500, restY: -120 }.`,
      )
    }
    return rec
  })
}
