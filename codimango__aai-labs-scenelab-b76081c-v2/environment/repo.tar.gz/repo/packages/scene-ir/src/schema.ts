import { z } from 'zod'
import { assignBehaviorIds } from './btid'
import type { BTNode, ComponentMap, Entity, Keyframe } from './types'

const zVec3 = z.object({ x: z.number(), y: z.number(), z: z.number() })
const zVec2 = z.object({ x: z.number(), y: z.number() })
const zAxisAngle = z.object({ axis: zVec3, angle: z.number() })
const zColor = z.object({ r: z.number(), g: z.number(), b: z.number(), a: z.number() })

const zEasing = z.union([
  z.enum(['linear', 'easeIn', 'easeOut', 'easeInOut']),
  z.object({ cubicBezier: z.tuple([z.number(), z.number(), z.number(), z.number()]) }),
])

// Two keyframes is the floor: one is a constant wearing a timeline, which belongs in the value
// slot instead. Times are local to the leaf and must not run backwards (§4.2).
// The cast is the same pin as `zComponentMap` below — z.unknown() infers `value?: unknown`, which
// does not satisfy Keyframe<unknown>'s required `value`. The runtime shape is already correct.
const zCurveKeyframes = z
  .array(z.object({ t: z.number().min(0), value: z.unknown(), easing: zEasing.optional() }))
  .min(2)
  .refine((kfs) => kfs.every((k, i) => i === 0 || k.t >= kfs[i - 1]!.t), {
    message: 'curve keyframes must be ordered by ascending t (times are local to the leaf)',
  }) as unknown as z.ZodType<Keyframe<unknown>[]>

// Value slots have one variant (§4.3); keyframes belong in behavior-tree curve leaves.
const zAnimatable = <T extends z.ZodTypeAny>(value: T) =>
  z.object({ kind: z.literal('const', {
    errorMap: () => ({ message: "expected { kind: 'const', value }; keyframes belong in a behavior-tree `curve` leaf, not in a value (§4.2)" }),
  }), value })

const zTransform = z.object({
  position: zAnimatable(zVec3),
  rotation: zAnimatable(zAxisAngle),
  scale: zAnimatable(zVec3),
  anchor: zVec3,
})

const zStyle = z.object({
  fill: zAnimatable(zColor).optional(),
  stroke: zAnimatable(zColor).optional(),
  strokeWidth: zAnimatable(z.number()).optional(),
})

const zPathSegment = z.discriminatedUnion('type', [
  z.object({ type: z.literal('move'), to: zVec3 }),
  z.object({ type: z.literal('line'), to: zVec3 }),
  z.object({ type: z.literal('cubicBezier'), to: zVec3, cp1: zVec3, cp2: zVec3 }),
  z.object({ type: z.literal('quadraticBezier'), to: zVec3, cp: zVec3 }),
])

// `arrangement` and `behavior` are named explicitly so they keep real validation. Dropping them
// into the open catchall would have parsed any shape at all — a behavior tree is the part of a
// scene a model is most likely to get wrong, and it must not become the least checked.
// The cast pins the inferred type: zod infers `value?: unknown` for z.unknown(), which does not
// satisfy Animatable<unknown>'s required `value`. The runtime shape is already correct.
// z.lazy defers the reference: zArrangement and zBTNode are declared below, and an entity's
// components can contain either, so the two definitions are mutually recursive.
const zComponentMap = z
  .lazy(() =>
    z
      .object({
        arrangement: zAnimatable(zArrangement).optional(),
        behavior: zAnimatable(zBTNode).optional(),
      })
      .catchall(zAnimatable(z.unknown())),
  )
  .optional() as unknown as z.ZodType<ComponentMap | undefined>

const baseEntityFields = {
  id: z.string().regex(/^[A-Za-z0-9_.]+$/, { message: "id alphanumeric + '_' and '.' only (A-Za-z0-9_.), ':' reserved for procedural expansion and '-' not allowed" }),
  word: z.string(),
  name: z.string().optional(),
  transform: zTransform,
  locked: z.boolean().optional(),
  enabled: z.boolean().optional(),
  template: z.boolean().optional(),
  synthesized: z
    .object({ from: z.string(), provider: z.string(), version: z.string(), seed: z.number(), hash: z.string() })
    .optional(),
  components: zComponentMap,
}

const zInstanceOverride = z.object({
  transform: zTransform.optional(),
  enabled: z.boolean().optional(),
  locked: z.boolean().optional(),
  components: zComponentMap,
})

const zPointGenerator = z.discriminatedUnion('type', [
  z.object({ type: z.literal('grid'), countX: z.number().int().min(1), countY: z.number().int().min(1), spacingX: z.number(), spacingY: z.number(), start: zVec3.optional() }),
  z.object({ type: z.literal('line'), count: z.number().int().min(1), step: zTransform }),
  z.object({ type: z.literal('radial'), count: z.number().int().min(1), radius: z.number(), axis: zVec3.optional() }),
  z.object({ type: z.literal('poisson'), count: z.number().int().min(1), minDist: z.number(), seed: z.number(), bounds: z.object({ min: zVec3, max: zVec3 }).optional() }),
  z.object({ type: z.literal('pathFollow'), pathId: z.string(), count: z.number().int().min(1), spacing: z.number() }),
  z.object({ type: z.literal('script'), language: z.enum(['typescript', 'javascript']), code: z.string(), entry: z.string().optional() }),
])

const zArrangementOpInternal = z.discriminatedUnion('type', [
  z.object({ id: z.string(), type: z.literal('points'), generator: zPointGenerator }),
  z.object({ id: z.string(), type: z.literal('instance'), templates: z.array(z.string()), points: z.string(), overrides: z.record(zInstanceOverride).optional() }),
])

const zArrangement = z.object({
  ops: z.array(zArrangementOpInternal),
  edges: z.array(z.object({ from: z.string(), to: z.string() })),
})

const zBTNode: z.ZodType<BTNode> = z.lazy(() =>
  z.discriminatedUnion('type', [
    z.object({ type: z.literal('sequence'), id: z.string().optional(), children: z.array(zBTNode), speed: z.number().optional(), repeat: z.number().int().min(1).optional(), loop: z.boolean().optional() }),
    z.object({ type: z.literal('selector'), id: z.string().optional(), children: z.array(zBTNode) }),
    z.object({ type: z.literal('parallel'), id: z.string().optional(), children: z.array(zBTNode), policy: z.enum(['all', 'any']).optional() }),
    z.object({
      type: z.literal('decorator'),
      id: z.string().optional(),
      decorator: z.enum(['timeScale', 'invert', 'enabled', 'locked', 'motionStyle', 'script']),
      params: z.record(z.unknown()),
      child: zBTNode,
    }),
    z.object({
      type: z.literal('condition'),
      id: z.string().optional(),
      on: z.enum(['contact', 'collision', 'proximity', 'time', 'always', 'beat', 'script']),
      source: z.array(z.string()).optional(),
      threshold: z.number().optional(),
      beat: z.number().optional(),
      params: z.record(z.unknown()).optional(),
      child: zBTNode.optional(),
    }),
    z.object({ type: z.literal('action'), id: z.string().optional(), action: z.enum(['translate', 'scale', 'rotate', 'setEnabled', 'setLocked', 'upsertComponent', 'emitParticles', 'script']), target: z.union([z.string(), z.object({ templateId: z.string(), index: z.string() })]), duration: z.number(), params: z.record(z.unknown()) }),
    z.object({ type: z.literal('script'), id: z.string().optional(), language: z.enum(['typescript', 'javascript']), code: z.string(), entry: z.string().optional() }),
    z.object({
      type: z.literal('curve'),
      id: z.string().optional(),
      target: z.union([z.string(), z.object({ templateId: z.string(), index: z.string() })]),
      property: z.string().min(1),
      keyframes: zCurveKeyframes,
    }),
    z.object({
      type: z.literal('forEach'),
      id: z.string().optional(),
      source: z.union([
        z.object({ kind: z.literal('rows'), rows: z.array(z.record(z.unknown())) }),
        z.object({ kind: z.literal('script'), language: z.enum(['typescript', 'javascript']), code: z.string(), entry: z.string().optional() }),
      ]),
      template: zBTNode,
      overrides: z.record(z.record(z.unknown())).optional(),
      mode: z.enum(['sequence', 'parallel']).optional(),
    }),
  ])
    // Action params are typed per action kind. They were `z.record(z.unknown())`, so a model could
    // write `{from:"A", to:"C"}` — peg names, not coordinates — and the scene would parse, render,
    // and quietly do nothing. Checking here puts the error where the author sees it, rather than
    // deep in resolve after the artifact already looks finished. (Refined on the union rather than
    // the member: a `superRefine` yields a ZodEffects, which cannot be a discriminated-union option.)
    .superRefine((n, ctx) => {
      if (n.type !== 'action') return
      const p = (n.params ?? {}) as Record<string, unknown>
      // A forEach template holds unbound params: `{"$":"toX"}` in a value slot, `"${disk}"` in a
      // string. Those are legal here and only become concrete when a row is stamped, so treat a
      // binding reference as satisfying whatever it stands in for.
      const isBinding = (v: unknown): boolean =>
        (typeof v === 'object' && v !== null && typeof (v as Record<string, unknown>)['$'] === 'string') ||
        (typeof v === 'string' && /\$\{[A-Za-z_][A-Za-z0-9_]*\}/.test(v))
      const isNum = (v: unknown): boolean => typeof v === 'number' || isBinding(v)
      const isVec3 = (v: unknown): boolean =>
        isBinding(v) ||
        (typeof v === 'object' && v !== null && ['x', 'y', 'z'].every((k) => isNum((v as Record<string, unknown>)[k])))
      const need = (ok: boolean, message: string): void => {
        if (!ok) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['params'], message })
      }
      if (n.action === 'translate' || n.action === 'scale') {
        need(
          isVec3(p['to']) || isVec3(p['by']),
          `${n.action} needs params.to {x,y,z} (absolute) or params.by {x,y,z} (relative); params are ` +
            `scene-graph values, not domain names — resolve something like a peg id to coordinates first`,
        )
      } else if (n.action === 'rotate') {
        const to = p['to'] as { axis?: unknown; angle?: unknown } | undefined
        need(
          typeof to === 'object' && to !== null && isVec3(to.axis) && isNum(to.angle),
          'rotate needs params.to { axis: {x,y,z}, angle: <degrees> }',
        )
      } else if (n.action === 'setEnabled' || n.action === 'setLocked') {
        need(typeof p['value'] === 'boolean' || isBinding(p['value']), `${n.action} needs params.value true|false`)
      }
    }),
)

const zEntity: z.ZodType<Entity> = z.lazy(() =>
  z.object({ ...baseEntityFields, children: z.array(zEntity) }),
)

const zProjection = z.discriminatedUnion('type', [
  z.object({ type: z.literal('orthographic'), height: zAnimatable(z.number()) }),
  z.object({ type: z.literal('perspective'), fovY: zAnimatable(z.number()), near: z.number(), far: z.number() }),
])

const zCamera = z.object({ id: z.string(), transform: zTransform, projection: zProjection })

export const SceneSchema = z.object({
  schemaVersion: z.string(),
  id: z.string(),
  space: z.enum(['2d', '3d']),
  canvas: z.object({ width: z.number(), height: z.number(), background: zColor.optional() }),
  duration: z.number().optional(),
  fps: z.number().optional(),
  embeddings: z.record(z.union([
    z.object({ phrase: z.string() }),
    z.object({ inversion: z.object({ images: z.array(z.string()), steps: z.number().optional(), model: z.string() }) }),
  ])).optional(),
  camera: zCamera,
  root: zEntity,
  units: z.string().optional(),
  meta: z.record(z.unknown()).optional(),
})

export const CorrectionPairSchema = z.object({
  schemaVersion: z.string(),
  id: z.string(),
  prompt: z.string().optional(),
  before: SceneSchema,
  after: SceneSchema,
  events: z.array(z.unknown()),
  adapter: z.object({ renderer: z.string(), beforeCode: z.string(), afterCode: z.string() }).optional(),
  provenance: z.object({ model: z.string().optional(), createdAt: z.string(), stage: z.enum(['pre-render', 'post-render']), annotator: z.string().optional() }),
})

// Parsing is the gate (§5), so it is where the behavior-tree id guarantee is established: every
// scene that got in this way has an id on every tree node and is therefore fully correctable,
// without requiring the author — usually a model — to invent them (§4.6).
export function parseScene(input: unknown) {
  return assignBehaviorIds(SceneSchema.parse(input))
}

export function safeParseScene(input: unknown) {
  const result = SceneSchema.safeParse(input)
  return result.success
    ? { success: true, scene: assignBehaviorIds(result.data) }
    : { success: false, error: result.error }
}

export function parseCorrectionPair(input: unknown) {
  return CorrectionPairSchema.parse(input)
}
