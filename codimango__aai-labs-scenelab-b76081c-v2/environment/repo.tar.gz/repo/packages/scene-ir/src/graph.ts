/**
 * The scene is a DAG, not a tree. `children` is only the containment relation — the one that
 * drives transform inheritance and culling. On top of it sit reference edges: an `instance` op
 * consumes any entity in the scene as a template (`resolve.ts` looks templates up from `scene.root`,
 * so the producer can live anywhere), constraints target other entities, links join two of them, and
 * a behavior tree names the entities it drives.
 *
 * Nothing enforced the "acyclic" half of that until this module. The shape schema in `schema.ts`
 * validates one entity at a time and cannot see a cycle spanning two of them, so a scene where a
 * template transitively instantiates itself parsed cleanly and then recursed forever inside
 * `resolveScene`. This walks the whole edge set instead, and reports the cycle path.
 *
 * Two classes of cycle, deliberately graded differently:
 *
 *   - contains / instantiates — the EXPANSION edges. A cycle here is unrepresentable: stamping the
 *     template requires having already stamped it. These are errors.
 *   - constrains — evaluation edges (lookAt, link, BT targets). Two entities aiming at each other is
 *     circular but finite; `resolveScene` reads positions in one pass after the primitives exist,
 *     so it terminates and merely gives an order-dependent answer. These are warnings.
 */
import { BT_ID_PATTERN, collectBehaviorIds } from './btid'
import { arrangementOf, behaviorOf } from './builders'
import type { Animatable, BTNode, LinkComponent, Entity, EntityId, EntityRef, Scene } from './types'

export type RefEdgeKind = 'contains' | 'instantiates' | 'constrains'

export interface RefEdge {
  from: EntityId
  to: EntityId
  kind: RefEdgeKind
  /** Where the reference is written, so an error can point at the field to fix. */
  via: string
}

export interface GraphCycle {
  /** Entity ids in cycle order. The last edge's `to` closes the loop back onto `path[0]`. */
  path: EntityId[]
  edges: RefEdge[]
}

export type GraphDiagnosticCode =
  | 'expansion-cycle'
  | 'op-cycle'
  | 'constraint-cycle'
  | 'dangling-ref'
  | 'dangling-op-ref'
  | 'duplicate-bt-id'
  | 'invalid-bt-id'

export interface GraphDiagnostic {
  level: 'error' | 'warning'
  code: GraphDiagnosticCode
  message: string
}

/**
 * The concrete value in an Animatable slot. A slot holds one value (§4.3) — a property that varies
 * over time is driven by a `curve` leaf, whose target is collected as a behavior edge instead.
 */
function animValues<T>(a: Animatable<T> | undefined): T[] {
  if (!a || typeof a !== 'object') return []
  const anim = a as { kind?: string; value?: T }
  if (anim.kind === 'const') return anim.value === undefined ? [] : [anim.value]
  return []
}

/** An EntityRef can name an entity directly or address one stamped copy; the addressed form points at
 * both the stamping parent and the template, and both are real edges. */
function refToIds(ref: EntityRef | undefined): EntityId[] {
  if (ref === undefined || ref === null) return []
  if (typeof ref === 'string') return [ref]
  if ('id' in ref && typeof ref.id === 'string') return [ref.id]
  const out: EntityId[] = []
  if ('parentId' in ref && typeof ref.parentId === 'string') out.push(ref.parentId)
  if ('templateId' in ref && typeof ref.templateId === 'string') out.push(ref.templateId)
  return out
}

function collectBTEdges(bt: BTNode, ownerId: EntityId, path: string, push: (e: RefEdge) => void): void {
  const n = bt as unknown as Record<string, unknown>
  if (bt.type === 'action') {
    const target = n['target']
    if (typeof target === 'string') push({ from: ownerId, to: target, kind: 'constrains', via: `${path}.target` })
    else if (target && typeof target === 'object') {
      const tid = (target as { templateId?: unknown }).templateId
      if (typeof tid === 'string') push({ from: ownerId, to: tid, kind: 'constrains', via: `${path}.target.templateId` })
    }
  }
  if (bt.type === 'curve') {
    const target = n['target']
    if (typeof target === 'string') push({ from: ownerId, to: target, kind: 'constrains', via: `${path}.target` })
    else if (target && typeof target === 'object') {
      const tid = (target as { templateId?: unknown }).templateId
      if (typeof tid === 'string') push({ from: ownerId, to: tid, kind: 'constrains', via: `${path}.target.templateId` })
    }
  }
  if (bt.type === 'condition' && Array.isArray(n['source'])) {
    for (const s of n['source'] as unknown[]) {
      if (typeof s === 'string') push({ from: ownerId, to: s, kind: 'constrains', via: `${path}.source` })
    }
  }
  const children = n['children']
  if (Array.isArray(children)) {
    children.forEach((c, i) => collectBTEdges(c as BTNode, ownerId, `${path}.children[${i}]`, push))
  }
  if (n['child']) collectBTEdges(n['child'] as BTNode, ownerId, `${path}.child`, push)
  if (n['template']) collectBTEdges(n['template'] as BTNode, ownerId, `${path}.template`, push)
}

/**
 * Every entity→entity edge in the scene, containment included. This is the graph the "DAG" in
 * scene graph refers to; `children` alone is only a spanning tree of it.
 */
export function collectRefEdges(scene: Scene): RefEdge[] {
  const edges: RefEdge[] = []
  const push = (e: RefEdge): void => void edges.push(e)

  const visit = (entity: Entity): void => {
    for (const child of entity.children) {
      push({ from: entity.id, to: child.id, kind: 'contains', via: 'children' })
    }

    const comps = entity.components as Record<string, Animatable<unknown> | undefined> | undefined
    if (comps) {
      for (const c of animValues(comps['constraint'] as Animatable<{ type?: string }> | undefined)) {
        const con = c as { type?: string; targetId?: unknown; pathId?: unknown }
        if (con.type === 'lookAt' && typeof con.targetId === 'string') {
          push({ from: entity.id, to: con.targetId, kind: 'constrains', via: 'components.constraint.targetId' })
        } else if (con.type === 'followPath' && typeof con.pathId === 'string') {
          push({ from: entity.id, to: con.pathId, kind: 'constrains', via: 'components.constraint.pathId' })
        }
      }
      for (const l of animValues(comps['link'] as Animatable<LinkComponent> | undefined)) {
        for (const id of refToIds(l?.from)) push({ from: entity.id, to: id, kind: 'constrains', via: 'components.link.from' })
        for (const id of refToIds(l?.to)) push({ from: entity.id, to: id, kind: 'constrains', via: 'components.link.to' })
      }
      for (const sm of animValues(comps['skinnedMesh'] as Animatable<{ skeletonId?: unknown }> | undefined)) {
        if (typeof sm?.skeletonId === 'string') {
          push({ from: entity.id, to: sm.skeletonId, kind: 'constrains', via: 'components.skinnedMesh.skeletonId' })
        }
      }
    }

    const arrangement = arrangementOf(entity)
    if (arrangement) {
      for (const op of arrangement.ops) {
        if (op.type === 'instance') {
          for (const t of op.templates) {
            push({ from: entity.id, to: t, kind: 'instantiates', via: `arrangement.ops[${op.id}].templates` })
          }
        } else if (op.type === 'points' && op.generator.type === 'pathFollow') {
          push({
            from: entity.id,
            to: op.generator.pathId,
            kind: 'constrains',
            via: `arrangement.ops[${op.id}].generator.pathId`,
          })
        }
      }
    }

    const behavior = behaviorOf(entity)
    if (behavior) collectBTEdges(behavior, entity.id, 'components.behavior', push)

    for (const child of entity.children) visit(child as Entity)
  }

  visit(scene.root as Entity)
  return edges
}

/** Rotation-invariant identity for a cycle, so the same loop found from three entry points is
 * reported once. */
function cycleKey(edges: RefEdge[]): string {
  const labels = edges.map((e) => `${e.from}|${e.kind}|${e.via}`)
  let best = 0
  for (let i = 1; i < labels.length; i++) if (labels[i]! < labels[best]!) best = i
  return [...labels.slice(best), ...labels.slice(0, best)].join('>')
}

/** Depth-first search over `edges`, reporting one concrete path per distinct cycle. */
export function findCycles(edges: RefEdge[]): GraphCycle[] {
  const adj = new Map<EntityId, RefEdge[]>()
  for (const e of edges) {
    const list = adj.get(e.from)
    if (list) list.push(e)
    else adj.set(e.from, [e])
  }

  const found = new Map<string, RefEdge[]>()
  const state = new Map<EntityId, 'gray' | 'black'>()
  const stack: RefEdge[] = []

  const visit = (id: EntityId): void => {
    state.set(id, 'gray')
    for (const e of adj.get(id) ?? []) {
      const s = state.get(e.to)
      if (s === 'gray') {
        // Back edge. The cycle is the tail of the current path from wherever we first entered e.to.
        const start = stack.findIndex((x) => x.from === e.to)
        const cyc = start === -1 ? [e] : [...stack.slice(start), e]
        const key = cycleKey(cyc)
        if (!found.has(key)) found.set(key, cyc)
      } else if (s === undefined) {
        stack.push(e)
        visit(e.to)
        stack.pop()
      }
    }
    state.set(id, 'black')
  }

  // Only entities with outgoing edges can start a cycle, and every entity in a cycle has one.
  for (const id of adj.keys()) if (state.get(id) === undefined) visit(id)

  return [...found.values()].map((cyc) => ({ path: cyc.map((e) => e.from), edges: cyc }))
}

function formatCycle(c: GraphCycle): string {
  const head = c.edges.map((e) => `"${e.from}" --${e.kind}(${e.via})--> `).join('')
  return head + `"${c.edges[c.edges.length - 1]!.to}"`
}

function collectEntityIds(scene: Scene): Set<EntityId> {
  const ids = new Set<EntityId>()
  const visit = (n: Entity): void => {
    ids.add(n.id)
    for (const c of n.children) visit(c as Entity)
  }
  visit(scene.root as Entity)
  return ids
}

/**
 * Full reference-graph check: expansion cycles and malformed op graphs are errors, circular
 * constraints and references to ids that do not exist are warnings.
 *
 * Dangling references warn rather than fail because that is the status quo behaviour — `resolve`
 * filters unresolvable templates out (`resolve.ts`), so a mistyped template id renders nothing at
 * all and reports nothing. Surfacing it here is the only place it becomes visible.
 */
export function validateSceneGraph(scene: Scene): GraphDiagnostic[] {
  const diagnostics: GraphDiagnostic[] = []
  const edges = collectRefEdges(scene)
  const ids = collectEntityIds(scene)

  for (const c of findCycles(edges.filter((e) => e.kind === 'contains' || e.kind === 'instantiates'))) {
    diagnostics.push({
      level: 'error',
      code: 'expansion-cycle',
      message:
        `scene-ir: cyclic instance expansion — ${formatCycle(c)}. A template cannot be stamped ` +
        `inside its own expansion; break the loop by pointing the instance op at a copy of the ` +
        `template rather than at an ancestor of the arrangement entity doing the stamping.`,
    })
  }

  // Constraint cycles are computed over `constrains` edges alone. Mixing containment in would flag
  // the entirely ordinary case of a child that lookAt's its own parent.
  for (const c of findCycles(edges.filter((e) => e.kind === 'constrains'))) {
    diagnostics.push({
      level: 'warning',
      code: 'constraint-cycle',
      message:
        `scene-ir: circular constraint — ${formatCycle(c)}. This resolves, but the result depends ` +
        `on evaluation order rather than on the scene.`,
    })
  }

  for (const e of edges) {
    if (e.kind === 'contains' || ids.has(e.to)) continue
    diagnostics.push({
      level: 'warning',
      code: 'dangling-ref',
      message:
        `scene-ir: entity "${e.from}" references "${e.to}" via ${e.via}, which no entity declares` +
        (e.kind === 'instantiates' ? ' — the instance op will silently stamp nothing.' : '.'),
    })
  }

  // Behavior-tree node ids (§4.6). Correction events resolve a node by id, so a duplicate makes
  // an edit land on the wrong node — or on two — and an out-of-charset id collides with the ':'
  // that procedural expansion reserves. Both are errors for the same reason a duplicate entity id
  // is: they make an address ambiguous.
  const seenBtIds = new Map<string, string>()
  for (const { id, ownerId } of collectBehaviorIds(scene)) {
    if (!BT_ID_PATTERN.test(id)) {
      diagnostics.push({
        level: 'error',
        code: 'invalid-bt-id',
        message:
          `scene-ir: behavior tree node id "${id}" (in entity "${ownerId}") must be alphanumeric ` +
          `+ '_' and '.' only (A-Za-z0-9_.); ':' is reserved for procedural expansion.`,
      })
    }
    const prior = seenBtIds.get(id)
    if (prior !== undefined) {
      diagnostics.push({
        level: 'error',
        code: 'duplicate-bt-id',
        message:
          `scene-ir: duplicate behavior tree node id "${id}" (in entities "${prior}" and ` +
          `"${ownerId}") — a correction targeting it cannot say which node it means.`,
      })
    } else {
      seenBtIds.set(id, ownerId)
    }
  }

  // The op-level dataflow graph inside each arrangement entity: a second, independent DAG.
  const visitOps = (entity: Entity): void => {
    const arr = arrangementOf(entity)
    if (arr) {
      const opIds = new Set(arr.ops.map((o) => o.id))
      const opEdges: RefEdge[] = arr.edges.map((e) => ({
        from: e.from,
        to: e.to,
        kind: 'instantiates' as const,
        via: `${entity.id}.arrangement.edges`,
      }))
      for (const c of findCycles(opEdges)) {
        diagnostics.push({
          level: 'error',
          code: 'op-cycle',
          message: `scene-ir: cycle in arrangement.edges of entity "${entity.id}" — ${formatCycle(c)}.`,
        })
      }
      for (const e of arr.edges) {
        for (const end of [e.from, e.to]) {
          if (!opIds.has(end)) {
            diagnostics.push({
              level: 'warning',
              code: 'dangling-op-ref',
              message: `scene-ir: arrangement.edges of entity "${entity.id}" names op "${end}", which no op declares.`,
            })
          }
        }
      }
    }
    for (const c of entity.children) visitOps(c as Entity)
  }
  visitOps(scene.root as Entity)

  return diagnostics
}

/** Throws if the scene's reference graph is not a DAG. Warnings do not throw. */
export function assertAcyclic(scene: Scene): void {
  const errors = validateSceneGraph(scene).filter((d) => d.level === 'error')
  if (errors.length > 0) throw new Error(errors.map((e) => e.message).join('\n'))
}
