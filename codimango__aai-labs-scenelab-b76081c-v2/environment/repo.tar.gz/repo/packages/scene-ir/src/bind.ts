/**
 * Binding a `forEach` row into its template subtree (Design §2.8).
 *
 * Two forms, deliberately few:
 *   - `"ring_${disk}"`  — interpolation anywhere a string appears, which is what `target` needs.
 *   - `{ $: 'restY' }`  — whole-value substitution, which is what numbers and vectors need.
 *
 * There is no expression language on purpose. Anything computed belongs in the row, produced by
 * the source, so it stays inspectable data rather than becoming logic hidden in the template.
 * That is the same split an arrangement draws between a `points` generator and an `instance` op.
 */
import type { BTNode } from './types'

export type Row = Record<string, unknown>

const REF = /\$\{([A-Za-z_][A-Za-z0-9_]*)\}/g

function bindString(text: string, row: Row, where: string): string {
  return text.replace(REF, (_m, field: string) => {
    if (!(field in row)) {
      throw new Error(
        `scene-ir: forEach template references \${${field}} in ${where}, but the row has ` +
          `[${Object.keys(row).join(', ')}]. Fields come from the source rows.`,
      )
    }
    const value = row[field]
    // Interpolating anything else yields "[object Object]" or "null", which then reads as a target
    // id matching no entity — an action that quietly does nothing. Use { $: "field" } for a value.
    if (typeof value !== 'string' && typeof value !== 'number' && typeof value !== 'boolean') {
      throw new Error(
        `scene-ir: forEach template interpolates \${${field}} into a string in ${where}, but the ` +
          `row value is ${value === null ? 'null' : typeof value}. Only strings, numbers and ` +
          `booleans can be interpolated; use { $: "${field}" } to substitute a whole value.`,
      )
    }
    return String(value)
  })
}

function bindValue(value: unknown, row: Row, where: string): unknown {
  if (typeof value === 'string') return bindString(value, row, where)
  if (Array.isArray(value)) return value.map((v, i) => bindValue(v, row, `${where}[${i}]`))
  if (typeof value === 'object' && value !== null) {
    const rec = value as Record<string, unknown>
    // `{ $: 'field' }` substitutes the whole value, so a row can supply a number or a Vec3.
    if (typeof rec['$'] === 'string' && Object.keys(rec).length === 1) {
      const field = rec['$']
      if (!(field in row)) {
        throw new Error(
          `scene-ir: forEach template references { $: "${field}" } in ${where}, but the row has ` +
            `[${Object.keys(row).join(', ')}].`,
        )
      }
      return row[field]
    }
    const out: Record<string, unknown> = {}
    for (const [k, v] of Object.entries(rec)) out[k] = bindValue(v, row, `${where}.${k}`)
    return out
  }
  return value
}

/**
 * Stamp `template` for one row. Ids gain an `:index` suffix so each stamped action stays
 * addressable in the schedule, mirroring how instanced entities carry their repeat index.
 */
export function bindTemplate(template: BTNode, row: Row, index: number): BTNode {
  const bound = bindValue(template, row, `forEach row ${index}`) as BTNode
  const suffix = (entity: BTNode): BTNode => {
    const rec = entity as unknown as Record<string, unknown>
    if (typeof rec['id'] === 'string') rec['id'] = `${rec['id']}:${index}`
    const kids = rec['children']
    if (Array.isArray(kids)) rec['children'] = kids.map((c) => suffix(c as BTNode))
    for (const key of ['child', 'template'] as const) {
      const kid = rec[key]
      if (kid && typeof kid === 'object') rec[key] = suffix(kid as BTNode)
    }
    return entity
  }
  return suffix(bound)
}
