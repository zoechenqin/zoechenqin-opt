import { describe, it, expect } from 'vitest'
import {
  axisAngleToQuat,
  composeMat4,
  identityMat4,
  multiplyMat4,
  quatToAxisAngle,
  rotationMat4,
  transformPoint,
  translationMat4,
} from './math'

const close = (a: number, b: number, eps = 1e-9): boolean => Math.abs(a - b) < eps

describe('math: rotation', () => {
  it('rotates (1,0,0) by 90° about +Z to (0,1,0) — RH, Y-up, CCW (§3.8)', () => {
    const q = axisAngleToQuat({ axis: { x: 0, y: 0, z: 1 }, angle: Math.PI / 2 })
    const p = transformPoint(rotationMat4(q), { x: 1, y: 0, z: 0 })
    expect(close(p.x, 0)).toBe(true)
    expect(close(p.y, 1)).toBe(true)
    expect(close(p.z, 0)).toBe(true)
  })

  it('axis-angle ↔ quaternion round-trips', () => {
    const aa = quatToAxisAngle(axisAngleToQuat({ axis: { x: 0, y: 1, z: 0 }, angle: 1.1 }))
    expect(close(aa.angle, 1.1, 1e-6)).toBe(true)
    expect(close(aa.axis.y, 1, 1e-6)).toBe(true)
  })
})

describe('math: composition (§3.3)', () => {
  it('places the anchor at position', () => {
    const m = composeMat4({ x: 100, y: 20, z: 0 }, [0, 0, 0, 1], { x: 1, y: 1, z: 1 }, { x: 0, y: 0, z: 0 })
    const p = transformPoint(m, { x: 0, y: 0, z: 0 })
    expect(p).toEqual({ x: 100, y: 20, z: 0 })
  })

  it('composes parent · child translations', () => {
    const parent = translationMat4({ x: 100, y: 0, z: 0 })
    const child = translationMat4({ x: 10, y: 5, z: 0 })
    const world = multiplyMat4(parent, child)
    expect(transformPoint(world, { x: 0, y: 0, z: 0 })).toEqual({ x: 110, y: 5, z: 0 })
  })

  it('identity is a no-op', () => {
    expect(transformPoint(identityMat4(), { x: 3, y: 4, z: 5 })).toEqual({ x: 3, y: 4, z: 5 })
  })
})
