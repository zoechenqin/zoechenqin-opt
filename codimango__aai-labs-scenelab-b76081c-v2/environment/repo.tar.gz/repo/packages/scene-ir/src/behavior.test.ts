import { describe, it, expect } from 'vitest'
import { behaviorStateAt, constant, identityTransform, parseScene, resolveScene } from './index'
import type { BTNode, Scene } from './index'

/** One entity at the origin plus a behavior tree, so a test says only what it is about. */
const sceneWith = (behavior: BTNode, start = { x: 0, y: 0, z: 0 }): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'bt',
    space: '2d',
    canvas: { width: 100, height: 100 },
    camera: {
      id: 'camera',
      transform: identityTransform(),
      projection: { type: 'orthographic', height: constant(100) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'thing',
          word: 'timeline',
          transform: identityTransform(),
          children: [],
          components: { behavior: constant(behavior) },
        },
        {
          id: 'mover',
          word: 'dot',
          transform: { ...identityTransform(), position: constant(start) },
          components: { circle: constant({ radius: 1, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) },
          children: [],
        },
      ],
    },
  }) as Scene

const translate = (id: string, duration: number, to: { x: number; y: number; z: number }): BTNode => ({
  type: 'action',
  id,
  action: 'translate',
  target: 'mover',
  duration,
  params: { to },
})

describe('behaviorStateAt (§2.8)', () => {
  it('interpolates a translate across its duration', () => {
    const s = sceneWith(translate('a', 2, { x: 10, y: 0, z: 0 }))
    expect(behaviorStateAt(s, 0).get('mover')?.position?.x).toBe(0)
    expect(behaviorStateAt(s, 1).get('mover')?.position?.x).toBe(5)
    expect(behaviorStateAt(s, 2).get('mover')?.position?.x).toBe(10)
  })

  it('holds the final value after the action ends', () => {
    const s = sceneWith(translate('a', 2, { x: 10, y: 0, z: 0 }))
    expect(behaviorStateAt(s, 99).get('mover')?.position?.x).toBe(10)
  })

  it('chains moves from where the previous one left off, not from the authored transform', () => {
    // This is what lets 381 sequential Hanoi moves compose into a solve.
    const s = sceneWith({
      type: 'sequence',
      children: [translate('a', 1, { x: 10, y: 0, z: 0 }), translate('b', 1, { x: 10, y: 5, z: 0 })],
    })
    expect(behaviorStateAt(s, 1).get('mover')?.position).toMatchObject({ x: 10, y: 0 })
    expect(behaviorStateAt(s, 1.5).get('mover')?.position).toMatchObject({ x: 10, y: 2.5 })
    expect(behaviorStateAt(s, 2).get('mover')?.position).toMatchObject({ x: 10, y: 5 })
  })

  it('starts from the entity\'s own authored position', () => {
    const s = sceneWith(translate('a', 1, { x: 10, y: 0, z: 0 }), { x: -10, y: 0, z: 0 })
    expect(behaviorStateAt(s, 0).get('mover')?.position?.x).toBe(-10)
    expect(behaviorStateAt(s, 0.5).get('mover')?.position?.x).toBe(0)
  })

  it('supports a relative `by`', () => {
    const s = sceneWith({ type: 'action', id: 'a', action: 'translate', target: 'mover', duration: 1, params: { by: { x: 4, y: 0, z: 0 } } }, { x: 1, y: 0, z: 0 })
    expect(behaviorStateAt(s, 1).get('mover')?.position?.x).toBe(5)
  })

  it('setEnabled culls the entity', () => {
    const s = sceneWith({ type: 'action', id: 'off', action: 'setEnabled', target: 'mover', duration: 0, params: { value: false } })
    expect(resolveScene(s, 0).primitives.find((p) => p.id === 'mover')).toBeUndefined()
  })

  it('leaves entities no tree mentions alone', () => {
    const s = sceneWith(translate('a', 1, { x: 10, y: 0, z: 0 }))
    expect(behaviorStateAt(s, 1).has('root')).toBe(false)
  })

  it('a behaviour-only scene actually moves when resolved', () => {
    // Resolution must apply scheduled behavior even when no curve leaves are present.
    const s = sceneWith(translate('a', 2, { x: 10, y: 0, z: 0 }))
    const x = (t: number): number => resolveScene(s, t).primitives.find((p) => p.id === 'mover')!.worldMatrix[12]!
    expect(x(0)).toBe(0)
    expect(x(2)).toBe(10)
  })

  // Completed actions hold their result instead of snapping back to the authored pose.
  it('an action holds its result after it finishes', () => {
    const s = sceneWith(translate('a', 2, { x: 10, y: 0, z: 0 }))
    expect(resolveScene(s, 2).primitives.find((p) => p.id === 'mover')!.worldMatrix[12]).toBe(10)
    expect(resolveScene(s, 9).primitives.find((p) => p.id === 'mover')!.worldMatrix[12]).toBe(10)
  })

  it('can drive the camera, which is not an entity', () => {
    // The camera is outside the entity tree but remains a valid behavior target.
    const s = sceneWith({ type: 'action', id: 'dolly', action: 'translate', target: 'camera', duration: 2, params: { to: { x: 0, y: 0, z: 40 } } })
    ;(s.camera.transform as { position: unknown }).position = constant({ x: 0, y: 0, z: 10 })
    const z = (t: number): number => resolveScene(s, t).camera.worldMatrix[14]!
    expect(z(0)).toBe(10)
    expect(z(1)).toBe(25)
    expect(z(2)).toBe(40)
  })

  it('rejects params it cannot execute instead of silently doing nothing', () => {
    // Domain labels are not executable transform coordinates and must fail explicitly.
    const s = sceneWith({ type: 'action', id: 'm1', action: 'translate', target: 'mover', duration: 1, params: { from: 'A', to: 'C' } })
    expect(() => behaviorStateAt(s, 0.5)).toThrow(/domain vocabulary|expects/)
  })
})

describe('instance-targeted behaviour (§2.2, §2.8)', () => {
  const stamped = (target: unknown): Scene =>
    ({
      schemaVersion: '0.1.0', id: 'inst', space: '2d', canvas: { width: 100, height: 100 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
      root: {
        id: 'root', word: 's', transform: identityTransform(), children: [
          { id: 'tile', word: 'tile', template: true, transform: identityTransform(),
            components: { rect: constant({ size: { x: 5, y: 5 }, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) }, children: [] },
          { id: 'row', word: 'row', transform: identityTransform(), children: [],
            components: { arrangement: constant({ ops: [
              { id: 'pts', type: 'points', generator: { type: 'line', count: 4, step: { ...identityTransform(), position: constant({ x: 20, y: 0, z: 0 }) } } },
              { id: 'inst', type: 'instance', templates: ['tile'], points: 'pts' },
            ], edges: [] }) }, },
          { id: 'bt', word: 't', transform: identityTransform(), children: [],
            components: { behavior: constant({ type: 'action', id: 'lift', action: 'translate', target, duration: 1, params: { to: { x: 0, y: 100, z: 0 } } }) }, },
        ],
      },
    }) as Scene

  const ys = (s: Scene): number[] => resolveScene(s, 1).primitives.map((p) => Math.round(p.worldMatrix[13]!))

  it('a bare template id still moves every stamped copy', () => {
    // "all the rings rise" stays one action.
    expect(ys(stamped('tile'))).toEqual([100, 100, 100, 100])
  })

  it('an indexed target moves exactly one copy', () => {
    // The temporal counterpart of an instance `overrides` entry — "no, move THAT one".
    expect(ys(stamped({ templateId: 'tile', index: '2' }))).toEqual([0, 0, 100, 0])
  })

  it('leaves the other copies untouched rather than nudging them', () => {
    const out = ys(stamped({ templateId: 'tile', index: '0' }))
    expect(out.filter((y) => y === 0)).toHaveLength(3)
    expect(out[0]).toBe(100)
  })

  it('survives a schema round-trip', () => {
    const s = stamped({ templateId: 'tile', index: '1' })
    expect(() => parseScene(JSON.parse(JSON.stringify(s)))).not.toThrow()
  })
})
