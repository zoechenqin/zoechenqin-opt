/**
 * Behavior execution (Design §2.8): turn a simulated schedule into entity state at time t.
 *
 * `simulate()` says WHEN each action runs; this says WHAT it does and turns the schedule into
 * resolved entity state.
 *
 * Semantics, in one paragraph. A target's state starts at its authored transform sampled at t=0.
 * Entries for that target are applied in schedule order: an entry that has finished by `t` is
 * applied in full, the one straddling `t` is interpolated across its duration, and everything
 * later is ignored. So the value an action animates FROM is wherever the previous action left the
 * entity, never a re-read of the authored transform. That is what makes a long chain of moves compose.
 */
import { easeU, sampleKeyframes } from './animatable'
import { resolveAxisAngle, resolveVec3 } from './animatable'
import { addVec3, lerpVec3 } from './math'
import { simulate, targetKey, type ScheduleEntry } from './simulate'
import type { AxisAngle, Easing, Entity, EntityId, Keyframe, Scene, Seconds, Vec3 } from './types'

/** Whatever a behavior tree has decided about an entity by time t. Absent fields are untouched. */
export interface BehaviorState {
  position?: Vec3
  scale?: Vec3
  rotation?: AxisAngle
  enabled?: boolean
  /**
   * What `curve` leaves have driven that is not a transform channel, keyed by property path
   * (`components.rect.style.fill`). Transform paths land in the fields above instead, so a
   * consumer that only knows about transforms needs no changes (§4.4).
   */
  properties?: Record<string, unknown>
}

const isVec3 = (v: unknown): v is Vec3 =>
  typeof v === 'object' &&
  v !== null &&
  typeof (v as Vec3).x === 'number' &&
  typeof (v as Vec3).y === 'number' &&
  typeof (v as Vec3).z === 'number'

const isAxisAngle = (v: unknown): v is AxisAngle =>
  typeof v === 'object' && v !== null && isVec3((v as AxisAngle).axis) && typeof (v as AxisAngle).angle === 'number'

/**
 * `params` is deliberately open (scripts and custom actions need it), so executable actions state
 * their shape here and reject anything else. An action that is silently skipped costs the whole
 * motion it was meant to produce, with nothing in the output to say so.
 */
function badParams(entry: ScheduleEntry, expected: string): Error {
  const where = entry.btId !== undefined ? `action "${entry.btId}"` : `a "${entry.action}" action`
  return new Error(
    `scene-ir: ${where} targeting "${entry.target}" has params ${JSON.stringify(entry.params)}; ` +
      `${entry.action} expects ${expected}. Behavior-tree params are scene-graph values, not ` +
      `domain vocabulary — resolve names like a peg id to coordinates when you build the tree.`,
  )
}

function vec3Param(entry: ScheduleEntry, from: Vec3): Vec3 {
  const { to, by } = entry.params as { to?: unknown; by?: unknown }
  if (isVec3(to)) return to
  if (isVec3(by)) return addVec3(from, by)
  throw badParams(entry, '{ to: {x,y,z} } (absolute) or { by: {x,y,z} } (relative)')
}

function collectEntities(entity: Entity, out: Map<EntityId, Entity>): void {
  out.set(entity.id, entity)
  for (const child of entity.children) collectEntities(child as Entity, out)
}

/**
 * Fold the schedule down to the state each targeted entity is in at `t`.
 * Entities no behavior tree mentions are absent from the map and keep their authored transform.
 */
export function behaviorStateAt(scene: Scene, t: Seconds): Map<EntityId, BehaviorState> {
  const { schedule } = simulate(scene)
  const out = new Map<EntityId, BehaviorState>()
  if (schedule.length === 0) return out

  const entities = new Map<EntityId, Entity>()
  collectEntities(scene.root as Entity, entities)
  // Expose the camera under its own id so behavior can target its transform.
  if (!entities.has(scene.camera.id)) {
    entities.set(scene.camera.id, { id: scene.camera.id, transform: scene.camera.transform, children: [] } as unknown as Entity)
  }

  // Keyed by canonical target: `ring` applies to every stamped copy, `ring#3` to one of them.
  const byTarget = new Map<string, ScheduleEntry[]>()
  for (const entry of schedule) {
    const key = targetKey(entry.target, entry.targetIndex)
    const list = byTarget.get(key)
    if (list) list.push(entry)
    else byTarget.set(key, [entry])
  }

  for (const [key, entries] of byTarget) {
    // The base transform always comes from the source entity (the template), since the per-copy
    // offset lives in the parent's world matrix, not in the template's own transform.
    const entity = entities.get(entries[0]!.target)
    // A tree may name an entity that does not exist, or one that only instancing will create. Neither
    // is executable here; leave it alone rather than guessing.
    if (!entity) continue

    const state: BehaviorState = {}
    let position = resolveVec3(entity.transform.position, 0)
    let scale = resolveVec3(entity.transform.scale, 0)
    let rotation = resolveAxisAngle(entity.transform.rotation, 0)
    let enabled = entity.enabled !== false
    let touchedPosition = false
    let touchedScale = false
    let touchedRotation = false
    let touchedEnabled = false
    const properties: Record<string, unknown> = {}

    for (const entry of entries) {
      if (t < entry.start) break
      const done = t >= entry.start + entry.duration
      const u =
        done || entry.duration <= 0
          ? 1
          : easeU((entry.params['easing'] as Easing | undefined) ?? 'linear', (t - entry.start) / entry.duration)

      switch (entry.action) {
        case 'curve': {
          // Keyframe times are local to the leaf, so map global time back onto the local axis
          // before sampling. Going through `u` rather than subtracting `entry.start` directly is
          // what makes a curve under a timeScale decorator stretch instead of truncate.
          const keyframes = entry.params['keyframes'] as Array<Keyframe<unknown>> | undefined
          if (!Array.isArray(keyframes) || keyframes.length === 0) break
          const property = entry.params['property']
          if (typeof property !== 'string') break
          const span = typeof entry.params['span'] === 'number' ? (entry.params['span'] as number) : 0
          const value = sampleKeyframes(keyframes, u * span)

          if (property === 'transform.position' && isVec3(value)) {
            position = value
            touchedPosition = true
          } else if (property === 'transform.scale' && isVec3(value)) {
            scale = value
            touchedScale = true
          } else if (property === 'transform.rotation' && isAxisAngle(value)) {
            rotation = value
            touchedRotation = true
          } else {
            properties[property] = value
          }
          break
        }
        case 'translate': {
          const goal = vec3Param(entry, position)
          position = u >= 1 ? goal : lerpVec3(position, goal, u)
          touchedPosition = true
          break
        }
        case 'scale': {
          const goal = vec3Param(entry, scale)
          scale = u >= 1 ? goal : lerpVec3(scale, goal, u)
          touchedScale = true
          break
        }
        case 'rotate': {
          const to = entry.params['to']
          if (
            typeof to !== 'object' ||
            to === null ||
            !isVec3((to as AxisAngle).axis) ||
            typeof (to as AxisAngle).angle !== 'number'
          ) {
            throw badParams(entry, '{ to: { axis: {x,y,z}, angle: <degrees> } }')
          }
          const goal = to as AxisAngle
          rotation =
            u >= 1
              ? goal
              : { axis: goal.axis, angle: rotation.angle + (goal.angle - rotation.angle) * u }
          touchedRotation = true
          break
        }
        case 'setEnabled': {
          const value = entry.params['value']
          if (typeof value !== 'boolean') throw badParams(entry, '{ value: true | false }')
          // A state change takes effect at its start; it does not ease.
          enabled = value
          touchedEnabled = true
          break
        }
        // setLocked/upsertComponent/emitParticles/script do not move geometry, so they contribute
        // nothing to the sampled transform. They still occupy their slot in the schedule.
        default:
          break
      }
      if (!done) break
    }

    if (touchedPosition) state.position = position
    if (touchedScale) state.scale = scale
    if (touchedRotation) state.rotation = rotation
    if (touchedEnabled) state.enabled = enabled
    if (Object.keys(properties).length > 0) state.properties = properties
    if (Object.keys(state).length > 0) out.set(key, state)
  }

  return out
}
