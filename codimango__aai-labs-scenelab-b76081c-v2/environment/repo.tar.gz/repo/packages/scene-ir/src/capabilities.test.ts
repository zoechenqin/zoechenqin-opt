import { describe, it, expect } from 'vitest'
import { COMPONENT_SUPPORT, constant, dropReport, formatDropReport, identityTransform, THREE_COMPONENTS } from './index'
import type { ComponentMap, Scene } from './index'

const sceneWith = (...components: ComponentMap[]): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'caps',
    space: '3d',
    canvas: { width: 100, height: 100 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: components.map((c, i) => ({
        id: `n${i}`,
        word: 'thing',
        transform: identityTransform(),
        components: c,
        children: [],
      })),
    },
  }) as Scene

const rect = { rect: constant({ size: { x: 1, y: 1 }, style: {} }) } as ComponentMap
const light = { light: constant({ type: 'ambient', color: { r: 1, g: 1, b: 1, a: 1 }, intensity: 1 }) } as ComponentMap
const cyl = { cylinder: constant({ radius: 1, height: 1, style: {} }) } as ComponentMap

describe('drop report (§2.9)', () => {
  it('says nothing when everything is carried', () => {
    const drops = dropReport(sceneWith(rect))
    expect(drops).toEqual([])
    expect(formatDropReport(drops)).toBe('nothing dropped')
  })

  it('names a component this renderer will not carry', () => {
    // The 2D painters cannot light anything, so a declared light is inert there — and a scene
    // that declares one otherwise looks like a success at every layer.
    const drops = dropReport(sceneWith(rect, light))
    expect(drops).toHaveLength(1)
    expect(drops[0]).toMatchObject({ entityId: 'n1', component: 'light', outcome: 'skipped' })
    expect(formatDropReport(drops)).toMatch(/1x light skipped/)
  })

  it('the three.js renderer does carry lights', () => {
    // The same scene, reported against a renderer that shades real geometry.
    const drops = dropReport(sceneWith(rect, light), THREE_COMPONENTS, [])
    expect(drops).toEqual([])
  })

  it('a component genuinely read by nobody still says so', () => {
    const scene = sceneWith({ rigidbody: constant({ mass: 1 }) } as ComponentMap)
    const drops = dropReport(scene)
    expect(drops[0]).toMatchObject({ component: 'rigidbody', support: 'unimplemented', outcome: 'skipped' })
    expect(drops[0]?.note).toMatch(/read by no renderer/)
  })

  it('distinguishes an approximation from a skip', () => {
    const drops = dropReport(sceneWith(cyl))
    expect(drops).toHaveLength(1)
    expect(drops[0]?.outcome).toBe('approximated')
    expect(drops[0]?.note).toMatch(/planar stand-in/)
  })

  it('marks a descriptive component as skipped, with its own reason', () => {
    const scene = sceneWith({ embedding: constant({ ref: 'oak' }) } as ComponentMap)
    ;(scene as { embeddings?: Record<string, unknown> }).embeddings = { oak: { phrase: 'an oak' } }
    const drops = dropReport(scene)
    expect(drops[0]).toMatchObject({ component: 'embedding', support: 'descriptive', outcome: 'skipped' })
    expect(drops[0]?.note).toMatch(/nothing synthesizes it/)
  })

  it('honours a narrower renderer', () => {
    // An adapter that only draws rects should say so about the circle.
    const scene = sceneWith(rect, { circle: constant({ radius: 1, style: {} }) } as ComponentMap)
    const drops = dropReport(scene, ['rect'], [])
    expect(drops.map((d) => d.component)).toEqual(['circle'])
  })

  it('groups and counts in the report line', () => {
    const drops = dropReport(sceneWith(light, light, cyl))
    expect(formatDropReport(drops)).toBe(
      '2x light skipped (not supported by this renderer); ' +
        '1x cylinder approximated (volumetric shape drawn as a planar stand-in, not shaded geometry)',
    )
  })

  it('classifies every component the schema accepts', () => {
    // A component absent from the table would be silently reported as unimplemented, which is the
    // safe default but hides the fact that nobody classified it.
    for (const key of ['circle', 'rect', 'text', 'box', 'opacity', 'embedding', 'light', 'link']) {
      expect(COMPONENT_SUPPORT[key]).toBeDefined()
    }
  })
})
