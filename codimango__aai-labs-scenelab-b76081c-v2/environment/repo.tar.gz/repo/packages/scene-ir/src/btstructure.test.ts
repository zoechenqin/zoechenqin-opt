import { describe, it, expect } from 'vitest'
import { applyEvent, behaviorOf, constant, findEntity, identityTransform, parseScene, simulate } from './index'
import type { BTNode, Scene } from './index'

const move = (id: string, to: number, duration = 1): BTNode =>
  ({ id, type: 'action', action: 'translate', target: 'box', duration, params: { to: { x: to, y: 0, z: 0 } } }) as BTNode

const sceneWith = (behavior: BTNode): Scene =>
  parseScene(
    JSON.parse(
      JSON.stringify({
        schemaVersion: '0.1.0',
        id: 'bts',
        space: '2d',
        canvas: { width: 100, height: 100 },
        camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
        root: {
          id: 'root',
          word: 'scene',
          transform: identityTransform(),
          children: [
            { id: 'bt', word: 'motion', transform: identityTransform(), children: [], components: { behavior: constant(behavior) } },
            {
              id: 'box',
              word: 'box',
              transform: identityTransform(),
              children: [],
              components: { rect: constant({ size: { x: 1, y: 1 }, style: {} }) },
            },
          ],
        },
      }),
    ),
  )

const tree = (scene: Scene): any => behaviorOf(findEntity(scene.root as any, 'bt')!)
const kidIds = (scene: Scene): string[] => tree(scene).children.map((c: any) => c.id)

const seq = (...kids: BTNode[]): BTNode => ({ id: 'root_seq', type: 'sequence', children: kids }) as BTNode

describe('behavior.addNode', () => {
  it('inserts at an index in a composite', () => {
    const scene = applyEvent(sceneWith(seq(move('a', 1), move('c', 3))), {
      type: 'behavior.addNode',
      parent: 'root_seq',
      node: move('b', 2),
      index: 1,
    })
    expect(kidIds(scene)).toEqual(['a', 'b', 'c'])
    expect(simulate(scene).duration).toBe(3)
  })

  it('clamps an out-of-range index rather than dropping the node', () => {
    const scene = applyEvent(sceneWith(seq(move('a', 1))), {
      type: 'behavior.addNode',
      parent: 'root_seq',
      node: move('b', 2),
      index: 99,
    })
    expect(kidIds(scene)).toEqual(['a', 'b'])
  })

  it('gives an inserted node an id when it arrives without one', () => {
    const scene = applyEvent(sceneWith(seq(move('a', 1))), {
      type: 'behavior.addNode',
      parent: 'root_seq',
      node: { type: 'action', action: 'translate', target: 'box', duration: 1, params: { to: { x: 5, y: 0, z: 0 } } } as BTNode,
      index: 1,
    })
    expect(kidIds(scene)[1]).toBeTruthy()
  })

  it('fills the single slot of a decorator, and refuses a second occupant', () => {
    const withEmpty = sceneWith({ id: 'dec', type: 'decorator', decorator: 'timeScale', params: { scale: 2 }, child: move('a', 1) } as BTNode)
    expect(() =>
      applyEvent(withEmpty, { type: 'behavior.addNode', parent: 'dec', node: move('b', 2), index: 0 }),
    ).toThrow(/already holds a child/)
  })

  it('refuses to give a leaf children', () => {
    expect(() =>
      applyEvent(sceneWith(seq(move('a', 1))), { type: 'behavior.addNode', parent: 'a', node: move('b', 2), index: 0 }),
    ).toThrow(/leaf and cannot hold children/)
  })
})

describe('behavior.removeNode', () => {
  it('drops a child of a composite', () => {
    const scene = applyEvent(sceneWith(seq(move('a', 1), move('b', 2), move('c', 3))), {
      type: 'behavior.removeNode',
      target: 'b',
    })
    expect(kidIds(scene)).toEqual(['a', 'c'])
    expect(simulate(scene).duration).toBe(2)
  })

  it('refuses to empty a slot its holder requires', () => {
    const scene = sceneWith({ id: 'dec', type: 'decorator', decorator: 'timeScale', params: { scale: 2 }, child: move('a', 1) } as BTNode)
    expect(() => applyEvent(scene, { type: 'behavior.removeNode', target: 'a' })).toThrow(/requires/)
  })

  it('refuses to remove the root of the tree', () => {
    expect(() => applyEvent(sceneWith(seq(move('a', 1))), { type: 'behavior.removeNode', target: 'root_seq' }))
      .toThrow(/the root of its tree/)
  })

  it('names an id that is not in any tree', () => {
    expect(() => applyEvent(sceneWith(seq(move('a', 1))), { type: 'behavior.removeNode', target: 'nope' }))
      .toThrow(/"nope"/)
  })
})

describe('behavior.reparentNode', () => {
  it('reorders within one parent — the same-parent case', () => {
    const scene = applyEvent(sceneWith(seq(move('a', 1), move('b', 2), move('c', 3))), {
      type: 'behavior.reparentNode',
      target: 'c',
      newParent: 'root_seq',
      index: 0,
    })
    expect(kidIds(scene)).toEqual(['c', 'a', 'b'])
  })

  it('moves a node into a different composite', () => {
    const inner = { id: 'inner', type: 'parallel', children: [] } as unknown as BTNode
    const scene = applyEvent(sceneWith(seq(move('a', 1), inner)), {
      type: 'behavior.reparentNode',
      target: 'a',
      newParent: 'inner',
      index: 0,
    })
    expect(kidIds(scene)).toEqual(['inner'])
    expect(tree(scene).children[0].children.map((c: any) => c.id)).toEqual(['a'])
  })

  it('refuses to move a node inside its own subtree', () => {
    const inner = { id: 'inner', type: 'parallel', children: [move('a', 1)] } as unknown as BTNode
    expect(() =>
      applyEvent(sceneWith(seq(inner)), { type: 'behavior.reparentNode', target: 'inner', newParent: 'a', index: 0 }),
    ).toThrow(/inside its own subtree/)
  })

  it('refuses to move the root', () => {
    expect(() =>
      applyEvent(sceneWith(seq(move('a', 1))), { type: 'behavior.reparentNode', target: 'root_seq', newParent: 'a', index: 0 }),
    ).toThrow(/the root of its tree/)
  })
})

describe('behavior.setType', () => {
  it('swaps a composite and keeps its children', () => {
    const before = sceneWith(seq(move('a', 1, 1), move('b', 2, 2)))
    expect(simulate(before).duration).toBe(3) // sequence: 1s then 2s

    const scene = applyEvent(before, { type: 'behavior.setType', target: 'root_seq', from: 'sequence', to: 'parallel' })
    expect(tree(scene).type).toBe('parallel')
    expect(kidIds(scene)).toEqual(['a', 'b'])
    // Control flow really changed, not just the label: run together, they end at 2 rather than 3.
    expect(simulate(scene).duration).toBe(2)
  })

  it('drops fields that belonged to the old type only', () => {
    const scene = applyEvent(sceneWith({ id: 'root_seq', type: 'sequence', repeat: 3, children: [move('a', 1)] } as BTNode), {
      type: 'behavior.setType',
      target: 'root_seq',
      from: 'sequence',
      to: 'selector',
    })
    expect(tree(scene).repeat).toBeUndefined()
  })

  it('refuses a node that is not a composite', () => {
    expect(() =>
      applyEvent(sceneWith(seq(move('a', 1))), { type: 'behavior.setType', target: 'a', from: 'sequence', to: 'selector' }),
    ).toThrow(/only composites/)
  })
})

describe('structural edits are immutable', () => {
  it('leaves the input scene untouched', () => {
    const before = sceneWith(seq(move('a', 1), move('b', 2)))
    applyEvent(before, { type: 'behavior.removeNode', target: 'b' })
    expect(kidIds(before)).toEqual(['a', 'b'])
  })
})
