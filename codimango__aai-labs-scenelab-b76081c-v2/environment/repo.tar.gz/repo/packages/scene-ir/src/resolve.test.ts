
import { describe, it, expect } from 'vitest'
import { resolveNumber, resolveScene, transformPoint } from './index'
import type { Animatable, Entity, Scene } from './index'
import { constant, identityTransform, translateTransform } from './index'
import { sampleWithEmbeddings } from './index'

const close = (a: number, b: number, eps = 1e-9): boolean => Math.abs(a - b) < eps

describe('animatable resolve', () => {
  it('const returns its value at any t', () => {
    expect(resolveNumber(constant(42), 0)).toBe(42)
    expect(resolveNumber(constant(42), 5)).toBe(42)
  })

  // Value slots are time-invariant; curve interpolation is tested at the behavior-tree boundary.
  it('a value slot ignores t entirely', () => {
    const v: Animatable<number> = constant(7)
    expect(resolveNumber(v, -1)).toBe(7)
    expect(resolveNumber(v, 1)).toBe(7)
    expect(resolveNumber(v, 1e6)).toBe(7)
  })
})

describe('resolveScene transform composition', () => {
  const scene: Scene = {
    schemaVersion: '0.1.0',
    id: 's',
    space: '2d',
    canvas: { width: 100, height: 100 },
    camera: {
      id: 'camera',
      transform: identityTransform(),
      projection: { type: 'orthographic', height: constant(100) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'group_a',
          word: 'group',
          transform: translateTransform({ x: 100, y: 0, z: 0 }),
          components: { opacity: constant(0.5) },
          children: [
            {
              id: 'dot',
              word: 'dot',
              transform: translateTransform({ x: 10, y: 5, z: 0 }),
              components: { circle: constant({ radius: 3, style: {} }), opacity: constant(0.5) } as any,
              children: [],
            },
          ],
        },
      ],
    } as Entity,
  }

  it('accumulates world transform down tree', () => {
    const prim = resolveScene(scene).primitives.find((p) => p.id === 'dot')
    const wp = transformPoint(prim!.worldMatrix, { x: 0, y: 0, z: 0 })
    expect(close(wp.x, 110)).toBe(true)
    expect(close(wp.y, 5)).toBe(true)
  })

  it('accumulates opacity', () => {
    const prim = resolveScene(scene).primitives.find((p) => p.id === 'dot')
    expect(close(prim!.opacity, 0.25)).toBe(true)
  })

  it('enforces id charset and uniqueness', () => {
    const bad = {
      ...scene,
      root: { ...scene.root, children: [{ id: 'bad-id', word: 'x', transform: identityTransform(), children: [] }] } as any,
    } as Scene
    expect(() => resolveScene(bad)).toThrow(/alphanumeric/)
  })

  it('culls invisible subtrees', () => {
    const hidden = {
      ...scene,
      root: {
        ...scene.root,
        children: [
          {
            id: 'hidden_group',
            word: 'g',
            transform: identityTransform(),
            enabled: false,
            children: [{ id: 'hidden_dot', word: 'dot', transform: identityTransform(), components: { circle: constant({ radius: 3, style: {} }) } as any, children: [] }],
          },
        ],
      },
    } as Scene
    expect(resolveScene(hidden).primitives.length).toBe(0)
  })

  it('a template is not drawn where it sits, only where it is stamped', () => {
    const scene: Scene = {
      schemaVersion: '0.1.0',
      id: 't',
      space: '2d',
      canvas: { width: 100, height: 100 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'tile',
            word: 'tile',
            template: true,
            transform: identityTransform(),
            components: { circle: constant({ radius: 1, style: {} }) },
            children: [],
          },
          {
            id: 'board',
            word: 'board',
            transform: identityTransform(),
            children: [],
            components: { arrangement: constant({
              ops: [
                { id: 'pts', type: 'points', generator: { type: 'line', count: 3, step: translateTransform({ x: 10, y: 0, z: 0 }) } },
                { id: 'inst', type: 'instance', templates: ['tile'], points: 'pts' },
              ],
              edges: [{ from: 'pts', to: 'inst' }],
            }) },
          },
        ],
      } as any,
    }
    const ids = resolveScene(scene).primitives.map((p) => p.id)
    // three stamped copies, and no bare `tile` drawn at its own location
    expect(ids).toEqual(['board:tile:0', 'board:tile:1', 'board:tile:2'])
  })

  it('rejects an embedding reference that names no declaration', () => {
    const scene = sampleWithEmbeddings()
    const broken = {
      ...scene,
      embeddings: {},
    } as Scene
    expect(() => resolveScene(broken)).toThrow(/undeclared embedding/)
  })
})
