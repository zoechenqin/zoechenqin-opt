import { describe, it, expect } from 'vitest'
import { constant, identityTransform, parseScene, resolveScene, safeParseScene, sampleScene } from './index'

describe('schema (§3.2)', () => {
  const json = JSON.parse(JSON.stringify(sampleScene())) as unknown

  it('parses a valid scene', () => {
    const scene = parseScene(json)
    expect(scene.id).toBe('sample')
    expect(scene.root.children.length).toBe(2)
  })

  it('round-trips through resolveScene', () => {
    expect(resolveScene(parseScene(json)).primitives.length).toBe(2)
  })

  it('rejects an invalid scene (bad enum)', () => {
    const bad = { ...(json as object), space: 'nope' }
    const result = safeParseScene(bad)
    expect(result.success).toBe(false)
  })

  it('rejects a scene missing required fields', () => {
    const result = safeParseScene({ id: 'x' })
    expect(result.success).toBe(false)
  })
})

describe('action params are typed (§2.8)', () => {
  const mk = (params: unknown): unknown => ({
    schemaVersion: '0.1.0', id: 'p', space: '2d', canvas: { width: 10, height: 10 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(10) } },
    root: { id: 'root', word: 's', transform: identityTransform(), children: [
      { id: 'bt', word: 't', transform: identityTransform(), children: [],
        components: { behavior: constant({ type: 'action', action: 'translate', target: 'a', duration: 1, params }) }, }] },
  })

  it('rejects domain vocabulary where coordinates belong', () => {
    // Domain names where coordinates belong: this parses, renders, and does nothing.
    const r = safeParseScene(mk({ from: 'A', to: 'C', liftY: 168 }))
    expect(r.success).toBe(false)
    expect(r.success ? '' : (r.error?.issues[0]?.message ?? '')).toMatch(/params.to \{x,y,z\}|not domain names/)
  })

  it('accepts a real vector', () => {
    expect(safeParseScene(mk({ to: { x: 1, y: 2, z: 0 } })).success).toBe(true)
  })

  it('accepts an unbound forEach binding in a template', () => {
    // Inside a forEach template these are placeholders until a row is stamped.
    expect(safeParseScene(mk({ to: { x: { $: 'toX' }, y: 260, z: 0 } })).success).toBe(true)
  })
})
