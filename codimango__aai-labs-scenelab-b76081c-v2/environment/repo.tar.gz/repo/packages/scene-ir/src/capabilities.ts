/**
 * What a renderer consumes, and what it therefore drops (Design §2.9).
 *
 * The adapter contract has two halves: "Degrade, never fail" and "Report what was dropped". This
 * is the second — naming, per renderer, what will not survive the trip. Without it a scene can
 * declare components nothing reads and look like a success at every layer that could complain.
 */
import type { ComponentMap, Entity, Scene } from './types'

/**
 * How a component relates to output.
 *  - `drawable`     produces geometry.
 *  - `modifier`     changes how a subtree draws (opacity).
 *  - `descriptive`  a request, not a specification (§2.7); ignoring one is legitimate.
 *  - `unimplemented` typed, accepted by the schema, and read by nothing. Declaring these is not a
 *                   mistake by the scene author — the format invites them — so a renderer owes an
 *                   explicit report rather than silence.
 */
export type ComponentSupport = 'drawable' | 'modifier' | 'descriptive' | 'unimplemented'

export const COMPONENT_SUPPORT: Record<string, ComponentSupport> = {
  circle: 'drawable',
  rect: 'drawable',
  polygon: 'drawable',
  line: 'drawable',
  path: 'drawable',
  text: 'drawable',
  box: 'drawable',
  sphere: 'drawable',
  cylinder: 'drawable',
  cone: 'drawable',
  torus: 'drawable',
  mesh: 'drawable',
  opacity: 'modifier',
  embedding: 'descriptive',
  motionEmbedding: 'descriptive',
  skeleton: 'unimplemented',
  skinnedMesh: 'unimplemented',
  // Read by the three.js renderer; the 2D painters skip it, which `dropReport` will say.
  light: 'drawable',
  rigidbody: 'unimplemented',
  collider: 'unimplemented',
  constraint: 'unimplemented',
  link: 'unimplemented',
}

/** Components that produce geometry in the shared projection pass, hence in canvas and manim. */
export const PROJECTED_COMPONENTS: readonly string[] = [
  'circle', 'rect', 'polygon', 'line', 'path', 'text', 'box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh', 'opacity',
]

/**
 * What the three.js renderer consumes. It shades real geometry, so it carries the volumetric
 * shapes faithfully and reads declared lights — neither of which the 2D painters can do.
 */
export const THREE_COMPONENTS: readonly string[] = [
  'circle', 'rect', 'polygon', 'line', 'path', 'text', 'box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh', 'opacity', 'light',
]

/**
 * Volumetric shapes have no true projection in the 2D pass; they are drawn as planar stand-ins.
 * That is a legitimate degradation, but the viewer should be told it happened rather than
 * wondering why a sphere looks like a circle.
 */
export const APPROXIMATED_COMPONENTS: readonly string[] = ['box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh']

export interface Drop {
  entityId: string
  component: string
  support: ComponentSupport
  /** `skipped` contributes nothing; `approximated` draws, but not as authored. */
  outcome: 'skipped' | 'approximated'
  note: string
}

function walk(entity: Entity, visit: (n: Entity) => void): void {
  visit(entity)
  for (const child of entity.children) walk(child as Entity, visit)
}

/**
 * What `supported` will not faithfully render in `scene`.
 * `approximate` names components that draw, but only as a stand-in.
 */
export function dropReport(
  scene: Scene,
  supported: Iterable<string> = PROJECTED_COMPONENTS,
  approximate: Iterable<string> = APPROXIMATED_COMPONENTS,
): Drop[] {
  const can = new Set(supported)
  const approx = new Set(approximate)
  const drops: Drop[] = []

  walk(scene.root as Entity, (n) => {
    const comps = n.components as ComponentMap | undefined
    if (!comps) return
    for (const key of Object.keys(comps)) {
      if (comps[key] === undefined) continue
      const support = COMPONENT_SUPPORT[key] ?? 'unimplemented'
      if (!can.has(key)) {
        drops.push({
          entityId: n.id,
          component: key,
          support,
          outcome: 'skipped',
          note:
            support === 'descriptive'
              ? 'descriptive component; nothing synthesizes it yet, so it contributes nothing'
              : support === 'unimplemented'
                ? 'typed by the schema but read by no renderer'
                : 'not supported by this renderer',
        })
      } else if (approx.has(key)) {
        drops.push({
          entityId: n.id,
          component: key,
          support,
          outcome: 'approximated',
          note: 'volumetric shape drawn as a planar stand-in, not shaded geometry',
        })
      }
    }
  })
  return drops
}

/** One line per distinct (component, outcome), with counts — the §2.9 sentence. */
export function formatDropReport(drops: Drop[]): string {
  if (drops.length === 0) return 'nothing dropped'
  const groups = new Map<string, { n: number; d: Drop }>()
  for (const d of drops) {
    const key = `${d.component}:${d.outcome}`
    const g = groups.get(key)
    if (g) g.n++
    else groups.set(key, { n: 1, d })
  }
  return [...groups.values()]
    .sort((a, b) => b.n - a.n)
    .map(({ n, d }) => `${n}x ${d.component} ${d.outcome} (${d.note})`)
    .join('; ')
}
