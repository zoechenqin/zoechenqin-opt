import { describe, it, expect, afterEach } from 'vitest'
import {
  constant,
  contentHash,
  identityTransform,
  parseScene,
  resolveScene,
  setSynthesisProvider,
  synthesize,
  synthesizedEntities,
} from './index'
import type { Entity, Scene, SynthesisProvider } from './index'

const scene = (): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'z',
    space: '2d',
    canvas: { width: 100, height: 100 },
    embeddings: { oak: { phrase: 'a gnarled oak' } },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'tree',
          word: 'tree',
          transform: identityTransform(),
          components: { embedding: constant({ ref: 'oak' }) },
          children: [],
        },
      ],
    },
  }) as unknown as Scene

/** A stand-in interpreter. The real one is not built; this exercises the contract around it. */
const stub = (over: Partial<SynthesisProvider> = {}): SynthesisProvider => ({
  name: 'stub',
  version: '1',
  synthesize: (req) => ({
    children: [
      {
        id: `${req.entityId}_trunk`,
        word: 'trunk',
        transform: identityTransform(),
        components: { rect: constant({ size: { x: 1, y: 5 }, style: { fill: constant({ r: 0.4, g: 0.2, b: 0.1, a: 1 }) } }) },
        children: [],
      } as unknown as Entity,
    ],
  }),
  ...over,
})

afterEach(() => setSynthesisProvider(null))

describe('synthesis (§2.7)', () => {
  it('does nothing, and says so, when no interpreter is registered', () => {
    // Silently returning the scene unchanged is how a description comes to look like a spec.
    const r = synthesize(scene())
    expect(r.synthesized).toBe(0)
    expect(r.skipped).toEqual([{ entityId: 'tree', ref: 'oak', reason: 'no-provider' }])
    expect(resolveScene(r.scene, 0).primitives).toHaveLength(0)
  })

  it('writes structure into the scene when one is', () => {
    setSynthesisProvider(stub())
    const r = synthesize(scene())
    expect(r.synthesized).toBe(1)
    expect(r.skipped).toEqual([])
    // the description became something a renderer can draw and a human can drag
    expect(resolveScene(r.scene, 0).primitives.map((p) => p.id)).toEqual(['tree_trunk'])
  })

  it('marks output with provenance that pins the interpreter', () => {
    setSynthesisProvider(stub())
    const marked = synthesizedEntities(synthesize(scene(), { seed: 7 }).scene)
    expect(marked.map((m) => m.id)).toEqual(['tree', 'tree_trunk'])
    expect(marked[0]?.provenance).toMatchObject({ from: 'oak', provider: 'stub', version: '1', seed: 7 })
    expect(marked[0]?.provenance.hash).toMatch(/^[0-9a-f]{8}$/)
  })

  it('keeps the description attached, so it can be re-synthesized', () => {
    setSynthesisProvider(stub())
    const out = synthesize(scene()).scene
    const tree = (out.root as Entity).children[0] as Entity
    expect(tree.components?.['embedding']).toBeDefined()
  })

  it('is reproducible: same inputs, same hash; different seed, different hash', () => {
    setSynthesisProvider(stub())
    const a = synthesizedEntities(synthesize(scene(), { seed: 1 }).scene)[0]!.provenance.hash
    const b = synthesizedEntities(synthesize(scene(), { seed: 1 }).scene)[0]!.provenance.hash
    const c = synthesizedEntities(synthesize(scene(), { seed: 2 }).scene)[0]!.provenance.hash
    expect(a).toBe(b)
    expect(a).not.toBe(c)
  })

  it('running it twice does not synthesize twice', () => {
    setSynthesisProvider(stub())
    const once = synthesize(scene()).scene
    const twice = synthesize(once)
    expect(twice.synthesized).toBe(0)
    expect(resolveScene(twice.scene, 0).primitives).toHaveLength(1)
  })

  it('an interpreter with no opinion is not an error', () => {
    setSynthesisProvider(stub({ synthesize: () => null }))
    const r = synthesize(scene())
    expect(r.skipped[0]?.reason).toBe('declined')
  })

  it('reports a reference to an undeclared embedding', () => {
    setSynthesisProvider(stub())
    const s = scene()
    delete (s as { embeddings?: unknown }).embeddings
    expect(synthesize(s).skipped[0]?.reason).toBe('undeclared')
  })

  it('is never part of resolve — resolving alone draws nothing', () => {
    // Synthesis commits one interpreter's answer, so it has to be something you chose to run.
    setSynthesisProvider(stub())
    expect(resolveScene(scene(), 0).primitives).toHaveLength(0)
  })

  it('the result survives a schema round-trip, provenance included', () => {
    setSynthesisProvider(stub())
    const out = synthesize(scene()).scene
    const back = parseScene(JSON.parse(JSON.stringify(out)))
    expect(synthesizedEntities(back)).toHaveLength(2)
  })

  it('applies synthesized style to the entity\'s own drawable', () => {
    // Synthesis is `(word, embedding) -> style, and possibly structure`; style is its primary
    // output, so a provider returning one must not have it quietly dropped.
    const s = scene()
    const tree = (s.root as Entity).children[0] as Entity
    ;(tree as { components: Record<string, unknown> }).components['rect'] = constant({
      size: { x: 2, y: 2 },
      style: { fill: constant({ r: 0, g: 0, b: 0, a: 1 }) },
    })
    setSynthesisProvider(stub({ synthesize: () => ({ style: { fill: constant({ r: 0.1, g: 0.9, b: 0.2, a: 1 }) } }) }))
    const out = synthesize(s).scene
    const fill = resolveScene(out, 0).primitives.find((p) => p.id === 'tree')!.shape.style.fill
    expect(fill).toMatchObject({ r: 0.1, g: 0.9, b: 0.2 })
  })

  it('applies style to generated children when the entity draws nothing itself', () => {
    setSynthesisProvider(stub({ synthesize: (req) => ({ ...stub().synthesize(req)!, style: { fill: constant({ r: 1, g: 0, b: 1, a: 1 }) } }) }))
    const out = synthesize(scene()).scene
    const fill = resolveScene(out, 0).primitives.find((p) => p.id === 'tree_trunk')!.shape.style.fill
    expect(fill).toMatchObject({ r: 1, g: 0, b: 1 })
  })

  it('hashes deterministically', () => {
    expect(contentHash('a')).toBe(contentHash('a'))
    expect(contentHash('a')).not.toBe(contentHash('b'))
  })
})
