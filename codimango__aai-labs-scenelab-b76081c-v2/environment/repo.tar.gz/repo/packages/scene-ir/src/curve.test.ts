import { describe, it, expect } from 'vitest'
import { behaviorOf, behaviorStateAt, constant, identityTransform, parseScene, resolveScene, sampleKeyframes, simulate } from './index'
import type { BTNode, Keyframe, Scene } from './index'

const kfs = (...pairs: Array<[number, unknown]>): Keyframe<unknown>[] =>
  pairs.map(([t, value]) => ({ t, value }) as Keyframe<unknown>)

const v = (x: number) => ({ x, y: 0, z: 0 })

const sceneWith = (behavior: BTNode, duration?: number): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'curve',
    space: '2d',
    canvas: { width: 100, height: 100 },
    ...(duration !== undefined ? { duration } : {}),
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        { id: 'bt', word: 'motion', transform: identityTransform(), children: [], components: { behavior: constant(behavior) } },
        {
          id: 'box',
          word: 'box',
          transform: identityTransform(),
          children: [],
          components: { rect: constant({ size: { x: 1, y: 1 }, style: { fill: constant({ r: 0, g: 0, b: 0, a: 1 }) } }) },
        },
      ],
    },
  }) as Scene

const posCurve = (from = 0, to = 10, end = 2): BTNode =>
  ({ type: 'curve', id: 'c', target: 'box', property: 'transform.position', keyframes: kfs([0, v(from)], [end, v(to)]) }) as BTNode

const posOf = (scene: Scene, t: number) => behaviorStateAt(scene, t).get('box')?.position

describe('sampleKeyframes', () => {
  it('interpolates vectors componentwise and holds outside the span', () => {
    const k = kfs([0, v(0)], [2, v(10)])
    expect(sampleKeyframes(k, 0)).toEqual(v(0))
    expect(sampleKeyframes(k, 1)).toEqual(v(5))
    expect(sampleKeyframes(k, 5)).toEqual(v(10))
  })

  it('steps values that have no meaningful midpoint rather than inventing one', () => {
    const k = kfs([0, 'red'], [2, 'blue'])
    expect(sampleKeyframes(k, 0.5)).toBe('red')
    expect(sampleKeyframes(k, 2)).toBe('blue')
  })

  it('blends colors componentwise', () => {
    const k = kfs([0, { r: 0, g: 0, b: 0, a: 1 }], [2, { r: 1, g: 1, b: 1, a: 1 }])
    expect(sampleKeyframes(k, 1)).toEqual({ r: 0.5, g: 0.5, b: 0.5, a: 1 })
  })
})

describe('curve leaf', () => {
  it('occupies its keyframe span in the schedule', () => {
    const sim = simulate(sceneWith(posCurve(0, 10, 2)))
    expect(sim.schedule).toHaveLength(1)
    expect(sim.schedule[0]).toMatchObject({ start: 0, duration: 2, target: 'box', action: 'curve' })
    expect(sim.duration).toBe(2)
  })

  it('drives a transform channel over its own span', () => {
    const scene = sceneWith(posCurve(0, 10, 2))
    expect(posOf(scene, 0)).toEqual(v(0))
    expect(posOf(scene, 1)).toEqual(v(5))
    expect(posOf(scene, 2)).toEqual(v(10))
  })

  it('holds its final value after it ends', () => {
    expect(posOf(sceneWith(posCurve(0, 10, 2)), 9)).toEqual(v(10))
  })

  it('times keyframes locally: a curve after an action starts when the action ends', () => {
    const scene = sceneWith({
      type: 'sequence',
      children: [
        { type: 'action', action: 'translate', target: 'box', duration: 3, params: { to: v(0) } },
        posCurve(0, 10, 2),
      ],
    } as BTNode)
    // The curve's own t=0 is scene t=3, so its midpoint is scene t=4 — not t=1.
    expect(posOf(scene, 3)).toEqual(v(0))
    expect(posOf(scene, 4)).toEqual(v(5))
    expect(posOf(scene, 5)).toEqual(v(10))
    expect(simulate(scene).duration).toBe(5)
  })

  it('is pinned to absolute time by a time condition', () => {
    const scene = sceneWith({ type: 'condition', on: 'time', params: { at: 4 }, child: posCurve(0, 10, 2) } as BTNode)
    expect(simulate(scene).schedule[0]).toMatchObject({ start: 4, duration: 2 })
    expect(posOf(scene, 5)).toEqual(v(5))
  })

  it('stretches rather than truncates under a timeScale decorator', () => {
    // scale 0.5 halves speed, so a 2s span occupies 4s and the midpoint moves to t=2.
    const scene = sceneWith({
      type: 'decorator',
      decorator: 'timeScale',
      params: { scale: 0.5 },
      child: posCurve(0, 10, 2),
    } as BTNode)
    expect(simulate(scene).schedule[0]).toMatchObject({ duration: 4 })
    expect(posOf(scene, 2)).toEqual(v(5))
    expect(posOf(scene, 4)).toEqual(v(10))
  })

  it('replays under repeat, which absolute times could not express', () => {
    const scene = sceneWith({ type: 'sequence', repeat: 3, children: [posCurve(0, 10, 2)] } as BTNode)
    expect(simulate(scene).schedule.map((e) => e.start)).toEqual([0, 2, 4])
    expect(simulate(scene).duration).toBe(6)
  })

  it('drives a component property through to the resolved primitive', () => {
    const scene = sceneWith({
      type: 'curve',
      id: 'fade',
      target: 'box',
      property: 'components.rect.style.fill',
      keyframes: kfs([0, { r: 0, g: 0, b: 0, a: 1 }], [2, { r: 1, g: 0, b: 0, a: 1 }]),
    } as BTNode)
    const prim = resolveScene(scene, 1).primitives.find((p) => p.id === 'box')
    expect((prim?.components?.['rect'] as any).style.fill).toEqual({ r: 0.5, g: 0, b: 0, a: 1 })
  })

  it('leaves untouched channels to the authored transform', () => {
    const state = behaviorStateAt(sceneWith(posCurve()), 1).get('box')
    expect(state?.position).toBeDefined()
    expect(state?.scale).toBeUndefined()
    expect(state?.rotation).toBeUndefined()
  })
})

describe('curve schema', () => {
  const withCurve = (curve: unknown) => () => parseScene(JSON.parse(JSON.stringify(sceneWith(curve as BTNode))))

  it('accepts a well-formed curve and gives it an id', () => {
    const scene = withCurve(posCurve())()
    expect(behaviorOf((scene.root as any).children[0])!.id).toBe('c')
  })

  it('rejects a single keyframe — that is a constant wearing a timeline', () => {
    expect(withCurve({ type: 'curve', target: 'box', property: 'transform.position', keyframes: kfs([0, v(1)]) })).toThrow()
  })

  it('rejects keyframes that run backwards', () => {
    expect(
      withCurve({ type: 'curve', target: 'box', property: 'transform.position', keyframes: kfs([2, v(1)], [0, v(2)]) }),
    ).toThrow(/ascending t/)
  })

  it('rejects an empty property path', () => {
    expect(withCurve({ type: 'curve', target: 'box', property: '', keyframes: kfs([0, v(0)], [1, v(1)]) })).toThrow()
  })
})
