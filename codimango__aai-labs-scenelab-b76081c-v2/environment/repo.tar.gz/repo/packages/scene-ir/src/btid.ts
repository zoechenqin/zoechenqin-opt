/**
 * Behavior-tree node identity (Design §4.6).
 *
 * A correction event addresses a tree node by id — `updateBehavior` resolves
 * `behavior.setDuration`, `behavior.setParams` and the `forEach.*` overrides that way, and the
 * structural events do the same. So a node without an id cannot be corrected at all: the event
 * fails as though the node were not in the scene. Leaving `id` optional therefore makes
 * correctability accidental, which is the wrong property for the artifact the project exists to
 * produce.
 *
 * Authoring stays permissive and the guarantee is established at the gate: `parseScene` runs
 * `assignBehaviorIds`, so every scene that entered the system through the schema has an id on
 * every node, whether or not its author wrote one. Authored ids are never overwritten — they are
 * what a human or model chose to call the node, and corrections may already reference them.
 */
import { constant } from './animatable'
import { behaviorOf } from './builders'
import type { BTNode, Entity, Scene } from './types'

/** Same charset as EntityId. `:` is reserved for procedural expansion and `-` is not allowed. */
export const BT_ID_PATTERN = /^[A-Za-z0-9_.]+$/

/**
 * Assigned ids are positional: the owning entity, then the index path down the tree
 * (`hanoi.bt`, `hanoi.bt.0`, `hanoi.bt.0.1`). Dots are legal in the charset, and deriving the id
 * from the path rather than a counter keeps it stable across runs — two parses of the same scene
 * produce the same ids, which is what lets a correction recorded in one session apply in the next.
 *
 * Positional ids do move if the tree is restructured. That is precisely what the structural
 * correction events are for: an edit that reorders nodes is recorded as an edit, not left to be
 * inferred from ids that silently changed meaning.
 */
function withIds(node: BTNode, path: string): BTNode {
  const n = node as unknown as Record<string, unknown>
  const needsId = typeof n['id'] !== 'string' || n['id'] === ''

  let children: BTNode[] | undefined
  if (Array.isArray(n['children'])) {
    const src = n['children'] as BTNode[]
    const mapped = src.map((c, i) => withIds(c, `${path}.${i}`))
    if (mapped.some((c, i) => c !== src[i])) children = mapped
  }
  const child = n['child'] ? withIds(n['child'] as BTNode, `${path}.c`) : undefined
  const template = n['template'] ? withIds(n['template'] as BTNode, `${path}.t`) : undefined
  const childChanged = child !== undefined && child !== n['child']
  const templateChanged = template !== undefined && template !== n['template']

  // Returning the input untouched when nothing needs an id is what lets the caller detect that a
  // scene is already fully identified and hand back the same object rather than a deep copy.
  if (!needsId && !children && !childChanged && !templateChanged) return node

  const next: Record<string, unknown> = { ...n }
  if (needsId) next['id'] = path
  if (children) next['children'] = children
  if (childChanged) next['child'] = child
  if (templateChanged) next['template'] = template
  return next as unknown as BTNode
}

/** Fill in every missing behavior-tree node id. Pure; authored ids are preserved. */
export function assignBehaviorIds(scene: Scene): Scene {
  let changed = false

  const visit = (entity: Entity): Entity => {
    let next = entity
    const behavior = behaviorOf(entity)
    if (behavior) {
      const assigned = withIds(behavior, `${entity.id}.bt`)
      if (assigned !== behavior) {
        next = { ...entity, components: { ...entity.components, behavior: constant(assigned) } } as Entity
        changed = true
      }
    }
    const children = next.children.map((c) => visit(c as Entity))
    if (children.some((c, i) => c !== next.children[i])) {
      next = { ...next, children } as Entity
      changed = true
    }
    return next
  }

  const root = visit(scene.root as Entity)
  return changed ? ({ ...scene, root: root as Scene['root'] }) : scene
}

/** Every behavior-tree node id in the scene, in traversal order, with the entity that owns it. */
export function collectBehaviorIds(scene: Scene): Array<{ id: string; ownerId: string }> {
  const out: Array<{ id: string; ownerId: string }> = []

  const walkBT = (node: BTNode, ownerId: string): void => {
    const n = node as unknown as Record<string, unknown>
    if (typeof n['id'] === 'string') out.push({ id: n['id'], ownerId })
    if (Array.isArray(n['children'])) for (const c of n['children'] as BTNode[]) walkBT(c, ownerId)
    if (n['child']) walkBT(n['child'] as BTNode, ownerId)
    if (n['template']) walkBT(n['template'] as BTNode, ownerId)
  }

  const visit = (entity: Entity): void => {
    const behavior = behaviorOf(entity)
    if (behavior) walkBT(behavior, entity.id)
    for (const c of entity.children) visit(c as Entity)
  }

  visit(scene.root as Entity)
  return out
}
