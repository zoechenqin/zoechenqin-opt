/**
 * Color: sRGB RGBA storage, with OKLab as the interpolation space (§3.11).
 * Perceptual work happens here, off the stored representation.
 */
import type { Color } from './types'

const clamp01 = (x: number): number => (x < 0 ? 0 : x > 1 ? 1 : x)

export function srgbToLinear(c: number): number {
  return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
}

export function linearToSrgb(c: number): number {
  return c <= 0.0031308 ? c * 12.92 : 1.055 * Math.pow(c, 1 / 2.4) - 0.055
}

type Triple = [number, number, number]

/** Linear sRGB → OKLab (Björn Ottosson). */
export function linearToOklab(rgb: Triple): Triple {
  const [r, g, b] = rgb
  const l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
  const m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
  const s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
  const l_ = Math.cbrt(l)
  const m_ = Math.cbrt(m)
  const s_ = Math.cbrt(s)
  return [
    0.2104542553 * l_ + 0.793617785 * m_ - 0.0040720468 * s_,
    1.9779984951 * l_ - 2.428592205 * m_ + 0.4505937099 * s_,
    0.0259040371 * l_ + 0.7827717662 * m_ - 0.808675766 * s_,
  ]
}

/** OKLab → linear sRGB. */
export function oklabToLinear(lab: Triple): Triple {
  const [L, a, b] = lab
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b
  const s_ = L - 0.0894841775 * a - 1.291485548 * b
  const l = l_ * l_ * l_
  const m = m_ * m_ * m_
  const s = s_ * s_ * s_
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  ]
}

/** Perceptually smooth color interpolation: lerp in OKLab, alpha linearly (§3.11). */
export function lerpColor(a: Color, b: Color, u: number): Color {
  const labA = linearToOklab([srgbToLinear(a.r), srgbToLinear(a.g), srgbToLinear(a.b)])
  const labB = linearToOklab([srgbToLinear(b.r), srgbToLinear(b.g), srgbToLinear(b.b)])
  const lab: Triple = [
    labA[0] + (labB[0] - labA[0]) * u,
    labA[1] + (labB[1] - labA[1]) * u,
    labA[2] + (labB[2] - labA[2]) * u,
  ]
  const lin = oklabToLinear(lab)
  return {
    r: clamp01(linearToSrgb(lin[0])),
    g: clamp01(linearToSrgb(lin[1])),
    b: clamp01(linearToSrgb(lin[2])),
    a: a.a + (b.a - a.a) * u,
  }
}
