/**
 * Timeline helpers (§4): timing metadata derived from a Scene, shared by the interactive
 * scrubber (canvas preview / widgets) and offline exporters (manim adapter, canvas render).
 * Keyframe times drive both the timeline ticks and the frames an adapter samples.
 */
import type { Animatable, Entity, Scene, Seconds, Keyframe } from './types'
import { simulate } from './simulate'

/**
 * INTERFACES
 */
export interface SceneTimeline {
  /** Seconds; `scene.duration` if set, else the last keyframe time (0 for a static scene). */
  duration: Seconds
  /** Frames per second; `scene.fps` if set, else 30. */
  fps: number
  /** Sorted keyframe times (includes 0) — timeline ticks / adapter sample points. */
  keyframeTimes: number[]
  /** Per-object lanes — property-agnostic, only entities that have at least one keyframe. Scene root excluded. */
  entities: EntityTimeline[]
}

interface EntityTimeline {
  id: string
  word: string
  name?: string
  depth: number
  times: number[]
  properties: PropertyTrack[]
}

interface PropertyTrack {
  /** The `curve` leaf this lane edits — the address a `keyframe.*` correction carries (§4.2). */
  curveId: string
  label: string
  /** Scene time at which this curve's local t=0 falls. */
  start: Seconds
  /** GLOBAL times, for display on the scene timeline. Subtract `start` for the authored value. */
  keyframes: Keyframe<unknown>[]
}

/**
 * HELPER FUNCTIONSß
 */
/** `transform.position` -> "Position"; `components.rect.style.fill` -> "Fill". */
function labelForProperty(property: string): string {
  const last = property.split('.').filter(Boolean).pop() ?? property
  return last.charAt(0).toUpperCase() + last.slice(1)
}

/**
 * Lanes come from the schedule, not from the entity tree: keyframes live in `curve` leaves
 * (§4.2), and only simulation knows when a given leaf starts. Times are converted to the scene
 * axis here so the scrubber can place markers directly; the widget converts back when it records
 * an edit, which is what keeps the stored keyframe times local.
 */
function buildEntityTimelines(scene: Scene): EntityTimeline[] {
  const byTarget = new Map<string, PropertyTrack[]>()
  for (const entry of simulate(scene).schedule) {
    if (entry.action !== 'curve') continue
    const keyframes = entry.params['keyframes'] as Keyframe<unknown>[] | undefined
    const property = entry.params['property']
    if (!Array.isArray(keyframes) || typeof property !== 'string') continue
    const lane: PropertyTrack = {
      curveId: entry.btId ?? property,
      label: labelForProperty(property),
      start: entry.start,
      keyframes: keyframes.map((kf) => ({ ...kf, t: entry.start + kf.t })),
    }
    const list = byTarget.get(entry.target)
    if (list) list.push(lane)
    else byTarget.set(entry.target, [lane])
  }

  const timelines: EntityTimeline[] = []
  const walk = (entity: Entity, depth: number): void => {
    const properties = byTarget.get(entity.id)
    if (properties && properties.length > 0) {
      const times = [...new Set(properties.flatMap((p) => p.keyframes.map((kf) => kf.t)))].sort((a, b) => a - b)
      timelines.push({
        id: entity.id,
        word: entity.word,
        ...(entity.name !== undefined ? { name: entity.name } : {}),
        depth,
        times,
        properties,
      })
    }
    for (const c of entity.children) walk(c as Entity, depth + 1)
  }
  // Scene root (id 'root' / word 'scene') does not get its own lane.
  for (const child of (scene.root as Entity).children) walk(child as Entity, 0)
  return timelines
}

/** Every keyframe time in the scene, sorted ascending. Always includes 0. */
export function keyframeTimes(scene: Scene): number[] {
  const entities = buildEntityTimelines(scene)
  // Ticks are explicit keyframes plus everything the behavior trees imply (Design §3.2).
  const set = new Set<number>([0, ...entities.flatMap((n) => n.times), ...simulate(scene).moments])
  return [...set].sort((a, b) => a - b)
}

/** Timing summary for players, scrubbers, and exporters. Single returned object from this module. */
export function sceneTimeline(scene: Scene): SceneTimeline {
  const entities = buildEntityTimelines(scene)
  const sim = simulate(scene)
  const globalSet = new Set<number>([0, ...entities.flatMap((n) => n.times), ...sim.moments])
  const times = [...globalSet].sort((a, b) => a - b)
  const lastKf = times.length > 0 ? times[times.length - 1]! : 0
  return {
    // A behaviour-driven scene has no keyframes at all, so the simulated end matters too.
    duration: scene.duration ?? Math.max(lastKf, sim.duration),
    fps: scene.fps ?? 30,
    keyframeTimes: times,
    entities,
  }
}
