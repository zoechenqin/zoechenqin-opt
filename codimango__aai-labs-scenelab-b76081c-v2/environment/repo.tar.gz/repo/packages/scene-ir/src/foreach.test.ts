import { describe, it, expect } from 'vitest'
import { constant, identityTransform, parseScene, resolveScene, simulate } from './index'
import type { BTNode, Scene } from './index'

const sceneWith = (behavior: BTNode, rings = 3): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'fe',
    space: '2d',
    canvas: { width: 100, height: 100 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        { id: 'bt', word: 'timeline', transform: identityTransform(), children: [], components: { behavior: constant(behavior) } },
        ...Array.from({ length: rings }, (_, i) => ({
          id: `ring_${i + 1}`,
          word: 'ring',
          transform: identityTransform(),
          components: { rect: constant({ size: { x: 1, y: 1 }, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) },
          children: [],
        })),
      ],
    },
  }) as Scene

/** One editable template: lift, move across, lower. Row fields supply the where. */
const liftMoveLower: BTNode = {
  type: 'sequence',
  id: 'move',
  children: [
    { type: 'action', id: 'lift', action: 'translate', target: 'ring_${disk}', duration: 0.5, params: { to: { x: { $: 'fromX' }, y: 100, z: 0 } } },
    { type: 'action', id: 'across', action: 'translate', target: 'ring_${disk}', duration: 0.5, params: { to: { x: { $: 'toX' }, y: 100, z: 0 } } },
    { type: 'action', id: 'lower', action: 'translate', target: 'ring_${disk}', duration: 0.5, params: { to: { x: { $: 'toX' }, y: { $: 'restY' }, z: 0 } } },
  ],
} as BTNode

const rows = [
  { disk: 1, fromX: -50, toX: 50, restY: 0 },
  { disk: 2, fromX: -50, toX: 0, restY: 10 },
]

const forEach = (extra: Record<string, unknown> = {}): BTNode =>
  ({ type: 'forEach', id: 'moves', source: { kind: 'rows', rows }, template: liftMoveLower, ...extra }) as BTNode

describe('forEach — the temporal instance op (§2.8)', () => {
  it('stamps the template once per row, laid end to end', () => {
    const sim = simulate(sceneWith(forEach()))
    expect(sim.schedule).toHaveLength(6) // 2 rows x 3 actions
    expect(sim.duration).toBe(3)
    expect(sim.unresolved).toEqual([])
  })

  it('binds row fields into targets and values', () => {
    const sim = simulate(sceneWith(forEach()))
    expect(sim.schedule.map((e) => e.target)).toEqual([
      'ring_1', 'ring_1', 'ring_1',
      'ring_2', 'ring_2', 'ring_2',
    ])
    expect(sim.schedule[2]?.params['to']).toEqual({ x: 50, y: 0, z: 0 })
    expect(sim.schedule[5]?.params['to']).toEqual({ x: 0, y: 10, z: 0 })
  })

  it('keeps each stamped action addressable by row index', () => {
    const sim = simulate(sceneWith(forEach()))
    expect(sim.schedule.map((e) => e.btId)).toEqual([
      'lift:0', 'across:0', 'lower:0',
      'lift:1', 'across:1', 'lower:1',
    ])
  })

  it('one template edit retimes every row', () => {
    // The property a script leaf cannot offer: change the motion once, not 127 times.
    const slower = JSON.parse(JSON.stringify(liftMoveLower)) as any
    for (const c of slower.children) c.duration = 1
    const sim = simulate(sceneWith({ type: 'forEach', id: 'moves', source: { kind: 'rows', rows }, template: slower } as BTNode))
    expect(sim.duration).toBe(6)
  })

  it('an override corrects a single row without touching the generator', () => {
    const sim = simulate(sceneWith(forEach({ overrides: { '1': { toX: 999 } } })))
    expect(sim.schedule[4]?.params['to']).toEqual({ x: 999, y: 100, z: 0 })
    // row 0 is untouched
    expect(sim.schedule[1]?.params['to']).toEqual({ x: 50, y: 100, z: 0 })
  })

  it('parallel mode starts every row together', () => {
    const sim = simulate(sceneWith(forEach({ mode: 'parallel' })))
    expect(sim.schedule.filter((e) => e.start === 0)).toHaveLength(2)
    expect(sim.duration).toBe(1.5)
  })

  it('drives real geometry through resolve', () => {
    const scene = sceneWith(forEach())
    const x = (t: number): number => resolveScene(scene, t).primitives.find((p) => p.id === 'ring_1')!.worldMatrix[12]!
    expect(x(0)).toBe(0)
    expect(x(3)).toBe(50)
  })

  it('takes rows from a script source', () => {
    const sim = simulate(
      sceneWith({
        type: 'forEach',
        id: 'moves',
        source: {
          kind: 'script',
          language: 'typescript',
          code: `function* main() { for (let i = 1; i <= 3; i++) yield { disk: i, fromX: -50, toX: i * 10, restY: 0 } }`,
        },
        template: liftMoveLower,
      } as BTNode),
    )
    expect(sim.schedule).toHaveLength(9)
    expect(sim.schedule[8]?.params['to']).toEqual({ x: 30, y: 0, z: 0 })
  })

  it('refuses a source that yields actions instead of data', () => {
    // The constraint that keeps the generator/motion split intact: a source produces DATA.
    const sim = simulate(
      sceneWith({
        type: 'forEach',
        id: 'moves',
        source: {
          kind: 'script',
          language: 'typescript',
          code: `function* main() { yield { action: 'translate', target: 'ring_1', duration: 1, params: {} } }`,
        },
        template: liftMoveLower,
      } as BTNode),
    )
    expect(sim.schedule).toEqual([])
    expect(sim.unresolved[0]?.detail).toMatch(/yielded an action|belongs in the template/)
  })

  it('refuses to interpolate a non-scalar into a string', () => {
    // Otherwise it becomes "ring_[object Object]", a target matching no entity, and the action
    // quietly does nothing.
    const sim = simulate(
      sceneWith({ type: 'forEach', id: 'moves', source: { kind: 'rows', rows: [{ disk: { x: 1 }, fromX: 0, toX: 1, restY: 0 }] }, template: liftMoveLower } as BTNode),
    )
    expect(sim.schedule).toEqual([])
    expect(sim.unresolved[0]?.detail).toMatch(/Only strings, numbers and booleans/)
  })

  it('names the missing field when a template references one the row lacks', () => {
    const sim = simulate(
      sceneWith({ type: 'forEach', id: 'moves', source: { kind: 'rows', rows: [{ disk: 1 }] }, template: liftMoveLower } as BTNode),
    )
    expect(sim.unresolved[0]?.detail).toMatch(/fromX|row has/)
  })

  it('survives a schema round-trip', () => {
    const scene = sceneWith(forEach({ overrides: { '1': { toX: 999 } }, mode: 'parallel' }))
    expect(() => parseScene(JSON.parse(JSON.stringify(scene)))).not.toThrow()
  })
})
