/**
 * @scenelab/scene-ir — the renderer-agnostic scene graph core (docs/foundation.md).
 * ZERO React/renderer dependencies. Types + schema + resolve() + applyEvent().
 */

/** Scene-graph schema version stamped on every artifact (docs/foundation.md §3.2). */
export { SCHEMA_VERSION } from './version'

export * from './types'
export * from './math'
export * from './color'
export * from './animatable'
export * from './builders'
export * from './fixtures'
export * from './resolve'
export * from './apply'
export * from './schema'
export * from './graph'
export * from './btid'
export * from './guide'
export * from './simulate'
export * from './behavior'
export * from './script'
export * from './bind'
export * from './capabilities'
export * from './synthesize'
export * from './timeline'
