
/** Sample scenes for tests and playground — now canonical uses components bag for shapes (path and shape as separate component types). */
import type { BTNode, Scene } from './types'
import { constant } from './animatable'
import { identityTransform, translateTransform } from './builders'
import type { Transform } from './types'

export function sampleScene(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'sample',
    space: '2d',
    canvas: { width: 1920, height: 1080, background: { r: 0.95, g: 0.95, b: 0.95, a: 1 } },
    camera: {
      id: 'camera',
      transform: translateTransform({ x: 0, y: 0, z: 1000 }),
      projection: { type: 'orthographic', height: constant(1080) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'circle_1',
          word: 'planet',
          transform: translateTransform({ x: 100, y: 0, z: 0 }),
          components: {
            circle: constant({ radius: 50, style: { fill: constant({ r: 0, g: 0.55, b: 0.8, a: 1 }) } }),
          },
          children: [],
        },
        {
          id: 'label_1',
          word: 'label',
          transform: translateTransform({ x: 0, y: 80, z: 0 }),
          components: {
            text: constant({ content: 'c^2', fontSize: 48, align: 'center' as const, style: { fill: constant({ r: 0.1, g: 0.1, b: 0.1, a: 1 }) } }),
          },
          children: [],
        },
      ],
    },
  }
}

export function sampleScene3D(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'sample_3d',
    space: '3d',
    canvas: { width: 1280, height: 720, background: { r: 0.05, g: 0.05, b: 0.08, a: 1 } },
    fps: 30,
    duration: 4,
    camera: {
      id: 'camera',
      transform: {
        ...identityTransform(),
        position: constant({ x: 0, y: 5, z: 13 }),
        rotation: constant({ axis: { x: 1, y: 0, z: 0 }, angle: -0.32 }),
      },
      projection: { type: 'perspective', fovY: constant(50), near: 0.1, far: 1000 },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      // The behavior rides on root rather than on an entity of its own. A tree is something an
      // entity HAS, so a node existing only to hold one showed up in the entity graph with no
      // transform anyone inherits, no children and nothing to draw.
      components: {
        behavior: constant({
          type: 'parallel',
          id: 'motion',
          children: [
            {
              type: 'curve',
              id: 'motion.spin',
              target: 'box',
              property: 'transform.rotation',
              // The midpoint is load-bearing, not decoration. Orientations interpolate by slerp,
              // and quat(2pi) is antipodal to quat(0) — the same orientation under the
              // quaternion double cover — so a single 0 -> 2pi segment slerps to no rotation at
              // all. Half turns are unambiguous, so a full turn needs two of them.
              keyframes: [
                { t: 0, value: { axis: { x: 0, y: 1, z: 0 }, angle: 0 } },
                { t: 2, value: { axis: { x: 0, y: 1, z: 0 }, angle: Math.PI } },
                { t: 4, value: { axis: { x: 0, y: 1, z: 0 }, angle: Math.PI * 2 } },
              ],
            },
            {
              type: 'curve',
              id: 'motion.bounce',
              target: 'sphere',
              property: 'transform.position',
              keyframes: [
                { t: 0, value: { x: 3, y: 0.5, z: 0 } },
                { t: 1, value: { x: 3, y: 2.5, z: 0 }, easing: 'easeInOut' },
                { t: 2, value: { x: 3, y: 0.5, z: 0 }, easing: 'easeInOut' },
                { t: 4, value: { x: 3, y: 0.5, z: 0 } },
              ],
            },
          ],
                  } as BTNode),
      },
      children: [
        {
          id: 'floor',
          word: 'floor',
          transform: {
            ...identityTransform(),
            position: constant({ x: 0, y: -2, z: 0 }),
            rotation: constant({ axis: { x: 1, y: 0, z: 0 }, angle: -Math.PI / 2 }),
          },
          components: {
            rect: constant({ size: { x: 18, y: 18 }, style: { fill: constant({ r: 0.2, g: 0.2, b: 0.25, a: 1 }) } }),
          },
          children: [],
        },
        {
          id: 'box',
          word: 'box',
          transform: {
            ...identityTransform(),
            position: constant({ x: 0, y: 0.5, z: 0 }),
            rotation: constant({ axis: { x: 0, y: 1, z: 0 }, angle: 0 }),
          },
          components: {
            box: constant({ size: { x: 1.2, y: 1.2, z: 1.2 }, style: { fill: constant({ r: 1, g: 0.84, b: 0, a: 1 }) } }),
          },
          children: [],
        },
        {
          id: 'sphere',
          word: 'sphere',
          transform: {
            ...identityTransform(),
            position: constant({ x: 3, y: 0.5, z: 0 }),
          },
          components: {
            sphere: constant({ radius: 0.75, style: { fill: constant({ r: 0.2, g: 0.7, b: 1, a: 1 }) } }),
          },
          children: [],
        },
        {
          id: 'cone',
          word: 'cone',
          transform: { ...identityTransform(), position: constant({ x: 0, y: 1.3, z: -2.5 }) },
          components: {
            cone: constant({ radius: 1.2, height: 2.6, style: { fill: constant({ r: 0.5, g: 0.9, b: 0.5, a: 1 }) } }),
          },
          children: [],
        },
        {
          id: 'torus',
          word: 'torus',
          transform: {
            ...identityTransform(),
            position: constant({ x: -3, y: 0.5, z: 0 }),
            rotation: constant({ axis: { x: 1, y: 0, z: 0 }, angle: Math.PI / 2 }),
          },
          components: {
            torus: constant({ radius: 0.7, tube: 0.25, style: { fill: constant({ r: 0.9, g: 0.3, b: 0.7, a: 1 }) } }),
          },
          children: [],
        },
      ],
    },
  }
}

/** Scene Language paper alignment: program P = repeat that composes 64 squares from same f_square (board) + DAG generalization. */
export function sampleBoard(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'board',
    space: '2d',
    embeddings: { weathered_oak: { phrase: 'weathered oak, visible grain' } },
    canvas: { width: 800, height: 800, background: { r: 1, g: 1, b: 1, a: 1 } },
    camera: {
      id: 'camera',
      transform: translateTransform({ x: 0, y: 0, z: 1000 }),
      projection: { type: 'orthographic', height: constant(800) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'square_template',
          template: true,
          word: 'square',
          transform: identityTransform(),
          components: {
            rect: constant({ size: { x: 70, y: 70 }, style: { fill: constant({ r: 0.82, g: 0.82, b: 0.82, a: 1 }) } }),
            embedding: constant({ ref: 'weathered_oak' }),
          },
          children: [],
        },
        {
          id: 'board',
          word: 'board',
          transform: translateTransform({ x: -280, y: -280, z: 0 }),
          components: { arrangement: constant({
            ops: [
              { id: 'points', type: 'points', generator: { type: 'grid', countX: 8, countY: 8, spacingX: 80, spacingY: 80 } },
              { id: 'instance', type: 'instance', templates: ['square_template'], points: 'points' },
            ],
            edges: [{ from: 'points', to: 'instance' }],
          }) },
          children: [],
        },
      ],
    },
  }
}

/** Arrangement — generalizable graph: points + instance with fan-out sharing same template (Houdini Copy to Points / Blender GeoNodes). */
export function sampleArrangement(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'arrangement_sample',
    space: '2d',
    canvas: { width: 800, height: 800, background: { r: 1, g: 1, b: 1, a: 1 } },
    camera: {
      id: 'camera',
      transform: translateTransform({ x: 0, y: 0, z: 1000 }),
      projection: { type: 'orthographic', height: constant(800) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'square_template',
          template: true,
          word: 'square',
          transform: identityTransform(),
          components: {
            rect: constant({ size: { x: 60, y: 60 }, style: { fill: constant({ r: 0.2, g: 0.6, b: 0.9, a: 1 }) } }),
          },
          children: [],
        },
        {
          id: 'boardA',
          word: 'board',
          transform: translateTransform({ x: -200, y: 0, z: 0 }),
          components: { arrangement: constant({
            ops: [
              { id: 'pointsA', type: 'points', generator: { type: 'grid', countX: 4, countY: 4, spacingX: 80, spacingY: 80, start: { x: -120, y: -120, z: 0 } } },
              { id: 'instanceA', type: 'instance', templates: ['square_template'], points: 'pointsA', overrides: { '0,0': { transform: translateTransform({ x: 10, y: 0, z: 0 }) } } },
            ],
            edges: [{ from: 'pointsA', to: 'instanceA' }],
          }) },
          children: [],
        },
        {
          id: 'boardB',
          word: 'board',
          transform: translateTransform({ x: 200, y: 0, z: 0 }),
          components: { arrangement: constant({
            ops: [
              { id: 'pointsB', type: 'points', generator: { type: 'radial', count: 8, radius: 120 } },
              { id: 'instanceB', type: 'instance', templates: ['square_template'], points: 'pointsB' },
            ],
            edges: [{ from: 'pointsB', to: 'instanceB' }],
          }) },
          children: [],
        },
      ],
    },
  }
}

/** Character skeletal hierarchy — extensible component framework example. */
export function sampleCharacter(): Scene {
  const bone = (pos: { x: number; y: number; z: number }): Transform => ({
    ...identityTransform(),
    position: constant(pos),
  })
  return {
    schemaVersion: '0.1.0',
    id: 'character',
    space: '3d',
    embeddings: { weathered_oak: { phrase: 'weathered oak, visible grain' } },
    canvas: { width: 1280, height: 720, background: { r: 0.05, g: 0.05, b: 0.08, a: 1 } },
    fps: 30,
    duration: 2,
    camera: {
      id: 'camera',
      transform: {
        ...identityTransform(),
        position: constant({ x: 0, y: 2.5, z: 6 }),
        rotation: constant({ axis: { x: 1, y: 0, z: 0 }, angle: -0.2 }),
      },
      projection: { type: 'perspective', fovY: constant(45), near: 0.1, far: 1000 },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'character_root',
          word: 'character',
          transform: translateTransform({ x: 0, y: 0, z: 0 }),
          components: {
            skeleton: constant({
              bones: [
                { id: 'hips', bindTransform: bone({ x: 0, y: 1.2, z: 0 }) },
                { id: 'spine', parent: 'hips', bindTransform: bone({ x: 0, y: 0.4, z: 0 }) },
                { id: 'left_thigh', parent: 'hips', bindTransform: bone({ x: -0.2, y: -0.1, z: 0 }), length: 0.5 },
                { id: 'left_shin', parent: 'left_thigh', bindTransform: bone({ x: 0, y: -0.5, z: 0 }), length: 0.5 },
                { id: 'left_foot', parent: 'left_shin', bindTransform: bone({ x: 0, y: -0.5, z: 0 }) },
              ],
            }),
            rigidbody: constant({ mass: 0 }),
          },
          children: [
            {
              id: 'body_mesh',
              word: 'body',
              transform: identityTransform(),
              components: {
                box: constant({ size: { x: 0.6, y: 1.2, z: 0.3 }, style: { fill: constant({ r: 0.9, g: 0.6, b: 0.5, a: 1 }) } }),
                skinnedMesh: constant({ skeletonId: 'character_root', bone: 'hips' }),
                embedding: constant({ ref: 'weathered_oak' }),
              },
              children: [],
            },
          ],
        },
      ],
    },
  }
}

/** W + Z: same word different embedding produces different visual identity (oak vs chrome). */
export function sampleWithEmbeddings(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'embeddings',
    space: '2d',
    embeddings: { polished_chrome: { phrase: 'polished chrome, mirror finish' }, weathered_oak: { phrase: 'weathered oak, visible grain' } },
    canvas: { width: 800, height: 400, background: { r: 1, g: 1, b: 1, a: 1 } },
    camera: {
      id: 'camera',
      transform: translateTransform({ x: 0, y: 0, z: 1000 }),
      projection: { type: 'orthographic', height: constant(400) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'chair_oak',
          word: 'chair',
          transform: translateTransform({ x: -150, y: 0, z: 0 }),
          components: {
            rect: constant({ size: { x: 120, y: 120 }, style: { fill: constant({ r: 0.6, g: 0.4, b: 0.2, a: 1 }) } }),
            embedding: constant({ ref: 'weathered_oak' }),
          },
          children: [],
        },
        {
          id: 'chair_chrome',
          word: 'chair',
          transform: translateTransform({ x: 150, y: 0, z: 0 }),
          components: {
            rect: constant({ size: { x: 120, y: 120 }, style: { fill: constant({ r: 0.8, g: 0.8, b: 0.9, a: 1 }) } }),
            embedding: constant({ ref: 'polished_chrome' }),
          },
          children: [],
        },
      ],
    },
  }
}

/** Bezier path sample — editor pen tool with cubic beziers, path and shape as separate component types. */
export function sampleBezierDiagram(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'bezier',
    space: '2d',
    embeddings: { weathered_oak: { phrase: 'weathered oak, visible grain' } },
    canvas: { width: 800, height: 400, background: { r: 1, g: 1, b: 1, a: 1 } },
    camera: {
      id: 'camera',
      transform: translateTransform({ x: 0, y: 0, z: 1000 }),
      projection: { type: 'orthographic', height: constant(400) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'curve_1',
          word: 'curve',
          transform: identityTransform(),
          components: {
            path: constant({
              segments: [
                { type: 'move', to: { x: -200, y: 0, z: 0 } },
                { type: 'cubicBezier', to: { x: 0, y: 0, z: 0 }, cp1: { x: -120, y: -120, z: 0 }, cp2: { x: -80, y: 120, z: 0 } },
                { type: 'cubicBezier', to: { x: 200, y: 0, z: 0 }, cp1: { x: 80, y: 120, z: 0 }, cp2: { x: 120, y: -120, z: 0 } },
              ],
              closed: false,
              style: { stroke: constant({ r: 0.1, g: 0.1, b: 0.8, a: 1 }), strokeWidth: constant(4) },
            }),
            embedding: constant({ ref: 'weathered_oak' }),
          },
          children: [],
        },
        {
          id: 'curve_2',
          word: 'path_closed',
          transform: translateTransform({ x: 0, y: -100, z: 0 }),
          components: {
            path: constant({
              segments: [
                { type: 'move', to: { x: -100, y: 0, z: 0 } },
                { type: 'cubicBezier', to: { x: 0, y: -100, z: 0 }, cp1: { x: -100, y: -80, z: 0 }, cp2: { x: -80, y: -100, z: 0 } },
                { type: 'cubicBezier', to: { x: 100, y: 0, z: 0 }, cp1: { x: 80, y: -100, z: 0 }, cp2: { x: 100, y: -80, z: 0 } },
                { type: 'cubicBezier', to: { x: 0, y: 100, z: 0 }, cp1: { x: 100, y: 80, z: 0 }, cp2: { x: 80, y: 100, z: 0 } },
                { type: 'cubicBezier', to: { x: -100, y: 0, z: 0 }, cp1: { x: -80, y: 100, z: 0 }, cp2: { x: -100, y: 80, z: 0 } },
              ],
              closed: true,
              style: { fill: constant({ r: 0.9, g: 0.3, b: 0.3, a: 1 }), stroke: constant({ r: 0.1, g: 0.1, b: 0.1, a: 1 }), strokeWidth: constant(2) },
            }),
          },
          children: [],
        },
      ],
    },
  }
}

/** Arrow referencing procedural board square — path + link component with EntityRef handling procedural ids via :. */
export function sampleArrowToBoard(): Scene {
  return {
    schemaVersion: '0.1.0',
    id: 'arrow_board',
    space: '2d',
    embeddings: { weathered_oak: { phrase: 'weathered oak, visible grain' } },
    canvas: { width: 800, height: 800, background: { r: 1, g: 1, b: 1, a: 1 } },
    camera: {
      id: 'camera',
      transform: translateTransform({ x: 0, y: 0, z: 1000 }),
      projection: { type: 'orthographic', height: constant(800) },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'square_template',
          template: true,
          word: 'square',
          transform: identityTransform(),
          components: {
            rect: constant({ size: { x: 70, y: 70 }, style: { fill: constant({ r: 0.85, g: 0.85, b: 0.85, a: 1 }), stroke: constant({ r: 0.2, g: 0.2, b: 0.2, a: 0.8 }) } }),
          },
          children: [],
        },
        {
          id: 'board',
          word: 'board',
          transform: translateTransform({ x: -280, y: -280, z: 0 }),
          components: { arrangement: constant({
            ops: [
              { id: 'points', type: 'points', generator: { type: 'grid', countX: 8, countY: 8, spacingX: 80, spacingY: 80 } },
              { id: 'instance', type: 'instance', templates: ['square_template'], points: 'points' },
            ],
            edges: [{ from: 'points', to: 'instance' }],
          }) },
          children: [],
        },
        {
          id: 'pointer',
          word: 'pointer',
          transform: identityTransform(),
          components: {
            path: constant({
              segments: [
                { type: 'move', to: { x: -300, y: 350, z: 0 } },
                { type: 'cubicBezier', to: { x: 40, y: 40, z: 0 }, cp1: { x: -200, y: 300, z: 0 }, cp2: { x: -100, y: 100, z: 0 } },
              ],
              closed: false,
              style: { stroke: constant({ r: 0.9, g: 0.1, b: 0.1, a: 1 }), strokeWidth: constant(3) },
            }),
            link: constant({
              // Only the head is pinned; the tail stays where the path's own `move` segment puts it.
              to: { parentId: 'board', index: '0,0', templateId: 'square_template', anchor: 'center' },
              toOffset: { x: 0, y: 0, z: 0 },
            }),
            embedding: constant({ ref: 'weathered_oak' }),
          },
          children: [],
        },
      ],
    },
  }
}

/** Hanoi 3 disks as plain BT sequence — shows hierarchical sub-steps lift/move/lower. */
export function sampleHanoiBehaviorTree(): Scene {
  const pegA = { x: -4, y: 0, z: 0 }
  const pegB = { x: 0, y: 0, z: 0 }
  const pegC = { x: 4, y: 0, z: 0 }

  const disk = (id: string, radius: number, y: number) => ({
    id,
    word: 'disk',
    transform: translateTransform({ x: pegA.x, y, z: 0 }),
    components: {
      cylinder: { kind: 'const' as const, value: { radius, height: 0.3, style: { fill: { kind: 'const' as const, value: { r: 0.8, g: 0.5, b: 0.2, a: 1 } } } } },
    },
    children: [] as any,
  })

  return {
    schemaVersion: '0.1.0',
    id: 'hanoi_bt',
    space: '3d',
    embeddings: { careful: { phrase: 'careful, deliberate movement' } },
    canvas: { width: 1280, height: 720, background: { r: 0.05, g: 0.05, b: 0.08, a: 1 } },
    fps: 30,
    duration: 7,
    camera: {
      id: 'camera',
      transform: {
        ...identityTransform(),
        position: constant({ x: 0, y: 3, z: 10 }),
        rotation: constant({ axis: { x: 1, y: 0, z: 0 }, angle: -0.3 }),
      },
      projection: { type: 'perspective', fovY: constant(45), near: 0.1, far: 1000 },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      components: {
        motionEmbedding: constant({ ref: 'careful' }),
        behavior: constant({
        type: 'sequence',
        id: 'hanoi_solve_3',
        speed: 1.0,
        children: [
          {
            type: 'sequence',
            id: 'move_1',
            children: [
              { type: 'action', id: 'm1_lift', action: 'translate', target: 'disk_1', duration: 1 / 3, params: { to: { x: pegA.x, y: 2, z: 0 } } },
              { type: 'action', id: 'm1_move', action: 'translate', target: 'disk_1', duration: 1 / 3, params: { to: { x: pegC.x, y: 2, z: 0 } } },
              { type: 'action', id: 'm1_lower', action: 'translate', target: 'disk_1', duration: 1 / 3, params: { to: { x: pegC.x, y: 0.15, z: 0 } } },
            ],
          },
          {
            type: 'decorator',
            id: 'move_2_hurried',
            decorator: 'motionStyle',
            params: { style: 'hurried', embedding: [0.1, 0.9, 0.1], model: 'motion_clip' },
            child: {
              type: 'sequence',
              id: 'move_2',
              children: [
                { type: 'action', id: 'm2_lift', action: 'translate', target: 'disk_2', duration: 1 / 3, params: { to: { x: pegA.x, y: 2, z: 0 } } },
                { type: 'action', id: 'm2_move', action: 'translate', target: 'disk_2', duration: 1 / 3, params: { to: { x: pegB.x, y: 2, z: 0 } } },
                { type: 'action', id: 'm2_lower', action: 'translate', target: 'disk_2', duration: 1 / 3, params: { to: { x: pegB.x, y: 0.45, z: 0 } } },
              ],
            },
          },
          {
            type: 'sequence',
            id: 'move_3',
            children: [
              { type: 'action', id: 'm3_lift', action: 'translate', target: 'disk_1', duration: 1 / 3, params: { to: { x: pegC.x, y: 2, z: 0 } } },
              { type: 'action', id: 'm3_move', action: 'translate', target: 'disk_1', duration: 1 / 3, params: { to: { x: pegB.x, y: 2, z: 0 } } },
              { type: 'action', id: 'm3_lower', action: 'translate', target: 'disk_1', duration: 1 / 3, params: { to: { x: pegB.x, y: 0.15, z: 0 } } },
            ],
          },
          {
            type: 'condition',
            id: 'fx_on_contact',
            on: 'contact',
            source: ['disk_1', 'peg_B'],
            child: {
              type: 'parallel',
              id: 'contact_fx',
              policy: 'all',
              children: [
                { type: 'action', id: 'fx_particles', action: 'upsertComponent', target: 'disk_1', duration: 1 / 3, params: { componentType: 'particleEmitter', value: { rate: 200 } } },
                { type: 'action', id: 'fx_flash', action: 'setStyle', target: 'peg_B', duration: 1 / 3, params: { path: 'fill', to: { r: 1, g: 0.2, b: 0.2, a: 1 } } },
              ],
            },
          },
        ],
        } as BTNode),
      } as never,
      children: [
        { id: 'peg_A', word: 'peg', transform: translateTransform(pegA), children: [] },
        { id: 'peg_B', word: 'peg', transform: translateTransform(pegB), children: [] },
        { id: 'peg_C', word: 'peg', transform: translateTransform(pegC), children: [] },
        disk('disk_1', 0.5, 0.15),
        disk('disk_2', 0.8, 0.45),
        disk('disk_3', 1.1, 0.75),
      ],
    },
  }
}

/** Hanoi 7 disks as Turing-complete script leaf in Behavior Tree — game BT style custom action, typescript preferred, script is part of BT model. */
export function sampleHanoiScript(): Scene {
  const pegs = [
    { x: -4, y: 0, z: 0 },
    { x: 0, y: 0, z: 0 },
    { x: 4, y: 0, z: 0 },
  ]
  return {
    schemaVersion: '0.1.0',
    id: 'hanoi_script',
    space: '3d',
    canvas: { width: 1280, height: 720, background: { r: 0.05, g: 0.05, b: 0.08, a: 1 } },
    fps: 30,
    duration: 15,
    camera: {
      id: 'camera',
      transform: {
        ...identityTransform(),
        position: constant({ x: 0, y: 3, z: 10 }),
        rotation: constant({ axis: { x: 1, y: 0, z: 0 }, angle: -0.3 }),
      },
      projection: { type: 'perspective', fovY: constant(45), near: 0.1, far: 1000 },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      components: { behavior: constant({
        type: 'script',
        id: 'hanoi_algorithm',
        language: 'typescript',
        code: `
          type Move = { disk: number; from: number; to: number };
          function* hanoi(n: number, from: number, to: number, aux: number): Generator<Move> {
            if (n === 1) yield { disk: 1, from, to };
            else {
              yield* hanoi(n-1, from, aux, to);
              yield { disk: n, from, to };
              yield* hanoi(n-1, aux, to, from);
            }
          }
          export function generate(ctx: { t: number, pegs: {x:number,y:number,z:number}[], liftHeight: number, speed: number }) {
            const moves = [...hanoi(7, 0, 2, 1)];
            const moveIndex = Math.floor(ctx.t * ctx.speed);
            const move = moves[Math.min(moveIndex, moves.length-1)];
            if (!move) return {};
            const fromPeg = ctx.pegs[move.from];
            const toPeg = ctx.pegs[move.to];
            const phase = (ctx.t * ctx.speed) % 1;
            let pos: {x:number,y:number,z:number};
            if (phase < 0.3) pos = { x: fromPeg.x, y: ctx.liftHeight, z: fromPeg.z };
            else if (phase < 0.7) {
              const p = (phase-0.3)/0.4;
              pos = { x: fromPeg.x + (toPeg.x-fromPeg.x)*p, y: ctx.liftHeight, z: 0 };
            } else {
              pos = { x: toPeg.x, y: 0.15 + (move.disk-1)*0.3, z: 0 };
            }
            return { transforms: { [\`disk_\${move.disk}\`]: pos }, moveIndex, totalMoves: moves.length };
          }
        `,
        entry: 'generate',
        } as BTNode),
      } as never,
      children: [
        { id: 'peg_A', word: 'peg', transform: translateTransform(pegs[0]!), children: [], locked: true },
        { id: 'peg_B', word: 'peg', transform: translateTransform(pegs[1]!), children: [], locked: true },
        { id: 'peg_C', word: 'peg', transform: translateTransform(pegs[2]!), children: [], locked: true },
        ...[0, 1, 2, 3, 4, 5, 6].map((i) => ({
          id: `disk_${i + 1}`,
          word: 'disk',
          transform: translateTransform({ x: pegs[0]!.x, y: 0.15 + i * 0.3, z: 0 }),
          components: {
            cylinder: { kind: 'const' as const, value: { radius: 1.2 - i * 0.12, height: 0.25, style: { fill: { kind: 'const' as const, value: { r: 0.8, g: 0.5, b: 0.2, a: 1 } } } } },
          },
          children: [] as any,
        })),
      ],
    },
  }
}
