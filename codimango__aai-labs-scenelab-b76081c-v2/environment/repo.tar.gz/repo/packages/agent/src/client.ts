/**
 * LLM client — the model-integration layer (docs/foundation.md, "Avocado API").
 * Avocado is served over an OpenAI-compatible Chat Completions API, so this is a plain
 * `fetch` to `${baseURL}/chat/completions` with a bearer key. Point it at Avocado (or any
 * OpenAI-compatible gateway) via config/env; nothing else in the pipeline changes.
 */

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

/** A client is just: messages in, assistant text out. Mockable for tests. */
export type LLMClient = (messages: ChatMessage[]) => Promise<string>

export interface OpenAIClientConfig {
  baseURL: string
  model: string
  apiKey: string
  temperature?: number
  /** Send response_format:{type:'json_object'} (default true). Turn off if a gateway rejects it. */
  jsonMode?: boolean
}

export function openAICompatibleClient(cfg: OpenAIClientConfig): LLMClient {
  return async (messages) => {
    const body: Record<string, unknown> = {
      model: cfg.model,
      messages,
      temperature: cfg.temperature ?? 0.2,
    }
    if (cfg.jsonMode !== false) body.response_format = { type: 'json_object' }

    const res = await fetch(`${cfg.baseURL.replace(/\/+$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${cfg.apiKey}` },
      body: JSON.stringify(body),
    })
    if (!res.ok) {
      throw new Error(`LLM request failed ${res.status}: ${await res.text().catch(() => '')}`)
    }
    const data = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> }
    const content = data.choices?.[0]?.message?.content
    if (typeof content !== 'string') throw new Error('LLM response missing message content')
    return content
  }
}

/**
 * Build a client from environment variables. Avocado (OpenAI-compatible):
 *   SCENELAB_LLM_BASE_URL   e.g. the MetaGen/llama gateway base url
 *   SCENELAB_LLM_MODEL      default "meta/avocado-code-latest"
 *   SCENELAB_LLM_API_KEY    an entitled Avocado key
 *   SCENELAB_LLM_JSON_MODE  set to "off" to disable response_format
 */
export function clientFromEnv(env: Record<string, string | undefined>): LLMClient {
  const baseURL = env.SCENELAB_LLM_BASE_URL
  const apiKey = env.SCENELAB_LLM_API_KEY
  const model = env.SCENELAB_LLM_MODEL ?? 'meta/avocado-code-latest'
  if (!baseURL || !apiKey) {
    throw new Error(
      'Missing LLM config. Set SCENELAB_LLM_BASE_URL and SCENELAB_LLM_API_KEY ' +
        '(Avocado is OpenAI-compatible; SCENELAB_LLM_MODEL defaults to "meta/avocado-code-latest").',
    )
  }
  return openAICompatibleClient({ baseURL, model, apiKey, jsonMode: env.SCENELAB_LLM_JSON_MODE !== 'off' })
}

/**
 * MetaCode CLI client — uses the `metacode run` command to proxy through its
 * managed infrastructure. This bypasses the need for direct API keys and
 * entitlements, using the existing MetaCode session auth instead.
 *
 * Model format: "provider/model" (e.g., "meta/avocado-code-latest", "anthropic/claude-sonnet-4")
 * Requires `metacode` CLI to be installed and authenticated.
 */
export function metacodeClient(model: string, opts?: { timeout?: number }): LLMClient {
  return async (messages) => {
    const { spawnSync } = await import('node:child_process')

    // Serialize the full conversation so the model receives system instructions,
    // the few-shot example, and all prior turns (critical for self-repair retries).
    const prompt = messages
      .map(m => `[${m.role.toUpperCase()}]\n${m.content}`)
      .join('\n\n')

    // Build metacode command — use spawnSync with args array to avoid shell quoting issues (backticks in prompt)
    const args = ['run', '-m', model, '--format', 'text']
    if (opts?.timeout) {
      args.push('--timeout', String(opts.timeout))
    }
    args.push(prompt)

    try {
      const result = spawnSync('metacode', args, {
        encoding: 'utf-8',
        maxBuffer: 20 * 1024 * 1024,
        env: { ...process.env, NO_COLOR: '1' },
      })
      if (result.error) throw result.error
      if (result.status !== 0) {
        const stderr = result.stderr?.toString() || result.stdout?.toString() || `exit ${result.status}`
        throw new Error(stderr.slice(0, 2000))
      }
      const output = (result.stdout as string) ?? ''
      if (!output.trim()) {
        throw new Error(`empty output, stderr: ${(result.stderr as string)?.slice(0, 500) ?? ''}`)
      }
      return output.trim()
    } catch (error: any) {
      const stderr = error.stderr?.toString?.() || error.stdout?.toString?.() || error.message
      throw new Error(`MetaCode CLI failed: ${stderr}`)
    }
  }
}

/**
 * Build a MetaCode client from environment variables:
 *   SCENELAB_METACODE_MODEL   e.g. "meta/avocado-code-latest" or "anthropic/claude-sonnet-4"
 *   SCENELAB_METACODE_TIMEOUT optional timeout in seconds
 */
export function metacodeClientFromEnv(env: Record<string, string | undefined>): LLMClient {
  const model = env.SCENELAB_METACODE_MODEL ?? 'meta/avocado-code-latest'
  const timeout = env.SCENELAB_METACODE_TIMEOUT ? parseInt(env.SCENELAB_METACODE_TIMEOUT, 10) : undefined
  return metacodeClient(model, { timeout })
}
