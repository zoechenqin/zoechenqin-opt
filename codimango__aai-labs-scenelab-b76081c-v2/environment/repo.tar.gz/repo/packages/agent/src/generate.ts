/**
 * generateScene — prompt → validated Scene. Extracts JSON from the model output, validates
 * with parseScene, and on failure feeds the validation error back for a self-repair retry
 * (docs/foundation.md §5: the agent generates the scene graph; parseScene is the gate).
 */
import { parseScene, type Scene } from '@scenelab/scene-ir'
import type { LLMClient } from './client'
import { buildMessages } from './prompt'

/** Pull a JSON object out of model text (handles code fences and surrounding prose). Robust to multiple concatenated objects and trailing prose. */
export function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i)
  const candidate = fenced?.[1] ?? text

  // Find balanced {…} blocks while respecting JSON strings and escapes
  const blocks: string[] = []
  let start = -1
  let depth = 0
  let inString = false
  let escapeNext = false
  for (let i = 0; i < candidate.length; i++) {
    const ch = candidate[i]
    if (escapeNext) {
      escapeNext = false
      continue
    }
    if (ch === '\\') {
      if (inString) escapeNext = true
      continue
    }
    if (ch === '"') {
      inString = !inString
      continue
    }
    if (inString) continue
    if (ch === '{') {
      if (depth === 0) start = i
      depth++
    } else if (ch === '}') {
      depth--
      if (depth === 0 && start !== -1) {
        blocks.push(candidate.slice(start, i + 1))
        start = -1
      }
      if (depth < 0) {
        // reset on malformed
        depth = 0
        start = -1
      }
    }
  }

  if (blocks.length === 0) {
    throw new Error('no JSON object found in model output')
  }

  // Try each block in order of appearance — prefer blocks that look like SceneLab output
  // (have "scene" or "schemaVersion" + "id")
  const tryParse = (s: string): unknown | null => {
    try {
      return JSON.parse(s)
    } catch {
      return null
    }
  }

  // First pass: blocks that contain "scene" or "schemaVersion"
  for (const b of blocks) {
    const parsed = tryParse(b)
    if (!parsed) continue
    if (typeof parsed === 'object' && parsed !== null) {
      const obj = parsed as any
      if (obj.scene || obj.schemaVersion) return parsed
    }
  }
  // Second pass: any valid JSON object
  for (const b of blocks) {
    const parsed = tryParse(b)
    if (parsed) return parsed
  }
  // Fallback: previous behavior — first { to last } (may include concatenation but better than nothing)
  const first = candidate.indexOf('{')
  const last = candidate.lastIndexOf('}')
  if (first !== -1 && last !== -1 && last > first) {
    const fallback = tryParse(candidate.slice(first, last + 1))
    if (fallback) return fallback
  }
  throw new Error(`no parseable JSON object found (found ${blocks.length} balanced block(s) but none parsed)`)
}

export interface GenerateOptions {
  /** Total attempts including the initial one (self-repair retries = maxAttempts - 1). */
  maxAttempts?: number
}

export async function generateScene(prompt: string, client: LLMClient, opts: GenerateOptions = {}): Promise<Scene> {
  const maxAttempts = Math.max(1, opts.maxAttempts ?? 3)
  const messages = buildMessages(prompt)
  let lastError = ''

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const content = await client(messages)
    try {
      const parsed = extractJson(content)
      
      // Handle two-stage output: { scene, motion } or just scene
      const scene = (parsed as any).scene ? parseScene((parsed as any).scene) : parseScene(parsed)
      
      // Validate: reject if output matches the few-shot example (indicates model copied example)
      if (scene.id === 'example') {
        throw new Error('Model output matches the few-shot example scene (id: "example"). The model copied the example instead of generating a new scene for the prompt. This indicates a prompt engineering failure.')
      }
      
      return scene
    } catch (e) {
      lastError = e instanceof Error ? e.message : String(e)
      // Self-repair: show the model its output and the validation error, ask for a fix.
      messages.push({ role: 'assistant', content })
      messages.push({
        role: 'user',
        content: `That did not validate as a SceneLab Scene: ${lastError}. Reply with ONLY the corrected JSON object.`,
      })
    }
  }
  throw new Error(`generateScene: failed after ${maxAttempts} attempt(s). Last error: ${lastError}`)
}
