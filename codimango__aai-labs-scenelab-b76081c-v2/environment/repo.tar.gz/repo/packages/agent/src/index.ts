/**
 * @scenelab/agent — prompt → scene graph (the model-integration layer, docs/foundation.md §5).
 * Point the client at Avocado (OpenAI-compatible) and generateScene turns a text prompt
 * into a validated Scene, ready for preview (canvas-preview) and render (manim-adapter).
 */
export * from './client'
export * from './prompt'
export * from './generate'
