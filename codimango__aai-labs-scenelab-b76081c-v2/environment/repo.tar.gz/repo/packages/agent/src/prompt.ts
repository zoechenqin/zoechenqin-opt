/**
 * Prompt construction for entity-graph generation (the "training-free inference" step).
 * We hand the model the schema + conventions
 * and ask for a Scene JSON — which parseScene then validates.
 */
import { readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { constant, IR_RULES } from '@scenelab/scene-ir'
import type { ChatMessage } from './client'

export const SCENE_GUIDE = `You generate SceneLab scene graphs: a renderer-agnostic, structured description of a
2D/3D scene that will be previewed and rendered (e.g. to a Manim video).

A scene is an ENTITY GRAPH. An entity is one thing in the scene: it has an id, a "word" naming
its semantic class, a transform, components that give it something to draw, and children. The
children form the containment hierarchy that composes transforms, but entities also reference
each other by id — a template entity is instantiated by another entity's op, a constraint aims
one entity at another. Those references may not form a cycle.

⚠️  ANIMATION IS REQUIRED FOR MOTION PROMPTS ⚠️
If the user request contains ANY motion verb (solve, move, animate, rotate, slide, walk,
run, fly, travel, go, come, etc.), the scene MUST contain a "behavior" entity. A scene
whose values are all constant does not move, and is INVALID for a motion prompt.

FORMAT RULES (canonical — shared with every other surface that prompts a model):
${IR_RULES.join('\n')}

THE ENVELOPE — the literal shapes, since you are writing the whole document:
- Scene: { schemaVersion:"0.1.0", id, space:"2d"|"3d", canvas:{width,height,background?},
  camera, root, units? }
- camera: { id:"camera", transform, projection:{type:"orthographic", height:<const number>} }
  The orthographic "height" is how many world units span the viewport vertically; match it to
  canvas.height (e.g. 1080) so 1 unit ~= 1px and centre is (0,0).
- entity: { id, kind, word (semantic class, lowercase-kebab noun e.g. "disk","peg"), transform,
  children[], components? }
- transform: { position:<Vec3 value>, rotation:<AxisAngle value>, scale:<Vec3 value>,
  anchor:Vec3 }. Opacity is a component, not part of the transform.
  Vec3 = {x,y,z}. AxisAngle = {axis:{x,y,z}, angle:radians} (2D uses axis {0,0,1}).
- behavior entity: { id, kind:"behavior", word, transform, children:[], behavior:<one BT node> }
- drawable components: circle{radius}, rect{size:{x,y},cornerRadius?}, polygon{points:Vec3[]},
  line{from,to}, path, text{content,fontSize,fontFamily?,fontWeight?,lineHeight?}, box{size:Vec3},
  sphere{radius}, cylinder{radius,height}, cone{radius,height}, torus{radius,tube}, mesh{asset}. Each carries
  "style":{ fill?, stroke?, strokeWidth? }. Also: opacity (a subtree-wide number).
- Every value is wrapped: components:{ rect:{"kind":"const","value":{...}} }.

CRITICAL INSTRUCTIONS:
- The prior assistant turn is ONLY a format example. DO NOT copy its content or id.
- For the NEW request, you MUST generate a COMPLETELY NEW scene that matches the NEW request.
- Analyze the NEW request, break it down into components, and create appropriate entities.
- For "Tower of Hanoi": create 3 pegs, 3 disks of different sizes, a base. Use words: "peg", "disk", "base".
- DO NOT output the example scene. Generate a NEW scene for the NEW request.
- VERIFICATION: After generating, check that every value is {"kind":"const"} and that no value contains "keyframes". Then, if the prompt asks for motion/solving/animation, check your output contains an entity with "kind":"behavior" whose tree actually targets the entities that should move. A motion prompt answered with no behavior entity, or with a tree that targets nothing, HAS FAILED. Regenerate.

OUTPUT FORMAT — you MUST return a JSON object with exactly two top-level keys:
{"scene": { … the SceneLab scene graph … }, "motion": [ … motion descriptions … ]}
If there is no motion, "motion" may be []. Output ONLY the JSON object, no prose, no code fences.`

/** A minimal valid {"scene", "motion"} response used as a few-shot example. */
export const FEW_SHOT_EXAMPLE = JSON.stringify({
  scene: {
    schemaVersion: '0.1.0',
    id: 'example',
    space: '2d',
    canvas: { width: 1920, height: 1080, background: { r: 1, g: 1, b: 1, a: 1 } },
    camera: {
      id: 'camera',
      transform: {
        position: { kind: 'const', value: { x: 0, y: 0, z: 1000 } },
        rotation: { kind: 'const', value: { axis: { x: 0, y: 0, z: 1 }, angle: 0 } },
        scale: { kind: 'const', value: { x: 1, y: 1, z: 1 } },
        anchor: { x: 0, y: 0, z: 0 },
      },
      projection: { type: 'orthographic', height: { kind: 'const', value: 1080 } },
    },
    root: {
      id: 'root',
      word: 'scene',
      transform: {
        position: { kind: 'const', value: { x: 0, y: 0, z: 0 } },
        rotation: { kind: 'const', value: { axis: { x: 0, y: 0, z: 1 }, angle: 0 } },
        scale: { kind: 'const', value: { x: 1, y: 1, z: 1 } },
        anchor: { x: 0, y: 0, z: 0 },
      },
      children: [
        {
          id: 'rect_1',
          word: 'square',
          transform: {
            position: { kind: 'const', value: { x: 0, y: 0, z: 0 } },
            rotation: { kind: 'const', value: { axis: { x: 0, y: 0, z: 1 }, angle: 0 } },
            scale: { kind: 'const', value: { x: 1, y: 1, z: 1 } },
            anchor: { x: 0, y: 0, z: 0 },
          },
          components: { rect: constant({ size: { x: 200, y: 100 }, style: { fill: constant({ r: 0.2, g: 0.4, b: 0.9, a: 1 }) } }) },
          children: [],
        },
      ],
    },
  },
  motion: [],
})

export function buildMessages(prompt: string): ChatMessage[] {
  // Read source files to provide full context (like MetaCode does)
  // This gives the model access to the actual SceneLab source code
  let sourceContext = ''
  try {
    const cwd = process.cwd()
    
    // 1. TypeScript interfaces (most important - defines the structure)
    const typesPath = join(cwd, 'packages/scene-ir/src/types.ts')
    if (existsSync(typesPath)) {
      const typesContent = readFileSync(typesPath, 'utf-8')
      sourceContext += '\n\n=== SceneLab Types (packages/scene-ir/src/types.ts) ===\n' + typesContent
    }
    
    // 2. Zod schema (validation rules)
    const schemaPath = join(cwd, 'packages/scene-ir/src/schema.ts')
    if (existsSync(schemaPath)) {
      const schemaContent = readFileSync(schemaPath, 'utf-8')
      sourceContext += '\n\n=== SceneLab Schema (packages/scene-ir/src/schema.ts) ===\n' + schemaContent
    }
    
    // 3. Foundation docs - key sections only (too large to include fully)
    const foundationPath = join(cwd, 'docs/foundation.md')
    if (existsSync(foundationPath)) {
      const foundationContent = readFileSync(foundationPath, 'utf-8')
      // Extract key sections: Entity Graph (§3) and Animation (§4)
      const sceneGraphMatch = foundationContent.match(/## 3\. The entity graph[\s\S]*?(?=## 4\.|$)/)
      const animationMatch = foundationContent.match(/## 4\. The animation[\s\S]*?(?=## 5\.|$)/)
      if (sceneGraphMatch) {
        sourceContext += '\n\n=== Foundation: Entity Graph (docs/foundation.md §3) ===\n' + sceneGraphMatch[0].substring(0, 3000)
      }
      if (animationMatch) {
        sourceContext += '\n\n=== Foundation: Animation (docs/foundation.md §4) ===\n' + animationMatch[0].substring(0, 4000)
      }
    }
  } catch (e) {
    // If files not accessible, fall back to SCENE_GUIDE description
    console.warn('Could not load source files for prompt context:', e instanceof Error ? e.message : String(e))
  }

  return [
    { role: 'system', content: SCENE_GUIDE + sourceContext },
    { role: 'assistant', content: FEW_SHOT_EXAMPLE },
    { role: 'user', content: prompt },
  ]
}
