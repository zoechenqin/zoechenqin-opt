import { describe, it, expect } from 'vitest'
import { constant, parseScene, simulate, resolveScene, transformPoint } from '@scenelab/scene-ir'
import { IR_GUIDE } from '@scenelab/scene-ir'
import { SCENE_GUIDE, FEW_SHOT_EXAMPLE } from './prompt'

/**
 * The guide is a string that typecheck cannot validate, so these tests ensure its documented
 * examples and shapes are accepted by the parser.
 */
const identity = {
  position: { kind: 'const', value: { x: 0, y: 0, z: 0 } },
  rotation: { kind: 'const', value: { axis: { x: 0, y: 0, z: 1 }, angle: 0 } },
  scale: { kind: 'const', value: { x: 1, y: 1, z: 1 } },
  anchor: { x: 0, y: 0, z: 0 },
}

const sceneAroundBehavior = (behavior: unknown) => ({
  schemaVersion: '0.1.0',
  id: 'guide_check',
  space: '2d',
  canvas: { width: 1920, height: 1080 },
  camera: { id: 'camera', transform: identity, projection: { type: 'orthographic', height: { kind: 'const', value: 1080 } } },
  root: {
    id: 'root',
    word: 'scene',
    transform: identity,
    children: [
      { id: 'motion', word: 'motion', transform: identity, children: [], components: { behavior: constant(behavior) } },
      {
        id: 'disk_1',
        word: 'disk',
        transform: identity,
        components: { rect: { kind: 'const', value: { size: { x: 100, y: 40 }, style: {} } } },
        children: [],
      },
    ],
  },
})

// Copied from the guide verbatim — if the guide changes, this should be updated with it.
const guideCurve = {
  type: 'curve',
  id: 'disk1.move',
  target: 'disk_1',
  property: 'transform.position',
  keyframes: [
    { t: 0, value: { x: -400, y: -200, z: 0 } },
    { t: 0.5, value: { x: -400, y: 100, z: 0 }, easing: 'easeInOut' },
    { t: 1.5, value: { x: 400, y: 100, z: 0 }, easing: 'easeInOut' },
    { t: 2, value: { x: 400, y: -200, z: 0 }, easing: 'easeInOut' },
  ],
}

const guideAction = {
  type: 'action',
  action: 'translate',
  target: 'disk_1',
  duration: 1,
  params: { to: { x: 400, y: -200, z: 0 } },
}

describe('SCENE_GUIDE describes shapes the parser accepts', () => {
  it('the curve example parses and actually moves its target', () => {
    const scene = parseScene(sceneAroundBehavior(guideCurve))
    expect(simulate(scene).duration).toBe(2)
    const x = (t: number) =>
      transformPoint(resolveScene(scene, t).primitives.find((p) => p.id === 'disk_1')!.worldMatrix, { x: 0, y: 0, z: 0 }).x
    expect(x(0)).toBe(-400)
    expect(x(2)).toBe(400)
  })

  it('the action example parses and actually moves its target', () => {
    const scene = parseScene(sceneAroundBehavior(guideAction))
    expect(simulate(scene).duration).toBe(1)
    const p = resolveScene(scene, 1).primitives.find((e) => e.id === 'disk_1')!
    expect(transformPoint(p.worldMatrix, { x: 0, y: 0, z: 0 }).x).toBe(400)
  })

  it('the sequence/parallel/time-condition composers parse', () => {
    for (const composer of [
      { type: 'sequence', children: [guideCurve, guideAction] },
      { type: 'parallel', children: [guideCurve] },
      { type: 'condition', on: 'time', params: { at: 5 }, child: guideCurve },
    ]) {
      expect(() => parseScene(sceneAroundBehavior(composer))).not.toThrow()
    }
  })

  it('a time condition starts its child at the stated absolute moment', () => {
    const scene = parseScene(sceneAroundBehavior({ type: 'condition', on: 'time', params: { at: 5 }, child: guideCurve }))
    expect(simulate(scene).schedule[0]).toMatchObject({ start: 5, duration: 2 })
  })

  it('the few-shot example parses', () => {
    expect(() => parseScene(JSON.parse(FEW_SHOT_EXAMPLE).scene)).not.toThrow()
  })
})

describe('SCENE_GUIDE is built from the canonical rules, not a second copy of them', () => {
  // scene-ir owns the rule assertions; this surface only verifies that it embeds those rules.
  it('embeds IR_GUIDE verbatim', () => {
    expect(SCENE_GUIDE).toContain(IR_GUIDE)
  })

  it('still adds what only a blind writer needs — the literal envelope', () => {
    expect(SCENE_GUIDE).toContain('schemaVersion:"0.1.0"')
    expect(SCENE_GUIDE).toContain('AxisAngle = {axis:{x,y,z}, angle:radians}')
  })

  it('does not instruct a "track" value anywhere', () => {
    expect(SCENE_GUIDE).not.toMatch(/"kind"\s*:\s*"track"/)
    expect(SCENE_GUIDE).not.toMatch(/kind":\s*"track/)
  })

  it('a track value is rejected, so the guide would be actively wrong to teach it', () => {
    const withTrack: any = sceneAroundBehavior(guideCurve)
    withTrack.root.children[1].transform.position = {
      kind: 'track',
      keyframes: [
        { t: 0, value: { x: 0, y: 0, z: 0 } },
        { t: 1, value: { x: 10, y: 0, z: 0 } },
      ],
    }
    expect(() => parseScene(withTrack)).toThrow()
  })
})
