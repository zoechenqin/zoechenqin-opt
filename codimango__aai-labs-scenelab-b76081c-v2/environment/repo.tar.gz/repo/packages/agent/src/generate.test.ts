import { describe, it, expect } from 'vitest'
import { parseScene, sampleScene } from '@scenelab/scene-ir'
import type { LLMClient } from './client'
import { buildMessages, FEW_SHOT_EXAMPLE, SCENE_GUIDE } from './prompt'
import { extractJson, generateScene } from './generate'

const validJson = JSON.stringify(sampleScene())

describe('extractJson', () => {
  it('parses a bare JSON object', () => {
    expect(extractJson('{"a":1}')).toEqual({ a: 1 })
  })
  it('parses a fenced ```json block', () => {
    expect(extractJson('here you go:\n```json\n{"a":2}\n```')).toEqual({ a: 2 })
  })
  it('parses JSON wrapped in prose', () => {
    expect(extractJson('Sure! {"a":3} hope that helps')).toEqual({ a: 3 })
  })
  it('throws when there is no JSON', () => {
    expect(() => extractJson('no json here')).toThrow()
  })
})

describe('buildMessages', () => {
  it('includes the schema guide and a valid example, ending with the prompt', () => {
    const msgs = buildMessages('draw a triangle')
    expect(msgs[0]?.role).toBe('system')
    expect(msgs[0]?.content).toContain('scene graph')
    // the few-shot example must itself be a valid scene
    const example = msgs.find((m) => m.role === 'assistant')
    expect(example).toBeDefined()
    expect(() => JSON.parse(example!.content)).not.toThrow()
    expect(msgs[msgs.length - 1]).toEqual({ role: 'user', content: 'draw a triangle' })
  })
})

describe('generateScene', () => {
  it('parses a valid model response into a Scene', async () => {
    const client: LLMClient = async () => validJson
    const scene = await generateScene('anything', client)
    expect(scene.id).toBe('sample')
    expect(scene.root.children.length).toBe(2)
  })

  it('self-repairs: retries after an invalid response and succeeds', async () => {
    let calls = 0
    const client: LLMClient = async (messages) => {
      calls++
      if (calls === 1) return 'oops, not json'
      // second call should have received the repair feedback
      expect(messages.some((m) => m.content.includes('did not validate'))).toBe(true)
      return validJson
    }
    const scene = await generateScene('anything', client)
    expect(calls).toBe(2)
    expect(scene.id).toBe('sample')
  })

  it('throws after exhausting attempts', async () => {
    const client: LLMClient = async () => 'never valid'
    await expect(generateScene('anything', client, { maxAttempts: 2 })).rejects.toThrow(/failed after 2/)
  })
})

describe('the prompt describes the IR the schema actually accepts', () => {
  it('the few-shot example parses', () => {
    // The example is shown to the model as a correct answer, so if it drifts from the schema the
    // model is being taught to produce invalid scenes.
    const parsed = JSON.parse(FEW_SHOT_EXAMPLE) as { scene: unknown }
    expect(() => parseScene(parsed.scene)).not.toThrow()
  })

  it('does not describe the pre-components entity model', () => {
    // Prose drifts silently where the example does not: nothing executes a paragraph.
    expect(SCENE_GUIDE).not.toMatch(/primitive\.shape|kind === 'primitive'|a "primitive" \(has shape\)/)
    expect(SCENE_GUIDE).toMatch(/components/)
  })
})
