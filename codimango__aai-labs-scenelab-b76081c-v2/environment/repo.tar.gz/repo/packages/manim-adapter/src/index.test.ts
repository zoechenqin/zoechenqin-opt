import { describe, it, expect } from 'vitest'
import { constant, identityTransform, sampleScene, type Scene } from '@scenelab/scene-ir'
import { toManim, pangoWeight } from './index'

const textScene = (fontWeight: number | string): Scene =>
  ({
    schemaVersion: '0.1.0',
    id: 'text_weight',
    space: '2d',
    canvas: { width: 1920, height: 1080 },
    camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
    root: {
      id: 'root',
      word: 'scene',
      transform: identityTransform(),
      children: [
        {
          id: 'label',
          word: 'label',
          transform: identityTransform(),
          children: [],
          components: { text: constant({ content: 'Hi', fontSize: 40, fontWeight, style: {} }) },
        },
      ],
    },
  }) as unknown as Scene

describe('manim-adapter', () => {
  it('emits a valid-looking Manim Scene for a static scene', () => {
    const py = toManim(sampleScene())
    expect(py).toContain('from manim import *')
    expect(py).toContain('class SceneLabScene(Scene):')
    expect(py).toContain('def construct(self):')
    expect(py).toContain('config.frame_height = 1080')
    expect(py).toContain('Circle(') // circle-1
    expect(py).toContain('Text(') // label-1
    expect(py).not.toContain('self.play(') // static scene: no animation
  })

  it('is deterministic', () => {
    expect(toManim(sampleScene())).toBe(toManim(sampleScene()))
  })

  it('renders text at a world-unit height with fill (not manim font_size units)', () => {
    const scene: Scene = {
      schemaVersion: '0.1.0',
      id: 'text',
      space: '2d',
      canvas: { width: 1920, height: 1080 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'title',
            word: 'title',
            transform: identityTransform(),
            components: { text: constant({ content: 'Hello', fontSize: 80, style: { fill: constant({ r: 1, g: 1, b: 1, a: 1 }) }} ) },
            children: [],
          },
        ],
      },
    }
    const py = toManim(scene)
    expect(py).toContain('Text("Hello")')
    // world-unit height, not raw font_size (which would render ~frameH/8x too small)
    expect(py).toContain('.scale_to_fit_height(80)')
    expect(py).toContain('aligned_edge=DOWN') // default align 'center' → bottom-center anchor
    expect(py).toContain('.set_fill("#ffffff"') // fill honored
    expect(py).not.toContain('font_size=80')
  })

  it('maps text align to the manim anchor edge (left=DL, center=DOWN, right=DR)', () => {
    const mk = (align: 'left' | 'center' | 'right'): Scene => ({
      schemaVersion: '0.1.0',
      id: 'ta',
      space: '2d',
      canvas: { width: 1920, height: 1080 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 't',
            word: 'title',
            transform: identityTransform(),
            components: { text: constant({ content: 'X', fontSize: 40, align, style: { fill: constant({ r: 1, g: 1, b: 1, a: 1 }) }} ) },
            children: [],
          },
        ],
      },
    })
    expect(toManim(mk('left'))).toContain('aligned_edge=DL')
    expect(toManim(mk('center'))).toContain('aligned_edge=DOWN')
    expect(toManim(mk('right'))).toContain('aligned_edge=DR')
  })

  it('animates a keyframed scene with Transform', () => {
    const scene: Scene = {
      schemaVersion: '0.1.0',
      id: 'anim',
      space: '2d',
      canvas: { width: 1920, height: 1080 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'motion',
            word: 'motion',
            transform: identityTransform(),
            children: [],
            components: { behavior: constant({
              type: 'curve' as const,
              id: 'motion.slide',
              target: 'dot',
              property: 'transform.position',
              keyframes: [
                { t: 0, value: { x: -100, y: 0, z: 0 } },
                { t: 1, value: { x: 100, y: 0, z: 0 } },
              ],
            }) },
          },
          {
            id: 'dot',
            word: 'dot',
            transform: { ...identityTransform(), position: constant({ x: -100, y: 0, z: 0 }) },
            components: { circle: constant({ radius: 20, style: { fill: constant({ r: 0, g: 0, b: 1, a: 1 }) }} ) },
            children: [],
          },
        ],
      },
    }
    const py = toManim(scene)
    expect(py).toContain('self.play(')
    expect(py).toContain('Transform(m_dot')
    expect(py).toContain('run_time=1')
  })

  // The adapter shipped a black-video bug for every perspective scene: `config.frame_height` is
  // measured in WORLD UNITS, but the code fed it a pixel count (1080) whenever the camera was not
  // orthographic, so manim viewed a 1920x1080-unit area and every scene collapsed to sub-pixel
  // size. Nothing caught it because every test scene above is 2D orthographic with
  // height === canvas.height, where the old and new framing happen to agree.
  const perspectiveScene = (components: Record<string, unknown>): Scene =>
    ({
      schemaVersion: '0.1.0',
      id: 'persp',
      space: '3d',
      canvas: { width: 1920, height: 1080 },
      camera: {
        id: 'camera',
        transform: { ...identityTransform(), position: constant({ x: 0, y: 0, z: 10 }) },
        projection: { type: 'perspective', fovY: constant(50), near: 0.1, far: 100 },
      },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'thing',
            word: 'ring',
            transform: identityTransform(),
            components,
            children: [],
          },
        ],
      },
    }) as Scene

  it('frames a perspective scene by the canvas, not by a pixel count read as world units', () => {
    const py = toManim(perspectiveScene({ cylinder: constant({ radius: 1, height: 0.4, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) }))
    expect(py).toContain('config.frame_width = 1920')
    expect(py).toContain('config.frame_height = 1080')
    expect(py).toContain('config.pixel_width = 1920')
  })

  it('draws volumetric shapes in a perspective scene instead of an invisible placeholder', () => {
    const py = toManim(perspectiveScene({ cylinder: constant({ radius: 1, height: 0.4, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) }))
    expect(py).toContain('Polygon(')
    expect(py).toContain('.set_fill("#ff0000"')
    // the old adapter emitted `Dot(...).set_opacity(0)` for cylinder/cone/mesh
    expect(py).not.toContain('set_opacity(0)')
  })

  it('places projected geometry inside the visible frame', () => {
    const py = toManim(perspectiveScene({ cylinder: constant({ radius: 1, height: 0.4, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) }))
    const coords = [...py.matchAll(/\[(-?[\d.]+), (-?[\d.]+), 0\]/g)].map((m) => [Number(m[1]), Number(m[2])] as const)
    expect(coords.length).toBeGreaterThan(0)
    // manim units are pixels here, so everything must sit within +-half the canvas to be on screen
    for (const [x, y] of coords) {
      expect(Math.abs(x)).toBeLessThanOrEqual(960)
      expect(Math.abs(y)).toBeLessThanOrEqual(540)
    }
    // and must not be degenerate — a few pixels at the origin was the symptom of the framing bug
    const spanX = Math.max(...coords.map((c) => c[0])) - Math.min(...coords.map((c) => c[0]))
    expect(spanX).toBeGreaterThan(20)
  })

  it('suppresses manim default white stroke on unstroked fills', () => {
    const py = toManim(perspectiveScene({ cylinder: constant({ radius: 1, height: 0.4, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) }))
    expect(py).toContain('.set_stroke(width=0)')
  })

  it('only Transforms primitives that changed since the previous keyframe', () => {
    // A mover with a position track alongside a fully static sibling. Only the mover should
    // be re-Transformed — re-emitting the static one at every keyframe is the megabyte-Python
    // bug this guards against.
    const scene: Scene = {
      schemaVersion: '0.1.0',
      id: 'partial',
      space: '2d',
      canvas: { width: 1920, height: 1080 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'motion',
            word: 'motion',
            transform: identityTransform(),
            children: [],
            components: { behavior: constant({
              type: 'curve' as const,
              id: 'motion.slide',
              target: 'mover',
              property: 'transform.position',
              keyframes: [
                { t: 0, value: { x: -100, y: 0, z: 0 } },
                { t: 1, value: { x: 100, y: 0, z: 0 } },
              ],
            }) },
          },
          {
            id: 'mover',
            word: 'dot',
            transform: { ...identityTransform(), position: constant({ x: -100, y: 0, z: 0 }) },
            components: { circle: constant({ radius: 20, style: { fill: constant({ r: 0, g: 0, b: 1, a: 1 }) }} ) },
            children: [],
          },
          {
            id: 'static',
            word: 'dot',
            transform: identityTransform(),
            components: { circle: constant({ radius: 20, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) }} ) },
            children: [],
          },
        ],
      },
    }
    const py = toManim(scene)
    expect(py).toContain('Transform(m_mover')
    expect(py).not.toContain('Transform(m_static')
  })
})

describe('font weight (manimpango takes names, not CSS numbers)', () => {
  it('maps the numeric scale to pango names', () => {
    expect(pangoWeight(700)).toBe('BOLD')
    expect(pangoWeight(400)).toBe('NORMAL')
    expect(pangoWeight(100)).toBe('THIN')
    expect(pangoWeight(900)).toBe('HEAVY')
  })

  it('snaps an off-scale number to the nearest named weight', () => {
    expect(pangoWeight(650)).toBe('BOLD')
    expect(pangoWeight(1000)).toBe('HEAVY')
    expect(pangoWeight(50)).toBe('THIN')
  })

  it('still accepts the named forms, in any case', () => {
    expect(pangoWeight('bold')).toBe('BOLD')
    expect(pangoWeight('NORMAL')).toBe('NORMAL')
  })

  it('falls back rather than emitting something manimpango rejects', () => {
    expect(pangoWeight('extra-chunky')).toBe('NORMAL')
  })

  // The regression itself: weight="700" in the output aborts the entire render, so what matters
  // is that no digits reach the emitted Python at all.
  it('never emits a numeric weight into the scene', () => {
    const scene = textScene(700)
    const py = toManim(scene)
    expect(py).toContain('weight="BOLD"')
    expect(py).not.toMatch(/weight="\d+"/)
  })
})
