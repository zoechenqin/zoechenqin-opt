/**
 * @scenelab/manim-adapter — scene graph → Manim Python (docs/foundation.md §8).
 * The first renderer adapter. It samples the scene at each keyframe time via
 * resolveScene(t) (so it reuses the same engine as the Canvas preview), builds mobjects
 * in world coordinates, and animates between states with Transform. Static scenes render
 * a single held frame; keyframed scenes animate.
 *
 * Geometry comes from the shared `project()` (canvas-preview), the same pass the Canvas preview
 * and the headless mp4 renderer use, so all three renderers agree by construction. project()
 * handles perspective, the painter sort, and the planar approximations for volumetric shapes;
 * this module's only job is to spell the resulting screen-space polygons as Python.
 *
 * Screen space is pixels, Y-down, origin top-left. Manim is Y-up with the origin at the centre of
 * a frame measured in WORLD UNITS, so we pin one manim unit to one pixel (see toManim) and flip Y.
 */
import type { Scene } from '@scenelab/scene-ir'
import { keyframeTimes, resolveScene } from '@scenelab/scene-ir'
import { project, type Px, type ScreenShape, type ScreenStyle } from '@scenelab/canvas-preview'

/** Seconds held at the first and last states — the manim video leads in with this much of t=0. */
export const HOLD = 0.6

/**
 * Exact mapping from a rendered manim video's wall-clock time → scene time, replicating the
 * timeline `toManim` emits: a HOLD of t=0, then one segment per keyframe gap consuming
 * `max(0.1, dt)` wall-clock seconds (tiny gaps between entities' keyframes get inflated, which is why
 * a manim render runs longer than the scene). Use this to keep a debug overlay in sync with the
 * manim output — the naive `videoTime - HOLD` drifts because manim's clock is stretched.
 */
export function manimTimeMap(scene: Scene): (videoDuration?: number) => (videoTime: number) => number {
  const times = keyframeTimes(scene)
  const tFirst = times[0] ?? 0
  const tLast = times[times.length - 1] ?? 0
  // Reconstruct the timeline `toManim` emits: self.wait(HOLD) of t=0, then one segment per keyframe
  // gap consuming `max(0.1, dt)` seconds, then a trailing self.wait(HOLD) of the final state.
  const segs: { w0: number; w1: number; t0: number; t1: number }[] = []
  let w = HOLD
  for (let i = 1; i < times.length; i++) {
    const rt = Math.max(0.1, times[i]! - times[i - 1]!)
    segs.push({ w0: w, w1: w + rt, t0: times[i - 1]!, t1: times[i]! })
    w += rt
  }
  const endHold = w // wall-clock where the final hold begins
  const modelTotal = w + HOLD
  const model = (mt: number): number => {
    if (mt <= HOLD) return tFirst
    if (mt >= endHold) return tLast
    for (const s of segs) {
      if (mt >= s.w0 && mt < s.w1) return s.t0 + ((mt - s.w0) / (s.w1 - s.w0)) * (s.t1 - s.t0)
    }
    return tLast
  }
  // Factory: given the ACTUAL rendered video duration, scale the model timeline onto it (manim's
  // real duration drifts from the model by ~1s from frame quantization) so the ends stay anchored.
  return (videoDuration?: number) => {
    const scale = videoDuration && videoDuration > 0 ? modelTotal / videoDuration : 1
    return (vt: number): number => model(vt * scale)
  }
}

const num = (n: number): string => (Object.is(n, -0) ? '0' : Number(n.toFixed(4)).toString())
const varName = (id: string): string => 'm_' + id.replace(/[^a-zA-Z0-9]/g, '_')

const hexOf = (c: { r: number; g: number; b: number }): string => {
  const h = (x: number): string =>
    Math.round(Math.min(1, Math.max(0, x)) * 255)
      .toString(16)
      .padStart(2, '0')
  return `"#${h(c.r)}${h(c.g)}${h(c.b)}"`
}

/** project() hands back CSS `rgba(r, g, b, a)`; manim wants a hex string and a separate alpha. */
function cssParts(css: string): { hex: string; alpha: number } {
  const m = /^rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+)\s*)?\)$/.exec(css)
  if (!m) return { hex: '"#ffffff"', alpha: 1 }
  const h = (s: string): string => Math.round(Number(s)).toString(16).padStart(2, '0')
  return {
    hex: `"#${h(m[1]!)}${h(m[2]!)}${h(m[3]!)}"`,
    alpha: m[4] !== undefined ? Number(m[4]) : 1,
  }
}

function styleSuffix(s: ScreenStyle): string {
  const parts: string[] = []
  if (s.fill !== undefined) {
    const f = cssParts(s.fill)
    parts.push(`.set_fill(${f.hex}, opacity=${num(f.alpha * s.opacity)})`)
  } else {
    parts.push(`.set_fill(opacity=0)`)
  }
  if (s.stroke !== undefined) {
    const st = cssParts(s.stroke)
    parts.push(`.set_stroke(${st.hex}, width=${num(s.strokeWidthPx ?? 1)}, opacity=${num(st.alpha * s.opacity)})`)
  } else {
    // Manim's VMobjects default to a white stroke; the canvas preview draws none. Say so explicitly
    // or every unstroked fill picks up an outline that is not in the scene.
    parts.push(`.set_stroke(width=0)`)
  }
  return parts.join('')
}

/**
 * A screen-space shape → a manim mobject expression. Coordinates arrive as pixels (Y-down,
 * origin top-left) and leave as manim units (Y-up, origin centre), one unit per pixel.
 */
function buildMobj(shape: ScreenShape, width: number, height: number): string {
  const style = styleSuffix(shape.style)
  const v = (p: Px): string => `[${num(p.x - width / 2)}, ${num(height / 2 - p.y)}, 0]`

  switch (shape.kind) {
    case 'circle':
      return `Circle(radius=${num(Math.max(1e-4, shape.r))}).move_to(${v({ x: shape.cx, y: shape.cy })})${style}`

    case 'polygon': {
      if (shape.points.length < 2) return `Dot(${v(shape.points[0] ?? { x: 0, y: 0 })}).set_opacity(0)`
      if (shape.closed && shape.points.length >= 3) {
        return `Polygon(${shape.points.map(v).join(', ')})${style}`
      }
      if (shape.points.length === 2) return `Line(${v(shape.points[0]!)}, ${v(shape.points[1]!)})${style}`
      return `VMobject().set_points_as_corners([${shape.points.map(v).join(', ')}])${style}`
    }

    case 'path': {
      if (shape.segments.length === 0) return `Dot([0, 0, 0]).set_opacity(0)`
      const hasBezier = shape.segments.some((s) => s.type === 'cubicBezier' || s.type === 'quadraticBezier')
      if (!hasBezier) {
        const pts = shape.segments.map((seg) => v(seg.to))
        if (shape.closed && pts.length >= 3) return `Polygon(${pts.join(', ')})${style}`
        return `VMobject().set_points_as_corners([${pts.join(', ')}])${style}`
      }
      let code = `VMobject()`
      let started = false
      for (const seg of shape.segments) {
        if (seg.type === 'move') {
          code += started ? `.add_line_to(${v(seg.to)})` : `.move_to(${v(seg.to)})`
          started = true
        } else if (seg.type === 'line') {
          code += `.add_line_to(${v(seg.to)})`
        } else if (seg.type === 'cubicBezier') {
          code += `.add_cubic_bezier_curve_to(${v(seg.cp2)}, ${v(seg.cp1)}, ${v(seg.to)})`
        } else if (seg.type === 'quadraticBezier') {
          code += `.add_quadratic_bezier_curve_to(${v(seg.cp)}, ${v(seg.to)})`
        }
      }
      return `${code}${style}`
    }

    case 'text': {
      // Text draws fill only, matching the canvas preview (draw.ts fills text, ignores stroke).
      const f = shape.style.fill !== undefined ? cssParts(shape.style.fill) : undefined
      const fill =
        f !== undefined
          ? `.set_fill(${f.hex}, opacity=${num(f.alpha * shape.style.opacity)})`
          : `.set_fill(opacity=0)`
      // manim's `font_size` is calibrated to its default ~8-unit frame, so in a pixel-unit frame we
      // set the height explicitly — passing font_size directly renders text far too small.
      // `align` anchors the text at the entity origin, matching the canvas preview's textAlign.
      const edge = shape.align === 'left' ? 'DL' : shape.align === 'right' ? 'DR' : 'DOWN'
      const opts = [
        ...(shape.fontFamily !== undefined ? [`font=${JSON.stringify(shape.fontFamily)}`] : []),
        ...(shape.fontWeight !== undefined ? [`weight=${JSON.stringify(pangoWeight(shape.fontWeight))}`] : []),
      ]
      const optStr = opts.length > 0 ? `, ${opts.join(', ')}` : ''
      const line = (text: string, y: number): string =>
        `Text(${JSON.stringify(text)}${optStr}).scale_to_fit_height(${num(Math.max(1, shape.sizePx))}).move_to(${v({ x: shape.x, y })}, aligned_edge=${edge})${fill}`
      if (shape.lines.length <= 1) return line(shape.text, shape.y)
      // Multi-line: one Text per line, grouped so a Transform still targets a single mobject.
      // Screen space is Y-down, so later lines sit at a LARGER screen y.
      return `VGroup(${shape.lines.map((l, i) => line(l, shape.y + i * shape.lineHeightPx)).join(', ')})`
    }
  }
}

/**
 * manimpango takes NAMED font weights. A CSS numeric one raises
 * `AttributeError: There is no Font Weight Called 700` and takes the WHOLE render down — not the
 * one Text, the entire video. The IR allows `fontWeight?: number | 'normal' | 'bold'` (types.ts),
 * so the numeric form is legal input that the adapter has to translate rather than pass through.
 *
 * Found by a batch run: two of fifteen trials produced a valid, canvas-renderable scene and no
 * manim video, because the adapter emitted weight="700".
 */
const PANGO_WEIGHTS: ReadonlyArray<readonly [number, string]> = [
  [100, 'THIN'],
  [200, 'ULTRALIGHT'],
  [300, 'LIGHT'],
  [400, 'NORMAL'],
  [500, 'MEDIUM'],
  [600, 'SEMIBOLD'],
  [700, 'BOLD'],
  [800, 'ULTRABOLD'],
  [900, 'HEAVY'],
]

export function pangoWeight(weight: number | string): string {
  // A numeric string ("700") reaches here too: components are `Animatable<unknown>` in the schema,
  // so nothing rejects one before the adapter sees it.
  const asNumber = typeof weight === 'number' ? weight : Number(weight)
  if (Number.isFinite(asNumber)) {
    // `<=` so an exact tie (650 sits between SEMIBOLD and BOLD) resolves to the heavier name,
    // matching CSS font matching, which prefers heavier above 500. Exact values are unaffected.
    let best = PANGO_WEIGHTS[0]!
    for (const candidate of PANGO_WEIGHTS) {
      if (Math.abs(candidate[0] - asNumber) <= Math.abs(best[0] - asNumber)) best = candidate
    }
    return best[1]
  }
  const upper = String(weight).toUpperCase()
  // Anything manimpango would not recognise falls back rather than failing the render.
  return PANGO_WEIGHTS.some(([, name]) => name === upper) ? upper : 'NORMAL'
}

export function toManim(scene: Scene, className = 'SceneLabScene'): string {
  const times = keyframeTimes(scene)
  const frames = times.map((t) => resolveScene(scene, t))
  const first = frames[0]!
  const width = first.canvas.width
  const height = first.canvas.height
  const bg = first.canvas.background

  const lines: string[] = []
  lines.push('from manim import *')
  lines.push('')
  // One manim unit == one pixel, so projected screen coordinates carry over directly.
  // `frame_width`/`frame_height` are WORLD UNITS, not a resolution — feeding them a pixel count
  // asks manim to view a 1920x1080-unit area, shrinking the scene to a few pixels at the centre.
  // `pixel_width`/`pixel_height` are the resolution.
  lines.push(`config.pixel_width = ${num(width)}`)
  lines.push(`config.pixel_height = ${num(height)}`)
  lines.push(`config.frame_width = ${num(width)}`)
  lines.push(`config.frame_height = ${num(height)}`)
  lines.push('')
  lines.push(`class ${className}(Scene):`)
  lines.push('    def construct(self):')
  if (bg) lines.push(`        self.camera.background_color = ${hexOf(bg)}`)

  // Initial state (t = times[0]). We remember each mobject's last-emitted expression so
  // that later keyframes only re-Transform the primitives that actually changed — otherwise
  // a scene like "solve Tower of Hanoi" (hundreds of keyframes × dozens of static mobjects)
  // emits O(keyframes × entities) redundant Transforms and produces a megabyte of Python that
  // the renderer chokes on. See docs/foundation.md §8.
  const known = new Map<string, string>() // id -> last-emitted buildMobj() expression
  // project() returns far → near. Manim draws by z_index, so the painter order has to be carried
  // across explicitly; Transform does not move a mobject's z_index, so changes are re-stated.
  const zIndex = new Map<string, number>()

  const firstShapes = project(first)
  firstShapes.forEach((shape, rank) => {
    const expr = buildMobj(shape, width, height)
    known.set(shape.id, expr)
    zIndex.set(shape.id, rank)
    lines.push(`        ${varName(shape.id)} = ${expr}.set_z_index(${rank})`)
  })
  if (firstShapes.length > 0) {
    lines.push(`        self.add(${firstShapes.map((s) => varName(s.id)).join(', ')})`)
  }
  lines.push(`        self.wait(${num(HOLD)})`)

  // Animate through subsequent keyframe times.
  for (let i = 1; i < frames.length; i++) {
    const dt = times[i]! - times[i - 1]!
    const anims: string[] = []
    const zUpdates: string[] = []
    const seen = new Set<string>()
    project(frames[i]!).forEach((shape, rank) => {
      seen.add(shape.id)
      const expr = buildMobj(shape, width, height)
      const prev = known.get(shape.id)
      if (prev === undefined) {
        lines.push(`        ${varName(shape.id)} = ${expr}.set_z_index(${rank})`)
        anims.push(`FadeIn(${varName(shape.id)})`)
        known.set(shape.id, expr)
        zIndex.set(shape.id, rank)
        return
      }
      if (zIndex.get(shape.id) !== rank) {
        zUpdates.push(`        ${varName(shape.id)}.set_z_index(${rank})`)
        zIndex.set(shape.id, rank)
      }
      if (prev !== expr) {
        anims.push(`Transform(${varName(shape.id)}, ${expr})`)
        known.set(shape.id, expr)
      }
      // unchanged since the previous keyframe → nothing to emit
    })
    for (const id of known.keys()) {
      if (!seen.has(id)) anims.push(`FadeOut(${varName(id)})`)
    }
    for (const id of [...known.keys()]) {
      if (!seen.has(id)) {
        known.delete(id)
        zIndex.delete(id)
      }
    }
    lines.push(...zUpdates)
    const runTime = num(Math.max(0.1, dt))
    if (anims.length > 0) {
      lines.push(`        self.play(${anims.join(', ')}, run_time=${runTime})`)
    } else if (dt > 0) {
      // No mobject changed at this keyframe; still advance the clock to keep timing correct.
      lines.push(`        self.wait(${runTime})`)
    }
  }
  lines.push(`        self.wait(${num(HOLD)})`)
  lines.push('')
  return lines.join('\n')
}
