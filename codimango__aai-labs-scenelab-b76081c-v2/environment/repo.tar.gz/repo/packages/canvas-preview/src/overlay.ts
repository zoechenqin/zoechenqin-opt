/**
 * Debug overlay — a *separate* annotation pass over the same projection the base render uses
 * (docs/foundation.md §5/§7). It deliberately does NOT re-draw filled shapes; it reveals what the
 * base can't show: bounding boxes, entity origins, id/word labels, and the world axes. Browser-safe
 * (only a CanvasRenderingContext2D) so it works in the scrubber, the Node renderer, and later as a
 * composite over an external (manim) frame — anything that can hand us a base-painted ctx.
 */
import type { ResolvedScene } from '@scenelab/scene-ir'
import { invertMat4, multiplyMat4, transformPoint } from '@scenelab/scene-ir'
import { project, screenMatrix, type Px, type ScreenShape } from './project'

export interface OverlayOptions {
  boundingBoxes?: boolean
  origins?: boolean
  ids?: boolean
  axes?: boolean
  /** Accent color for annotations (default cyan). */
  color?: string
}

const DEFAULTS: Required<Omit<OverlayOptions, 'color'>> = {
  boundingBoxes: true,
  origins: true,
  ids: true,
  axes: true,
}

/** Screen-space bounding box [x0, y0, x1, y1] of a projected shape. */
function bboxOf(s: ScreenShape): [number, number, number, number] {
  if (s.kind === 'circle') return [s.cx - s.r, s.cy - s.r, s.cx + s.r, s.cy + s.r]
  if (s.kind === 'polygon') {
    const xs = s.points.map((p) => p.x)
    const ys = s.points.map((p) => p.y)
    return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]
  }
  if (s.kind === 'path') {
    const pts: Px[] = []
    for (const seg of s.segments) {
      pts.push(seg.to)
      if (seg.type === 'cubicBezier') pts.push(seg.cp1, seg.cp2)
      else if (seg.type === 'quadraticBezier') pts.push(seg.cp)
    }
    if (pts.length === 0) return [0, 0, 0, 0]
    const xs = pts.map((p) => p.x)
    const ys = pts.map((p) => p.y)
    return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]
  }
  // text: baseline at (x, y); x is the left/center/right anchor.
  const w = s.sizePx * 0.6 * s.text.length
  const x0 = s.align === 'center' ? s.x - w / 2 : s.align === 'right' ? s.x - w : s.x
  return [x0, s.y - s.sizePx, x0 + w, s.y]
}

function segment(ctx: CanvasRenderingContext2D, a: Px, b: Px): void {
  ctx.beginPath()
  ctx.moveTo(a.x, a.y)
  ctx.lineTo(b.x, b.y)
  ctx.stroke()
}

function crosshair(ctx: CanvasRenderingContext2D, p: Px, r = 4): void {
  ctx.beginPath()
  ctx.moveTo(p.x - r, p.y)
  ctx.lineTo(p.x + r, p.y)
  ctx.moveTo(p.x, p.y - r)
  ctx.lineTo(p.x, p.y + r)
  ctx.stroke()
}

function perspProject(
  resolved: ResolvedScene,
  pt: { x: number; y: number; z: number },
): Px | null {
  const view = invertMat4(resolved.camera.worldMatrix)
  const cam = transformPoint(view, pt)
  if (cam.z >= -0.001) return null
  const proj = resolved.camera.projection as { type: 'perspective'; fovY: number }
  const fovYRad = (proj.fovY * Math.PI) / 180
  const aspect = resolved.canvas.width / resolved.canvas.height
  const f = 1 / Math.tan(fovYRad / 2)
  const xNdc = (cam.x * f / aspect) / -cam.z
  const yNdc = (cam.y * f) / -cam.z
  return {
    x: (xNdc * 0.5 + 0.5) * resolved.canvas.width,
    y: (1 - (yNdc * 0.5 + 0.5)) * resolved.canvas.height,
  }
}

/** Draw debug annotations over an already-painted context, from a resolved scene. */
export function drawOverlay(ctx: CanvasRenderingContext2D, resolved: ResolvedScene, opts: OverlayOptions = {}): void {
  const o = { ...DEFAULTS, ...opts }
  const accent = opts.color ?? '#00e5ff'
  const shapes = project(resolved)
  const isPersp = resolved.camera.projection.type === 'perspective'
  const sm = !isPersp ? screenMatrix(resolved) : null

  ctx.save()
  ctx.globalAlpha = 1
  ctx.lineWidth = 1

  if (o.axes) {
    if (!isPersp && sm) {
      const O = transformPoint(sm, { x: 0, y: 0, z: 0 })
      ctx.strokeStyle = 'rgba(255,80,80,0.7)'
      segment(ctx, O, transformPoint(sm, { x: 100, y: 0, z: 0 })) // +X
      ctx.strokeStyle = 'rgba(80,255,80,0.7)'
      segment(ctx, O, transformPoint(sm, { x: 0, y: 100, z: 0 })) // +Y
      ctx.fillStyle = accent
      ctx.beginPath()
      ctx.arc(O.x, O.y, 3, 0, Math.PI * 2)
      ctx.fill()
    } else {
      const O = perspProject(resolved, { x: 0, y: 0, z: 0 })
      const X = perspProject(resolved, { x: 100, y: 0, z: 0 })
      const Y = perspProject(resolved, { x: 0, y: 100, z: 0 })
      if (O) {
        if (X) {
          ctx.strokeStyle = 'rgba(255,80,80,0.7)'
          segment(ctx, O, X)
        }
        if (Y) {
          ctx.strokeStyle = 'rgba(80,255,80,0.7)'
          segment(ctx, O, Y)
        }
        ctx.fillStyle = accent
        ctx.beginPath()
        ctx.arc(O.x, O.y, 3, 0, Math.PI * 2)
        ctx.fill()
      }
    }
  }

  for (const s of shapes) {
    // Text gets an anchor + baseline marker instead of a box: renderers use different fonts and
    // sizes (e.g. manim's serif is larger than our sans), so a width-estimated box never wraps the
    // real glyphs. The anchor column (left/center/right per `align`) and baseline are what the
    // scene graph actually specifies — judge alignment against those, font-independently.
    if (s.kind === 'text') {
      if (o.boundingBoxes || o.origins) {
        ctx.strokeStyle = accent
        ctx.setLineDash([])
        segment(ctx, { x: s.x - 28, y: s.y }, { x: s.x + 28, y: s.y }) // baseline
        segment(ctx, { x: s.x, y: s.y - s.sizePx }, { x: s.x, y: s.y + s.sizePx * 0.25 }) // anchor column
      }
      if (o.ids) {
        ctx.fillStyle = accent
        ctx.font = '11px sans-serif'
        ctx.textAlign = 'left'
        ctx.textBaseline = 'bottom'
        ctx.fillText(`${s.word}#${s.id} (${s.align})`, s.x + 2, s.y - s.sizePx - 2)
      }
      continue
    }
    const [x0, y0, x1, y1] = bboxOf(s)
    if (o.boundingBoxes) {
      ctx.strokeStyle = accent
      ctx.setLineDash([4, 3])
      ctx.strokeRect(x0, y0, x1 - x0, y1 - y0)
      ctx.setLineDash([])
    }
    if (o.origins) {
      const prim = resolved.primitives.find((p) => p.id === s.id)
      if (prim) {
        ctx.strokeStyle = accent
        if (!isPersp && sm) {
          crosshair(ctx, transformPoint(multiplyMat4(sm, prim.worldMatrix), { x: 0, y: 0, z: 0 }))
        } else {
          const originWorld = transformPoint(prim.worldMatrix, { x: 0, y: 0, z: 0 })
          const originScreen = perspProject(resolved, originWorld)
          if (originScreen) crosshair(ctx, originScreen)
        }
      }
    }
    if (o.ids) {
      ctx.fillStyle = accent
      ctx.font = '11px sans-serif'
      ctx.textAlign = 'left'
      ctx.textBaseline = 'bottom'
      ctx.fillText(`${s.word}#${s.id}`, x0, y0 - 1)
    }
  }
  ctx.restore()
}
