import { describe, it, expect } from 'vitest'
import { constant, identityTransform, resolveScene, sampleScene } from '@scenelab/scene-ir'
import type { Scene } from '@scenelab/scene-ir'
import { project } from './project'

const near = (a: number, b: number, eps = 1e-6): boolean => Math.abs(a - b) < eps

// sampleScene: 1920x1080 canvas, ortho camera height 1080 ⇒ 1 px/unit, center origin.
describe('project (world → screen, §3.10)', () => {
  const shapes = project(resolveScene(sampleScene()))

  it('maps a world-origin-offset circle to center + offset (px/unit = 1)', () => {
    const circle = shapes.find((s) => s.id === 'circle_1')
    expect(circle?.kind).toBe('circle')
    if (circle?.kind !== 'circle') throw new Error('expected circle')
    // world (100,0,0) → screen (960+100, 540)
    expect(near(circle.cx, 1060)).toBe(true)
    expect(near(circle.cy, 540)).toBe(true)
    expect(near(circle.r, 50)).toBe(true)
  })

  it('flips Y: world +Y maps to screen −Y (upward)', () => {
    const label = shapes.find((s) => s.id === 'label_1')
    if (label?.kind !== 'text') throw new Error('expected text')
    // world (0,80,0) → screen (960, 540 − 80)
    expect(near(label.x, 960)).toBe(true)
    expect(near(label.y, 460)).toBe(true)
  })
})

describe('text (A3)', () => {
  const textScene = (text: Record<string, unknown>): Scene =>
    ({
      schemaVersion: '0.1.0', id: 't', space: '2d', canvas: { width: 200, height: 200 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(200) } },
      root: { id: 'root', word: 's', transform: identityTransform(), children: [
        { id: 'label', word: 'label', transform: identityTransform(),
          components: { text: constant({ fontSize: 20, style: { fill: constant({ r: 1, g: 1, b: 1, a: 1 }) }, ...text }) }, children: [] },
      ] },
    }) as unknown as Scene

  const textOf = (s: Scene) => project(resolveScene(s, 0)).find((p) => p.kind === 'text') as Extract<ReturnType<typeof project>[number], { kind: 'text' }>

  it('splits content on newlines', () => {
    const t = textOf(textScene({ content: 'first\nsecond\nthird' }))
    expect(t.lines).toEqual(['first', 'second', 'third'])
    expect(t.text).toBe('first\nsecond\nthird') // full string retained for hit-testing
  })

  it('is a single line when there are no newlines', () => {
    expect(textOf(textScene({ content: 'solo' })).lines).toEqual(['solo'])
  })

  it('defaults line height to 1.2x the size', () => {
    const t = textOf(textScene({ content: 'a\nb' }))
    expect(t.lineHeightPx).toBeCloseTo(t.sizePx * 1.2, 5)
  })

  it('honours an explicit line height', () => {
    const t = textOf(textScene({ content: 'a\nb', lineHeight: 2 }))
    expect(t.lineHeightPx).toBeCloseTo(t.sizePx * 2, 5)
  })

  it('carries font family and weight through', () => {
    const t = textOf(textScene({ content: 'x', fontFamily: 'serif', fontWeight: 'bold' }))
    expect(t.fontFamily).toBe('serif')
    expect(t.fontWeight).toBe('bold')
  })

  it('leaves them undefined when unspecified, so renderers keep their default', () => {
    const t = textOf(textScene({ content: 'x' }))
    expect(t.fontFamily).toBeUndefined()
    expect(t.fontWeight).toBeUndefined()
  })
})
