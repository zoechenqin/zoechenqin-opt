import { describe, it, expect } from 'vitest'
import { applyEvent, constant, resolveScene, sampleScene } from '@scenelab/scene-ir'
import { project } from './project'
import { hitTest } from './hit'

describe('hitTest (§5)', () => {
  it('hits the circle at its projected center and misses far away', () => {
    const shapes = project(resolveScene(sampleScene()))
    expect(hitTest(shapes, { x: 1060, y: 540 })).toBe('circle_1')
    expect(hitTest(shapes, { x: 5, y: 5 })).toBeNull()
  })

  it('returns the topmost (last-drawn) shape when shapes overlap', () => {
    // Add a rect on top of the circle, both covering screen (1060, 540).
    const withRect = applyEvent(sampleScene(), {
      type: 'entity.add',
      parent: 'root',
      entity: {
        id: 'cover',
        word: 'square',
        transform: {
          position: { kind: 'const', value: { x: 100, y: 0, z: 0 } },
          rotation: { kind: 'const', value: { axis: { x: 0, y: 0, z: 1 }, angle: 0 } },
          scale: { kind: 'const', value: { x: 1, y: 1, z: 1 } },
          anchor: { x: 0, y: 0, z: 0 },
        },
        components: { rect: constant({ size: { x: 40, y: 40 }, style: {} }) },
        children: [],
      },
      index: 99, // appended last ⇒ drawn on top
    })
    const shapes = project(resolveScene(withRect))
    expect(hitTest(shapes, { x: 1060, y: 540 })).toBe('cover')
  })
})
