/**
 * @scenelab/canvas-preview — the fast in-chat Canvas 2D checkpoint (docs/foundation.md §5, §7).
 * Consumes resolveScene output: project (world → pixels) → draw + hit-test.
 */
import type { Px } from './project'
import type { Scene } from '@scenelab/scene-ir'
import { resolveScene } from '@scenelab/scene-ir'
import { project } from './project'
import { draw } from './draw'
import { hitTest } from './hit'
import { drawOverlay, type OverlayOptions } from './overlay'

export * from './project'
export * from './draw'
export * from './hit'
export * from './overlay'

/** Resolve a scene at time t and draw it to a Canvas 2D context. */
export function renderScene(ctx: CanvasRenderingContext2D, scene: Scene, t = 0): void {
  draw(ctx, project(resolveScene(scene, t)))
}

/** Render the base scene, then debug annotations on top (single resolve). */
export function renderSceneWithOverlay(
  ctx: CanvasRenderingContext2D,
  scene: Scene,
  t = 0,
  overlay: OverlayOptions = {},
): void {
  const resolved = resolveScene(scene, t)
  draw(ctx, project(resolved))
  drawOverlay(ctx, resolved, overlay)
}

/** Topmost entity id under a pixel point, or null. */
export function hitTestScene(scene: Scene, pt: Px, t = 0): string | null {
  return hitTest(project(resolveScene(scene, t)), pt)
}
