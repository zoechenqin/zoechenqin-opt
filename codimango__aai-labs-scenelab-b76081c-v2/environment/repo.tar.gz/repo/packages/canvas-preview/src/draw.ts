/** Draw screen-space shapes onto a Canvas 2D context. The only DOM-touching module. */
import type { ScreenShape, ScreenStyle } from './project'

/**
 * The headless canvas does not resolve CSS generic families: "serif", "monospace" and
 * "sans-serif" all measure identically there, collapsing to one face with nothing to say so.
 * Naming concrete faces ahead of the generic resolves headlessly and stays correct in a browser,
 * where the generic remains the last resort.
 */
const FONT_STACKS: Record<string, string> = {
  serif: '"Times New Roman", Georgia, "DejaVu Serif", "Liberation Serif", serif',
  monospace: 'Menlo, "Courier New", "DejaVu Sans Mono", "Liberation Mono", monospace',
  'sans-serif': 'Helvetica, Arial, "DejaVu Sans", "Liberation Sans", sans-serif',
}

function fontStack(family: string | undefined): string {
  const f = family ?? 'sans-serif'
  return FONT_STACKS[f] ?? f
}

function fillStroke(ctx: CanvasRenderingContext2D, style: ScreenStyle): void {
  if (style.fill !== undefined) {
    ctx.fillStyle = style.fill
    ctx.fill()
  }
  if (style.stroke !== undefined) {
    ctx.strokeStyle = style.stroke
    ctx.lineWidth = style.strokeWidthPx ?? 1
    ctx.stroke()
  }
}

export function draw(ctx: CanvasRenderingContext2D, shapes: ScreenShape[]): void {
  for (const s of shapes) {
    ctx.save()
    ctx.globalAlpha = s.style.opacity
    if (s.kind === 'circle') {
      ctx.beginPath()
      ctx.arc(s.cx, s.cy, Math.max(0, s.r), 0, Math.PI * 2)
      fillStroke(ctx, s.style)
    } else if (s.kind === 'polygon') {
      ctx.beginPath()
      s.points.forEach((p, i) => (i === 0 ? ctx.moveTo(p.x, p.y) : ctx.lineTo(p.x, p.y)))
      if (s.closed) ctx.closePath()
      fillStroke(ctx, s.style)
    } else if (s.kind === 'path') {
      ctx.beginPath()
      for (const seg of s.segments) {
        if (seg.type === 'move') ctx.moveTo(seg.to.x, seg.to.y)
        else if (seg.type === 'line') ctx.lineTo(seg.to.x, seg.to.y)
        else if (seg.type === 'cubicBezier') ctx.bezierCurveTo(seg.cp1.x, seg.cp1.y, seg.cp2.x, seg.cp2.y, seg.to.x, seg.to.y)
        else if (seg.type === 'quadraticBezier') ctx.quadraticCurveTo(seg.cp.x, seg.cp.y, seg.to.x, seg.to.y)
      }
      if (s.closed) ctx.closePath()
      fillStroke(ctx, s.style)
    } else {
      const weight = s.fontWeight !== undefined ? `${s.fontWeight} ` : ''
      ctx.font = `${weight}${s.sizePx}px ${fontStack(s.fontFamily)}`
      ctx.textAlign = s.align === 'left' ? 'left' : s.align === 'right' ? 'right' : 'center'
      ctx.textBaseline = 'alphabetic'
      if (s.style.fill !== undefined) {
        ctx.fillStyle = s.style.fill
        // The anchor is the FIRST line's baseline; later lines stack below it.
        s.lines.forEach((line, i) => ctx.fillText(line, s.x, s.y + i * s.lineHeightPx))
      }
    }
    ctx.restore()
  }
}
