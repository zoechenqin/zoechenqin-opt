import { describe, it, expect } from 'vitest'
import { sampleScene } from '@scenelab/scene-ir'
import { hitTestScene, renderScene, renderSceneWithOverlay } from './index'

/** Minimal Canvas 2D mock that records which drawing methods were called. */
function mockCtx(): CanvasRenderingContext2D & { calls: string[] } {
  const calls: string[] = []
  const methods = ['save', 'restore', 'beginPath', 'moveTo', 'lineTo', 'closePath', 'arc', 'fill', 'stroke', 'fillText', 'strokeRect', 'setLineDash']
  const ctx: Record<string, unknown> = { calls }
  for (const m of methods) ctx[m] = (): void => void calls.push(m)
  return ctx as unknown as CanvasRenderingContext2D & { calls: string[] }
}

describe('canvas-preview integration', () => {
  it('renderScene issues draw calls (circle → arc + fill)', () => {
    const ctx = mockCtx()
    renderScene(ctx, sampleScene())
    expect(ctx.calls).toContain('arc')
    expect(ctx.calls).toContain('fill')
    expect(ctx.calls).toContain('fillText') // the text label
  })

  it('hitTestScene resolves and hit-tests end-to-end', () => {
    expect(hitTestScene(sampleScene(), { x: 1060, y: 540 })).toBe('circle_1')
  })

  it('renderSceneWithOverlay draws base + debug annotations (bbox strokeRect on top)', () => {
    const ctx = mockCtx()
    renderSceneWithOverlay(ctx, sampleScene(), 0, { boundingBoxes: true, ids: true })
    expect(ctx.calls).toContain('arc') // base still drawn
    expect(ctx.calls).toContain('strokeRect') // overlay bounding boxes
  })

  it('perspective 3D scenes no longer throw — graceful degrade (project + pixelsPerUnit)', async () => {
    const { sampleScene3D } = await import('@scenelab/scene-ir')
    const { project, pixelsPerUnit } = await import('./project')
    const { resolveScene } = await import('@scenelab/scene-ir')
    const s3d = sampleScene3D()
    const resolved = resolveScene(s3d, 0.5)
    // Should not throw
    expect(() => pixelsPerUnit(resolved)).not.toThrow()
    const shapes = project(resolved)
    // Should produce visible shapes for box/sphere/cone/floor
    expect(shapes.length).toBeGreaterThanOrEqual(3)
    // At least one circle (sphere projected) or polygon (box/floor) should be present
    const kinds = shapes.map((s) => s.kind)
    expect(kinds.some((k) => k === 'circle' || k === 'polygon')).toBe(true)
  })

  it('perspective overlay does not throw (axes + bboxes)', async () => {
    const { sampleScene3D } = await import('@scenelab/scene-ir')
    const { resolveScene } = await import('@scenelab/scene-ir')
    const ctx = mockCtx()
    const s3d = sampleScene3D()
    const resolved = resolveScene(s3d, 1)
    const { renderSceneWithOverlay } = await import('./index')
    expect(() => renderSceneWithOverlay(ctx, s3d, 1, { boundingBoxes: true, axes: true })).not.toThrow()
    expect(ctx.calls.length).toBeGreaterThan(0)
    void resolved
  })
})
