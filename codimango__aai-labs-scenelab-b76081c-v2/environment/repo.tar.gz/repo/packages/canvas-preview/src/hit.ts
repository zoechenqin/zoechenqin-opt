/** Hit-testing over projected screen shapes — pure, returns the topmost entity id. */
import type { Px, ScreenShape } from './project'

function pointInPolygon(pt: Px, poly: Px[]): boolean {
  let inside = false
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i]!
    const b = poly[j]!
    const intersect =
      a.y > pt.y !== b.y > pt.y && pt.x < ((b.x - a.x) * (pt.y - a.y)) / (b.y - a.y) + a.x
    if (intersect) inside = !inside
  }
  return inside
}

function distToSegment(p: Px, a: Px, b: Px): number {
  const dx = b.x - a.x
  const dy = b.y - a.y
  const len2 = dx * dx + dy * dy
  if (len2 === 0) return Math.hypot(p.x - a.x, p.y - a.y)
  let t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / len2
  t = Math.max(0, Math.min(1, t))
  return Math.hypot(p.x - (a.x + t * dx), p.y - (a.y + t * dy))
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t
}

function cubicPoint(t: number, p0: Px, c1: Px, c2: Px, p1: Px): Px {
  const mt = 1 - t
  const mt2 = mt * mt
  const t2 = t * t
  return {
    x: mt2 * mt * p0.x + 3 * mt2 * t * c1.x + 3 * mt * t2 * c2.x + t2 * t * p1.x,
    y: mt2 * mt * p0.y + 3 * mt2 * t * c1.y + 3 * mt * t2 * c2.y + t2 * t * p1.y,
  }
}

function quadraticPoint(t: number, p0: Px, cp: Px, p1: Px): Px {
  const mt = 1 - t
  return {
    x: mt * mt * p0.x + 2 * mt * t * cp.x + t * t * p1.x,
    y: mt * mt * p0.y + 2 * mt * t * cp.y + t * t * p1.y,
  }
}

function distToCubic(p: Px, p0: Px, c1: Px, c2: Px, p1: Px): number {
  let min = Infinity
  for (let i = 0; i <= 10; i++) {
    const pt = cubicPoint(i / 10, p0, c1, c2, p1)
    const d = Math.hypot(p.x - pt.x, p.y - pt.y)
    if (d < min) min = d
  }
  // Refine around closest via 2 extra samples
  return min
}

function distToQuadratic(p: Px, p0: Px, cp: Px, p1: Px): number {
  let min = Infinity
  for (let i = 0; i <= 10; i++) {
    const pt = quadraticPoint(i / 10, p0, cp, p1)
    const d = Math.hypot(p.x - pt.x, p.y - pt.y)
    if (d < min) min = d
  }
  return min
}

function flattenPath(segments: import('./project').ScreenPathSegment[]): Px[] {
  const pts: Px[] = []
  let cur: Px | null = null
  for (const seg of segments) {
    if (seg.type === 'move') {
      cur = seg.to
      pts.push(cur)
    } else if (seg.type === 'line') {
      cur = seg.to
      pts.push(cur)
    } else if (seg.type === 'cubicBezier') {
      if (!cur) { cur = seg.to; pts.push(cur); continue }
      for (let i = 1; i <= 8; i++) {
        pts.push(cubicPoint(i / 8, cur, seg.cp1, seg.cp2, seg.to))
      }
      cur = seg.to
    } else if (seg.type === 'quadraticBezier') {
      if (!cur) { cur = seg.to; pts.push(cur); continue }
      for (let i = 1; i <= 8; i++) {
        pts.push(quadraticPoint(i / 8, cur, seg.cp, seg.to))
      }
      cur = seg.to
    }
  }
  return pts
}

function hitShape(s: ScreenShape, pt: Px): boolean {
  if (s.kind === 'circle') return Math.hypot(pt.x - s.cx, pt.y - s.cy) <= s.r
  if (s.kind === 'polygon') {
    if (s.closed) return pointInPolygon(pt, s.points)
    const tol = Math.max((s.style.strokeWidthPx ?? 1) / 2, 3)
    for (let i = 0; i < s.points.length - 1; i++) {
      if (distToSegment(pt, s.points[i]!, s.points[i + 1]!) <= tol) return true
    }
    return false
  }
  if (s.kind === 'path') {
    if (s.closed) {
      const flat = flattenPath(s.segments)
      if (flat.length >= 3 && pointInPolygon(pt, flat)) return true
    }
    const tol = Math.max((s.style.strokeWidthPx ?? 1) / 2, 4)
    let cur: Px | null = null
    for (const seg of s.segments) {
      if (seg.type === 'move') {
        cur = seg.to
      } else if (seg.type === 'line') {
        if (cur && distToSegment(pt, cur, seg.to) <= tol) return true
        cur = seg.to
      } else if (seg.type === 'cubicBezier') {
        if (cur && distToCubic(pt, cur, seg.cp1, seg.cp2, seg.to) <= tol) return true
        cur = seg.to
      } else if (seg.type === 'quadraticBezier') {
        if (cur && distToQuadratic(pt, cur, seg.cp, seg.to) <= tol) return true
        cur = seg.to
      }
    }
    return false
  }
  // text: approximate bbox anchored at the (x, y) baseline; x is the left/center/right anchor.
  const w = s.sizePx * 0.6 * s.text.length
  const x0 = s.align === 'center' ? s.x - w / 2 : s.align === 'right' ? s.x - w : s.x
  return pt.x >= x0 && pt.x <= x0 + w && pt.y <= s.y && pt.y >= s.y - s.sizePx
}

/** Topmost (last-drawn) shape under the point, or null. */
export function hitTest(shapes: ScreenShape[], pt: Px): string | null {
  for (let i = shapes.length - 1; i >= 0; i--) {
    const s = shapes[i]!
    if (hitShape(s, pt)) return s.id
  }
  return null
}
