/**
 * Projection: ResolvedScene (world space) → screen-space geometry (pixels).
 * Pure and renderer-free, so it's fully unit-testable without a DOM canvas. The camera
 * maps world → pixels (§3.10); the 2D preview supports orthographic projection (§3.5).
 */
import type { Color, ResolvedScene, ResolvedStyle, TextAlign, Vec3 } from '@scenelab/scene-ir'
import {
  invertMat4,
  multiplyMat4,
  scalingMat4,
  transformPoint,
  translationMat4,
  type Mat4,
} from '@scenelab/scene-ir'

export interface Px {
  x: number
  y: number
}

export interface ScreenStyle {
  fill?: string
  stroke?: string
  strokeWidthPx?: number
  opacity: number
}

export type ScreenPathSegment =
  | { type: 'move'; to: Px }
  | { type: 'line'; to: Px }
  | { type: 'cubicBezier'; to: Px; cp1: Px; cp2: Px }
  | { type: 'quadraticBezier'; to: Px; cp: Px }

export type ScreenShape =
  | { id: string; word: string; kind: 'polygon'; points: Px[]; closed: boolean; style: ScreenStyle }
  | { id: string; word: string; kind: 'path'; segments: ScreenPathSegment[]; closed: boolean; style: ScreenStyle }
  | { id: string; word: string; kind: 'circle'; cx: number; cy: number; r: number; style: ScreenStyle }
  | {
      id: string
      word: string
      kind: 'text'
      x: number
      y: number
      /** The full string, newlines included — kept for hit-testing and diffing. */
      text: string
      /** `text` split on newlines; renderers lay these out top to bottom. */
      lines: string[]
      sizePx: number
      lineHeightPx: number
      fontFamily?: string
      fontWeight?: number | 'normal' | 'bold'
      align: TextAlign
      style: ScreenStyle
    }

export function colorToCss(c: Color): string {
  const to255 = (v: number): number => Math.round(Math.min(1, Math.max(0, v)) * 255)
  return `rgba(${to255(c.r)}, ${to255(c.g)}, ${to255(c.b)}, ${c.a})`
}

/** World units → pixels. Ortho = exact; perspective = estimate at world origin for UI deltas. */
export function pixelsPerUnit(resolved: ResolvedScene): number {
  const { camera, canvas } = resolved
  if (camera.projection.type === 'orthographic') {
    return canvas.height / camera.projection.height
  }
  // Perspective estimate: effective world height at distance to origin.
  const view = invertMat4(resolved.camera.worldMatrix)
  const originCam = transformPoint(view, { x: 0, y: 0, z: 0 })
  const dist = Math.max(0.1, -originCam.z) // camera looks down -Z, so -z is forward distance
  const fovYRad = (camera.projection.fovY * Math.PI) / 180
  const worldH = 2 * dist * Math.tan(fovYRad / 2)
  return worldH > 1e-6 ? canvas.height / worldH : 1
}

/** world → screen pixels: ortho(center + Y-flip + ppu) · inverse(camera world). Persp returns view only for compat — use project() for real perspective. */
export function screenMatrix(resolved: ResolvedScene): Mat4 {
  const view = invertMat4(resolved.camera.worldMatrix)
  if (resolved.camera.projection.type === 'orthographic') {
    const ppu = pixelsPerUnit(resolved)
    const ortho = multiplyMat4(
      translationMat4({ x: resolved.canvas.width / 2, y: resolved.canvas.height / 2, z: 0 }),
      scalingMat4({ x: ppu, y: -ppu, z: 1 }), // Y-up world → Y-down screen
    )
    return multiplyMat4(ortho, view)
  }
  // For perspective, screenMatrix alone can't represent perspective divide; return view so
  // callers that need full projection should use project() or perspective helpers.
  return view
}

/** Internal helper: camera-space point → screen, for perspective. */
function perspectiveToScreen(
  cam: Vec3,
  fovYRad: number,
  aspect: number,
  width: number,
  height: number,
): Px | null {
  // Behind camera (z >= 0) -> invisible; allow tiny epsilon
  if (cam.z >= -0.001) return null
  const f = 1 / Math.tan(fovYRad / 2)
  const xNdc = (cam.x * f / aspect) / -cam.z
  const yNdc = (cam.y * f) / -cam.z
  // Optional frustum cull — keep even if slightly outside, so overlay still shows near-offscreen
  return {
    x: (xNdc * 0.5 + 0.5) * width,
    y: (1 - (yNdc * 0.5 + 0.5)) * height,
  }
}

/** One text primitive, split into lines. Line height defaults to 1.2x, the usual typographic default. */
function textShape(
  base: { id: string; word: string },
  x: number,
  y: number,
  shape: { content: string; align: TextAlign; fontFamily?: string; fontWeight?: number | 'normal' | 'bold'; lineHeight?: number },
  sizePx: number,
  style: ScreenStyle,
): ScreenShape {
  return {
    ...base,
    kind: 'text',
    x,
    y,
    text: shape.content,
    lines: shape.content.split('\n'),
    sizePx,
    lineHeightPx: sizePx * (shape.lineHeight ?? 1.2),
    ...(shape.fontFamily !== undefined ? { fontFamily: shape.fontFamily } : {}),
    ...(shape.fontWeight !== undefined ? { fontWeight: shape.fontWeight } : {}),
    align: shape.align,
    style,
  }
}

function screenStyle(style: ResolvedStyle, opacity: number, ppu: number): ScreenStyle {
  return {
    ...(style.fill !== undefined ? { fill: colorToCss(style.fill) } : {}),
    ...(style.stroke !== undefined ? { stroke: colorToCss(style.stroke) } : {}),
    ...(style.strokeWidth !== undefined ? { strokeWidthPx: style.strokeWidth * ppu } : {}),
    opacity,
  }
}

export function project(resolved: ResolvedScene): ScreenShape[] {
  const ppu = pixelsPerUnit(resolved)
  const view = invertMat4(resolved.camera.worldMatrix)
  const isPersp = resolved.camera.projection.type === 'perspective'
  const shapes: ScreenShape[] = []
  const depths: number[] = [] // parallel array for painter sort when perspective

  if (!isPersp) {
    const sm = screenMatrix(resolved) // ortho path already includes view
    for (const prim of resolved.primitives) {
      const m = multiplyMat4(sm, prim.worldMatrix)
      const toPx = (p: Vec3): Px => {
        const q = transformPoint(m, p)
        return { x: q.x, y: q.y }
      }
      const pxRadius = (rWorld: number): number => {
        const c = transformPoint(m, { x: 0, y: 0, z: 0 })
        const e = transformPoint(m, { x: rWorld, y: 0, z: 0 })
        return Math.hypot(e.x - c.x, e.y - c.y)
      }
      const style = screenStyle(prim.shape.style, prim.opacity, ppu)
      const base = { id: prim.id, word: prim.word }
      const shape = prim.shape

      switch (shape.type) {
        case 'circle':
        case 'sphere': {
          const c = transformPoint(m, { x: 0, y: 0, z: 0 })
          shapes.push({ ...base, kind: 'circle', cx: c.x, cy: c.y, r: pxRadius(shape.radius), style })
          break
        }
        case 'rect':
        case 'box': {
          const hw = shape.size.x / 2
          const hh = shape.size.y / 2
          shapes.push({
            ...base,
            kind: 'polygon',
            closed: true,
            points: [
              toPx({ x: -hw, y: -hh, z: 0 }),
              toPx({ x: hw, y: -hh, z: 0 }),
              toPx({ x: hw, y: hh, z: 0 }),
              toPx({ x: -hw, y: hh, z: 0 }),
            ],
            style,
          })
          break
        }
        case 'polygon':
          shapes.push({ ...base, kind: 'polygon', closed: true, points: shape.points.map(toPx), style })
          break
        case 'line':
          shapes.push({ ...base, kind: 'polygon', closed: false, points: [toPx(shape.from), toPx(shape.to)], style })
          break
        case 'path': {
          const segs: ScreenPathSegment[] = []
          for (const seg of shape.segments) {
            if (seg.type === 'move') segs.push({ type: 'move', to: toPx(seg.to) })
            else if (seg.type === 'line') segs.push({ type: 'line', to: toPx(seg.to) })
            else if (seg.type === 'cubicBezier') segs.push({ type: 'cubicBezier', to: toPx(seg.to), cp1: toPx(seg.cp1), cp2: toPx(seg.cp2) })
            else if (seg.type === 'quadraticBezier') segs.push({ type: 'quadraticBezier', to: toPx(seg.to), cp: toPx(seg.cp) })
          }
          shapes.push({ ...base, kind: 'path', segments: segs, closed: shape.closed ?? false, style })
          break
        }
        case 'text': {
          const p = transformPoint(m, { x: 0, y: 0, z: 0 })
          shapes.push(textShape(base, p.x, p.y, shape, pxRadius(shape.fontSize), style))
          break
        }
        // Volumetric shapes get the same planar stand-ins as the perspective path below. Skipping
        // them here would make a cylinder invisible in every orthographic render, with nothing in
        // the output to say a primitive went missing.
        case 'cylinder': {
          const hw = shape.radius
          const hh = shape.height / 2
          shapes.push({
            ...base,
            kind: 'polygon',
            closed: true,
            points: [
              toPx({ x: -hw, y: -hh, z: 0 }),
              toPx({ x: hw, y: -hh, z: 0 }),
              toPx({ x: hw, y: hh, z: 0 }),
              toPx({ x: -hw, y: hh, z: 0 }),
            ],
            style,
          })
          break
        }
        case 'cone': {
          const r = shape.radius
          const hh = shape.height / 2
          shapes.push({
            ...base,
            kind: 'polygon',
            closed: true,
            points: [toPx({ x: 0, y: hh, z: 0 }), toPx({ x: -r, y: -hh, z: 0 }), toPx({ x: r, y: -hh, z: 0 })],
            style,
          })
          break
        }
        case 'mesh': {
          shapes.push({
            ...base,
            kind: 'polygon',
            closed: true,
            points: [
              toPx({ x: -0.5, y: -0.5, z: 0 }),
              toPx({ x: 0.5, y: -0.5, z: 0 }),
              toPx({ x: 0.5, y: 0.5, z: 0 }),
              toPx({ x: -0.5, y: 0.5, z: 0 }),
            ],
            style,
          })
          break
        }
        case 'torus': {
          // Donut approximated as outer circle (major + tube) for visibility.
          const c = transformPoint(m, { x: 0, y: 0, z: 0 })
          const outer = shape.radius + shape.tube
          shapes.push({ ...base, kind: 'circle', cx: c.x, cy: c.y, r: pxRadius(outer), style })
          break
        }
      }
    }
    return shapes
  }

  // ---- perspective path ----
  const persp = resolved.camera.projection as { type: 'perspective'; fovY: number }
  const fovYRad = (persp.fovY * Math.PI) / 180
  const aspect = resolved.canvas.width / resolved.canvas.height
  const width = resolved.canvas.width
  const height = resolved.canvas.height

  for (const prim of resolved.primitives) {
    const camM = multiplyMat4(view, prim.worldMatrix) // local → camera
    const centerCam = transformPoint(camM, { x: 0, y: 0, z: 0 })
    if (centerCam.z >= -0.001) continue // behind camera, skip
    const depth = -centerCam.z

    const toPx = (p: Vec3): Px | null => {
      const camPt = transformPoint(camM, p)
      return perspectiveToScreen(camPt, fovYRad, aspect, width, height)
    }
    const centerPx = perspectiveToScreen(centerCam, fovYRad, aspect, width, height)
    if (!centerPx) continue
    const pxRadius = (rWorld: number): number => {
      const offCam = transformPoint(camM, { x: rWorld, y: 0, z: 0 })
      const offPx = perspectiveToScreen(offCam, fovYRad, aspect, width, height)
      if (!offPx) return 0
      return Math.hypot(offPx.x - centerPx.x, offPx.y - centerPx.y)
    }

    const style = screenStyle(prim.shape.style, prim.opacity, ppu)
    const base = { id: prim.id, word: prim.word }
    const shape = prim.shape

    let produced: ScreenShape | null = null
    switch (shape.type) {
      case 'circle':
      case 'sphere': {
        const r = pxRadius(shape.radius)
        if (r > 0) produced = { ...base, kind: 'circle', cx: centerPx.x, cy: centerPx.y, r, style }
        break
      }
      case 'rect': {
        const hw = shape.size.x / 2
        const hh = shape.size.y / 2
        const pts = [
          toPx({ x: -hw, y: -hh, z: 0 }),
          toPx({ x: hw, y: -hh, z: 0 }),
          toPx({ x: hw, y: hh, z: 0 }),
          toPx({ x: -hw, y: hh, z: 0 }),
        ]
        if (pts.every((p): p is Px => p !== null)) produced = { ...base, kind: 'polygon', closed: true, points: pts, style }
        break
      }
      case 'box': {
        // Project front face (+-hw, +-hh at z = +hz/2) as polygon for visibility
        const hw = shape.size.x / 2
        const hh = shape.size.y / 2
        const hz = shape.size.z / 2
        const pts = [
          toPx({ x: -hw, y: -hh, z: hz }),
          toPx({ x: hw, y: -hh, z: hz }),
          toPx({ x: hw, y: hh, z: hz }),
          toPx({ x: -hw, y: hh, z: hz }),
        ]
        if (pts.every((p): p is Px => p !== null)) produced = { ...base, kind: 'polygon', closed: true, points: pts, style }
        break
      }
      case 'polygon': {
        const pts = shape.points.map((p) => toPx(p)).filter((p): p is Px => p !== null)
        if (pts.length >= 3) produced = { ...base, kind: 'polygon', closed: true, points: pts, style }
        break
      }
      case 'line': {
        const a = toPx(shape.from)
        const b = toPx(shape.to)
        if (a && b) produced = { ...base, kind: 'polygon', closed: false, points: [a, b], style }
        break
      }
      case 'path': {
        const segs: ScreenPathSegment[] = []
        let ok = true
        for (const seg of shape.segments) {
          if (seg.type === 'move') {
            const t = toPx(seg.to)
            if (!t) { ok = false; break }
            segs.push({ type: 'move', to: t })
          } else if (seg.type === 'line') {
            const t = toPx(seg.to)
            if (!t) { ok = false; break }
            segs.push({ type: 'line', to: t })
          } else if (seg.type === 'cubicBezier') {
            const t = toPx(seg.to)
            const c1 = toPx(seg.cp1)
            const c2 = toPx(seg.cp2)
            if (!t || !c1 || !c2) { ok = false; break }
            segs.push({ type: 'cubicBezier', to: t, cp1: c1, cp2: c2 })
          } else if (seg.type === 'quadraticBezier') {
            const t = toPx(seg.to)
            const c = toPx(seg.cp)
            if (!t || !c) { ok = false; break }
            segs.push({ type: 'quadraticBezier', to: t, cp: c })
          }
        }
        if (ok && segs.length > 0) produced = { ...base, kind: 'path', segments: segs, closed: shape.closed ?? false, style }
        break
      }
      case 'text': {
        const r = pxRadius(shape.fontSize)
        produced = textShape(base, centerPx.x, centerPx.y, shape, Math.max(1, r), style)
        break
      }
      case 'cylinder': {
        // Approximate as rectangle of width 2r, height h at center
        const hw = shape.radius
        const hh = shape.height / 2
        const pts = [
          toPx({ x: -hw, y: -hh, z: 0 }),
          toPx({ x: hw, y: -hh, z: 0 }),
          toPx({ x: hw, y: hh, z: 0 }),
          toPx({ x: -hw, y: hh, z: 0 }),
        ]
        if (pts.every((p): p is Px => p !== null)) produced = { ...base, kind: 'polygon', closed: true, points: pts, style }
        break
      }
      case 'cone': {
        // Triangle approximation
        const r = shape.radius
        const hh = shape.height / 2
        const pts = [toPx({ x: 0, y: hh, z: 0 }), toPx({ x: -r, y: -hh, z: 0 }), toPx({ x: r, y: -hh, z: 0 })]
        if (pts.every((p): p is Px => p !== null)) produced = { ...base, kind: 'polygon', closed: true, points: pts, style }
        break
      }
      case 'mesh': {
        const pts = [
          toPx({ x: -0.5, y: -0.5, z: 0 }),
          toPx({ x: 0.5, y: -0.5, z: 0 }),
          toPx({ x: 0.5, y: 0.5, z: 0 }),
          toPx({ x: -0.5, y: 0.5, z: 0 }),
        ]
        if (pts.every((p): p is Px => p !== null)) produced = { ...base, kind: 'polygon', closed: true, points: pts, style }
        break
      }
      case 'torus': {
        const outer = shape.radius + shape.tube
        const r = pxRadius(outer)
        if (r > 0) produced = { ...base, kind: 'circle', cx: centerPx.x, cy: centerPx.y, r, style }
        break
      }
    }
    if (produced) {
      shapes.push(produced)
      depths.push(depth)
    }
  }

  // Painter's order: far → near so near draws on top (simple z-sort, §8 note).
  const order = depths.map((_, i) => i).sort((a, b) => depths[b]! - depths[a]!)
  return order.map((i) => shapes[i]!)
}
