import { describe, it, expect } from 'vitest'
import { constant, identityTransform, resolveScene, SCHEMA_VERSION } from '@scenelab/scene-ir'
import type { CorrectionEvent, EventEnvelope, Scene } from '@scenelab/scene-ir'
import {
  activeEvents,
  append,
  emptyLog,
  fromJsonl,
  replay,
  retract,
  supportedSchemaVersion,
  toCorrectionPair,
  toJsonl,
} from './index'

const base: Scene = {
  schemaVersion: '0.1.0',
  id: 'log',
  space: '2d',
  canvas: { width: 100, height: 100 },
  camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(100) } },
  root: {
    id: 'root',
    word: 'scene',
    transform: identityTransform(),
    children: [
      {
        id: 'dot',
        word: 'dot',
        transform: { ...identityTransform(), position: constant({ x: 0, y: 0, z: 0 }) },
        components: { circle: constant({ radius: 5, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }) },
        children: [],
      },
    ],
  },
} as Scene

const move = (from: number, to: number, target = 'dot'): CorrectionEvent =>
  ({ type: 'entity.translate', target, from: { x: from, y: 0, z: 0 }, to: { x: to, y: 0, z: 0 } }) as CorrectionEvent

const env = (event: CorrectionEvent, extra: Partial<EventEnvelope> = {}): EventEnvelope =>
  ({ event, source: 'human', timestamp: 0, sessionId: 's1', ...extra }) as EventEnvelope

const x = (s: Scene): number => resolveScene(s, 0).primitives.find((p) => p.id === 'dot')!.worldMatrix[12]!

describe('correction-log', () => {
  it('resolves the workspace scene-ir dependency', () => {
    expect(supportedSchemaVersion).toBe(SCHEMA_VERSION)
  })
})

describe('correction log (§3.6)', () => {
  it('replays events in order onto the base scene', () => {
    let log = emptyLog()
    log = append(log, env(move(0, 10)))
    log = append(log, env(move(10, 25)))
    const r = replay(base, log)
    expect(r.applied).toBe(2)
    expect(x(r.scene)).toBe(25)
    expect(x(base)).toBe(0) // the base is untouched
  })

  it('a retraction removes an edit without inverting it', () => {
    // Undo is a new record naming what no longer counts — not an opposite edit, not a deletion.
    let log = emptyLog()
    log = append(log, env(move(0, 10))) // e0
    log = append(log, env(move(10, 25))) // e1
    log = retract(log, 'e1', { reason: 'too far' })

    const r = replay(base, log)
    expect(x(r.scene)).toBe(10)
    expect(r.applied).toBe(1)
    expect(r.retracted).toBe(1)
    // history survives: the rejected attempt is still on the record, which is the training signal
    expect(log.records).toHaveLength(3)
    expect(log.records.some((rec) => rec.kind === 'retraction' && rec.reason === 'too far')).toBe(true)
  })

  it('retracting a transaction retracts every event in it', () => {
    let log = emptyLog()
    log = append(log, env(move(0, 5), { transactionId: 'group-1' }))
    log = append(log, env(move(5, 9), { transactionId: 'group-1' }))
    log = append(log, env(move(9, 12)))
    const r = replay(base, retract(log, 'group-1'))
    expect(r.retracted).toBe(2)
    expect(r.applied).toBe(1)
  })

  it('retracting a retraction restores what it struck out', () => {
    // Redo, without rewriting history.
    let log = emptyLog()
    log = append(log, env(move(0, 10))) // e0
    log = retract(log, 'e0', { id: 'r1' })
    expect(x(replay(base, log).scene)).toBe(0)
    log = retract(log, 'r1', { id: 'r2' })
    expect(x(replay(base, log).scene)).toBe(10)
  })

  it('reports a failing event instead of losing the rest of the log', () => {
    let log = emptyLog()
    log = append(log, env(move(0, 10)))
    log = append(log, env(move(0, 1, 'nope')))
    log = append(log, env(move(10, 20)))
    const r = replay(base, log)
    expect(r.failures).toHaveLength(1)
    expect(r.failures[0]?.id).toBe('e1')
    expect(r.applied).toBe(2)
    expect(x(r.scene)).toBe(20)
  })

  it('round-trips through JSONL, one record per line', () => {
    let log = emptyLog()
    log = append(log, env(move(0, 10)))
    log = retract(log, 'e0', { reason: 'nope' })
    expect(fromJsonl(toJsonl(log)).records).toEqual(log.records)
    expect(toJsonl(log).split('\n')).toHaveLength(2)
  })

  it('rejects a malformed log rather than silently dropping lines', () => {
    expect(() => fromJsonl('{"kind":"event","id":"e0"}\nnot json')).toThrow(/line 2/)
    expect(() => fromJsonl('{"kind":"nonsense","id":"x"}')).toThrow(/unknown record kind/)
  })

  it('emits a correction pair whose events account for before -> after', () => {
    let log = emptyLog()
    log = append(log, env(move(0, 10)))
    log = append(log, env(move(10, 30)))
    log = retract(log, 'e1')
    const pair = toCorrectionPair(base, log, {
      id: 'pair-1',
      prompt: 'move the dot',
      createdAt: '2026-08-13T00:00:00Z',
      model: 'test',
    })

    expect(x(pair.before)).toBe(0)
    expect(x(pair.after)).toBe(10)
    // the retracted attempt is excluded from the pair but retained in the log
    expect(pair.events).toHaveLength(1)
    expect(activeEvents(log)).toHaveLength(1)
    expect(log.records).toHaveLength(3)
    expect(pair.provenance.model).toBe('test')
  })

  it('is pure: replaying twice gives the same scene', () => {
    let log = emptyLog()
    log = append(log, env(move(0, 10)))
    expect(replay(base, log).scene).toEqual(replay(base, log).scene)
  })
})
