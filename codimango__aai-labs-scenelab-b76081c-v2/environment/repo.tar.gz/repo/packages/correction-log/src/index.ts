/**
 * @scenelab/correction-log — the append-only record of what was corrected, and why (Design §3.6).
 *
 * A procedural scene is only worth more than a baked one if a change to it is cheap AND
 * capturable, which is what turns editing into training data.
 *
 * The log is mutable-once. Undo neither deletes a record nor applies an inverse: it appends a
 * retraction naming what no longer counts. An inverse would misreport history — "moved it, then
 * moved it back" and "never moved it" reach the same scene but are different evidence, and the
 * first is the signal a correction corpus exists to capture. So `replay` is the only way to get a
 * scene from a log, and it is pure in (base, log).
 *
 * Entry ids are positional (`e0`, `e1`, …) so a log serialises and replays identically everywhere;
 * append-only is what makes that stable.
 */
import { applyEvent, SCHEMA_VERSION } from '@scenelab/scene-ir'
import type { CorrectionPair, EventEnvelope, Scene } from '@scenelab/scene-ir'

/** Scene-graph schema version stamped on emitted correction pairs. */
export const supportedSchemaVersion: string = SCHEMA_VERSION

export interface EventRecord {
  kind: 'event'
  id: string
  envelope: EventEnvelope
}

export interface RetractionRecord {
  kind: 'retraction'
  id: string
  /** An entry id, or a `transactionId` to retract a structural edit as a unit. */
  retracts: string
  reason?: string
  source: 'human' | 'agent'
  timestamp: number
}

export type LogRecord = EventRecord | RetractionRecord

export interface CorrectionLog {
  readonly records: readonly LogRecord[]
}

export const emptyLog = (): CorrectionLog => ({ records: [] })

/** Append an event. Returns a new log; the input is untouched. */
export function append(log: CorrectionLog, envelope: EventEnvelope, id?: string): CorrectionLog {
  const rec: EventRecord = { kind: 'event', id: id ?? `e${log.records.length}`, envelope }
  return { records: [...log.records, rec] }
}

/**
 * Append a retraction. `retracts` names an entry id or a transactionId; naming a transaction
 * retracts every event in it, which is how a group or reparent undoes as one thing.
 */
export function retract(
  log: CorrectionLog,
  retracts: string,
  opts: { source?: 'human' | 'agent'; reason?: string; timestamp?: number; id?: string } = {},
): CorrectionLog {
  const rec: RetractionRecord = {
    kind: 'retraction',
    id: opts.id ?? `r${log.records.length}`,
    retracts,
    ...(opts.reason !== undefined ? { reason: opts.reason } : {}),
    source: opts.source ?? 'human',
    timestamp: opts.timestamp ?? 0,
  }
  return { records: [...log.records, rec] }
}

/**
 * Which records still count. A record is inactive when an ACTIVE retraction names it — so
 * retracting a retraction restores what it struck out, which is redo without rewriting history.
 * Append-only guarantees a retraction only names earlier records, so this terminates.
 */
export function activeIds(log: CorrectionLog): Set<string> {
  const byId = new Map<string, LogRecord>()
  for (const r of log.records) byId.set(r.id, r)

  const memo = new Map<string, boolean>()
  const isActive = (id: string): boolean => {
    const cached = memo.get(id)
    if (cached !== undefined) return cached
    memo.set(id, true) // provisional, so a malformed cycle cannot recurse forever
    const rec = byId.get(id)
    let active = true
    if (rec) {
      for (const other of log.records) {
        if (other.kind !== 'retraction') continue
        const hits =
          other.retracts === id || (rec.kind === 'event' && other.retracts === rec.envelope.transactionId)
        if (hits && isActive(other.id)) {
          active = false
          break
        }
      }
    }
    memo.set(id, active)
    return active
  }

  const out = new Set<string>()
  for (const r of log.records) if (isActive(r.id)) out.add(r.id)
  return out
}

/** The envelopes that still count, in order. */
export function activeEvents(log: CorrectionLog): EventEnvelope[] {
  const active = activeIds(log)
  return log.records.filter((r): r is EventRecord => r.kind === 'event' && active.has(r.id)).map((r) => r.envelope)
}

export interface ReplayResult {
  scene: Scene
  applied: number
  /** Retracted, so deliberately not applied. */
  retracted: number
  /** Events that threw. Reported rather than swallowed: a log that silently drops edits is not a record. */
  failures: Array<{ id: string; error: string }>
}

/**
 * Rebuild a scene by replaying the log over `base`. Pure in (base, log).
 *
 * A failing event is recorded and skipped rather than aborting. A log spanning a schema change may
 * hold events that no longer apply, and losing the rest of the history to one of them is worse
 * than reporting it.
 */
export function replay(base: Scene, log: CorrectionLog): ReplayResult {
  const active = activeIds(log)
  let scene = base
  let applied = 0
  let retracted = 0
  const failures: Array<{ id: string; error: string }> = []

  for (const rec of log.records) {
    if (rec.kind !== 'event') continue
    if (!active.has(rec.id)) {
      retracted++
      continue
    }
    try {
      scene = applyEvent(scene, rec.envelope.event)
      applied++
    } catch (err) {
      failures.push({ id: rec.id, error: (err as Error).message })
    }
  }
  return { scene, applied, retracted, failures }
}

/** One JSON record per line — appendable without rewriting, greppable, diffable. */
export function toJsonl(log: CorrectionLog): string {
  return log.records.map((r) => JSON.stringify(r)).join('\n')
}

export function fromJsonl(text: string): CorrectionLog {
  const records = text
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0)
    .map((l, i) => {
      try {
        return JSON.parse(l) as LogRecord
      } catch {
        throw new Error(`correction-log: line ${i + 1} is not valid JSON`)
      }
    })
  for (const [i, r] of records.entries()) {
    if (r.kind !== 'event' && r.kind !== 'retraction') {
      throw new Error(`correction-log: line ${i + 1} has unknown record kind "${String((r as { kind: string }).kind)}"`)
    }
  }
  return { records }
}

/**
 * The training artifact: what the scene was, what it became, and the events accounting for the
 * difference. Retracted events are excluded from `events` but remain in the log — the pair is the
 * outcome, the log is the history.
 */
export function toCorrectionPair(
  base: Scene,
  log: CorrectionLog,
  meta: {
    id: string
    prompt?: string
    createdAt: string
    model?: string
    stage?: 'pre-render' | 'post-render'
    annotator?: string
  },
): CorrectionPair {
  const { scene } = replay(base, log)
  return {
    schemaVersion: SCHEMA_VERSION,
    id: meta.id,
    ...(meta.prompt !== undefined ? { prompt: meta.prompt } : {}),
    before: base,
    after: scene,
    events: activeEvents(log),
    provenance: {
      ...(meta.model !== undefined ? { model: meta.model } : {}),
      createdAt: meta.createdAt,
      stage: meta.stage ?? 'pre-render',
      ...(meta.annotator !== undefined ? { annotator: meta.annotator } : {}),
    },
  }
}
