import * as THREE from 'three'
import type { ResolvedScene } from '@scenelab/scene-ir'
import { clampPhi, posFromSpherical, sphericalFromPos, WORLD_UP, clampZoom, zoomAtPoint } from './math'
import type { ControlsState, DragState, Px, Viewport2DState, Viewport2DDragState } from './state'

// ---------------------------------------------------------------------------
// 3D orbit controller — used by ThreeCanvas
// ---------------------------------------------------------------------------

export function initFromResolved(ctrl: ControlsState, resolved: ResolvedScene): void {
  const m = new THREE.Matrix4().fromArray(resolved.camera.worldMatrix as unknown as number[])
  const pos = new THREE.Vector3().setFromMatrixPosition(m)

  if (resolved.camera.projection.type === 'perspective') {
    ctrl.fovY = resolved.camera.projection.fovY
  } else {
    ctrl.fovY = 50
    ctrl.orthoHeight = resolved.camera.projection.height
  }

  if (!ctrl.initialized) {
    ctrl.target.set(0, 0, 0)
    const sph = sphericalFromPos(pos, ctrl.target)
    sph.radius = Math.max(0.1, sph.radius)
    ctrl.spherical = sph
    ctrl.orthoZoom = 1
    ctrl.initialized = true
  }
}

export function applyToCamera(camera: THREE.Camera, ctrl: ControlsState): void {
  if (!ctrl.initialized) return

  const pos = posFromSpherical(ctrl.spherical, ctrl.target)
  camera.position.copy(pos)
  camera.lookAt(ctrl.target)

  if ((camera as THREE.OrthographicCamera).isOrthographicCamera) {
    const oc = camera as THREE.OrthographicCamera
    oc.zoom = ctrl.orthoZoom
    oc.updateProjectionMatrix()
  }

  camera.updateMatrixWorld()
}

export function createDragState(
  ctrl: ControlsState,
  mode: 'orbit' | 'pan' | 'look',
  startX: number,
  startY: number,
): DragState {
  return {
    mode: mode as any,
    startX,
    startY,
    startTheta: ctrl.spherical.theta,
    startPhi: ctrl.spherical.phi,
    startTarget: ctrl.target.clone(),
    startRadius: ctrl.spherical.radius,
    startOrthoZoom: ctrl.orthoZoom,
  }
}

export function updateOrbit(
  ctrl: ControlsState,
  drag: DragState,
  dx: number,
  dy: number,
  rotateSpeed = 0.005,
): void {
  ctrl.spherical.theta = drag.startTheta - dx * rotateSpeed
  ctrl.spherical.phi = clampPhi(drag.startPhi - dy * rotateSpeed)
}

// Rotate around own center — camera stays, target orbits around camera.
export function updateLook(
  ctrl: ControlsState,
  drag: DragState,
  dx: number,
  dy: number,
  rotateSpeed = 0.005,
): void {
  // Camera pos at drag start — stays fixed during look
  const startPos = posFromSpherical(
    { radius: drag.startRadius, theta: drag.startTheta, phi: drag.startPhi },
    drag.startTarget,
  )
  // Spherical of target relative to camera pos at start
  const startLook = sphericalFromPos(drag.startTarget, startPos)

  const newTheta = startLook.theta - dx * rotateSpeed
  const newPhi = clampPhi(startLook.phi + dy * rotateSpeed)

  const newLook = { radius: startLook.radius, theta: newTheta, phi: newPhi }
  const newTarget = posFromSpherical(newLook, startPos)

  ctrl.target.copy(newTarget)
  // Recompute offset spherical (pos relative to new target) to keep state consistent
  const newOffset = sphericalFromPos(startPos, newTarget)
  ctrl.spherical = newOffset
}

export function updatePan(
  ctrl: ControlsState,
  drag: DragState,
  dx: number,
  dy: number,
  canvasHeight: number,
  isOrthographic: boolean,
): void {
  const startPos = posFromSpherical(
    { radius: drag.startRadius, theta: drag.startTheta, phi: drag.startPhi },
    drag.startTarget,
  )
  const forward = new THREE.Vector3().subVectors(drag.startTarget, startPos).normalize()

  let right = new THREE.Vector3().crossVectors(forward, WORLD_UP)
  if (right.lengthSq() < 1e-6) {
    right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(1, 0, 0))
  }
  right.normalize()
  const up = new THREE.Vector3().crossVectors(right, forward).normalize()

  let worldPerPixel: number
  if (isOrthographic) {
    const effHeight = ctrl.orthoHeight / ctrl.orthoZoom
    worldPerPixel = effHeight / canvasHeight
  } else {
    const worldHeight = 2 * drag.startRadius * Math.tan(THREE.MathUtils.degToRad(ctrl.fovY) / 2)
    worldPerPixel = worldHeight / canvasHeight
  }

  const panX = -dx * worldPerPixel
  const panY = dy * worldPerPixel

  const off = new THREE.Vector3()
  off.addScaledVector(right, panX)
  off.addScaledVector(up, panY)

  ctrl.target.copy(drag.startTarget).add(off)
}

export function updateZoomPerspective(ctrl: ControlsState, deltaY: number): void {
  const factor = deltaY < 0 ? 0.9 : 1.1
  ctrl.spherical.radius = Math.max(0.1, Math.min(10000, ctrl.spherical.radius * factor))
}

export function updateZoomOrthographic(ctrl: ControlsState, deltaY: number): void {
  const factor = deltaY < 0 ? 1.1 : 0.9
  ctrl.orthoZoom = Math.max(0.05, Math.min(100, ctrl.orthoZoom * factor))
}

export function updateZoom(ctrl: ControlsState, deltaY: number, isPerspective: boolean): void {
  if (isPerspective) {
    updateZoomPerspective(ctrl, deltaY)
  } else {
    updateZoomOrthographic(ctrl, deltaY)
  }
}

// WASD — move target (and thus camera) along camera local axes, like Unity scene view.
export function moveCameraForward(ctrl: ControlsState, distance: number): void {
  if (!ctrl.initialized) return
  const pos = posFromSpherical(ctrl.spherical, ctrl.target)
  const forward = new THREE.Vector3().subVectors(ctrl.target, pos).normalize()
  // Keep movement mostly horizontal for 3D, but allow full 3D forward for orbit flexibility
  ctrl.target.addScaledVector(forward, distance)
}

export function moveCameraStrafe(ctrl: ControlsState, distance: number): void {
  if (!ctrl.initialized) return
  const pos = posFromSpherical(ctrl.spherical, ctrl.target)
  const forward = new THREE.Vector3().subVectors(ctrl.target, pos).normalize()
  let right = new THREE.Vector3().crossVectors(forward, WORLD_UP)
  if (right.lengthSq() < 1e-6) {
    right = new THREE.Vector3().crossVectors(forward, new THREE.Vector3(1, 0, 0))
  }
  right.normalize()
  ctrl.target.addScaledVector(right, distance)
}

// ---------------------------------------------------------------------------
// 2D viewport controller — moved from SpatialCanvas (space+drag pan, wheel zoom at cursor)
// ---------------------------------------------------------------------------

export function createViewport2DDragState(viewport: Viewport2DState, startCanvas: Px): Viewport2DDragState {
  return {
    startCanvas,
    startPan: { ...viewport.pan },
  }
}

/** Mutating version: apply pan delta from current canvas position and drag start. */
export function updateViewportPan(
  viewport: Viewport2DState,
  drag: Viewport2DDragState,
  currentCanvas: Px,
): void {
  const dx = currentCanvas.x - drag.startCanvas.x
  const dy = currentCanvas.y - drag.startCanvas.y
  viewport.pan.x = drag.startPan.x + dx
  viewport.pan.y = drag.startPan.y + dy
}

/** Immutable version: returns a new viewport with pan updated from drag. */
export function panViewport(
  viewport: Viewport2DState,
  drag: Viewport2DDragState,
  currentCanvas: Px,
): Viewport2DState {
  const dx = currentCanvas.x - drag.startCanvas.x
  const dy = currentCanvas.y - drag.startCanvas.y
  return {
    pan: { x: drag.startPan.x + dx, y: drag.startPan.y + dy },
    zoom: viewport.zoom,
  }
}

/** Mutating zoom at a point — clamps and keeps anchor. */
export function updateViewportZoomAtPoint(
  viewport: Viewport2DState,
  canvasPx: Px,
  newZoom: number,
  minZoom = 0.1,
  maxZoom = 40,
): void {
  const clamped = clampZoom(newZoom, minZoom, maxZoom)
  const ratio = clamped / viewport.zoom
  viewport.pan.x = canvasPx.x - (canvasPx.x - viewport.pan.x) * ratio
  viewport.pan.y = canvasPx.y - (canvasPx.y - viewport.pan.y) * ratio
  viewport.zoom = clamped
}

/** Wheel delta convenience — mutates viewport, matching SpatialCanvas factor. */
export function updateViewportZoomFromDelta(
  viewport: Viewport2DState,
  canvasPx: Px,
  deltaY: number,
  minZoom = 0.1,
  maxZoom = 40,
): void {
  const factor = deltaY < 0 ? 1.1 : 0.9
  const newZoom = clampZoom(viewport.zoom * factor, minZoom, maxZoom)
  // reuse anchor math
  const ratio = newZoom / viewport.zoom
  viewport.pan.x = canvasPx.x - (canvasPx.x - viewport.pan.x) * ratio
  viewport.pan.y = canvasPx.y - (canvasPx.y - viewport.pan.y) * ratio
  viewport.zoom = newZoom
}

/** Immutable: compute new viewport for zoom factor anchored at canvas point. */
export function computeZoomedViewport(
  viewport: Viewport2DState,
  canvasPx: Px,
  factor: number,
  minZoom = 0.1,
  maxZoom = 40,
): Viewport2DState {
  const newZoom = clampZoom(viewport.zoom * factor, minZoom, maxZoom)
  return zoomAtPoint(viewport, canvasPx, newZoom)
}
