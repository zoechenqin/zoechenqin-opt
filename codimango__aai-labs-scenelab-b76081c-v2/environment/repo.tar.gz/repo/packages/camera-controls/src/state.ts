import * as THREE from 'three'
import type { Spherical } from './math'

// ---------------------------------------------------------------------------
// 3D orbit controls state — used by ThreeCanvas (right-drag orbit, middle-drag pan, wheel zoom)
// ---------------------------------------------------------------------------

export interface ControlsState {
  target: THREE.Vector3
  spherical: Spherical
  orthoZoom: number
  initialized: boolean
  fovY: number // for pan scaling, degrees
  orthoHeight: number // world height for orthographic
}

export type DragMode = 'orbit' | 'pan' | 'look' | null

export interface DragState {
  mode: DragMode
  startX: number
  startY: number
  startTheta: number
  startPhi: number
  startTarget: THREE.Vector3
  startRadius: number
  startOrthoZoom: number
}

export function createInitialState(): ControlsState {
  return {
    target: new THREE.Vector3(0, 0, 0),
    spherical: { radius: 10, theta: 0, phi: Math.PI / 3 },
    orthoZoom: 1,
    initialized: false,
    fovY: 50,
    orthoHeight: 1080,
  }
}

// ---------------------------------------------------------------------------
// 2D viewport controls state — moved from SpatialCanvas (space+drag pan, wheel zoom at cursor)
// ---------------------------------------------------------------------------

export interface Px {
  x: number
  y: number
}

export interface Viewport2DState {
  pan: Px
  zoom: number
}

export interface Viewport2DDragState {
  startCanvas: Px
  startPan: Px
}

export function createInitialViewport2DState(): Viewport2DState {
  return { pan: { x: 0, y: 0 }, zoom: 1 }
}

// Backwards-compat alias — SpatialCanvas previously exported Viewport2D
export type Viewport2D = Viewport2DState
