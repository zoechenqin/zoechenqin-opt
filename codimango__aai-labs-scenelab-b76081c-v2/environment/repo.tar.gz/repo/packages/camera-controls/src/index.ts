/**
 * @scenelab/camera-controls — camera orbit/pan/zoom controls extracted from ThreeCanvas,
 * plus 2D viewport controls moved from SpatialCanvas.
 *
 * Pure, framework-agnostic: math + state + controllers only. No React/Jsx.
 * Dependencies: three + @scenelab/scene-ir only (no @scenelab/widgets, three-renderer, or React).
 * React hooks live directly in their widgets: useOrbitControls in ThreeCanvas.tsx,
 * useViewport2DControls in SpatialCanvas.tsx, so this package stays framework-agnostic.
 *
 * File organization (single file per concern, 2D/3D differentiated by comments):
 * - `math.ts` — 3D spherical math + 2D viewport math (Px, canvasPxFromClient, zoomAtPoint, etc.)
 * - `state.ts` — 3D ControlsState/DragState + 2D Viewport2DState/DragState
 * - `controller.ts` — 3D orbit/pan/zoom controllers + 2D pan/zoom controllers
 */

// 3D orbit — pure
export type { Spherical } from './math'
export { WORLD_UP, clampPhi, sphericalFromPos, posFromSpherical } from './math'
export type { ControlsState, DragState, DragMode } from './state'
export { createInitialState } from './state'
export {
  initFromResolved,
  applyToCamera,
  createDragState,
  updateOrbit,
  updatePan,
  updateLook,
  updateZoom,
  updateZoomPerspective,
  updateZoomOrthographic,
  moveCameraForward,
  moveCameraStrafe,
} from './controller'

// 2D viewport — moved from SpatialCanvas, now co-located in the same files above
// (differentiated by comments inside state.ts / math.ts / controller.ts)
export type { Px, Viewport2DState, Viewport2DDragState, Viewport2D } from './state'
export { createInitialViewport2DState } from './state'
export { canvasPxFromClient, toBasePx, clampZoom, zoomAtPoint, zoomFromDelta } from './math'
export {
  createViewport2DDragState,
  updateViewportPan,
  panViewport,
  updateViewportZoomAtPoint,
  updateViewportZoomFromDelta,
  computeZoomedViewport,
} from './controller'
