import * as THREE from 'three'
import type { Px, Viewport2DState } from './state'

// ---------------------------------------------------------------------------
// 3D orbit math — spherical coords for ThreeCanvas
// ---------------------------------------------------------------------------

export interface Spherical {
  radius: number
  theta: number
  phi: number
}

export const WORLD_UP = new THREE.Vector3(0, 1, 0)

export function clampPhi(phi: number): number {
  const eps = 0.001
  return Math.max(eps, Math.min(Math.PI - eps, phi))
}

export function sphericalFromPos(pos: THREE.Vector3, target: THREE.Vector3): Spherical {
  const offset = new THREE.Vector3().subVectors(pos, target)
  const radius = offset.length() || 0.0001
  const theta = Math.atan2(offset.x, offset.z)
  const phi = Math.acos(Math.max(-1, Math.min(1, offset.y / radius)))
  return { radius, theta, phi: clampPhi(phi) }
}

export function posFromSpherical(s: Spherical, target: THREE.Vector3): THREE.Vector3 {
  const sinPhi = Math.sin(s.phi)
  const x = s.radius * sinPhi * Math.sin(s.theta)
  const y = s.radius * Math.cos(s.phi)
  const z = s.radius * sinPhi * Math.cos(s.theta)
  return new THREE.Vector3(x, y, z).add(target)
}

// ---------------------------------------------------------------------------
// 2D viewport math — moved from SpatialCanvas (Canvas2D view)
// ---------------------------------------------------------------------------

/** Map a client (CSS) pointer position to canvas raster pixels. */
export function canvasPxFromClient(canvas: HTMLCanvasElement, clientX: number, clientY: number): Px {
  const rect = canvas.getBoundingClientRect()
  const sx = rect.width === 0 ? 1 : canvas.width / rect.width
  const sy = rect.height === 0 ? 1 : canvas.height / rect.height
  return { x: (clientX - rect.left) * sx, y: (clientY - rect.top) * sy }
}

/** Convert a raster canvas pixel to base (pre-transform) space. */
export function toBasePx(canvasPx: Px, viewport: Viewport2DState): Px {
  return {
    x: (canvasPx.x - viewport.pan.x) / viewport.zoom,
    y: (canvasPx.y - viewport.pan.y) / viewport.zoom,
  }
}

/** Clamp zoom factor to allowed range. */
export function clampZoom(zoom: number, min = 0.1, max = 40): number {
  return Math.max(min, Math.min(max, zoom))
}

/**
 * Compute new viewport when zooming at a specific canvas point, keeping that point anchored.
 * Formula taken from SpatialCanvas original: newPan = canvasPx - (canvasPx - oldPan) * ratio
 */
export function zoomAtPoint(viewport: Viewport2DState, canvasPx: Px, newZoom: number): Viewport2DState {
  const ratio = newZoom / viewport.zoom
  return {
    pan: {
      x: canvasPx.x - (canvasPx.x - viewport.pan.x) * ratio,
      y: canvasPx.y - (canvasPx.y - viewport.pan.y) * ratio,
    },
    zoom: newZoom,
  }
}

/** Compute zoomed viewport from a deltaY (wheel) — factor 1.1 in / 0.9 out, matching 2D and 3D conventions. */
export function zoomFromDelta(
  viewport: Viewport2DState,
  canvasPx: Px,
  deltaY: number,
  minZoom = 0.1,
  maxZoom = 40,
): Viewport2DState {
  const factor = deltaY < 0 ? 1.1 : 0.9
  const newZoom = clampZoom(viewport.zoom * factor, minZoom, maxZoom)
  return zoomAtPoint(viewport, canvasPx, newZoom)
}
