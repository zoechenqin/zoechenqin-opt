import { describe, expect, it } from 'vitest'
import * as THREE from 'three'
import { clampPhi, posFromSpherical, sphericalFromPos, toBasePx, zoomAtPoint, clampZoom } from './math'
import { createInitialState, createInitialViewport2DState } from './state'
import {
  applyToCamera,
  initFromResolved,
  updateOrbit,
  updatePan,
  updateZoom,
  createViewport2DDragState,
  panViewport,
  updateViewportZoomFromDelta,
} from './controller'
import { constant, identityTransform } from '@scenelab/scene-ir'

function sampleResolved(isPersp = false) {
  return {
    canvas: { width: 640, height: 480 },
    primitives: [],
    camera: {
      worldMatrix: new THREE.Matrix4().makeTranslation(0, 0, 10).toArray() as unknown as any,
      projection: isPersp
        ? { type: 'perspective' as const, fovY: 50, near: 0.1, far: 1000 }
        : { type: 'orthographic' as const, height: 10 },
    },
  } as any
}

describe('math', () => {
  it('round-trips spherical', () => {
    const target = new THREE.Vector3(0, 0, 0)
    const pos = new THREE.Vector3(3, 4, 5)
    const sph = sphericalFromPos(pos, target)
    const back = posFromSpherical(sph, target)
    expect(back.distanceTo(pos)).toBeLessThan(1e-6)
  })
  it('clamps phi', () => {
    expect(clampPhi(0)).toBeGreaterThan(0)
    expect(clampPhi(Math.PI)).toBeLessThan(Math.PI)
  })
})

describe('controller', () => {
  it('inits from resolved', () => {
    const state = createInitialState()
    initFromResolved(state, sampleResolved())
    expect(state.initialized).toBe(true)
    expect(state.spherical.radius).toBeGreaterThan(0)
  })
  it('inverts vertical orbit (drag up decreases phi)', () => {
    const state = createInitialState()
    initFromResolved(state, sampleResolved())
    const startPhi = state.spherical.phi
    const drag = { mode: 'orbit' as const, startX: 0, startY: 0, startTheta: state.spherical.theta, startPhi, startTarget: state.target.clone(), startRadius: state.spherical.radius, startOrthoZoom: 1 }
    updateOrbit(state, drag, 0, -10) // dy negative = drag up
    // after inverted fix, phi should increase? Actually dy = -10 (drag up). Our impl: phi = startPhi - dy* speed = startPhi - (-10)*speed = startPhi + positive => increase? Wait check: we want drag up to increase? Let's think: drag up (dy negative) should move camera up? Standard? Our current impl: phi = startPhi - dy*speed, so dy -10 => phi bigger? Actually start - (-10) = +. That means dragging up increases phi (camera goes down). That's what we have after inversion? Let's verify against actual code: we did startPhi - dy. Original was + dy. Original drag up decreased phi. Now inverted drag up increases phi. So expectation inverted.
    expect(state.spherical.phi).toBeGreaterThan(startPhi)
  })
  it('pan moves target', () => {
    const state = createInitialState()
    initFromResolved(state, sampleResolved())
    const drag = { mode: 'pan' as const, startX: 0, startY: 0, startTheta: state.spherical.theta, startPhi: state.spherical.phi, startTarget: state.target.clone(), startRadius: state.spherical.radius, startOrthoZoom: 1 }
    const before = state.target.clone()
    updatePan(state, drag, 10, 5, 480, true)
    expect(state.target.distanceTo(before)).toBeGreaterThan(0)
  })
  it('zoom clamps', () => {
    const state = createInitialState()
    state.spherical.radius = 10
    updateZoom(state, -1, true)
    expect(state.spherical.radius).toBeLessThan(10)
    state.orthoZoom = 1
    updateZoom(state, -1, false)
    expect(state.orthoZoom).toBeGreaterThan(1)
  })
  it('applyToCamera sets position', () => {
    const state = createInitialState()
    initFromResolved(state, sampleResolved(true))
    const cam = new THREE.PerspectiveCamera(50, 1, 0.1, 1000)
    applyToCamera(cam, state)
    expect(cam.position.length()).toBeGreaterThan(0)
  })
})

describe('viewport2d', () => {
  it('toBasePx inverts pan/zoom', () => {
    const vp = { pan: { x: 10, y: 20 }, zoom: 2 }
    const base = toBasePx({ x: 30, y: 60 }, vp)
    expect(base.x).toBeCloseTo(10)
    expect(base.y).toBeCloseTo(20)
  })

  it('zoomAtPoint keeps anchor', () => {
    const vp = { pan: { x: 0, y: 0 }, zoom: 1 }
    const canvasPx = { x: 100, y: 100 }
    const zoomed = zoomAtPoint(vp, canvasPx, 2)
    // anchor 100,100 should map to same base before/after
    const before = toBasePx(canvasPx, vp)
    const after = toBasePx(canvasPx, zoomed)
    expect(after.x).toBeCloseTo(before.x)
    expect(after.y).toBeCloseTo(before.y)
  })

  it('panViewport moves pan by drag delta', () => {
    const vp = createInitialViewport2DState()
    const drag = createViewport2DDragState(vp, { x: 0, y: 0 })
    const next = panViewport(vp, drag, { x: 10, y: 15 })
    expect(next.pan.x).toBe(10)
    expect(next.pan.y).toBe(15)
    expect(next.zoom).toBe(vp.zoom)
  })

  it('updateViewportZoomFromDelta clamps', () => {
    const vp = { pan: { x: 0, y: 0 }, zoom: 1 }
    updateViewportZoomFromDelta(vp, { x: 0, y: 0 }, -100, 0.1, 40)
    expect(vp.zoom).toBeGreaterThan(1)
    expect(vp.zoom).toBeLessThanOrEqual(40)
    const vp2 = { pan: { x: 0, y: 0 }, zoom: 40 }
    updateViewportZoomFromDelta(vp2, { x: 0, y: 0 }, -10, 0.1, 40)
    expect(vp2.zoom).toBe(40)
  })

  it('clampZoom respects bounds', () => {
    expect(clampZoom(0.01, 0.1, 40)).toBe(0.1)
    expect(clampZoom(100, 0.1, 40)).toBe(40)
    expect(clampZoom(5, 0.1, 40)).toBe(5)
  })
})
