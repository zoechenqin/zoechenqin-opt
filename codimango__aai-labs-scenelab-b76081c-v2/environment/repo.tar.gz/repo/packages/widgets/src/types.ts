/** Shared widget types and helpers (host-embedding contract, §5.2). */
import type { CorrectionEvent, EventEnvelope } from '@scenelab/scene-ir'

export interface WidgetConfig {
  sessionId?: string
  readOnly?: boolean
}

/** Wrap a human-authored correction event as an envelope (§5.4). */
export function humanEnvelope(event: CorrectionEvent, sessionId = 'session'): EventEnvelope {
  return { event, source: 'human', timestamp: Date.now(), sessionId }
}

// UI layout for dynamic widget spawning in web interfaces (agent can POST /api/ui)
export type WidgetType = 'project' | 'scene' | 'outliner' | 'scene-view' | 'preview' | 'properties' | 'timeline' | 'trace'
export interface UIPanel {
  id: string
  type: WidgetType
  position?: 'left' | 'center' | 'right' | 'floating'
  props?: Record<string, unknown>
}
export interface UILayout {
  revision: number
  panels: UIPanel[]
}
