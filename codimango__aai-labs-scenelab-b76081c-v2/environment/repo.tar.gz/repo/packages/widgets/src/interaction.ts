/**
 * Pure interaction math (pixel ↔ world), extracted so it's unit-testable.
 * 2D view helpers (Px, canvasPxFromClient, toBasePx, etc.) now live in
 * @scenelab/camera-controls for shared 2D/3D ownership. This module re-exports
 * them for backwards compatibility and retains worldDeltaFromPixels which is
 * specific to SpatialCanvas object dragging.
 */

export type { Px } from '@scenelab/camera-controls'
export { canvasPxFromClient, toBasePx } from '@scenelab/camera-controls'

/** Screen pixel delta → world delta (Y-down screen → Y-up world, §3.10). */
export function worldDeltaFromPixels(dpx: number, dpy: number, pixelsPerUnit: number): { x: number; y: number; z: number } {
  return { x: dpx / pixelsPerUnit, y: -dpy / pixelsPerUnit, z: 0 }
}
