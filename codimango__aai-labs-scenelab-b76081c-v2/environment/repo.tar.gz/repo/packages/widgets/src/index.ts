/**
 * @scenelab/widgets — embeddable React widgets (docs/foundation.md §5, §8).
 * Each is a controlled component: `scene` in, typed correction events out.
 */
export * from './types'
export * from './interaction'
export * from './SpatialCanvas'
export * from './ThreeCanvas'
export * from './PropertiesPanel'
export * from './timeline/Timeline'
export * from './WidgetHost'
