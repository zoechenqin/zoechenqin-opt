/**
 * ThreeCanvas — unified 2D+3D preview widget.
 * - Scene View (editableCamera=true): independent editor camera.
 * - Preview (editableCamera=false): locked to scene's camera.
 */
import { useCallback, useEffect, useRef } from 'react'
import * as THREE from 'three'
import type { ResolvedScene, Scene } from '@scenelab/scene-ir'
import { resolveScene } from '@scenelab/scene-ir'
import { ThreeView } from '@scenelab/three-renderer'
import { clientToNdc, hitTest } from '@scenelab/three-renderer'
import type { ControlsState, DragState } from '@scenelab/camera-controls'
import {
  createInitialState,
  applyToCamera,
  createDragState,
  initFromResolved,
  updateOrbit,
  updatePan,
  updateLook,
  updateZoom,
  moveCameraForward,
  moveCameraStrafe,
} from '@scenelab/camera-controls'

interface UseOrbitControlsOptions {
  canvasRef: React.RefObject<HTMLCanvasElement>
  resolvedRef: React.RefObject<ResolvedScene | null>
  renderRef: React.MutableRefObject<() => void>
  enabled: boolean
}

function useOrbitControls(opts: UseOrbitControlsOptions) {
  const { canvasRef, resolvedRef, renderRef, enabled } = opts

  const controlsRef = useRef<ControlsState>(createInitialState())
  const dragRef = useRef<DragState | null>(null)
  const keysRef = useRef<Set<string>>(new Set())
  const rafRef = useRef<number | null>(null)
  const lastTimeRef = useRef<number>(performance.now())

  const init = useCallback(
    (resolved: ResolvedScene) => {
      initFromResolved(controlsRef.current, resolved)
    },
    [],
  )

  const applyControls = useCallback((camera: THREE.Camera) => {
    applyToCamera(camera, controlsRef.current)
  }, [])

  const tick = useCallback(() => {
    const ctrl = controlsRef.current
    if (!ctrl.initialized) {
      rafRef.current = null
      return
    }
    const now = performance.now()
    const dt = Math.min(0.1, (now - lastTimeRef.current) / 1000)
    lastTimeRef.current = now

    if (keysRef.current.size === 0) {
      rafRef.current = null
      return
    }

    const curPos = (() => {
      const sph = ctrl.spherical
      const tgt = ctrl.target
      const sinPhi = Math.sin(sph.phi)
      const x = sph.radius * sinPhi * Math.sin(sph.theta)
      const y = sph.radius * Math.cos(sph.phi)
      const z = sph.radius * sinPhi * Math.cos(sph.theta)
      return new THREE.Vector3(x, y, z).add(tgt)
    })()
    const forwardDir = new THREE.Vector3().subVectors(ctrl.target, curPos).normalize()
    let rightDir = new THREE.Vector3().crossVectors(forwardDir, new THREE.Vector3(0, 1, 0))
    if (rightDir.lengthSq() < 1e-6) rightDir = new THREE.Vector3().crossVectors(forwardDir, new THREE.Vector3(1, 0, 0))
    rightDir.normalize()

    const speed = Math.max(0.8, ctrl.spherical.radius * 0.6) * dt * 3.5
    let f = 0
    let s = 0
    if (keysRef.current.has('w')) f += speed
    if (keysRef.current.has('s')) f -= speed
    if (keysRef.current.has('a')) s -= speed
    if (keysRef.current.has('d')) s += speed

    if (f !== 0) {
      ctrl.target.addScaledVector(forwardDir, f)
    }
    if (s !== 0) {
      ctrl.target.addScaledVector(rightDir, s)
    }

    if ((f !== 0 || s !== 0) && dragRef.current) {
      const drag = dragRef.current
      if (f !== 0) drag.startTarget.addScaledVector(forwardDir, f)
      if (s !== 0) drag.startTarget.addScaledVector(rightDir, s)
    }

    if (f !== 0 || s !== 0) renderRef.current()

    if (keysRef.current.size > 0) {
      rafRef.current = requestAnimationFrame(tick)
    } else {
      rafRef.current = null
    }
  }, [])

  const ensureTicking = useCallback(() => {
    if (rafRef.current !== null) return
    lastTimeRef.current = performance.now()
    rafRef.current = requestAnimationFrame(tick)
  }, [tick])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    if (!enabled) return

    const onWheelNative = (e: WheelEvent): void => {
      e.preventDefault()
      e.stopPropagation()
      const ctrl = controlsRef.current
      if (!ctrl.initialized) return
      const isPersp = resolvedRef.current?.camera.projection.type === 'perspective'
      updateZoom(ctrl, e.deltaY, !!isPersp)
      renderRef.current()
    }

    const onKeyDown = (e: KeyboardEvent): void => {
      const key = e.key.toLowerCase()
      if (!['w', 'a', 's', 'd'].includes(key)) return
      const target = e.target as HTMLElement | null
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return
      if (keysRef.current.has(key)) return
      e.preventDefault()
      keysRef.current.add(key)
      ensureTicking()
    }

    const onKeyUp = (e: KeyboardEvent): void => {
      const key = e.key.toLowerCase()
      if (keysRef.current.has(key)) {
        keysRef.current.delete(key)
      }
    }

    canvas.addEventListener('wheel', onWheelNative, { passive: false })
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)
    return () => {
      canvas.removeEventListener('wheel', onWheelNative)
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current)
        rafRef.current = null
      }
      keysRef.current.clear()
    }
  }, [canvasRef, resolvedRef, renderRef, enabled, ensureTicking])

  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): void => {
      if (!enabled) return
      const ctrl = controlsRef.current
      if (!ctrl.initialized) return

      const isOrbit = e.button === 2
      const isPan = e.button === 1
      if (!isOrbit && !isPan) return

      e.preventDefault()
      canvasRef.current?.setPointerCapture(e.pointerId)

      dragRef.current = createDragState(ctrl, isOrbit ? 'orbit' : 'pan', e.clientX, e.clientY)
    },
    [canvasRef, enabled],
  )

  const onPointerMove = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): void => {
      if (!enabled) return
      const drag = dragRef.current
      const ctrl = controlsRef.current
      if (!drag || !ctrl.initialized) return

      const dx = e.clientX - drag.startX
      const dy = e.clientY - drag.startY
      const canvas = canvasRef.current
      const canvasHeight = canvas?.height ?? 720

      if (drag.mode === 'orbit') {
        updateOrbit(ctrl, drag, dx, dy)
        renderRef.current()
      } else if (drag.mode === 'look') {
        updateLook(ctrl, drag, dx, dy)
        renderRef.current()
      } else if (drag.mode === 'pan') {
        const isOrtho = resolvedRef.current?.camera.projection.type === 'orthographic'
        updatePan(ctrl, drag, dx, dy, canvasHeight, !!isOrtho)
        renderRef.current()
      }
    },
    [canvasRef, resolvedRef, renderRef, enabled],
  )

  const onPointerUp = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): void => {
      if (!enabled) return
      if (dragRef.current) {
        dragRef.current = null
        canvasRef.current?.releasePointerCapture(e.pointerId)
      }
    },
    [canvasRef, enabled],
  )

  const onContextMenu = useCallback((e: React.MouseEvent): void => {
    if (enabled) e.preventDefault()
  }, [enabled])

  return {
    initFromResolved: init,
    applyControls,
    onPointerDown,
    onPointerMove,
    onPointerUp,
    onContextMenu,
  }
}

export interface ThreeCanvasProps {
  scene: Scene
  t?: number
  width?: number
  editableCamera?: boolean
  selectedId?: string | null
  onSelect?: (id: string | null) => void
  config?: import('./types').WidgetConfig
}

export function ThreeCanvas({ scene, t = 0, width, editableCamera = true, selectedId, onSelect, config }: ThreeCanvasProps): JSX.Element {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const viewRef = useRef<ThreeView | null>(null)
  const resolvedRef = useRef<ResolvedScene | null>(null)
  const renderRef = useRef<() => void>(() => {})

  const { initFromResolved, applyControls, onPointerDown: onOrbitPointerDown, onPointerMove, onPointerUp, onContextMenu } =
    useOrbitControls({
      canvasRef,
      resolvedRef,
      renderRef,
      enabled: editableCamera,
    })

  const renderCurrent = useCallback(() => {
    const view = viewRef.current
    const resolved = resolvedRef.current
    if (!view || !resolved) return
    // Pass selectedId so the view can highlight the node in the viewport
    if (editableCamera) {
      view.render(resolved, selectedId ?? null, applyControls)
    } else {
      view.render(resolved, selectedId ?? null)
    }
  }, [applyControls, editableCamera, selectedId])

  const handleSelectPointerDown = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): void => {
      if (config?.readOnly) return
      if (!onSelect) return
      // Only left-click selects; right/middle are reserved for orbit/pan
      if (e.button !== 0) return
      const canvas = canvasRef.current
      const view = viewRef.current
      if (!canvas || !view) return

      const rect = canvas.getBoundingClientRect()
      const { ndcX, ndcY } = clientToNdc(e.clientX, e.clientY, rect)

      // Similar to SpatialCanvas's `hitTestScene(scene, pt, t)` — the widget
      // owns the hit-test call and the view just supplies the built scene/camera.
      const hitId = hitTest(view.scene, view.camera, ndcX, ndcY)
      onSelect(hitId)
    },
    [config, onSelect],
  )

  const combinedPointerDown = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): void => {
      // Orbit handles right (2) and middle (1) when editable
      if (editableCamera && (e.button === 1 || e.button === 2)) {
        onOrbitPointerDown(e)
        return
      }
      if (e.button === 0) {
        handleSelectPointerDown(e)
      }
    },
    [editableCamera, onOrbitPointerDown, handleSelectPointerDown],
  )

  useEffect(() => {
    renderRef.current = renderCurrent
  }, [renderCurrent])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const view = new ThreeView(canvas)
    view.setSize(scene.canvas.width, scene.canvas.height)
    viewRef.current = view
    return () => {
      view.dispose()
      viewRef.current = null
    }
  }, [scene.canvas.width, scene.canvas.height])

  useEffect(() => {
    const resolved = resolveScene(scene, t)
    resolvedRef.current = resolved
    if (editableCamera) {
      initFromResolved(resolved)
    }
    renderCurrent()
  }, [scene, t, initFromResolved, renderCurrent, editableCamera])

  const displayWidth = width ?? scene.canvas.width
  const displayHeight = displayWidth * (scene.canvas.height / scene.canvas.width)

  // Re-render when selection changes so the highlight updates in the viewport
  useEffect(() => {
    renderCurrent()
  }, [selectedId, renderCurrent])

  const hasSelectionHandler = !!onSelect
  const canvasStyle: React.CSSProperties = {
    width: displayWidth,
    height: displayHeight,
    border: '1px solid #333',
    display: 'block',
    touchAction: 'none',
    overscrollBehavior: 'contain',
    cursor: hasSelectionHandler ? 'pointer' : editableCamera ? 'grab' : 'default',
    outline: 'none',
  }

  return (
    <canvas
      ref={canvasRef}
      width={scene.canvas.width}
      height={scene.canvas.height}
      tabIndex={0}
      style={canvasStyle}
      onPointerDown={hasSelectionHandler || editableCamera ? combinedPointerDown : undefined}
      onPointerMove={editableCamera ? onPointerMove : undefined}
      onPointerUp={editableCamera ? onPointerUp : undefined}
      onPointerCancel={editableCamera ? onPointerUp : undefined}
      onContextMenu={onContextMenu}
    />
  )
}
