/**
 * PropertiesPanel — numeric editing of the selected entity's properties (docs/foundation.md §5).
 * Controlled: values come from `scene`; edits emit typed correction events via `onEdit`.
 */
import type { CorrectionEvent, Entity, EventEnvelope, Scene, Vec3 } from '@scenelab/scene-ir'
import { findEntity } from '@scenelab/scene-ir'
import { humanEnvelope, type WidgetConfig } from './types'

export interface PropertiesPanelProps {
  scene: Scene
  selectedId?: string | null
  onEdit?: (events: EventEnvelope[]) => void
  config?: WidgetConfig
}

const isVec = (v: unknown): v is Vec3 => typeof v === 'object' && v !== null && 'x' in v && 'y' in v

function NumberField(props: { label: string; value: number; onChange: (v: number) => void }): JSX.Element {
  return (
    <label style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontSize: 13, marginBottom: 4 }}>
      <span>{props.label}</span>
      <input
        type="number"
        value={props.value}
        onChange={(e) => {
          const v = Number(e.target.value)
          if (!Number.isNaN(v)) props.onChange(v)
        }}
        style={{ width: 90 }}
      />
    </label>
  )
}

/** No `kind` field any more — an entity's role is whatever it carries (scene-ir types.ts). */
function entityRole(entity: Entity): string {
  const roles: string[] = []
  if (entity.components?.arrangement) roles.push('arrangement')
  if (entity.components?.behavior) roles.push('behavior')
  return roles.length > 0 ? roles.join(' + ') : 'group'
}

export function PropertiesPanel(props: PropertiesPanelProps): JSX.Element {
  const { scene, selectedId, onEdit, config } = props
  const entity = selectedId ? findEntity(scene.root, selectedId) : undefined
  const emit = (event: CorrectionEvent): void => onEdit?.([humanEnvelope(event, config?.sessionId)])

  if (!entity) return <div style={{ fontSize: 13, color: '#888' }}>No selection</div>

  const pos = entity.transform.position.kind === 'const' ? entity.transform.position.value : null
  const scale = entity.transform.scale.kind === 'const' ? entity.transform.scale.value : null
  const rot = entity.transform.rotation.kind === 'const' ? entity.transform.rotation.value : null
  const rawOpacity = entity.components?.opacity
  const opacity = rawOpacity && rawOpacity.kind === 'const' && typeof rawOpacity.value === 'number' ? rawOpacity.value : null

  // One drawable per entity (Design §2.5): find whichever shape component is present.
  const DRAWABLE_TYPES = ['circle', 'rect', 'polygon', 'line', 'path', 'text', 'box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh'] as const
  const drawableType = DRAWABLE_TYPES.find((t) => entity.components?.[t] !== undefined)
  const rawDrawable = drawableType ? entity.components?.[drawableType] : undefined
  const drawable =
    drawableType && rawDrawable && rawDrawable.kind === 'const' && typeof rawDrawable.value === 'object' && rawDrawable.value !== null
      ? { type: drawableType, value: rawDrawable.value as Record<string, unknown> }
      : undefined
  const setDrawableProp = (path: string, from: unknown, to: unknown): void => {
    if (!drawableType) return
    emit({ type: 'component.setProp', target: entity.id, componentType: drawableType, path, from, to })
  }

  const isLocked = entity.locked === true
  const isEnabled = entity.enabled !== false

  return (
    <div style={{ fontSize: 13 }}>
      <div style={{ marginBottom: 8 }}>
        <strong>{entity.word}</strong> <span style={{ color: '#888' }}>#{entity.id}</span>
        {entity.name ? <div style={{ color: '#555' }}>{entity.name}</div> : null}
        <div style={{ color: '#999', fontSize: 11 }}>{entityRole(entity)} · space:{scene.space}{isLocked ? ' · 🔒 locked' : ''}{!isEnabled ? ' · 👁 hidden' : ''}</div>
      </div>

      <fieldset style={{ border: '1px solid #eee', marginBottom: 8, padding: '4px 6px' }}>
        <legend style={{ fontSize: 11, color: '#666' }}>Editor (typical semantics)</legend>
        <label style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontSize: 12, marginBottom: 4 }}>
          <span>🔒 Locked {isLocked ? '(not draggable)' : ''}</span>
          <input type="checkbox" checked={isLocked} onChange={(e) => emit({ type: 'entity.setLocked', target: entity.id, from: isLocked, to: e.target.checked })} />
        </label>
        <label style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontSize: 12 }}>
          <span>👁 Visible {isEnabled ? '' : '(hidden, not rendered)'}</span>
          <input type="checkbox" checked={isEnabled} onChange={(e) => emit({ type: 'entity.setEnabled', target: entity.id, from: isEnabled, to: e.target.checked })} />
        </label>
        <div style={{ fontSize: 10, color: '#999', marginTop: 4 }}>Locked = rendered but not selectable/draggable. Hidden = not rendered + not hit-tested, children hidden too.</div>
      </fieldset>

      {pos && (
        <fieldset style={{ border: '1px solid #eee', marginBottom: 8, padding: '4px 6px' }}>
          <legend style={{ fontSize: 11, color: '#666' }}>Position (Vec3)</legend>
          <NumberField label="X" value={pos.x} onChange={(x) => emit({ type: 'entity.translate', target: entity.id, from: pos, to: { ...pos, x } })} />
          <NumberField label="Y" value={pos.y} onChange={(y) => emit({ type: 'entity.translate', target: entity.id, from: pos, to: { ...pos, y } })} />
          <NumberField label="Z (depth)" value={pos.z} onChange={(z) => emit({ type: 'entity.translate', target: entity.id, from: pos, to: { ...pos, z } })} />
        </fieldset>
      )}

      {scale && (
        <fieldset style={{ border: '1px solid #eee', marginBottom: 8, padding: '4px 6px' }}>
          <legend style={{ fontSize: 11, color: '#666' }}>Scale (Vec3)</legend>
          <NumberField label="X" value={scale.x} onChange={(x) => emit({ type: 'entity.scale', target: entity.id, from: scale, to: { ...scale, x } })} />
          <NumberField label="Y" value={scale.y} onChange={(y) => emit({ type: 'entity.scale', target: entity.id, from: scale, to: { ...scale, y } })} />
          <NumberField label="Z" value={scale.z} onChange={(z) => emit({ type: 'entity.scale', target: entity.id, from: scale, to: { ...scale, z } })} />
        </fieldset>
      )}

      {rot && (
        <fieldset style={{ border: '1px solid #eee', marginBottom: 8, padding: '4px 6px' }}>
          <legend style={{ fontSize: 11, color: '#666' }}>Rotation (axis-angle)</legend>
          <NumberField label="Axis X" value={rot.axis.x} onChange={(x) => emit({ type: 'entity.rotate', target: entity.id, from: rot, to: { ...rot, axis: { ...rot.axis, x } } })} />
          <NumberField label="Axis Y" value={rot.axis.y} onChange={(y) => emit({ type: 'entity.rotate', target: entity.id, from: rot, to: { ...rot, axis: { ...rot.axis, y } } })} />
          <NumberField label="Axis Z" value={rot.axis.z} onChange={(z) => emit({ type: 'entity.rotate', target: entity.id, from: rot, to: { ...rot, axis: { ...rot.axis, z } } })} />
          <NumberField label="Angle (rad)" value={rot.angle} onChange={(angle) => emit({ type: 'entity.rotate', target: entity.id, from: rot, to: { ...rot, angle } })} />
          <div style={{ fontSize: 10, color: '#999', marginTop: 2 }}>2D uses axis Z, angle = θ</div>
        </fieldset>
      )}

      {opacity !== null && (
        <NumberField label="Opacity" value={opacity} onChange={(to) => emit({ type: 'component.upsert', target: entity.id, componentType: 'opacity', from: opacity, to })} />
      )}

      {/* Drawable — one per entity (Design §2.5), edited through component.setProp. */}
      {drawable && (
        <fieldset style={{ border: '1px solid #eee', marginBottom: 8, padding: '4px 6px' }}>
          <legend style={{ fontSize: 11, color: '#666' }}>Drawable · {drawable.type}</legend>
          {'radius' in drawable.value && typeof drawable.value.radius === 'number' && (
            <NumberField
              label="Radius"
              value={drawable.value.radius}
              onChange={(radius) => setDrawableProp('radius', drawable.value.radius, radius)}
            />
          )}
          {'tube' in drawable.value && typeof drawable.value.tube === 'number' && (
            <NumberField
              label="Tube"
              value={drawable.value.tube}
              onChange={(tube) => setDrawableProp('tube', (drawable.value as { tube: number }).tube, tube)}
            />
          )}
          {'height' in drawable.value && typeof drawable.value.height === 'number' && (
            <NumberField
              label="Height"
              value={drawable.value.height}
              onChange={(h) => setDrawableProp('height', drawable.value.height, h)}
            />
          )}
          {isVec(drawable.value.size) && (
            <>
              <NumberField label="W" value={(drawable.value.size as Vec3).x} onChange={(x) => setDrawableProp('size.x', (drawable.value.size as Vec3).x, x)} />
              <NumberField label="H" value={(drawable.value.size as Vec3).y} onChange={(y) => setDrawableProp('size.y', (drawable.value.size as Vec3).y, y)} />
              {typeof (drawable.value.size as Vec3).z === 'number' && (
                <NumberField label="D" value={(drawable.value.size as Vec3).z} onChange={(z) => setDrawableProp('size.z', (drawable.value.size as Vec3).z, z)} />
              )}
            </>
          )}
          {'content' in drawable.value && (
            <div style={{ fontSize: 11, color: '#666', marginBottom: 4 }}>“{String(drawable.value.content)}”</div>
          )}
          {'fontSize' in drawable.value && typeof drawable.value.fontSize === 'number' && (
            <NumberField
              label="Font size"
              value={drawable.value.fontSize}
              onChange={(s) => setDrawableProp('fontSize', drawable.value.fontSize, s)}
            />
          )}
        </fieldset>
      )}
    </div>
  )
}
