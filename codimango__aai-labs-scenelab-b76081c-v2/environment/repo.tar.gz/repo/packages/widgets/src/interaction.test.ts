import { describe, it, expect } from 'vitest'
import { worldDeltaFromPixels } from './interaction'

describe('interaction: worldDeltaFromPixels (§3.10)', () => {
  it('flips Y and scales by pixels-per-unit', () => {
    // drag 100px right, 50px up (−50 in screen Y), at 1 px/unit
    expect(worldDeltaFromPixels(100, -50, 1)).toEqual({ x: 100, y: 50, z: 0 })
  })

  it('scales by ppu', () => {
    expect(worldDeltaFromPixels(200, 0, 2)).toEqual({ x: 100, y: -0, z: 0 })
  })
})
