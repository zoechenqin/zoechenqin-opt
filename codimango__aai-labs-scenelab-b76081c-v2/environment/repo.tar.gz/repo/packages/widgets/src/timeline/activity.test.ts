import { describe, it, expect } from 'vitest'
import { activitySpans, type ActivityEntity } from './activity'

const entity = (properties: Array<Array<number>>): ActivityEntity => ({
  id: 'e',
  word: 'e',
  properties: properties.map((times) => ({ keyframes: times.map((t) => ({ t })) })),
})

describe('activitySpans', () => {
  it('spans a curve from its first keyframe to its last', () => {
    expect(activitySpans(entity([[1, 1.5, 2]]))).toEqual([{ from: 1, to: 2 }])
  })

  it('merges curves that run together, so one move is one bar', () => {
    // A move animating position and scale at once: two curves, slightly different times.
    expect(activitySpans(entity([[0, 0.2, 0.52, 0.72], [0, 0.1, 0.62, 0.72]]))).toEqual([{ from: 0, to: 0.72 }])
  })

  it('keeps separate moves separate', () => {
    expect(activitySpans(entity([[0, 1], [5, 6]]))).toEqual([
      { from: 0, to: 1 },
      { from: 5, to: 6 },
    ])
  })

  it('merges spans that touch end to start', () => {
    expect(activitySpans(entity([[0, 1], [1, 2]]))).toEqual([{ from: 0, to: 2 }])
  })

  it('merges out-of-order curves', () => {
    expect(activitySpans(entity([[5, 6], [0, 1], [0.5, 5.5]]))).toEqual([{ from: 0, to: 6 }])
  })

  it('ignores curves with no keyframes', () => {
    expect(activitySpans(entity([[], [2, 3]]))).toEqual([{ from: 2, to: 3 }])
  })

  it('has no spans for an entity with nothing animated', () => {
    expect(activitySpans(entity([]))).toEqual([])
  })
})
