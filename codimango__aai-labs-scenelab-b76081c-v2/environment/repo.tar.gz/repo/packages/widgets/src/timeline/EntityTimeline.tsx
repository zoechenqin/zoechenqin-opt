/**
 * EntityTimeline — per-object lane with optional collapsible property tracks.
 * Displays narrow-line markers aligned with the main scene timeline.
 * Property track rows are delegated to PropertyTimeline.tsx.
 * Now threads onEdit/config/onPause to allow keyframe drag handling.
 */
import type { EventEnvelope } from '@scenelab/scene-ir'
import type { SceneTimeline as SceneTimelineData } from '@scenelab/scene-ir'
import { PropertyTimeline } from './PropertyTimeline'
import type { WidgetConfig } from '../types'
// @ts-ignore - CSS side-effect import handled by Vite
import './styles.css'

type EntityData = SceneTimelineData['entities'][number]

export interface EntityTimelineProps {
  entity: EntityData
  t: number
  duration: number
  isPropsOpen: boolean
  onToggle: () => void
  onEdit?: (events: EventEnvelope[]) => void
  config?: WidgetConfig
  onPause?: () => void
}

export function EntityTimeline({
  entity,
  t,
  duration,
  isPropsOpen,
  onToggle,
  onEdit,
  config,
  onPause,
}: EntityTimelineProps): JSX.Element {
  const pct = (time: number): number => (duration > 0 ? (time / duration) * 100 : 0)
  const label = entity.name ?? entity.word
  const hasProps = entity.properties.length > 0

  return (
    <div className="entity-timeline-lane">
      <div className="entity-timeline-header-row">
        <div className="entity-timeline-label-area" style={{ paddingLeft: entity.depth * 12 }}>
          {hasProps && (
            <button
              className="entity-timeline-toggle-button"
              onClick={onToggle}
              aria-label={isPropsOpen ? 'Collapse properties' : 'Expand properties'}
              aria-expanded={isPropsOpen}
            >
              {isPropsOpen ? '▼' : '▶'}
            </button>
          )}
          <div
            className="entity-timeline-label"
            title={`${entity.word}${entity.name ? ` — ${entity.name}` : ''} (${entity.id}) — ${entity.times.length} keyframes · ${entity.properties.length} tracks`}
          >
            {label}
          </div>
        </div>
        <div className="entity-timeline-track">
          {entity.times.map((kt, i) => (
            <span
              key={i}
              className="entity-timeline-keyframe-marker"
              title={`${kt.toFixed(2)}s`}
              style={{ left: `${pct(kt)}%` }}
            />
          ))}
          <span className="entity-timeline-playhead" style={{ left: `${pct(t)}%` }} />
        </div>
        <span className="entity-timeline-track-count" title={`${entity.properties.length} property tracks`}>
          {hasProps ? `${entity.properties.length} track${entity.properties.length > 1 ? 's' : ''}` : ''}
        </span>
      </div>

      {isPropsOpen && hasProps && (
        <div className="entity-property-tracks-list">
          {entity.properties.map((prop) => (
            <PropertyTimeline
              key={`${entity.id}-${prop.label}`}
              property={prop}
              entityId={entity.id}
              depth={entity.depth}
              t={t}
              duration={duration}
              onEdit={onEdit}
              config={config}
              onPause={onPause}
            />
          ))}
        </div>
      )}
    </div>
  )
}
