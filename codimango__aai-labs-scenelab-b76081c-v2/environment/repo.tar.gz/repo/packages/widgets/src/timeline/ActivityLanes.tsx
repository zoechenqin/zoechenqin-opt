/**
 * ActivityLanes — one row per moving entity, showing WHEN it moves rather than where its
 * keyframes fall.
 *
 * This replaces the global keyframe ticks, which counted the encoding rather than the animation:
 * a scene whose motion is stamped from a template (a `forEach` over a script) reports hundreds of
 * instants that say nothing about what the viewer sees, and at that density the ticks render as a
 * solid bar. A span per active interval survives density — a disk that moves sixty-four times
 * reads as sixty-four marks in a rhythm, which is the shape of the recursion that produced it.
 *
 * An interval is one curve's first-to-last keyframe. Overlapping intervals on the same entity are
 * merged, so a position and a scale curve running together count as one span, not two.
 */
// @ts-ignore - CSS side-effect import handled by Vite
import './styles.css'

import { activitySpans, type ActivityEntity } from './activity'

export type { ActivityEntity }

export interface ActivityLanesProps {
  entities: ActivityEntity[]
  duration: number
  t: number
  /** Rows beyond this collapse into a "+N more" line; the tall scenes are the ones that need it. */
  maxRows?: number
}

export function ActivityLanes({ entities, duration, t, maxRows = 12 }: ActivityLanesProps): JSX.Element | null {
  if (entities.length === 0 || duration <= 0) return null

  const pct = (time: number): number => (time / duration) * 100
  const shown = entities.slice(0, maxRows)
  const hidden = entities.length - shown.length

  return (
    <div className="scene-activity">
      {shown.map((e) => {
        const spans = activitySpans(e)
        const active = spans.some((s) => t >= s.from && t <= s.to)
        return (
          <div className="scene-activity-row" key={e.id}>
            <span className={`scene-activity-label ${active ? 'scene-activity-label--active' : ''}`} title={e.id}>
              {e.name ?? e.word ?? e.id}
            </span>
            <div className="scene-activity-track">
              {spans.map((s, i) => (
                <span
                  key={i}
                  className="scene-activity-span"
                  title={`${s.from.toFixed(2)}s – ${s.to.toFixed(2)}s`}
                  style={{
                    left: `${pct(s.from)}%`,
                    // Sub-pixel spans vanish; floor the width so a brief move stays visible.
                    width: `max(2px, ${pct(s.to - s.from)}%)`,
                  }}
                />
              ))}
              <span className="scene-activity-playhead" style={{ left: `${pct(Math.min(t, duration))}%` }} />
            </div>
            <span className="scene-activity-spacer" />
          </div>
        )
      })}
      {hidden > 0 && <div className="scene-activity-more">+{hidden} more</div>}
    </div>
  )
}
