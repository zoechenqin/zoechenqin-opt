/**
 * Timeline — a scrubbable, playable time control for a Scene (docs/foundation.md §5).
 * Controlled on `t` (the host owns the scrub time); play/pause is internal.
 * Top-level orchestrator: keeps collapsability state, delegates rendering to
 * SceneTimeline (main scrubber) and EntityTimeline (per-object lanes).
 * Now also threads onEdit/config for keyframe drag handling.
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import type { EventEnvelope, Scene } from '@scenelab/scene-ir'
import { sceneTimeline } from '@scenelab/scene-ir'
import { SceneTimeline } from './SceneTimeline'
import { ActivityLanes } from './ActivityLanes'
import { EntityTimeline } from './EntityTimeline'
import type { WidgetConfig } from '../types'
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - CSS side-effect import handled by Vite
import './styles.css'

export interface TimelineProps {
  scene: Scene
  /** Current scrub time in seconds (controlled). */
  t: number
  onChange: (t: number) => void
  /** Display width in px (matches the canvas above it). */
  width?: number
  /** Emits correction events (e.g. keyframe.move) from property tracks. */
  onEdit?: (events: EventEnvelope[]) => void
  /** Optional config passed to child tracks for envelope creation. */
  config?: WidgetConfig
}

export function Timeline({ scene, t, onChange, width = 640, onEdit, config }: TimelineProps): JSX.Element {
  const { duration, fps, entities } = useMemo(() => sceneTimeline(scene), [scene])
  const [playing, setPlaying] = useState(false)
  const [tracksOpen, setTracksOpen] = useState(false)
  const [openPropertyIds, setOpenPropertyIds] = useState<Set<string>>(() => new Set<string>())
  const tRef = useRef(t)
  tRef.current = t

  const togglePropertyTracks = (id: string): void => {
    setOpenPropertyIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  // Play loop: advance t by wall-clock; loop back to 0 at the end.
  useEffect(() => {
    if (!playing || duration <= 0) return
    let raf = 0
    let last = performance.now()
    const tick = (now: number): void => {
      const dt = (now - last) / 1000
      last = now
      const next = tRef.current + dt
      onChange(next >= duration ? 0 : next)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [playing, duration, onChange])

  const isStatic = duration <= 0

  return (
    <div className="timeline-root" style={{ width }}>
      <SceneTimeline
        duration={duration}
        fps={fps}
        canvas={scene.canvas}
        animatedCount={entities.length}
        t={t}
        isStatic={isStatic}
        playing={playing}
        onChange={onChange}
        onTogglePlaying={() => setPlaying((p) => !p)}
        onRestart={() => {
          setPlaying(false)
          onChange(0)
        }}
        onPause={() => setPlaying(false)}
      />

      {/* When each object moves — replaces the global keyframe ticks. */}
      <ActivityLanes entities={entities} duration={duration} t={t} />

      {entities.length > 0 && (
        <div className="timeline-object-tracks-section">
          <button
            className="timeline-object-tracks-toggle"
            onClick={() => setTracksOpen((o) => !o)}
            aria-label={tracksOpen ? 'Collapse object tracks' : 'Expand object tracks'}
          >
            {tracksOpen ? '▼' : '▶'} {entities.length} {entities.length === 1 ? 'Object' : 'Objects'}
          </button>

          {tracksOpen && (
            <div className="timeline-object-tracks-list">
              {entities.map((n) => (
                <EntityTimeline
                  key={n.id}
                  entity={n}
                  t={t}
                  duration={duration}
                  isPropsOpen={openPropertyIds.has(n.id)}
                  onToggle={() => togglePropertyTracks(n.id)}
                  onEdit={onEdit}
                  config={config}
                  onPause={() => setPlaying(false)}
                />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
