/**
 * SceneTimeline — main scrubbable timeline (playback controls + range input).
 * Extracted from Timeline.tsx. Uses callbacks for playhead changes.
 *
 * The readout describes the video you would export — size, rate, length, frames, and how many
 * things move. It used to report `keyframeTimes.length` as "keyframes", which was neither: that
 * array is the deduplicated set of sample instants (what the manim adapter resolves a pose at),
 * so it counted the encoding and undercounted the keyframes. Frame count is the number that
 * predicts something the user feels — export time and file size.
 */
// @ts-ignore - CSS side-effect import handled by Vite
import './styles.css'

export interface SceneTimelineProps {
  duration: number
  fps: number
  /** Canvas size, for the export readout. */
  canvas: { width: number; height: number }
  /** How many entities have any motion — `sceneTimeline().entities.length`. */
  animatedCount: number
  t: number
  isStatic: boolean
  playing: boolean
  onChange: (t: number) => void
  onTogglePlaying: () => void
  onRestart: () => void
  onPause: () => void
}

/** 93 -> "1:33"; sub-minute stays in seconds so short scenes do not read as "0:04". */
function clock(seconds: number): string {
  if (seconds < 60) return `${seconds.toFixed(seconds < 10 ? 2 : 1)}s`
  const m = Math.floor(seconds / 60)
  const s = Math.round(seconds - m * 60)
  return `${m}:${String(s).padStart(2, '0')}`
}

export function SceneTimeline({
  duration,
  fps,
  canvas,
  animatedCount,
  t,
  isStatic,
  playing,
  onChange,
  onTogglePlaying,
  onRestart,
  onPause,
}: SceneTimelineProps): JSX.Element {
  const seekFromTrackClick = (e: React.MouseEvent<HTMLDivElement>): void => {
    if (isStatic) return
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = rect.width > 0 ? (e.clientX - rect.left) / rect.width : 0
    const next = Math.min(duration, Math.max(0, ratio * duration))
    onPause()
    onChange(next)
  }

  return (
    <>
      <div className="scene-timeline-header">
        <div className="scene-playback-controls">
          <button
            className="scene-play-button"
            onClick={onTogglePlaying}
            disabled={isStatic}
            aria-label={playing ? 'Pause' : 'Play'}
          >
            {playing ? '❚❚' : '▶'}
          </button>
          <button
            className="scene-restart-button"
            onClick={onRestart}
            disabled={isStatic}
            aria-label="Restart"
          >
            ↺
          </button>
        </div>
        <div
          className={`scene-scrubber-track ${isStatic ? 'scene-scrubber-track--static' : 'scene-scrubber-track--interactive'}`}
          onClick={isStatic ? undefined : seekFromTrackClick}
        >
          <input
            className="scene-range-input"
            type="range"
            min={0}
            max={duration || 0}
            step={0.001}
            value={t}
            disabled={isStatic}
            onClick={(e) => e.stopPropagation()}
            onChange={(e) => {
              onPause()
              onChange(parseFloat(e.target.value))
            }}
          />
        </div>
        <span className="scene-time-readout">
          {t.toFixed(2)} / {duration.toFixed(2)}s
        </span>
      </div>
      <div className="scene-fps-info">
        {isStatic
          ? `${canvas.width}×${canvas.height} · static scene (nothing animates)`
          : `${canvas.width}×${canvas.height} · ${fps} fps · ${clock(duration)} · ${Math.round(duration * fps)} frames · ${animatedCount} animated`}
      </div>
    </>
  )
}
