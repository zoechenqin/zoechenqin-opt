/**
 * PropertyTimeline — per-property lane (e.g. Position, Rotation, Scale, Opacity).
 * Displays diamond markers for that property's keyframes and a playhead.
 * Now supports click-and-drag of keyframes: dragging emits `keyframe.move`
 * via onEdit (wrapped in humanEnvelope), with live visual preview while dragging.
 * Persists after drop by keeping preview until parent scene updates.
 */
import { useEffect, useRef, useState } from 'react'
import type { CorrectionEvent, EventEnvelope } from '@scenelab/scene-ir'
import type { SceneTimeline as SceneTimelineData } from '@scenelab/scene-ir'
import { humanEnvelope, type WidgetConfig } from '../types'
// @ts-ignore - CSS side-effect import handled by Vite
import './styles.css'

type PropertyData = SceneTimelineData['entities'][number]['properties'][number]

export interface PropertyTimelineProps {
  property: PropertyData
  entityId: string
  depth: number
  t: number
  duration: number
  onEdit?: (events: EventEnvelope[]) => void
  config?: WidgetConfig
  onPause?: () => void
}

interface DragState {
  index: number
  from: number
  current: number
  committed: boolean // true after pointer-up, waiting for parent to confirm new keyframes
}

export function PropertyTimeline({
  property,
  entityId,
  depth,
  t,
  duration,
  onEdit,
  config,
  onPause,
}: PropertyTimelineProps): JSX.Element {
  const pct = (time: number): number => (duration > 0 ? (time / duration) * 100 : 0)
  const trackRef = useRef<HTMLDivElement | null>(null)
  const [drag, setDrag] = useState<DragState | null>(null)

  const timeFromClientX = (clientX: number): number => {
    const el = trackRef.current
    if (!el) return 0
    const rect = el.getBoundingClientRect()
    if (rect.width <= 0) return 0
    const ratio = (clientX - rect.left) / rect.width
    return Math.min(duration, Math.max(0, ratio * duration))
  }

  // Once parent scene updates to include the new time, clear committed drag to avoid stale preview.
  useEffect(() => {
    if (!drag?.committed) return
    const hasNewTime = property.keyframes.some((kf) => Math.abs((kf.t as number) - drag.current) < 0.001)
    if (hasNewTime) {
      setDrag(null)
    } else {
      // Fallback: if parent didn't update within 500ms (e.g. onEdit not wired), clear anyway after delay
      // to avoid stuck dragging state.
      const timer = setTimeout(() => setDrag(null), 600)
      return () => clearTimeout(timer)
    }
  }, [property.keyframes, drag])

  const handlePointerDown = (e: React.PointerEvent<HTMLSpanElement>, idx: number, kfT: number): void => {
    if (duration <= 0 || config?.readOnly) return
    e.preventDefault()
    e.stopPropagation()
    onPause?.()
    const target = e.currentTarget as HTMLElement
    try {
      target.setPointerCapture(e.pointerId)
    } catch {
      // ignore if pointer capture not supported
    }
    setDrag({ index: idx, from: kfT, current: kfT, committed: false })
  }

  const handlePointerMove = (e: React.PointerEvent<HTMLSpanElement>): void => {
    if (!drag || drag.committed) return
    e.preventDefault()
    const next = timeFromClientX(e.clientX)
    setDrag((prev) => (prev ? { ...prev, current: next } : prev))
  }

  const handlePointerUp = (e: React.PointerEvent<HTMLSpanElement>): void => {
    if (!drag || drag.committed) return
    const target = e.currentTarget as HTMLElement
    try {
      target.releasePointerCapture(e.pointerId)
    } catch {
      // ignore
    }
    const { index, from, current } = drag
    if (Math.abs(current - from) > 1e-6) {
      // The lane draws on the scene axis, but a curve's keyframes are stored local to the leaf
      // (§4.2). Convert back here, at the edit boundary, so the recorded correction stays valid
      // if the surrounding tree is later restructured.
      const event: CorrectionEvent = {
        type: 'keyframe.move',
        target: property.curveId,
        index,
        from: from - property.start,
        to: current - property.start,
      }
      onEdit?.([humanEnvelope(event, config?.sessionId)])
      // Keep preview at new position until parent confirms update — prevents snap-back flicker
      setDrag({ index, from, current, committed: true })
    } else {
      setDrag(null)
    }
  }

  const handlePointerCancel = (e: React.PointerEvent<HTMLSpanElement>): void => {
    const target = e.currentTarget as HTMLElement
    try {
      target.releasePointerCapture(e.pointerId)
    } catch {
      // ignore
    }
    setDrag(null)
  }

  return (
    <div key={`${entityId}-${property.label}`} className="property-track-row">
      <div
        className="property-track-label"
        style={{ paddingLeft: (depth + 1) * 12 }}
        title={`${property.label} — ${property.keyframes.length} keyframes`}
      >
        {property.label}
      </div>
      <div
        ref={trackRef}
        className="property-track-timeline"
        title={`${property.label}: ${property.keyframes.length} keyframes`}
      >
        {property.keyframes.map((kf, i) => {
          const isDragging = drag?.index === i
          const displayT = isDragging ? drag.current : (kf.t as number)
          const titleT = isDragging ? drag.current : (kf.t as number)
          return (
            <span
              key={`${entityId}-${property.label}-${i}-${kf.t}`}
              className={`property-track-keyframe-marker${isDragging ? ' property-track-keyframe-marker--dragging' : ''}`}
              title={`${property.label} @ ${titleT.toFixed(2)}s`}
              style={{ left: `${pct(displayT)}%` }}
              onPointerDown={(e) => handlePointerDown(e, i, kf.t as number)}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerCancel={handlePointerCancel}
            />
          )
        })}
        <span className="property-track-playhead" style={{ left: `${pct(t)}%` }} />
      </div>
      <span className="property-track-count">{property.keyframes.length} kf</span>
    </div>
  )
}
