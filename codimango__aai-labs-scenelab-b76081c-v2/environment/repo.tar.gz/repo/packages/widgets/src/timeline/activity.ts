/**
 * Activity spans — WHEN an entity moves, derived from its curve tracks.
 *
 * Kept apart from ActivityLanes.tsx so the derivation is testable without the component's CSS
 * side-effect import.
 */

/** Structurally what `sceneTimeline().entities` gives us. */
export interface ActivityEntity {
  id: string
  word: string
  name?: string
  properties: Array<{ keyframes: Array<{ t: number }> }>
}

export interface Span {
  from: number
  to: number
}

/**
 * One span per curve, first keyframe to last, merged where they overlap or touch.
 *
 * Merging matters because a single move is usually several curves at once — position and scale
 * animating together should read as one span, not two stacked bars.
 */
export function activitySpans(entity: ActivityEntity): Span[] {
  const raw: Span[] = []
  for (const p of entity.properties) {
    if (p.keyframes.length === 0) continue
    const times = p.keyframes.map((k) => k.t)
    raw.push({ from: Math.min(...times), to: Math.max(...times) })
  }
  raw.sort((a, b) => a.from - b.from)

  const merged: Span[] = []
  for (const s of raw) {
    const last = merged[merged.length - 1]
    if (last && s.from <= last.to) last.to = Math.max(last.to, s.to)
    else merged.push({ ...s })
  }
  return merged
}
