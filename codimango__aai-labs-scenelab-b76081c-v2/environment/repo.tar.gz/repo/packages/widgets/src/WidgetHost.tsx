/**
 * WidgetHost — renders dynamic widgets for end-user web interfaces.
 * Floating panels are draggable windows rendered in the same React tree
 * to keep playback time synchronized.
 */
import { useCallback, useRef, useState } from 'react'
import type { EventEnvelope, Scene } from '@scenelab/scene-ir'
import { PropertiesPanel } from './PropertiesPanel'
import { SpatialCanvas } from './SpatialCanvas'
import { ThreeCanvas } from './ThreeCanvas'
import { Timeline } from './timeline/Timeline'
import type { UIPanel } from './types'

type WidgetType = UIPanel['type']

export interface WidgetHostProps {
  layout: { panels: UIPanel[] } | null
  scene: Scene
  t?: number
  selectedId?: string | null
  onSelect?: (id: string | null) => void
  onEdit?: (events: EventEnvelope[]) => void
  onRemovePanel?: (id: string) => void
  width?: number
}

function SceneInfoWidget({ scene }: { scene: Scene }) {
  return (
    <div style={{ fontSize: 11, background: '#232326', padding: 8, borderRadius: 4 }}>
      <div>id: {scene.id}</div>
      <div>space: {scene.space}</div>
      <div>camera: {scene.camera.projection.type}</div>
      <div>canvas: {scene.canvas.width}x{scene.canvas.height}</div>
      <div>primitives: {scene.root.children.length}</div>
    </div>
  )
}

function DraggableFloating({
  panel,
  children,
  onClose,
  initialX,
  initialY,
}: {
  panel: UIPanel
  children: React.ReactNode
  onClose?: (id: string) => void
  initialX: number
  initialY: number
}): JSX.Element {
  const [pos, setPos] = useState({ x: initialX, y: initialY })
  const [z, setZ] = useState(1)
  const dragRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null)

  const onPointerDown = useCallback(
    (e: React.PointerEvent) => {
      ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
      dragRef.current = { startX: e.clientX, startY: e.clientY, origX: pos.x, origY: pos.y }
      setZ((prev) => prev + 1000)
    },
    [pos.x, pos.y],
  )

  const onPointerMove = useCallback((e: React.PointerEvent) => {
    const d = dragRef.current
    if (!d) return
    setPos({ x: d.origX + (e.clientX - d.startX), y: d.origY + (e.clientY - d.startY) })
  }, [])

  const onPointerUp = useCallback((e: React.PointerEvent) => {
    dragRef.current = null
    try { (e.target as HTMLElement).releasePointerCapture(e.pointerId) } catch {}
  }, [])

  const popOutExternal = useCallback(() => {
    try {
      const url = `${window.location.origin}${window.location.pathname}?view=${panel.type}`
      window.open(url, `scenelab-${panel.type}-${panel.id.slice(0, 8)}`, 'width=900,height=700')
      // Remove the inline floating after popping out, if handler provided
      onClose?.(panel.id)
    } catch {}
  }, [panel.id, panel.type, onClose])

  return (
    <div
      style={{
        position: 'fixed',
        left: pos.x,
        top: pos.y,
        zIndex: 50 + z,
        minWidth: 320,
        maxWidth: 700,
        background: '#1e1e20',
        border: '1px solid #444',
        borderRadius: 8,
        boxShadow: '0 8px 32px rgba(0,0,0,0.6)',
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
      }}
      onPointerDown={() => setZ((p) => p + 1)}
    >
      <div
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '6px 8px',
          background: '#2a2a2e',
          cursor: 'grab',
          userSelect: 'none',
          borderBottom: '1px solid #333',
        }}
      >
        <span style={{ fontSize: 11, fontWeight: 600, color: '#ccc', textTransform: 'uppercase' }}>
          {panel.type} • {panel.id.slice(0, 8)}
        </span>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <button
            onClick={(e) => { e.stopPropagation(); popOutExternal() }}
            title="Pop out to separate window — drag away from main window, live sync via BroadcastChannel"
            style={{ background: '#2d4a6a', border: '1px solid #3a5a7a', color: '#8ec7ff', cursor: 'pointer', borderRadius: 3, padding: '2px 6px', fontSize: 10 }}
          >
            ↗ Pop-out
          </button>
          <span style={{ fontSize: 10, color: '#666' }}>drag to move</span>
          {onClose && (
            <button
              onClick={() => onClose(panel.id)}
              style={{ background: '#333', border: 'none', color: '#ff8888', cursor: 'pointer', borderRadius: 3, padding: '2px 6px', fontSize: 11 }}
            >
              ✕
            </button>
          )}
        </div>
      </div>
      <div style={{ padding: 8, overflow: 'auto', maxHeight: 600, background: '#1a1a1e' }}>{children}</div>
    </div>
  )
}

export function WidgetHost({ layout, scene, t = 0, selectedId, onSelect, onEdit, onRemovePanel, width = 320 }: WidgetHostProps): JSX.Element {
  if (!layout) return <div style={{ fontSize: 12, color: '#666' }}>No UI layout (standalone)</div>

  const renderPanel = (panel: UIPanel) => {
    const type = panel.type as WidgetType
    switch (type) {
      case 'project':
        return <div style={{ fontSize: 11, color: '#888' }}>Project — {JSON.stringify(panel.props)}</div>
      case 'scene':
        return <SceneInfoWidget scene={scene} />
      case 'outliner':
        return (
          <div style={{ fontSize: 11 }}>
            {scene.root.children.map((c: any) => (
              <div key={c.id} style={{ padding: '2px 0' }}>
                <button onClick={() => onSelect?.(c.id)} style={{ background: 'none', border: 'none', color: selectedId === c.id ? '#8ec7ff' : '#ccc', cursor: 'pointer' }}>
                  {c.word} ({c.id})
                </button>
              </div>
            ))}
          </div>
        )
      case 'scene-view':
        return (
          <div>
            {scene.space === '3d' || scene.camera.projection.type === 'perspective' ? (
              <ThreeCanvas scene={scene} t={t} width={width} editableCamera={true} selectedId={selectedId} onSelect={onSelect} config={{ sessionId: 'demo' }} />
            ) : (
              <SpatialCanvas scene={scene} selectedId={selectedId} onSelect={onSelect} onEdit={onEdit} width={width} t={t} config={{ sessionId: 'demo' }} />
            )}
          </div>
        )
      case 'preview':
        return (
          <div>
            <ThreeCanvas scene={scene} t={t} width={width} editableCamera={false} selectedId={selectedId} onSelect={onSelect} config={{ sessionId: 'demo' }} />
            <div style={{ fontSize: 10, color: '#666', marginTop: 4 }}>Preview — scene camera locked (final output)</div>
          </div>
        )
      case 'properties':
        return <PropertiesPanel scene={scene} selectedId={selectedId ?? null} onEdit={onEdit} config={{ sessionId: 'demo' }} />
      case 'timeline':
        return <Timeline scene={scene} t={t} onChange={() => {}} width={width} onEdit={onEdit} config={{ sessionId: 'demo' }} />
      case 'trace':
        return <div style={{ fontSize: 11, color: '#777' }}>Trace — {scene.id}</div>
      default:
        return <div style={{ fontSize: 11, color: '#666' }}>Unknown: {String(type)}</div>
    }
  }

  const left = layout.panels.filter((p) => p.position === 'left')
  const center = layout.panels.filter((p) => p.position === 'center')
  const right = layout.panels.filter((p) => p.position === 'right')
  const floating = layout.panels.filter((p) => !p.position || p.position === 'floating')

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        {left.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 10, color: '#888', textTransform: 'uppercase' }}>Left</div>
            {left.map((p) => (
              <div key={p.id} style={{ border: '1px solid #333', borderRadius: 6, padding: 8, minWidth: width }}>
                <div style={{ fontSize: 10, color: '#666', marginBottom: 4 }}>{p.type} ({p.id})</div>
                {renderPanel(p)}
              </div>
            ))}
          </div>
        )}
        {center.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
            <div style={{ fontSize: 10, color: '#888', textTransform: 'uppercase' }}>Center</div>
            {center.map((p) => (
              <div key={p.id} style={{ border: '1px solid #333', borderRadius: 6, padding: 8 }}>
                <div style={{ fontSize: 10, color: '#666', marginBottom: 4 }}>{p.type} ({p.id})</div>
                {renderPanel(p)}
              </div>
            ))}
          </div>
        )}
        {right.length > 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ fontSize: 10, color: '#888', textTransform: 'uppercase' }}>Right</div>
            {right.map((p) => (
              <div key={p.id} style={{ border: '1px solid #333', borderRadius: 6, padding: 8, minWidth: width }}>
                <div style={{ fontSize: 10, color: '#666', marginBottom: 4 }}>{p.type} ({p.id})</div>
                {renderPanel(p)}
              </div>
            ))}
          </div>
        )}
      </div>

      {floating.length > 0 && (
        <>
          {floating.map((p, idx) => (
            <DraggableFloating key={p.id} panel={p} onClose={onRemovePanel} initialX={100 + idx * 40} initialY={100 + idx * 40}>
              {renderPanel(p)}
            </DraggableFloating>
          ))}
        </>
      )}
    </div>
  )
}
