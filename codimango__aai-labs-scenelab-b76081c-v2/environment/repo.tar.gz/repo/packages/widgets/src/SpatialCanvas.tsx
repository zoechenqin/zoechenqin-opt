/**
 * SpatialCanvas — the direct-manipulation widget (docs/foundation.md §5). Controlled
 * component: the host owns `scene`; drags emit typed correction events via `onEdit`.
 * Live drag feedback uses `applyEvent` on a preview copy (no local scene ownership);
 * one consolidated event is emitted on pointer-up.
 *
 * 2D view controls (pan: space+drag, zoom: wheel anchored at cursor) pure logic lives
 * in @scenelab/camera-controls; React wrapper lives here in this widget so
 * camera-controls stays framework-agnostic (no React dependency).
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import type { CorrectionEvent, EventEnvelope, Scene, Vec3 } from '@scenelab/scene-ir'
import { applyEvent, findEntity, resolveScene } from '@scenelab/scene-ir'
import { draw, hitTestScene, pixelsPerUnit, project } from '@scenelab/canvas-preview'
import { worldDeltaFromPixels } from './interaction'
import type { Px, Viewport2DState, Viewport2DDragState } from '@scenelab/camera-controls'
import {
  createInitialViewport2DState,
  createViewport2DDragState,
  updateViewportZoomFromDelta,
  panViewport,
  canvasPxFromClient,
  toBasePx as toBasePxPure,
} from '@scenelab/camera-controls'
import { humanEnvelope, type WidgetConfig } from './types'

// ---------------------------------------------------------------------------
// React controls for SpatialCanvas — lives in this widget, wraps pure camera-controls
// ---------------------------------------------------------------------------

interface UseViewport2DControlsOptions {
  canvasRef: React.RefObject<HTMLCanvasElement>
  minZoom?: number
  maxZoom?: number
  initial?: Viewport2DState
}

function useViewport2DControls(opts: UseViewport2DControlsOptions) {
  const { canvasRef, minZoom = 0.1, maxZoom = 40, initial } = opts

  const [viewport, setViewport] = useState<Viewport2DState>(() => initial ?? createInitialViewport2DState())
  const viewportRef = useRef<Viewport2DState>(viewport)
  useEffect(() => {
    viewportRef.current = viewport
  }, [viewport])

  const dragRef = useRef<Viewport2DDragState | null>(null)
  const [isPanning, setIsPanning] = useState(false)
  const [isSpacePressed, setIsSpacePressed] = useState(false)
  const spaceRef = useRef(false)

  // Smooth continuous WASD for 2D
  const keysRef = useRef<Set<string>>(new Set())
  const rafRef = useRef<number | null>(null)
  const lastTimeRef = useRef<number>(performance.now())

  const tick = useCallback(() => {
    const now = performance.now()
    const dt = Math.min(0.1, (now - lastTimeRef.current) / 1000)
    lastTimeRef.current = now
    if (keysRef.current.size === 0) {
      rafRef.current = null
      return
    }
    const speed = (200 / viewportRef.current.zoom) * dt // px/sec scaled by zoom
    let dx = 0
    let dy = 0
    if (keysRef.current.has('w')) dy += speed
    if (keysRef.current.has('s')) dy -= speed
    if (keysRef.current.has('a')) dx += speed
    if (keysRef.current.has('d')) dx -= speed
    if (dx !== 0 || dy !== 0) {
      setViewport((prev) => {
        const next = { pan: { x: prev.pan.x + dx, y: prev.pan.y + dy }, zoom: prev.zoom }
        viewportRef.current = next
        return next
      })
    }
    rafRef.current = requestAnimationFrame(tick)
  }, [])

  const ensureTicking = useCallback(() => {
    if (rafRef.current !== null) return
    lastTimeRef.current = performance.now()
    rafRef.current = requestAnimationFrame(tick)
  }, [tick])

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent): void => {
      if (e.code === 'Space') {
        spaceRef.current = true
        setIsSpacePressed(true)
      }
      const k = e.key.toLowerCase()
      if (['w', 'a', 's', 'd'].includes(k)) {
        const target = e.target as HTMLElement | null
        if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable)) return
        if (!keysRef.current.has(k)) {
          keysRef.current.add(k)
          ensureTicking()
        }
      }
    }
    const onKeyUp = (e: KeyboardEvent): void => {
      if (e.code === 'Space') {
        spaceRef.current = false
        setIsSpacePressed(false)
      }
      const k = e.key.toLowerCase()
      keysRef.current.delete(k)
    }
    const onBlur = (): void => {
      spaceRef.current = false
      setIsSpacePressed(false)
      keysRef.current.clear()
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current)
        rafRef.current = null
      }
    }
    window.addEventListener('keydown', onKeyDown)
    window.addEventListener('keyup', onKeyUp)
    window.addEventListener('blur', onBlur)
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      window.removeEventListener('keyup', onKeyUp)
      window.removeEventListener('blur', onBlur)
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current)
        rafRef.current = null
      }
      keysRef.current.clear()
    }
  }, [ensureTicking])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const onWheelNative = (e: WheelEvent): void => {
      e.preventDefault()
      e.stopPropagation()
      const cPx = canvasPxFromClient(canvas, e.clientX, e.clientY)
      setViewport((prev: Viewport2DState) => {
        const next = { pan: { ...prev.pan }, zoom: prev.zoom }
        updateViewportZoomFromDelta(next, cPx, e.deltaY, minZoom, maxZoom)
        viewportRef.current = next
        return next
      })
    }

    canvas.addEventListener('wheel', onWheelNative, { passive: false })
    return () => canvas.removeEventListener('wheel', onWheelNative)
  }, [canvasRef, minZoom, maxZoom])

  const toBasePx = useCallback(
    (canvasPx: Px): Px => toBasePxPure(canvasPx, viewportRef.current),
    [],
  )

  const clientToBasePx = useCallback(
    (clientX: number, clientY: number): Px | null => {
      const canvas = canvasRef.current
      if (!canvas) return null
      const cPx = canvasPxFromClient(canvas, clientX, clientY)
      return toBasePxPure(cPx, viewportRef.current)
    },
    [canvasRef],
  )

  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): boolean => {
      if (!spaceRef.current) return false
      const canvas = canvasRef.current
      if (!canvas) return false
      const cPx = canvasPxFromClient(canvas, e.clientX, e.clientY)
      dragRef.current = createViewport2DDragState(viewportRef.current, cPx)
      setIsPanning(true)
      return true
    },
    [canvasRef],
  )

  const onPointerMove = useCallback(
    (e: React.PointerEvent<HTMLCanvasElement>): boolean => {
      const drag = dragRef.current
      if (!drag) return false
      const canvas = canvasRef.current
      if (!canvas) return false
      const cPx = canvasPxFromClient(canvas, e.clientX, e.clientY)
      setViewport((prev: Viewport2DState) => {
        const next = panViewport(prev, drag, cPx)
        viewportRef.current = next
        return next
      })
      return true
    },
    [canvasRef],
  )

  const onPointerUp = useCallback(
    (_e: React.PointerEvent<HTMLCanvasElement>): boolean => {
      if (!dragRef.current) return false
      dragRef.current = null
      setIsPanning(false)
      return true
    },
    [],
  )

  return {
    viewport,
    toBasePx,
    clientToBasePx,
    onPointerDown,
    onPointerMove,
    onPointerUp,
    isPanning,
    isSpacePressed,
  }
}

export interface SpatialCanvasProps {
  scene: Scene
  config?: WidgetConfig
  onEdit?: (events: EventEnvelope[]) => void
  onCommit?: (scene: Scene, trace: EventEnvelope[]) => void
  selectedId?: string | null
  onSelect?: (id: string | null) => void
  /** CSS display width in px (raster stays scene.canvas size). */
  width?: number
  /** Scrub time in seconds (default 0). The canvas re-renders the scene at this time. */
  t?: number
}

interface DragState {
  id: string
  startPx: Px // in base (untransformed) screen space
  startPos: Vec3
}

const constPosition = (scene: Scene, id: string): Vec3 | null => {
  const entity = findEntity(scene.root, id)
  if (!entity) return null
  return entity.transform.position.kind === 'const' ? entity.transform.position.value : null
}

export function SpatialCanvas(props: SpatialCanvasProps): JSX.Element {
  const { scene, config, onEdit, onSelect } = props
  const t = props.t ?? 0
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [drag, setDrag] = useState<DragState | null>(null)
  const [preview, setPreview] = useState<CorrectionEvent | null>(null)

  // 2D view controls now live in @scenelab/camera-controls
  const {
    viewport,
    toBasePx,
    clientToBasePx,
    onPointerDown: onViewPointerDown,
    onPointerMove: onViewPointerMove,
    onPointerUp: onViewPointerUp,
    isPanning,
    isSpacePressed,
  } = useViewport2DControls({ canvasRef })

  const rendered = preview ? applyEvent(scene, preview) : scene

  useEffect(() => {
    const canvas = canvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    const bg = rendered.canvas.background
    if (bg) {
      ctx.save()
      ctx.fillStyle = `rgba(${Math.round(bg.r * 255)}, ${Math.round(bg.g * 255)}, ${Math.round(bg.b * 255)}, ${bg.a})`
      ctx.fillRect(0, 0, canvas.width, canvas.height)
      ctx.restore()
    }
    ctx.save()
    ctx.translate(viewport.pan.x, viewport.pan.y)
    ctx.scale(viewport.zoom, viewport.zoom)
    const resolved = resolveScene(rendered, t)
    draw(ctx, project(resolved))
    ctx.restore()
  }, [rendered, t, viewport])

  const onPointerDown = (e: React.PointerEvent<HTMLCanvasElement>): void => {
    const canvas = canvasRef.current
    if (!canvas) return

    // space+drag => view pan (view-only, no correction event) — handled by camera-controls
    if (onViewPointerDown(e)) {
      canvas.setPointerCapture(e.pointerId)
      return
    }

    if (config?.readOnly) return

    const basePx = clientToBasePx(e.clientX, e.clientY)
    if (!basePx) return

    const id = hitTestScene(scene, basePx, t)
    onSelect?.(id)
    if (id) {
      const entity = findEntity(scene.root, id)
      // Locked = visible but not draggable (typical editor: still selectable to allow unlock)
      if (entity?.locked === true) return
      const startPos = constPosition(scene, id)
      if (startPos) {
        setDrag({ id, startPx: basePx, startPos })
        canvas.setPointerCapture(e.pointerId)
      }
    }
  }

  const onPointerMove = (e: React.PointerEvent<HTMLCanvasElement>): void => {
    // View pan has priority
    if (onViewPointerMove(e)) return

    if (!drag) return
    const basePx = clientToBasePx(e.clientX, e.clientY)
    if (!basePx) return
    const ppu = pixelsPerUnit(resolveScene(scene, t))
    const d = worldDeltaFromPixels(basePx.x - drag.startPx.x, basePx.y - drag.startPx.y, ppu)
    setPreview({
      type: 'entity.translate',
      target: drag.id,
      from: drag.startPos,
      to: { x: drag.startPos.x + d.x, y: drag.startPos.y + d.y, z: drag.startPos.z },
    })
  }

  const endDrag = (e: React.PointerEvent<HTMLCanvasElement>): void => {
    if (onViewPointerUp(e)) {
      canvasRef.current?.releasePointerCapture?.(e.pointerId)
      return
    }
    if (drag && preview) onEdit?.([humanEnvelope(preview, config?.sessionId)])
    setDrag(null)
    setPreview(null)
    canvasRef.current?.releasePointerCapture?.(e.pointerId)
  }

  const displayWidth = props.width ?? scene.canvas.width
  const displayHeight = displayWidth * (scene.canvas.height / scene.canvas.width)

  return (
    <canvas
      ref={canvasRef}
      width={scene.canvas.width}
      height={scene.canvas.height}
      style={{
        width: displayWidth,
        height: displayHeight,
        touchAction: 'none',
        border: '1px solid #ddd',
        cursor: isPanning ? 'grabbing' : isSpacePressed ? 'grab' : 'auto',
        overscrollBehavior: 'contain',
      }}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
    />
  )
}

// Re-export for backwards compat; new code should import from @scenelab/camera-controls
export type { Viewport2DState as Viewport2D } from '@scenelab/camera-controls'
