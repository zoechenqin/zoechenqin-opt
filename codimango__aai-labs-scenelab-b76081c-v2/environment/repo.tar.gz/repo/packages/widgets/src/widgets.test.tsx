import { describe, it, expect } from 'vitest'
import { renderToString } from 'react-dom/server'
import { sampleScene } from '@scenelab/scene-ir'
import { PropertiesPanel, SpatialCanvas, Timeline } from './index'

describe('widgets render (SSR smoke)', () => {
  it('SpatialCanvas renders a canvas at the scene raster size', () => {
    const html = renderToString(<SpatialCanvas scene={sampleScene()} />)
    expect(html).toContain('<canvas')
    expect(html).toContain('width="1920"')
  })

  it('PropertiesPanel shows the selected entity', () => {
    const html = renderToString(<PropertiesPanel scene={sampleScene()} selectedId="circle_1" />)
    expect(html).toContain('planet') // circle_1's word
    expect(html).toContain('Radius')
  })

  it('PropertiesPanel handles empty selection', () => {
    const html = renderToString(<PropertiesPanel scene={sampleScene()} selectedId={null} />)
    expect(html).toContain('No selection')
  })

  it('Timeline renders a scrubber with a duration readout', () => {
    const html = renderToString(<Timeline scene={sampleScene()} t={0} onChange={() => {}} />)
    expect(html).toContain('type="range"')
    expect(html).toContain('/ ') // "t / duration s" readout
  })
})
