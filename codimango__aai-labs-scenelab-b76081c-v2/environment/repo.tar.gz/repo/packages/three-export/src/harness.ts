/**
 * Browser render harness — bundled (esbuild → IIFE) and injected into a headless Chromium page by
 * index.ts. Exposes window.__sl.{init,render}: init sets up a WebGLRenderer on the page's #sl
 * canvas; render(t) draws the scene at time t (preserveDrawingBuffer so the frame can be captured).
 * Uses the same three-renderer core as the interactive browser preview → export matches preview.
 */
import * as THREE from 'three'
import { parseScene, resolveScene, type Scene } from '@scenelab/scene-ir'
import { buildThreeScene } from '@scenelab/three-renderer'

declare global {
  interface Window {
    __sl: {
      init: (sceneJson: string, w: number, h: number) => void
      render: (t: number) => void
    }
  }
}

let renderer: THREE.WebGLRenderer
let scene: Scene
let current: THREE.Scene | null = null

function disposeCurrent(): void {
  if (!current) return
  current.traverse((o) => {
    const mesh = o as THREE.Mesh
    mesh.geometry?.dispose?.()
    const mat = (mesh as { material?: THREE.Material | THREE.Material[] }).material
    if (mat) (Array.isArray(mat) ? mat : [mat]).forEach((x) => x.dispose())
  })
  current = null
}

window.__sl = {
  init(sceneJson, w, h) {
    const canvas = document.getElementById('sl') as HTMLCanvasElement
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true })
    renderer.setSize(w, h, false)
    scene = parseScene(JSON.parse(sceneJson))
  },
  render(t) {
    disposeCurrent()
    const { scene: s, camera } = buildThreeScene(resolveScene(scene, t))
    current = s
    renderer.render(s, camera)
  },
}
