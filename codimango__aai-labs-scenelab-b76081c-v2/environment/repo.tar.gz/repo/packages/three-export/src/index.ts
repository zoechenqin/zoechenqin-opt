/**
 * @scenelab/three-export — headless three.js → mp4 (Node-only). Renders a Scene through the unified
 * three.js renderer in headless Chromium (real WebGL2 via SwiftShader), captures each frame, and
 * encodes with ffmpeg. This is the 3D-capable export path.
 *
 * NOTE: needs to launch headless Chromium, which the Claude Code managed sandbox blocks
 * (mach-port permission denied). Run it from a normal terminal — the same place batch-compare's
 * metacode agents already run.
 */
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { build } from 'esbuild'
import { chromium } from 'playwright'
import ffmpegPath from 'ffmpeg-static'
import type { Scene } from '@scenelab/scene-ir'
import { sceneTimeline } from '@scenelab/scene-ir'

export interface ThreeExportOptions {
  out: string
  fps?: number
  duration?: number
}

let harnessCache: string | null = null
/** Bundle the browser harness (ESM → IIFE) once; injected into the page via addScriptTag. */
async function bundleHarness(): Promise<string> {
  if (harnessCache) return harnessCache
  const entry = join(dirname(fileURLToPath(import.meta.url)), 'harness.ts')
  const result = await build({ entryPoints: [entry], bundle: true, format: 'iife', write: false, platform: 'browser', logLevel: 'silent' })
  harnessCache = result.outputFiles[0]!.text
  return harnessCache
}

/** Render a Scene to an mp4 with the unified three.js renderer in headless Chromium. */
export async function renderSceneToMp4(scene: Scene, opts: ThreeExportOptions): Promise<{ out: string; frames: number; fps: number }> {
  if (!ffmpegPath) throw new Error('three-export: no ffmpeg binary (ffmpeg-static)')
  const { width, height } = scene.canvas
  const tl = sceneTimeline(scene)
  const fps = opts.fps ?? tl.fps
  const duration = opts.duration ?? tl.duration
  const frames = duration > 0 ? Math.max(1, Math.round(duration * fps)) : fps
  const timeAt = (i: number): number => (duration > 0 ? Math.min(i / fps, duration) : 0)

  const js = await bundleHarness()
  const browser = await chromium.launch({
    args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
  })
  const dir = mkdtempSync(join(tmpdir(), 'sl-three-'))
  try {
    const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1 })
    await page.setContent(
      `<style>*{margin:0;padding:0}</style><canvas id="sl" width="${width}" height="${height}" style="width:${width}px;height:${height}px"></canvas>`,
    )
    await page.addScriptTag({ content: js })
    await page.evaluate(
      ([sj, w, h]) => window.__sl.init(sj as string, w as number, h as number),
      [JSON.stringify(scene), width, height] as const,
    )
    const canvas = page.locator('#sl')
    for (let i = 0; i < frames; i++) {
      await page.evaluate((t) => window.__sl.render(t as number), timeAt(i))
      writeFileSync(join(dir, `f_${String(i).padStart(5, '0')}.png`), await canvas.screenshot({ type: 'png' }))
    }
    await new Promise<void>((resolve, reject) => {
      const ff = spawn(
        ffmpegPath as string,
        ['-y', '-framerate', String(fps), '-i', join(dir, 'f_%05d.png'), '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-movflags', '+faststart', opts.out],
        { stdio: ['ignore', 'ignore', 'pipe'] },
      )
      let err = ''
      ff.stderr.on('data', (d) => { err += String(d) })
      ff.on('error', reject)
      ff.on('close', (c) => (c === 0 ? resolve() : reject(new Error(`ffmpeg exited ${c}\n${err.slice(-1500)}`))))
    })
  } finally {
    rmSync(dir, { recursive: true, force: true })
    await browser.close().catch(() => {})
  }
  return { out: opts.out, frames, fps }
}
