/**
 * @scenelab/canvas-render — the manim-less renderer (docs/foundation.md §7/§8, Node-only).
 * Reuses the browser-safe canvas-preview engine (resolveScene → project → draw) to rasterize
 * each frame on a headless @napi-rs/canvas, then pipes raw RGBA straight to ffmpeg → mp4.
 * Same engine as the interactive scrubber, so an exported video matches what you scrub.
 */
import { execFileSync, spawn } from 'node:child_process'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { createCanvas } from '@napi-rs/canvas'
import ffmpegPath from 'ffmpeg-static'
import type { Scene } from '@scenelab/scene-ir'
import { resolveScene, sceneTimeline } from '@scenelab/scene-ir'
import { drawOverlay, renderScene, renderSceneWithOverlay, type OverlayOptions } from '@scenelab/canvas-preview'

export interface RenderOptions {
  /** Output .mp4 path. */
  out: string
  /** Frames per second (default: scene.fps ?? 30). */
  fps?: number
  /** Duration in seconds (default: scene.duration, else last keyframe). */
  duration?: number
  /** x264 quality, lower = better (default 18). */
  crf?: number
  /** Draw debug annotations over the render. `true` = all defaults; or pass specific toggles. */
  overlay?: boolean | OverlayOptions
}

export interface RenderResult {
  out: string
  frames: number
  fps: number
  duration: number
}

/**
 * Frames to emit for a clip of `duration`, INCLUDING the endpoint.
 *
 * `round(duration * fps)` alone covers `t = 0 … duration - 1/fps` and never samples the final
 * moment, so whatever the animation does last goes undrawn. The visible size of that scales with
 * pacing: against short actions one frame can be most of the final move, leaving objects stopped
 * short of where they were heading. The extra frame costs 1/fps of video.
 */
export function frameCount(duration: number, fps: number): number {
  return duration > 0 ? Math.max(1, Math.round(duration * fps) + 1) : fps
}

/** Scene time for frame `i`, clamped so the final frame lands exactly on `duration`. */
export function frameTime(i: number, duration: number, fps: number): number {
  return duration > 0 ? Math.min(i / fps, duration) : 0
}

/** Render a Scene to an mp4 by rasterizing frames and piping raw RGBA to ffmpeg. */
export async function renderToMp4(scene: Scene, opts: RenderOptions): Promise<RenderResult> {
  if (!ffmpegPath) throw new Error('canvas-render: no ffmpeg binary (ffmpeg-static)')
  const { width, height } = scene.canvas
  const tl = sceneTimeline(scene)
  const fps = opts.fps ?? tl.fps
  const duration = opts.duration ?? tl.duration
  // Static scenes (no keyframes) get a 1s hold so the mp4 is playable.
  const frames = frameCount(duration, fps)
  const timeAt = (i: number): number => frameTime(i, duration, fps)

  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d') as unknown as CanvasRenderingContext2D
  const bg = scene.canvas.background
  const overlay = opts.overlay ? (opts.overlay === true ? {} : opts.overlay) : null

  const ff = spawn(
    ffmpegPath,
    [
      '-y',
      '-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${width}x${height}`, '-r', String(fps), '-i', 'pipe:0',
      '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', String(opts.crf ?? 18), '-movflags', '+faststart',
      opts.out,
    ],
    { stdio: ['pipe', 'ignore', 'pipe'] },
  )
  let ffErr = ''
  ff.stderr.on('data', (d) => { ffErr += String(d) })
  const closed = new Promise<void>((resolve, reject) => {
    ff.on('error', reject)
    ff.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exited ${code}\n${ffErr.slice(-2000)}`))))
  })

  const writeFrame = (buf: Buffer): Promise<void> =>
    new Promise((res, rej) => {
      ff.stdin.write(buf, (err) => (err ? rej(err) : undefined))
      // respect backpressure
      if (ff.stdin.writableNeedDrain) ff.stdin.once('drain', res)
      else res()
    })

  for (let i = 0; i < frames; i++) {
    ctx.clearRect(0, 0, width, height)
    if (bg) {
      ctx.save()
      ctx.fillStyle = `rgba(${Math.round(bg.r * 255)}, ${Math.round(bg.g * 255)}, ${Math.round(bg.b * 255)}, ${bg.a})`
      ctx.fillRect(0, 0, width, height)
      ctx.restore()
    }
    if (overlay) renderSceneWithOverlay(ctx, scene, timeAt(i), overlay)
    else renderScene(ctx, scene, timeAt(i))
    await writeFrame(Buffer.from(ctx.getImageData(0, 0, width, height).data.buffer))
  }
  ff.stdin.end()
  await closed
  return { out: opts.out, frames, fps, duration }
}

export interface CompositeOptions {
  /** Path to an existing base video (e.g. a manim render) to draw debug annotations over. */
  baseVideo: string
  out: string
  overlay?: OverlayOptions
  /**
   * Base wall-clock → scene-time mapping, as a factory that receives the probed video duration
   * (so it can anchor to the real timeline). E.g. manim: pass `manimTimeMap(scene)`. Takes
   * precedence over `leadIn`.
   */
  timeMap?: (videoDuration?: number) => (videoTime: number) => number
  /**
   * Fallback when no `timeMap`: seconds the base leads in with the t=0 state; the overlay samples
   * sceneT = clamp(videoTime - leadIn, 0, duration). Default 0.
   */
  leadIn?: number
}

/** Probe a video's pixel size, fps and duration by parsing `ffmpeg -i` stderr. */
function probeVideo(path: string): { width: number; height: number; fps: number; duration: number } {
  let info = ''
  try {
    execFileSync(ffmpegPath as string, ['-i', path], { stdio: ['ignore', 'ignore', 'pipe'] })
  } catch (e) {
    info = String((e as { stderr?: Buffer }).stderr ?? '')
  }
  const size = info.match(/,\s(\d{2,5})x(\d{2,5})/)
  const fps = info.match(/([\d.]+)\sfps/)
  const dur = info.match(/Duration:\s(\d+):(\d+):([\d.]+)/)
  return {
    width: size ? Number(size[1]) : 1920,
    height: size ? Number(size[2]) : 1080,
    fps: fps ? Number(fps[1]) : 30,
    duration: dur ? Number(dur[1]) * 3600 + Number(dur[2]) * 60 + Number(dur[3]) : 0,
  }
}

/**
 * Composite debug annotations over an EXTERNAL video (manim or any renderer): render transparent
 * overlay PNG frames, then ffmpeg-`overlay` them onto the base. The overlay uses the same
 * projection as the scene, and is scaled to the base video's resolution — so annotations land in
 * the right place even if the base was rendered at a different quality (e.g. manim -ql = 480p).
 */
export async function compositeOverlay(scene: Scene, opts: CompositeOptions): Promise<RenderResult> {
  if (!ffmpegPath) throw new Error('canvas-render: no ffmpeg binary (ffmpeg-static)')
  const { width, height } = scene.canvas // overlay rendered at scene res, ffmpeg scales to base
  const base = probeVideo(opts.baseVideo)
  const tl = sceneTimeline(scene)
  const fps = base.fps || tl.fps
  const duration = base.duration || tl.duration
  const leadIn = opts.leadIn ?? 0
  const frames = Math.max(1, Math.round(duration * fps))
  const mapper = opts.timeMap ? opts.timeMap(duration) : null
  const timeAt = (i: number): number =>
    mapper ? mapper(i / fps) : Math.min(Math.max(i / fps - leadIn, 0), tl.duration)

  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d') as unknown as CanvasRenderingContext2D
  const dir = mkdtempSync(join(tmpdir(), 'scenelab-overlay-'))
  try {
    for (let i = 0; i < frames; i++) {
      ctx.clearRect(0, 0, width, height) // transparent — annotations only
      drawOverlay(ctx, resolveScene(scene, timeAt(i)), opts.overlay ?? {})
      writeFileSync(join(dir, `o_${String(i).padStart(5, '0')}.png`), canvas.toBuffer('image/png'))
    }
    const ff = spawn(
      ffmpegPath,
      [
        '-y',
        '-i', opts.baseVideo,
        '-framerate', String(fps), '-i', join(dir, 'o_%05d.png'),
        '-filter_complex', `[1:v]scale=${base.width}:${base.height}[ov];[0:v][ov]overlay=shortest=1`,
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-crf', '18', '-movflags', '+faststart',
        opts.out,
      ],
      { stdio: ['ignore', 'ignore', 'pipe'] },
    )
    let ffErr = ''
    ff.stderr.on('data', (d) => { ffErr += String(d) })
    await new Promise<void>((resolve, reject) => {
      ff.on('error', reject)
      ff.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exited ${code}\n${ffErr.slice(-2000)}`))))
    })
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
  return { out: opts.out, frames, fps, duration }
}
