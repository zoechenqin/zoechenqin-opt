import { describe, it, expect } from 'vitest'
import { existsSync, statSync, rmSync, mkdtempSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { constant, identityTransform, type Scene } from '@scenelab/scene-ir'
import { frameCount, frameTime, renderToMp4 } from './index'

// A tiny animated scene (small raster → fast) so the smoke test exercises the full
// napi-canvas → ffmpeg pipeline without a heavy render.
const scene: Scene = {
  schemaVersion: '0.1.0',
  id: 'smoke',
  space: '2d',
  canvas: { width: 64, height: 64 }, fps: 10, duration: 0.5,
  camera: { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(64) } },
  root: {
    id: 'root',
    word: 'scene',
    transform: identityTransform(),
    children: [
      {
        id: 'motion',
        word: 'motion',
        transform: identityTransform(),
        children: [],
        components: { behavior: constant({
          type: 'curve' as const,
          id: 'motion.slide',
          target: 'dot',
          property: 'transform.position',
          keyframes: [{ t: 0, value: { x: -20, y: 0, z: 0 } }, { t: 0.5, value: { x: 20, y: 0, z: 0 } }],
        }) },
      },
      {
        id: 'dot',
        word: 'dot',
        transform: { ...identityTransform(), position: constant({ x: -20, y: 0, z: 0 }) },
        components: { circle: constant({ radius: 8, style: { fill: constant({ r: 0.2, g: 0.5, b: 1, a: 1 }) }} ) },
        children: [],
      },
    ],
  },
}

describe('canvas-render', () => {
  it('renders a scene to a non-empty mp4 (napi-canvas → ffmpeg)', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'scenelab-render-'))
    const out = join(dir, 'out.mp4')
    const r = await renderToMp4(scene, { out })
    expect(r.frames).toBe(6) // 0.5s * 10fps, plus the endpoint frame
    expect(existsSync(out)).toBe(true)
    expect(statSync(out).size).toBeGreaterThan(0)
    rmSync(dir, { recursive: true, force: true })
  }, 30_000)

  // Rendering `t = 0 … duration - 1/fps` drops whatever the animation does last. With short
  // actions that is most of the final move: at 30fps and ~0.07s per action, one missing frame is
  // half of it, and the last object stops visibly short of where it was heading.
  describe('the final frame lands on the end of the clip', () => {
    it('includes the endpoint', () => {
      expect(frameCount(0.5, 10)).toBe(6)
      expect(frameTime(frameCount(0.5, 10) - 1, 0.5, 10)).toBe(0.5)
    })

    it('holds for a static scene', () => {
      expect(frameCount(0, 30)).toBe(30)
      expect(frameTime(5, 0, 30)).toBe(0)
    })

    it('never samples past the end', () => {
      const d = 1.4, fps = 24
      for (let i = 0; i < frameCount(d, fps); i++) expect(frameTime(i, d, fps)).toBeLessThanOrEqual(d)
    })
  })
})
