#!/usr/bin/env node
/**
 * CLI: scene.json → mp4 (manim-less).
 *   scenelab-render <scene.json> [out.mp4] [--fps N] [--duration S] [--crf N]
 */
import { readFileSync } from 'node:fs'
import { parseScene } from '@scenelab/scene-ir'
import { compositeOverlay, renderToMp4 } from './index'

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`)
  return i >= 0 ? process.argv[i + 1] : undefined
}

async function main(): Promise<void> {
  const positional = process.argv.slice(2).filter((a) => !a.startsWith('--'))
  const scenePath = positional[0]
  if (!scenePath) {
    console.error('usage: scenelab-render <scene.json> [out.mp4] [--fps N] [--duration S] [--crf N]')
    process.exit(1)
  }
  const out = positional[1] ?? scenePath.replace(/\.json$/, '') + '.mp4'
  const scene = parseScene(JSON.parse(readFileSync(scenePath, 'utf-8')))
  const fps = arg('fps') ? Number(arg('fps')) : undefined
  const duration = arg('duration') ? Number(arg('duration')) : undefined
  const crf = arg('crf') ? Number(arg('crf')) : undefined
  const overlay = process.argv.includes('--overlay')
  const base = arg('base')
  const leadIn = arg('lead-in') ? Number(arg('lead-in')) : undefined
  const r = base
    ? await compositeOverlay(scene, { baseVideo: base, out, leadIn })
    : await renderToMp4(scene, { out, fps, duration, crf, overlay })
  console.error(
    `${base ? 'composited overlay over ' + base : 'rendered'}: ${r.frames} frames @ ${r.fps}fps (${r.duration.toFixed(2)}s) → ${r.out}`,
  )
}

main().catch((e) => {
  console.error(e instanceof Error ? e.message : e)
  process.exit(1)
})
