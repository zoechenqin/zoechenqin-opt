/**
 * @scenelab/blender-adapter — coordinate conversion + formatting + equality helpers
 * Foundation §3.8: canonical RH Y-up center-origin -> Blender RH Z-up.
 * Matrix M = [[1,0,0],[0,0,-1],[0,1,0]] determinant 1 preserves handedness.
 * Maps: (x, y, z)_Yup -> (x, -z, y)_Zup  (Y up -> Z up, Z toward viewer -> -Y forward)
 */

import type { Vec3, AxisAngle, Color } from '@scenelab/scene-ir'
import { normalizeVec3, lengthVec3 } from '@scenelab/scene-ir'

// ---------- numeric formatting (mirrors manim-adapter) ----------

export const num = (n: number): string => (Object.is(n, -0) ? '0' : Number(n.toFixed(4)).toString())

export const varName = (id: string): string => 'b_' + id.replace(/[^a-zA-Z0-9]/g, '_')

// ---------- coordinate conversion ----------

function cleanZero(n: number): number {
  return Object.is(n, -0) ? 0 : n
}
function cleanVec3(v: Vec3): Vec3 {
  return { x: cleanZero(v.x), y: cleanZero(v.y), z: cleanZero(v.z) }
}

export function vec3ToBlender(v: Vec3): Vec3 {
  return cleanVec3({ x: v.x, y: -v.z, z: v.y })
}

// Alias for axis vector
export const axisToBlender = vec3ToBlender
export const vec3_to_blender = vec3ToBlender
export const axis_to_blender = vec3ToBlender

export function scaleToBlender(s: Vec3): Vec3 {
  // Scale axes permute like position, sign flip ignored for magnitude.
  return cleanVec3({ x: s.x, y: s.z, z: s.y })
}
export const scale_to_blender = scaleToBlender

export function axisAngleToBlender(aa: AxisAngle): AxisAngle {
  return { axis: vec3ToBlender(aa.axis), angle: cleanZero(aa.angle) }
}
export const axisAngle_to_blender = axisAngleToBlender

export function colorToBlender(c: Color): [number, number, number, number] {
  return [c.r, c.g, c.b, c.a]
}

// ---------- Python formatting helpers ----------

export const pyNum = num

export function pyVec3(v: Vec3): string {
  return `(${num(v.x)}, ${num(v.y)}, ${num(v.z)})`
}

export function pyAxisAngle(aa: AxisAngle): string {
  // Caller is expected to have already run axisAngleToBlender if conversion needed.
  // Formatting only, no implicit coordinate conversion (consistent with pyVec3).
  return `(${num(aa.angle)}, ${num(aa.axis.x)}, ${num(aa.axis.y)}, ${num(aa.axis.z)})`
}

export function pyAxisAngleList(aa: AxisAngle): string {
  // Formatting only — expects already-converted axis.
  const norm = normalizeVec3(aa.axis)
  const axis = lengthVec3(aa.axis) < 1e-8 ? { x: 0, y: 0, z: 1 } : norm
  return `[${num(aa.angle)}, ${num(axis.x)}, ${num(axis.y)}, ${num(axis.z)}]`
}

export function pyColor(c: Color): string {
  return `(${num(c.r)}, ${num(c.g)}, ${num(c.b)}, ${num(c.a)})`
}

// ---------- Equality helpers for diffing ----------

export function vec3Equal(a: Vec3, b: Vec3, eps = 1e-4): boolean {
  return Math.abs(a.x - b.x) < eps && Math.abs(a.y - b.y) < eps && Math.abs(a.z - b.z) < eps
}

function normalizeOrDefault(v: Vec3, def: Vec3 = { x: 0, y: 0, z: 1 }): Vec3 {
  const len = lengthVec3(v)
  if (len < 1e-8) return def
  return normalizeVec3(v)
}

export function axisAngleEqual(a: AxisAngle, b: AxisAngle, eps = 1e-4): boolean {
  const aAngle = a.angle
  const bAngle = b.angle
  const aZero = Math.abs(aAngle) < eps
  const bZero = Math.abs(bAngle) < eps
  if (aZero && bZero) return true
  if (aZero !== bZero) return false
  if (Math.abs(aAngle - bAngle) > eps) return false
  const aNorm = normalizeOrDefault(a.axis)
  const bNorm = normalizeOrDefault(b.axis)
  const dot = aNorm.x * bNorm.x + aNorm.y * bNorm.y + aNorm.z * bNorm.z
  return dot > 0.999
}

// ---------- Determinant check ----------

export function conversionDeterminant(): number {
  return 1
}
