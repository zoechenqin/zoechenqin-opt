/**
 * material.ts — fill Color -> Blender Principled BSDF
 * Minimal for v1: base_color from fill, alpha -> blend_method.
 * Deduplication via header helper create_material() + per-primitive cache key.
 */

import type { Color } from '@scenelab/scene-ir'
import { varName, num, pyColor } from './convert'

/** Header helper emitted once in generated script to avoid duplicate material boilerplate */
export function materialHeader(): string[] {
  return [
    'def create_material(name, r, g, b, a):',
    '    mat = bpy.data.materials.new(name=name)',
    '    mat.use_nodes = True',
    '    bsdf = mat.node_tree.nodes.get("Principled BSDF")',
    '    if bsdf:',
    '        bsdf.inputs["Base Color"].default_value = (r, g, b, a)',
    '        # Alpha as separate input for newer Blender versions',
    '        if "Alpha" in bsdf.inputs:',
    '            bsdf.inputs["Alpha"].default_value = a',
    '    if a < 1.0:',
    '        try:',
    '            mat.blend_method = "BLEND"',
    '        except AttributeError:',
    '            pass',
    '        try:',
    '            mat.shadow_method = "HASHED"',
    '        except AttributeError:',
    '            pass',
    '    return mat',
    '',
  ]
}

/** Sanitized material variable name for a given primitive id */
export function materialVarName(id: string): string {
  return `${varName(id)}_mat`
}

/** Material python name (bpy data name) */
export function materialDataName(id: string): string {
  // bpy material data names are more lenient, but we prefix to avoid collisions
  return `mat_${id.replace(/[^a-zA-Z0-9_]/g, '_')}`
}

/**
 * Code to create a material for a given fill color.
 * Uses the header helper create_material.
 * @param id primitive id (for naming)
 * @param color resolved final color (fill * opacity)
 * @returns lines like `b_box_mat = create_material("mat_box", 0.95, 0.35, 0.65, 1.0)`
 */
export function createMaterialCode(id: string, color: Color): string[] {
  const mVar = materialVarName(id)
  const mDataName = materialDataName(id)
  // Use pyColor but expanded as individual args for helper signature
  return [`${mVar} = create_material("${mDataName}", ${num(color.r)}, ${num(color.g)}, ${num(color.b)}, ${num(color.a)})`]
}

/**
 * Inline version without helper – emits full bpy boilerplate for one material.
 * Useful if you don't want header helper.
 */
export function createMaterialInlineCode(id: string, color: Color): string[] {
  const mVar = materialVarName(id)
  const mDataName = materialDataName(id)
  const colorStr = pyColor(color)
  return [
    `${mVar} = bpy.data.materials.new(name="${mDataName}")`,
    `${mVar}.use_nodes = True`,
    `bsdf = ${mVar}.node_tree.nodes.get("Principled BSDF")`,
    `if bsdf:`,
    `    bsdf.inputs["Base Color"].default_value = ${colorStr}`,
    `    if "Alpha" in bsdf.inputs:`,
    `        bsdf.inputs["Alpha"].default_value = ${num(color.a)}`,
    `if ${num(color.a)} < 1.0:`,
    `    try: ${mVar}.blend_method = "BLEND"`,
    `    except AttributeError: pass`,
  ]
}

/** Assign material to object var */
export function assignMaterialCode(objectVar: string, materialVar: string): string[] {
  return [`${objectVar}.data.materials.append(${materialVar})`]
}

/**
 * Cache key for color deduplication (r,g,b,a quantized to 4 decimals)
 */
export function colorKey(c: Color): string {
  return `${num(c.r)},${num(c.g)},${num(c.b)},${num(c.a)}`
}
