/**
 * hierarchy.ts — walk Scene.root, build parent-child map, handle Empty creation
 * Supports both legacy Node shape (kind + shape) and new Entity components model.
 */

import { varName } from './convert'

export interface NodeInfo {
  id: string
  parentId: string | null
  varName: string
  depth: number
  kind: 'group' | 'primitive'
  shapeType?: string // for primitives
  original: any // Entity | legacy Node
}

const DRAWABLE_TYPES = new Set([
  'circle',
  'rect',
  'polygon',
  'line',
  'path',
  'text',
  'box',
  'sphere',
  'cylinder',
  'cone',
  'torus',
  'mesh',
])

/** Extract shape type from either legacy Node.shape or modern Entity.components */
export function extractShapeType(entity: any): string | undefined {
  if (!entity) return undefined
  // Legacy: PrimitiveNode.shape.type
  if (entity.shape?.type) return entity.shape.type
  // Modern: components bag
  const comps = entity.components
  if (!comps) return undefined
  for (const key of Object.keys(comps)) {
    if (DRAWABLE_TYPES.has(key)) return key
  }
  return undefined
}

function getChildren(entity: any): any[] {
  const ch = entity?.children
  if (Array.isArray(ch)) return ch
  return []
}

function isTemplate(entity: any): boolean {
  return entity?.template === true
}

function isDrawableEntity(entity: any): boolean {
  return extractShapeType(entity) !== undefined
}

function isGroupShape(entity: any): boolean {
  // Legacy check
  if (entity?.kind === 'group') return true
  if (entity?.kind === 'primitive') return false
  // Modern: no drawable = group/empty
  return !isDrawableEntity(entity)
}

export function collectNodes(root: any, parentId: string | null = null, depth = 0, out: NodeInfo[] = []): NodeInfo[] {
  // Skip template subtrees entirely (matches resolveScene behavior)
  if (isTemplate(root)) return out

  const shapeType = extractShapeType(root)
  // Determine kind: use legacy kind if present, else infer
  const legacyKind = root?.kind as 'group' | 'primitive' | undefined
  const kind: 'group' | 'primitive' = legacyKind ?? (shapeType ? 'primitive' : 'group')

  const info: NodeInfo = {
    id: root.id,
    parentId,
    varName: varName(root.id),
    depth,
    kind,
    shapeType,
    original: root,
  }
  out.push(info)
  if (kind === 'group' || isGroupShape(root)) {
    for (const child of getChildren(root)) {
      if (isTemplate(child)) continue
      collectNodes(child, root.id, depth + 1, out)
    }
  }
  return out
}

export function createGroupEmptyCode(info: NodeInfo): string[] {
  const v = info.varName
  return [
    `bpy.ops.object.empty_add(type='PLAIN_AXES', location=(0, 0, 0))`,
    `${v} = bpy.context.active_object`,
    `${v}.name = "${info.id.replace(/"/g, '\\"')}"`,
    `${v}.rotation_mode = 'AXIS_ANGLE'`,
    `${v}.empty_display_size = 0.5`,
  ]
}

export function createSkippedCode(id: string, shapeType: string): string[] {
  return [`# Skipped "${id}" type=${shapeType} — 2D not supported in blender-adapter v1`]
}

export function createParentCode(childVar: string, parentVar: string): string[] {
  return [
    `${childVar}.parent = ${parentVar}`,
    `# Keep transform as local (no inverse correction needed when setting location after parenting)`,
  ]
}

/** Check if shape type is 3D supported in v1 */
const SUPPORTED_3D = new Set(['box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh'])

export function isSupported3D(shapeType: string): boolean {
  return SUPPORTED_3D.has(shapeType)
}

export function isGroupNode(n: any): boolean {
  if (n?.kind === 'group') return true
  if (n?.kind === 'primitive') return false
  return !isDrawableEntity(n)
}

export function isPrimitiveNode(n: any): boolean {
  if (n?.kind === 'primitive') return true
  if (n?.kind === 'group') return false
  return isDrawableEntity(n)
}
