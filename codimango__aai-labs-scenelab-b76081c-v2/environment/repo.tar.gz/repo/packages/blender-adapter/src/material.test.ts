import { describe, it, expect } from 'vitest'
import { materialHeader, createMaterialCode, assignMaterialCode, materialVarName } from './material'

describe('material', () => {
  it('header contains create_material', () => {
    const h = materialHeader().join('\n')
    expect(h).toContain('def create_material')
    expect(h).toContain('Principled BSDF')
    expect(h).toContain('blend_method')
  })
  it('createMaterialCode uses helper', () => {
    const lines = createMaterialCode('box', { r: 0.95, g: 0.35, b: 0.65, a: 1 })
    expect(lines[0]).toContain('b_box_mat')
    expect(lines[0]).toContain('create_material')
    expect(lines[0]).toContain('0.95')
  })
  it('assign', () => {
    expect(assignMaterialCode('b_box', 'b_box_mat')[0]).toContain('data.materials.append')
  })
})
