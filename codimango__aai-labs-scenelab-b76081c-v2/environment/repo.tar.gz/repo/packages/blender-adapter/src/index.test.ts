import { describe, it, expect } from 'vitest'
import { toBlender } from './index'
import { sampleScene, sampleScene3D } from '@scenelab/scene-ir'
import { constant } from '@scenelab/scene-ir'
import { identityTransform, translateTransform } from '@scenelab/scene-ir'
import type { Scene } from '@scenelab/scene-ir'

describe('toBlender', () => {
  it('2D sampleScene emits skip comments and does not crash', () => {
    const py = toBlender(sampleScene())
    expect(py).toContain('import bpy')
    expect(py).toContain('Skipped')
    // Should contain empty for root group
    expect(py).toContain('empty_add')
  })

  it('3D sampleScene3D contains expected bpy calls', () => {
    const py = toBlender(sampleScene3D())
    expect(py).toContain('primitive_cube_add')
    expect(py).toContain('primitive_uv_sphere_add')
    expect(py).toContain('primitive_cone_add')
    expect(py).toContain('bpy.data.materials.new')
    expect(py).toContain('keyframe_insert')
    expect(py).toContain('empty_add')
    expect(py).toContain('camera_add')
    expect(py).toContain('create_material')
    // vec3_to_blender conversion: camera at (0,5,13) -> (0,-13,5)
    expect(py).toContain('(0, -13, 5)')
  })

  it('frame numbers for animated scene at 30fps: t=0,2,4 -> frames 1,61,121', () => {
    const scene = sampleScene3D() // has keyframes at 0,2,4 for box rotation and sphere position
    const py = toBlender(scene, { fps: 30, frameStart: 1 })
    // frameStart 1, t0=0 -> frame 1, t=2 -> 1+60=61, t=4 -> 1+120=121
    expect(py).toContain('frame 1')
    expect(py).toContain('frame 61')
    expect(py).toContain('frame 121')
    // Check explicit keyframe_insert frame numbers appear
    expect(py).toMatch(/keyframe_insert.*frame=1/)
    expect(py).toMatch(/keyframe_insert.*frame=61/)
    expect(py).toMatch(/keyframe_insert.*frame=121/)
  })

  it('diffing: only animated mover gets extra keyframes', () => {
    // Build a scene with 2 primitives: box animated via behavior, cone static — uses new IR
    const scene: Scene = {
      schemaVersion: '0.1.0',
      id: 'diff-test',
      space: '3d',
      canvas: { width: 1280, height: 720, background: { r: 0, g: 0, b: 0, a: 1 }, fps: 30, duration: 4 },
      camera: {
        id: 'camera',
        transform: identityTransform(),
        projection: { type: 'perspective', fovY: constant(50), near: 0.1, far: 1000 },
      },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'box',
            word: 'box',
            transform: identityTransform(),
            components: {
              box: constant({ size: { x: 1, y: 1, z: 1 }, style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }),
            },
            children: [],
          },
          {
            id: 'cone',
            word: 'cone',
            transform: identityTransform(),
            components: {
              cone: constant({ radius: 1, height: 2, style: { fill: constant({ r: 0, g: 1, b: 0, a: 1 }) } }),
            },
            children: [],
          },
        ],
        components: {
          behavior: constant({
            type: 'sequence',
            id: 'diff-motion',
            children: [
              {
                type: 'curve',
                id: 'box-spin',
                target: 'box',
                property: 'transform.rotation',
                keyframes: [
                  { t: 0, value: { axis: { x: 0, y: 1, z: 0 }, angle: 0 } },
                  { t: 2, value: { axis: { x: 0, y: 1, z: 0 }, angle: Math.PI } },
                  { t: 4, value: { axis: { x: 0, y: 1, z: 0 }, angle: Math.PI * 2 } },
                ],
              },
            ],
          } as any),
        },
      },
    } as any

    const py = toBlender(scene, { fps: 30 })

    // Count keyframe_insert occurrences per var
    const boxInserts = (py.match(/b_box\.keyframe_insert/g) ?? []).length
    const coneInserts = (py.match(/b_cone\.keyframe_insert/g) ?? []).length

    // Box animated over 3 times -> should have >1 inserts per channel
    expect(boxInserts).toBeGreaterThan(coneInserts)
    // Cone static: only t=0 inserts -> 3 (loc, rot, scale)
    expect(coneInserts).toBe(3)
    expect(boxInserts).toBeGreaterThanOrEqual(5)
  })

  it('preserves hierarchy via parent assignment', () => {
    const py = toBlender(sampleScene3D())
    // root -> box etc should have parent assignment
    expect(py).toContain('.parent =')
    expect(py).toContain('b_root')
  })

  it('handles clearScene option', () => {
    const pyWithClear = toBlender(sampleScene3D(), { clearScene: true })
    const pyNoClear = toBlender(sampleScene3D(), { clearScene: false })
    expect(pyWithClear).toContain('select_all')
    expect(pyNoClear).not.toContain('select_all')
  })

  it('generates valid python-ish (balanced parens check)', () => {
    const py = toBlender(sampleScene3D())
    // Simple check: count '(' and ')'
    const open = (py.match(/\(/g) ?? []).length
    const close = (py.match(/\)/g) ?? []).length
    expect(open).toBe(close)
  })

  it('torus primitive emits torus_add with radius and tube', () => {
    const py = toBlender(sampleScene3D())
    expect(py).toContain('primitive_torus_add')
    expect(py).toContain('major_radius')
    expect(py).toContain('minor_radius')
    // sampleScene3D torus has radius 0.7 tube 0.25
    expect(py).toContain('0.7')
    expect(py).toContain('0.25')
    // Should have var for torus
    expect(py).toContain('b_torus')
  })

  it('torus standalone scene creates torus object', () => {
    const scene: Scene = {
      schemaVersion: '0.1.0',
      id: 'torus-test',
      space: '3d',
      canvas: { width: 1280, height: 720, background: { r: 0, g: 0, b: 0, a: 1 } },
      camera: {
        id: 'camera',
        transform: identityTransform(),
        projection: { type: 'perspective', fovY: constant(50), near: 0.1, far: 1000 },
      },
      root: {
        id: 'root',
        word: 'scene',
        transform: identityTransform(),
        children: [
          {
            id: 'my_torus',
            word: 'torus',
            transform: identityTransform(),
            components: {
              torus: constant({
                radius: 1.2,
                tube: 0.3,
                style: { fill: constant({ r: 0.9, g: 0.3, b: 0.7, a: 1 }) },
              }),
            },
            children: [],
          },
        ],
      },
    } as any

    const py = toBlender(scene)
    expect(py).toContain('primitive_torus_add')
    expect(py).toContain('major_radius=1.2')
    expect(py).toContain('minor_radius=0.3')
    expect(py).toContain('b_my_torus')
  })
})
