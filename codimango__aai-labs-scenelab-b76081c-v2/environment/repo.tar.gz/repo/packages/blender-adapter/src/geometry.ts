/**
 * geometry.ts — shape -> bpy code per type (3D primitives only)
 * Each creator assumes object is created at origin; location/rotation/scale set later by hierarchy pass.
 */

import type { Vec3 } from '@scenelab/scene-ir'
import { varName, num, pyVec3, scaleToBlender } from './convert'

export interface GeometryResult {
  objectVar: string
  codeLines: string[]
}

function baseObjectSetup(id: string, objectVar: string): string[] {
  return [
    `${objectVar} = bpy.context.active_object`,
    `${objectVar}.name = "${id.replace(/"/g, '\\"')}"`,
    `${objectVar}.rotation_mode = 'AXIS_ANGLE'`,
  ]
}

function cleanId(id: string): string {
  return id.replace(/[^a-zA-Z0-9_]/g, '_')
}

export function createBoxCode(id: string, size: Vec3): GeometryResult {
  const objVar = varName(id)
  const sizeBl = scaleToBlender(size) // (x, z, y)
  return {
    objectVar: objVar,
    codeLines: [
      `bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))`,
      ...baseObjectSetup(id, objVar),
      // Scale from size=1 cube to desired dimensions
      `${objVar}.scale = ${pyVec3(sizeBl)}`,
    ],
  }
}

export function createSphereCode(id: string, radius: number): GeometryResult {
  const objVar = varName(id)
  return {
    objectVar: objVar,
    codeLines: [
      `bpy.ops.mesh.primitive_uv_sphere_add(radius=${num(radius)}, location=(0, 0, 0))`,
      ...baseObjectSetup(id, objVar),
    ],
  }
}

export function createCylinderCode(id: string, radius: number, height: number): GeometryResult {
  const objVar = varName(id)
  return {
    objectVar: objVar,
    codeLines: [
      // In Blender, cylinder depth is along Z, which matches converted Y->Z height
      `bpy.ops.mesh.primitive_cylinder_add(radius=${num(radius)}, depth=${num(height)}, location=(0, 0, 0))`,
      ...baseObjectSetup(id, objVar),
    ],
  }
}

export function createConeCode(id: string, radius: number, height: number): GeometryResult {
  const objVar = varName(id)
  return {
    objectVar: objVar,
    codeLines: [
      `bpy.ops.mesh.primitive_cone_add(radius1=${num(radius)}, radius2=0, depth=${num(height)}, location=(0, 0, 0))`,
      ...baseObjectSetup(id, objVar),
    ],
  }
}

export function createTorusCode(id: string, radius: number, tube: number): GeometryResult {
  const objVar = varName(id)
  return {
    objectVar: objVar,
    codeLines: [
      `bpy.ops.mesh.primitive_torus_add(major_radius=${num(radius)}, minor_radius=${num(tube)}, major_segments=48, minor_segments=12, location=(0, 0, 0))`,
      ...baseObjectSetup(id, objVar),
    ],
  }
}

export function createMeshPlaceholderCode(id: string, asset: string): GeometryResult {
  const objVar = varName(id)
  return {
    objectVar: objVar,
    codeLines: [
      `# Skipped mesh asset "${asset.replace(/"/g, '\\"')}" for "${id}" — not implemented, placeholder cube`,
      `bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))`,
      ...baseObjectSetup(id, objVar),
    ],
  }
}

/** Generic dispatcher for 3D primitives — returns null for unsupported 2D types */
export function createPrimitiveCode(
  id: string,
  shape: { type: string; size?: Vec3; radius?: number; height?: number; tube?: number; asset?: string }
): GeometryResult | null {
  switch (shape.type) {
    case 'box':
      if (!shape.size) return null
      return createBoxCode(id, shape.size)
    case 'sphere':
      if (shape.radius == null) return null
      return createSphereCode(id, shape.radius)
    case 'cylinder':
      if (shape.radius == null || shape.height == null) return null
      return createCylinderCode(id, shape.radius, shape.height)
    case 'cone':
      if (shape.radius == null || shape.height == null) return null
      return createConeCode(id, shape.radius, shape.height)
    case 'torus':
      if (shape.radius == null || shape.tube == null) return null
      return createTorusCode(id, shape.radius, shape.tube)
    case 'mesh':
      return createMeshPlaceholderCode(id, shape.asset ?? 'unknown')
    default:
      return null // 2D types handled as skipped elsewhere
  }
}
