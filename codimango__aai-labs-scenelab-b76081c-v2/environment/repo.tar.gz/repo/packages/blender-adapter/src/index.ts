/**
 * @scenelab/blender-adapter — scene graph → Blender Python (docs/foundation.md §3.8)
 * - Preserves GroupNode hierarchy as Empties
 * - Maps RH Y-up -> RH Z-up via (x, -z, y)
 * - Minimal Principled BSDF from fill
 * - Animation via sampled keyframeTimes + diffed keyframe_insert (only changed channels)
 *
 * Supports both legacy Node (kind + shape) and new Entity (components) IRs,
 * and includes torus primitive.
 */

import type { Scene, Vec3, AxisAngle, Color } from '@scenelab/scene-ir'
import {
  keyframeTimes,
  resolveVec3,
  resolveAxisAngle,
  resolveNumber,
  resolveColor,
  behaviorStateAt,
} from '@scenelab/scene-ir'

import {
  num,
  varName,
  vec3ToBlender,
  scaleToBlender,
  axisAngleToBlender,
  pyVec3,
  pyAxisAngleList,
  vec3Equal,
  axisAngleEqual,
} from './convert'

import {
  materialHeader,
  createMaterialCode,
  assignMaterialCode,
  materialVarName,
  colorKey,
} from './material'

import {
  createBoxCode,
  createSphereCode,
  createCylinderCode,
  createConeCode,
  createTorusCode,
  createMeshPlaceholderCode,
} from './geometry'

import {
  collectNodes,
  createGroupEmptyCode,
  createSkippedCode,
  createParentCode,
  isSupported3D,
  extractShapeType,
} from './hierarchy'

export * from './convert'
export * from './material'
export * from './geometry'
export * from './hierarchy'

export interface ToBlenderOptions {
  fps?: number
  frameStart?: number
  clearScene?: boolean
}

type ResolvedLocal = { pos: Vec3; rot: AxisAngle; scale: Vec3 }

// ---- helpers for dual IR support ----

function isAnimatable(v: any): boolean {
  return v != null && typeof v === 'object' && 'kind' in v
}

function resolveMaybeVec3(v: any, t: number, fallback: Vec3): Vec3 {
  if (!v) return fallback
  if (isAnimatable(v)) {
    try {
      return resolveVec3(v, t)
    } catch {
      return fallback
    }
  }
  if (typeof v === 'object' && 'x' in v && 'y' in v && 'z' in v) {
    return v as Vec3
  }
  return fallback
}

function resolveMaybeNumber(v: any, t: number, fallback: number): number {
  if (v == null) return fallback
  if (isAnimatable(v)) {
    try {
      return resolveNumber(v, t)
    } catch {
      return fallback
    }
  }
  if (typeof v === 'number') return v
  return fallback
}

function resolveMaybeColor(v: any, t: number): Color | undefined {
  if (!v) return undefined
  if (isAnimatable(v)) {
    try {
      return resolveColor(v, t)
    } catch {
      return undefined
    }
  }
  if (typeof v === 'object' && 'r' in v && 'g' in v && 'b' in v) {
    return v as Color
  }
  return undefined
}

function getDrawablePayload(entity: any): { type: string; value: any; style?: any } | null {
  if (!entity) return null
  // Legacy Node: shape property
  if (entity.shape?.type) {
    const sh = entity.shape
    return { type: sh.type, value: sh, style: sh.style }
  }
  const comps = entity.components
  if (!comps) return null
  const order = ['box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh', 'circle', 'rect', 'polygon', 'line', 'path', 'text']
  for (const key of order) {
    const anim = comps[key]
    if (anim && isAnimatable(anim)) {
      return { type: key, value: anim.value, style: anim.value?.style }
    }
  }
  // Fallback: any drawable key present even if not in order
  for (const key of Object.keys(comps)) {
    const anim = comps[key]
    if (anim && isAnimatable(anim) && (comps as any)[key]?.value) {
      // check if it looks like a shape by having style or type-like fields
      return { type: key, value: anim.value, style: anim.value?.style }
    }
  }
  return null
}

function finalFillColor(fill: Color | undefined, opacity: number): Color | undefined {
  if (!fill) return undefined
  return { r: fill.r, g: fill.g, b: fill.b, a: fill.a * opacity }
}

function resolveLocalUniversal(
  entity: any,
  t: number,
  btMap: Map<string, any>,
): { pos: Vec3; rot: AxisAngle; scale: Vec3; opacity: number; anchor: Vec3 } {
  const bt = btMap.get(entity.id)
  const tr = entity.transform ?? {}

  const posRaw = bt?.position ?? tr.position
  const rotRaw = bt?.rotation ?? tr.rotation
  const scaleRaw = bt?.scale ?? tr.scale

  const pos = resolveMaybeVec3(posRaw, t, { x: 0, y: 0, z: 0 })
  const rot = (() => {
    if (bt?.rotation) return bt.rotation as AxisAngle
    if (!rotRaw) return { axis: { x: 0, y: 0, z: 1 }, angle: 0 } as AxisAngle
    if (isAnimatable(rotRaw)) {
      try {
        return resolveAxisAngle(rotRaw, t)
      } catch {
        return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
      }
    }
    return rotRaw as AxisAngle
  })()
  const scale = resolveMaybeVec3(scaleRaw, t, { x: 1, y: 1, z: 1 })

  // Opacity: new IR components.opacity, legacy tr.opacity
  let opacity = 1
  const opacityComp = entity.components?.opacity
  if (opacityComp && isAnimatable(opacityComp)) {
    try {
      opacity = resolveNumber(opacityComp, t)
    } catch {}
  } else if (tr.opacity) {
    opacity = resolveMaybeNumber(tr.opacity, t, 1)
  }

  const anchor: Vec3 = tr.anchor ?? { x: 0, y: 0, z: 0 }

  return { pos, rot, scale, opacity, anchor }
}

function resolveGeometryValue(
  drawable: { type: string; value: any },
  t: number,
): { size?: Vec3; radius?: number; height?: number; tube?: number; asset?: string } {
  const v = drawable.value
  const out: any = {}
  // size may be Animatable<Vec3> (legacy) or plain Vec3 (new)
  if ('size' in v) {
    out.size = resolveMaybeVec3(v.size, t, { x: 1, y: 1, z: 1 })
  }
  if ('radius' in v) {
    out.radius = resolveMaybeNumber(v.radius, t, 1)
  }
  if ('height' in v) {
    out.height = resolveMaybeNumber(v.height, t, 1)
  }
  if ('tube' in v) {
    out.tube = resolveMaybeNumber(v.tube, t, 0.25)
  }
  if ('asset' in v) {
    out.asset = typeof v.asset === 'string' ? v.asset : 'unknown'
  }
  return out
}

export function toBlender(scene: Scene, opts: ToBlenderOptions = {}): string {
  const times = keyframeTimes(scene)
  const fps = opts.fps ?? (scene as any).canvas?.fps ?? 24
  const frameStart = opts.frameStart ?? 1
  const clearScene = opts.clearScene ?? true

  const duration = (scene as any).canvas?.duration ?? (times.length > 0 ? times[times.length - 1]! : 5)
  const frameEnd = frameStart + Math.round(duration * fps)

  const lines: string[] = []

  // Header
  lines.push('import bpy')
  lines.push('import math')
  lines.push('')

  if (clearScene) {
    lines.push('# Clear existing')
    lines.push('bpy.ops.object.select_all(action="SELECT")')
    lines.push('bpy.ops.object.delete()')
    lines.push('')
  }

  // World background
  if ((scene as any).canvas?.background) {
    const bg = (scene as any).canvas.background
    lines.push('# World background')
    lines.push('world = bpy.data.worlds.get("World")')
    lines.push('if world:')
    lines.push('    world.use_nodes = True')
    lines.push('    bg_node = world.node_tree.nodes.get("Background")')
    lines.push(`    if bg_node:`)
    lines.push(`        bg_node.inputs["Color"].default_value = (${num(bg.r)}, ${num(bg.g)}, ${num(bg.b)}, 1.0)`)
    lines.push('')
  }

  // Material helper
  lines.push('# Material helper')
  lines.push(...materialHeader())
  lines.push('')

  // Collect nodes depth-first (parent before child) — supports both IRs
  const nodeInfos = collectNodes((scene as any).root)
  const idToInfo = new Map<string, (typeof nodeInfos)[0]>()
  for (const n of nodeInfos) idToInfo.set(n.id, n)

  const created = new Set<string>() // ids that got a Blender object
  const materialCache = new Map<string, string>() // colorKey -> material var

  // Build behavior map at t=0 for initial transforms + geometry
  const btAt0 = behaviorStateAt(scene as any, 0)

  // Creation pass (at origin)
  lines.push('# --- Hierarchy creation ---')
  for (const info of nodeInfos) {
    if (info.kind === 'group') {
      lines.push(...createGroupEmptyCode(info))
      created.add(info.id)
    } else {
      const shapeType = info.shapeType ?? extractShapeType(info.original)
      if (!shapeType) {
        lines.push(`# Skipped "${info.id}" — no drawable found`)
        continue
      }

      if (!isSupported3D(shapeType)) {
        lines.push(...createSkippedCode(info.id, shapeType))
        continue
      }

      // Resolve shape at t=0 for initial geometry (handles legacy Animatable and new plain)
      let geom: { objectVar: string; codeLines: string[] } | null = null
      try {
        const drawable = getDrawablePayload(info.original)
        if (!drawable) {
          lines.push(`# No drawable payload for "${info.id}" type=${shapeType}`)
          continue
        }
        const geoVals = resolveGeometryValue(drawable, 0)

        switch (shapeType) {
          case 'box': {
            if (!geoVals.size) throw new Error('missing size')
            geom = createBoxCode(info.id, geoVals.size)
            break
          }
          case 'sphere': {
            if (geoVals.radius == null) throw new Error('missing radius')
            geom = createSphereCode(info.id, geoVals.radius)
            break
          }
          case 'cylinder': {
            if (geoVals.radius == null || geoVals.height == null) throw new Error('missing radius/height')
            geom = createCylinderCode(info.id, geoVals.radius, geoVals.height)
            break
          }
          case 'cone': {
            if (geoVals.radius == null || geoVals.height == null) throw new Error('missing radius/height')
            geom = createConeCode(info.id, geoVals.radius, geoVals.height)
            break
          }
          case 'torus': {
            if (geoVals.radius == null || geoVals.tube == null) throw new Error('missing radius/tube')
            geom = createTorusCode(info.id, geoVals.radius, geoVals.tube)
            break
          }
          case 'mesh': {
            geom = createMeshPlaceholderCode(info.id, geoVals.asset ?? 'unknown')
            break
          }
        }
      } catch (e) {
        lines.push(`# Failed to resolve shape for "${info.id}" type=${shapeType} ${(e as Error).message ?? ''}`)
        continue
      }

      if (!geom) {
        lines.push(`# Unsupported shape for "${info.id}" type=${shapeType}`)
        continue
      }

      lines.push(...geom.codeLines)
      created.add(info.id)

      // Material for this primitive (t=0)
      const drawable = getDrawablePayload(info.original)
      const style = drawable?.style as { fill?: any } | undefined
      if (style?.fill) {
        try {
          const fillCol = resolveMaybeColor(style.fill, 0)
          const local0 = resolveLocalUniversal(info.original, 0, btAt0)
          const final = finalFillColor(fillCol, local0.opacity)
          if (final) {
            const key = colorKey(final)
            let matVar = materialCache.get(key)
            if (!matVar) {
              matVar = materialVarName(info.id)
              lines.push(...createMaterialCode(info.id, final))
              materialCache.set(key, matVar)
            }
            lines.push(...assignMaterialCode(info.varName, matVar))
          }
        } catch {
          // ignore material errors
        }
      }
    }

    // Parenting (after creation, so parent var exists)
    if (info.parentId) {
      const parentInfo = idToInfo.get(info.parentId)
      if (parentInfo && created.has(parentInfo.id) && created.has(info.id)) {
        lines.push(...createParentCode(info.varName, parentInfo.varName))
      }
    }
  }
  lines.push('')

  // Initial transforms at t=0
  lines.push('# --- Initial transforms at t=0 ---')
  const prev = new Map<string, ResolvedLocal>()

  for (const info of nodeInfos) {
    if (!created.has(info.id)) continue
    const local = resolveLocalUniversal(info.original, 0, btAt0)
    const posBl = vec3ToBlender(local.pos)
    const rotBl = axisAngleToBlender(local.rot)
    const scaleBl = scaleToBlender(local.scale)

    const anc = local.anchor
    if (Math.abs(anc.x) > 1e-6 || Math.abs(anc.y) > 1e-6 || Math.abs(anc.z) > 1e-6) {
      lines.push(`# TODO: anchor ${anc.x},${anc.y},${anc.z} not handled for "${info.id}" — baked assumption 0`)
    }

    lines.push(`${info.varName}.location = ${pyVec3(posBl)}`)
    lines.push(`${info.varName}.rotation_axis_angle = ${pyAxisAngleList(rotBl)}`)
    lines.push(`${info.varName}.scale = ${pyVec3(scaleBl)}`)

    prev.set(info.id, { pos: posBl, rot: rotBl, scale: scaleBl })
  }
  lines.push('')

  // Camera — special handling: SceneLab camera looks down local -Z.
  function rotateVecByAA(aa: AxisAngle, v: Vec3): Vec3 {
    const ax = aa.axis
    const len = Math.sqrt(ax.x * ax.x + ax.y * ax.y + ax.z * ax.z)
    if (len < 1e-8 || Math.abs(aa.angle) < 1e-8) return v
    const nx = ax.x / len,
      ny = ax.y / len,
      nz = ax.z / len
    const cosA = Math.cos(aa.angle)
    const sinA = Math.sin(aa.angle)
    const dot = nx * v.x + ny * v.y + nz * v.z
    const crossX = ny * v.z - nz * v.y
    const crossY = nz * v.x - nx * v.z
    const crossZ = nx * v.y - ny * v.x
    return {
      x: v.x * cosA + crossX * sinA + nx * dot * (1 - cosA),
      y: v.y * cosA + crossY * sinA + ny * dot * (1 - cosA),
      z: v.z * cosA + crossZ * sinA + nz * dot * (1 - cosA),
    }
  }
  function lookAtAA(from: Vec3, to: Vec3): AxisAngle {
    const fx = from.x,
      fy = from.y,
      fz = from.z
    const tx = to.x,
      ty = to.y,
      tz = to.z
    const fl = Math.sqrt(fx * fx + fy * fy + fz * fz)
    const tl = Math.sqrt(tx * tx + ty * ty + tz * tz)
    if (fl < 1e-8 || tl < 1e-8) return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
    const nf = { x: fx / fl, y: fy / fl, z: fz / fl }
    const nt = { x: tx / tl, y: ty / tl, z: tz / tl }
    let d = nf.x * nt.x + nf.y * nt.y + nf.z * nt.z
    d = Math.max(-1, Math.min(1, d))
    const ang = Math.acos(d)
    if (ang < 1e-6) return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
    if (Math.abs(Math.PI - ang) < 1e-6) return { axis: { x: 0, y: 1, z: 0 }, angle: Math.PI }
    const cx = nf.y * nt.z - nf.z * nt.y
    const cy = nf.z * nt.x - nf.x * nt.z
    const cz = nf.x * nt.y - nf.y * nt.x
    const cl = Math.sqrt(cx * cx + cy * cy + cz * cz)
    if (cl < 1e-8) return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
    return { axis: { x: cx / cl, y: cy / cl, z: cz / cl }, angle: ang }
  }
  const FWD = { x: 0, y: 0, z: -1 }

  // Camera
  lines.push('# --- Camera ---')
  const camId = (scene as any).camera.id
  const camVar = varName(camId)
  const btCam0 = btAt0.get(camId)
  const camLocalRaw0 = {
    pos: btCam0?.position ?? resolveMaybeVec3((scene as any).camera.transform.position, 0, { x: 0, y: 0, z: 0 }),
    rot:
      btCam0?.rotation ??
      (() => {
        const r = (scene as any).camera.transform.rotation
        if (isAnimatable(r)) {
          try {
            return resolveAxisAngle(r, 0)
          } catch {
            return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
          }
        }
        return (r as AxisAngle) ?? { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
      })(),
    scale: resolveMaybeVec3((scene as any).camera.transform.scale, 0, { x: 1, y: 1, z: 1 }),
  }
  const camPosBl = vec3ToBlender(camLocalRaw0.pos)
  const camDirSl0 = rotateVecByAA(camLocalRaw0.rot, FWD)
  const camDirBl0 = vec3ToBlender(camDirSl0)
  const camRotBl = lookAtAA(FWD, camDirBl0)
  const camScaleBl = scaleToBlender(camLocalRaw0.scale)

  lines.push(`bpy.ops.object.camera_add(location=${pyVec3(camPosBl)})`)
  lines.push(`${camVar} = bpy.context.active_object`)
  lines.push(`${camVar}.name = "${camId.replace(/"/g, '\\"')}"`)
  lines.push(`${camVar}.rotation_mode = 'AXIS_ANGLE'`)
  lines.push(`${camVar}.location = ${pyVec3(camPosBl)}`)
  lines.push(`${camVar}.rotation_axis_angle = ${pyAxisAngleList(camRotBl)}`)
  lines.push(`${camVar}.scale = ${pyVec3(camScaleBl)}`)

  const proj = (scene as any).camera.projection
  if (proj.type === 'orthographic') {
    const h = resolveMaybeNumber(proj.height, 0, 10)
    lines.push(`${camVar}.data.type = 'ORTHO'`)
    lines.push(`${camVar}.data.ortho_scale = ${num(h)}`)
  } else {
    const fovY = resolveMaybeNumber(proj.fovY, 0, 50)
    lines.push(`${camVar}.data.type = 'PERSP'`)
    lines.push(`${camVar}.data.angle_y = math.radians(${num(fovY)})`)
    lines.push(`${camVar}.data.clip_start = ${num(proj.near ?? 0.1)}`)
    lines.push(`${camVar}.data.clip_end = ${num(proj.far ?? 1000)}`)
  }
  lines.push(`bpy.context.scene.camera = ${camVar}`)
  lines.push('')

  // Lights
  lines.push('# --- Lights ---')
  lines.push(`bpy.ops.object.light_add(type='SUN', location=(5, -5, 10))`)
  lines.push(`sun = bpy.context.active_object`)
  lines.push(`sun.data.energy = 3.0`)
  lines.push(`bpy.ops.object.light_add(type='POINT', location=(0, 5, 5))`)
  lines.push(`point = bpy.context.active_object`)
  lines.push(`point.data.energy = 500.0`)
  lines.push('')

  // Render settings
  lines.push('# --- Render settings ---')
  lines.push(`bpy.context.scene.frame_start = ${frameStart}`)
  lines.push(`bpy.context.scene.frame_end = ${frameEnd}`)
  lines.push(`bpy.context.scene.render.fps = ${fps}`)
  lines.push('')

  // Initial keyframes at t=0
  lines.push('# --- Keyframes t=0 ---')
  for (const info of nodeInfos) {
    if (!created.has(info.id)) continue
    lines.push(`${info.varName}.keyframe_insert(data_path="location", frame=${frameStart})`)
    lines.push(`${info.varName}.keyframe_insert(data_path="rotation_axis_angle", frame=${frameStart})`)
    lines.push(`${info.varName}.keyframe_insert(data_path="scale", frame=${frameStart})`)
  }
  lines.push(`${camVar}.keyframe_insert(data_path="location", frame=${frameStart})`)
  lines.push(`${camVar}.keyframe_insert(data_path="rotation_axis_angle", frame=${frameStart})`)
  lines.push(`${camVar}.keyframe_insert(data_path="scale", frame=${frameStart})`)
  lines.push('')

  // Animated keyframes with diffing
  if (times.length > 1) {
    lines.push('# --- Animated keyframes (diffed) ---')
    for (let i = 1; i < times.length; i++) {
      const t = times[i]!
      const frame = frameStart + Math.round(t * fps)
      lines.push(`# t=${t} -> frame ${frame}`)

      const btAtT = behaviorStateAt(scene as any, t)

      for (const info of nodeInfos) {
        if (!created.has(info.id)) continue
        const cur = resolveLocalUniversal(info.original, t, btAtT)
        const curPos = vec3ToBlender(cur.pos)
        const curRot = axisAngleToBlender(cur.rot)
        const curScale = scaleToBlender(cur.scale)

        const last = prev.get(info.id)!
        const posChanged = !vec3Equal(last.pos, curPos)
        const rotChanged = !axisAngleEqual(last.rot, curRot)
        const scaleChanged = !vec3Equal(last.scale, curScale)

        if (!posChanged && !rotChanged && !scaleChanged) continue

        if (posChanged) {
          lines.push(`${info.varName}.location = ${pyVec3(curPos)}`)
          lines.push(`${info.varName}.keyframe_insert(data_path="location", frame=${frame})`)
        }
        if (rotChanged) {
          lines.push(`${info.varName}.rotation_axis_angle = ${pyAxisAngleList(curRot)}`)
          lines.push(`${info.varName}.keyframe_insert(data_path="rotation_axis_angle", frame=${frame})`)
        }
        if (scaleChanged) {
          lines.push(`${info.varName}.scale = ${pyVec3(curScale)}`)
          lines.push(`${info.varName}.keyframe_insert(data_path="scale", frame=${frame})`)
        }

        prev.set(info.id, { pos: curPos, rot: curRot, scale: curScale })
      }

      lines.push('')
    }

    // Camera diffing — use same FWD-corrected rotation as initial camera
    let camPrev: ResolvedLocal = { pos: camPosBl, rot: camRotBl, scale: camScaleBl }
    for (let i = 1; i < times.length; i++) {
      const t = times[i]!
      const frame = frameStart + Math.round(t * fps)
      const btAtT = behaviorStateAt(scene as any, t)
      const btCam = btAtT.get(camId)
      const posRaw = btCam?.position ?? resolveMaybeVec3((scene as any).camera.transform.position, t, { x: 0, y: 0, z: 0 })
      const rotRaw =
        btCam?.rotation ??
        (() => {
          const r = (scene as any).camera.transform.rotation
          if (isAnimatable(r)) {
            try {
              return resolveAxisAngle(r, t)
            } catch {
              return { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
            }
          }
          return (r as AxisAngle) ?? { axis: { x: 0, y: 0, z: 1 }, angle: 0 }
        })()
      const curPos = vec3ToBlender(posRaw as Vec3)
      const dirSl = rotateVecByAA(rotRaw as AxisAngle, FWD)
      const dirBl = vec3ToBlender(dirSl)
      const curRot = lookAtAA(FWD, dirBl)
      const curScale = scaleToBlender(
        resolveMaybeVec3((scene as any).camera.transform.scale, t, { x: 1, y: 1, z: 1 }),
      )

      const posChanged = !vec3Equal(camPrev.pos, curPos)
      const rotChanged = !axisAngleEqual(camPrev.rot, curRot)
      const scaleChanged = !vec3Equal(camPrev.scale, curScale)

      if (posChanged) {
        lines.push(`${camVar}.location = ${pyVec3(curPos)}`)
        lines.push(`${camVar}.keyframe_insert(data_path="location", frame=${frame})`)
      }
      if (rotChanged) {
        lines.push(`${camVar}.rotation_axis_angle = ${pyAxisAngleList(curRot)}`)
        lines.push(`${camVar}.keyframe_insert(data_path="rotation_axis_angle", frame=${frame})`)
      }
      if (scaleChanged) {
        lines.push(`${camVar}.scale = ${pyVec3(curScale)}`)
        lines.push(`${camVar}.keyframe_insert(data_path="scale", frame=${frame})`)
      }

      if (posChanged || rotChanged || scaleChanged) {
        camPrev = { pos: curPos, rot: curRot, scale: curScale }
      }
    }
    lines.push('')
  }

  lines.push(`bpy.context.scene.frame_set(${frameStart})`)
  lines.push('')

  return lines.join('\n')
}
