import { describe, it, expect } from 'vitest'
import {
  vec3ToBlender,
  scaleToBlender,
  axisAngleToBlender,
  vec3Equal,
  axisAngleEqual,
  conversionDeterminant,
  num,
  varName,
  pyVec3,
} from './convert'

describe('blender-adapter convert', () => {
  it('determinant is 1 (RH preserved)', () => {
    expect(conversionDeterminant()).toBe(1)
  })

  it('vec3_to_blender mapping (x, -z, y)', () => {
    // Y-up (0,1,0) up -> Z-up (0,0,1)
    expect(vec3ToBlender({ x: 0, y: 1, z: 0 })).toEqual({ x: 0, y: 0, z: 1 })
    // Z toward viewer (0,0,1) -> -Y forward (0,-1,0)
    expect(vec3ToBlender({ x: 0, y: 0, z: 1 })).toEqual({ x: 0, y: -1, z: 0 })
    // sample from fixtures: camera at (0,5,13) -> (0,-13,5) per plan
    expect(vec3ToBlender({ x: 0, y: 5, z: 13 })).toEqual({ x: 0, y: -13, z: 5 })
    // identity X
    expect(vec3ToBlender({ x: 1, y: 0, z: 0 })).toEqual({ x: 1, y: 0, z: 0 })
  })

  it('scale mapping (sx, sz, sy)', () => {
    expect(scaleToBlender({ x: 2, y: 3, z: 4 })).toEqual({ x: 2, y: 4, z: 3 })
  })

  it('axisAngle preserves angle, converts axis', () => {
    const aa = { axis: { x: 0, y: 1, z: 0 }, angle: Math.PI / 2 }
    const bl = axisAngleToBlender(aa)
    expect(bl.angle).toBeCloseTo(Math.PI / 2)
    expect(bl.axis).toEqual({ x: 0, y: 0, z: 1 }) // Y -> Z
  })

  it('varName sanitizes', () => {
    expect(varName('box')).toBe('b_box')
    expect(varName('my-node.id')).toBe('b_my_node_id')
  })

  it('num formats', () => {
    expect(num(0)).toBe('0')
    expect(num(1.23456789)).toBe('1.2346')
    expect(num(-0)).toBe('0')
  })

  it('pyVec3 formats', () => {
    expect(pyVec3({ x: 0, y: -13, z: 5 })).toBe('(0, -13, 5)')
  })

  it('vec3Equal EPS', () => {
    expect(vec3Equal({ x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 0 })).toBe(true)
    expect(vec3Equal({ x: 0, y: 0, z: 0 }, { x: 0.00001, y: 0, z: 0 }, 1e-4)).toBe(true)
    expect(vec3Equal({ x: 0, y: 0, z: 0 }, { x: 0.001, y: 0, z: 0 }, 1e-4)).toBe(false)
  })

  it('axisAngleEqual handles zero angle', () => {
    const a = { axis: { x: 1, y: 0, z: 0 }, angle: 0 }
    const b = { axis: { x: 0, y: 1, z: 0 }, angle: 0 }
    expect(axisAngleEqual(a, b)).toBe(true) // axis irrelevant when angle 0
  })

  it('axisAngleEqual angle diff', () => {
    const a = { axis: { x: 0, y: 1, z: 0 }, angle: 0 }
    const b = { axis: { x: 0, y: 1, z: 0 }, angle: 0.5 }
    expect(axisAngleEqual(a, b)).toBe(false)
  })

  it('axisAngleEqual axis dot threshold', () => {
    const a = { axis: { x: 0, y: 1, z: 0 }, angle: 1 }
    const b = { axis: { x: 0, y: 0.9999, z: 0.0001 }, angle: 1 }
    expect(axisAngleEqual(a, b)).toBe(true)
    const c = { axis: { x: 1, y: 0, z: 0 }, angle: 1 }
    expect(axisAngleEqual(a, c)).toBe(false)
  })
})
