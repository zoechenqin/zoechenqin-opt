/**
 * @scenelab/three-renderer — the unified renderer core (docs/foundation.md §5/§7).
 * Maps a ResolvedScene (from resolveScene(scene, t)) into a three.js Scene + Camera. Pure and
 * GL-free: building/inspecting the object graph needs no WebGL context (only renderer.render()
 * does), so it's fully unit-testable in Node and identical in the browser. The actual pixels are
 * produced by a THREE.WebGLRenderer — in the browser for the interactive scrubber, and in headless
 * Chromium (Playwright) for offline export.
 *
 * SceneLab and three.js share conventions: right-handed, Y-up, +Z toward viewer, center origin, and
 * column-major 4x4 matrices (translation at [12,13,14]) — so world matrices load directly with no
 * transposition.
 */
import * as THREE from 'three'
import type { Color, ResolvedCamera, ResolvedPrimitive, ResolvedScene, ResolvedStyle, ResolvedLight } from '@scenelab/scene-ir'

export { ThreeView } from './view'
export * from './hit'

const color = (c: Color): THREE.Color => new THREE.Color(c.r, c.g, c.b)

const VOLUMETRIC = new Set(['box', 'sphere', 'cylinder', 'cone', 'torus', 'mesh'])

function isVolumetric(type: string): boolean {
  return VOLUMETRIC.has(type)
}

/** Fill material — Basic for flat 2D (exact colors), Standard for volumetric so lights shade them. */
function fillMaterial(
  shapeType: string,
  style: ResolvedStyle,
  opacity: number,
): THREE.Material | null {
  const src = style.fill ?? style.stroke
  if (!src) return null
  const a = src.a * opacity
  const common = {
    color: color(src),
    side: THREE.DoubleSide,
    transparent: a < 1,
    opacity: a,
  }
  if (isVolumetric(shapeType)) {
    // Lit — so default Ambient + Directional in buildThreeScene actually shade it.
    return new THREE.MeshStandardMaterial({
      ...common,
      roughness: 0.5,
      metalness: 0.05,
    })
  }
  return new THREE.MeshBasicMaterial(common)
}

function strokeMaterial(style: ResolvedStyle, opacity: number): THREE.Material | null {
  const src = style.stroke ?? style.fill
  if (!src) return null
  const a = src.a * opacity
  return new THREE.LineBasicMaterial({
    color: color(src),
    transparent: a < 1,
    opacity: a,
  })
}

/** Text plane placeholder — visible in 3D, GL-free. Width ≈ chars * fontSize * 0.6. */
function textGeometry(text: string, fontSize: number, align: string): THREE.BufferGeometry {
  const w = Math.max(0.1, text.length * fontSize * 0.6)
  const h = Math.max(0.1, fontSize)
  const geo = new THREE.PlaneGeometry(w, h)
  // Align anchor: canvas-preview left=DL, center=DOWN, right=DR — shift X so origin matches that edge.
  if (align === 'left') geo.translate(w / 2, 0, 0)
  else if (align === 'right') geo.translate(-w / 2, 0, 0)
  return geo
}

function meshPlaceholderGeometry(): THREE.BufferGeometry {
  return new THREE.BoxGeometry(1, 1, 1)
}

/** Local-space geometry for a resolved primitive (world transform applied by the caller). */
function geometryFor(prim: ResolvedPrimitive): THREE.BufferGeometry | null {
  const s = prim.shape
  switch (s.type) {
    case 'rect':
      return new THREE.PlaneGeometry(s.size.x, s.size.y)
    case 'circle':
      return new THREE.CircleGeometry(s.radius, 64)
    case 'polygon': {
      const pts = s.points.map((p) => new THREE.Vector2(p.x, p.y))
      if (pts.length < 3) return new THREE.BufferGeometry()
      const shape = new THREE.Shape(pts)
      return new THREE.ShapeGeometry(shape)
    }
    case 'line': {
      const g = new THREE.BufferGeometry()
      g.setAttribute(
        'position',
        new THREE.Float32BufferAttribute([s.from.x, s.from.y, s.from.z, s.to.x, s.to.y, s.to.z], 3),
      )
      return g
    }
    case 'path': {
      if (s.segments.length === 0) return new THREE.BufferGeometry()
      // If closed and we have fill, build ShapeGeometry with beziers; otherwise line strip as open polygon for stroke
      const hasFill = s.style.fill !== undefined
      if (hasFill) {
        const shape = new THREE.Shape()
        let first = true
        for (const seg of s.segments) {
          if (seg.type === 'move') {
            if (first) {
              shape.moveTo(seg.to.x, seg.to.y)
              first = false
            } else {
              shape.moveTo(seg.to.x, seg.to.y)
            }
          } else if (seg.type === 'line') {
            shape.lineTo(seg.to.x, seg.to.y)
          } else if (seg.type === 'cubicBezier') {
            shape.bezierCurveTo(seg.cp1.x, seg.cp1.y, seg.cp2.x, seg.cp2.y, seg.to.x, seg.to.y)
          } else if (seg.type === 'quadraticBezier') {
            shape.quadraticCurveTo(seg.cp.x, seg.cp.y, seg.to.x, seg.to.y)
          }
        }
        if (s.closed) return new THREE.ShapeGeometry(shape)
        // open path with fill? still return shape geometry
        return new THREE.ShapeGeometry(shape)
      }
      // Stroke-only path: build line segments flattened
      const pts: number[] = []
      let cur: { x: number; y: number; z: number } | null = null
      for (const seg of s.segments) {
        if (seg.type === 'move') {
          cur = seg.to
        } else if (seg.type === 'line') {
          if (cur) {
            pts.push(cur.x, cur.y, cur.z, seg.to.x, seg.to.y, seg.to.z)
          }
          cur = seg.to
        } else if (seg.type === 'cubicBezier' || seg.type === 'quadraticBezier') {
          // Flatten bezier into 10 line segments for stroke
          if (!cur) { cur = seg.to; continue }
          const steps = 10
          let prev = cur
          for (let i = 1; i <= steps; i++) {
            const t = i / steps
            let pt: { x: number; y: number; z: number }
            if (seg.type === 'cubicBezier') {
              const mt = 1 - t
              pt = {
                x: mt * mt * mt * cur.x + 3 * mt * mt * t * seg.cp1.x + 3 * mt * t * t * seg.cp2.x + t * t * t * seg.to.x,
                y: mt * mt * mt * cur.y + 3 * mt * mt * t * seg.cp1.y + 3 * mt * t * t * seg.cp2.y + t * t * t * seg.to.y,
                z: mt * mt * mt * cur.z + 3 * mt * mt * t * seg.cp1.z + 3 * mt * t * t * seg.cp2.z + t * t * t * seg.to.z,
              }
            } else {
              const mt = 1 - t
              pt = {
                x: mt * mt * cur.x + 2 * mt * t * seg.cp.x + t * t * seg.to.x,
                y: mt * mt * cur.y + 2 * mt * t * seg.cp.y + t * t * seg.to.y,
                z: mt * mt * cur.z + 2 * mt * t * seg.cp.z + t * t * seg.to.z,
              }
            }
            pts.push(prev.x, prev.y, prev.z, pt.x, pt.y, pt.z)
            prev = pt
          }
          cur = seg.to
        }
      }
      if (pts.length === 0) return new THREE.BufferGeometry()
      const g = new THREE.BufferGeometry()
      g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3))
      return g
    }
    case 'box':
      return new THREE.BoxGeometry(s.size.x, s.size.y, s.size.z)
    case 'sphere':
      return new THREE.SphereGeometry(s.radius, 48, 32)
    case 'cylinder':
      return new THREE.CylinderGeometry(s.radius, s.radius, s.height, 48)
    case 'cone':
      return new THREE.ConeGeometry(s.radius, s.height, 48)
    case 'torus':
      return new THREE.TorusGeometry(s.radius, s.tube, 32, 64)
    case 'text':
      return textGeometry(s.content, s.fontSize, s.align)
    case 'mesh':
      return meshPlaceholderGeometry()
  }
}

function tryMakeTextTexture(
  text: string,
  fontSize: number,
  fill: Color | undefined,
): THREE.Texture | null {
  // Browser-only path — Node tests have no document, so we stay GL-free there.
  if (typeof document === 'undefined') return null
  try {
    const canvas = document.createElement('canvas') as HTMLCanvasElement
    const pad = 8
    // Approximate canvas size; scale up for crispness.
    const w = Math.max(2, Math.ceil(text.length * fontSize * 0.6 * 4 + pad * 2))
    const h = Math.max(2, Math.ceil(fontSize * 4 + pad * 2))
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext('2d')
    if (!ctx) return null
    ctx.clearRect(0, 0, w, h)
    ctx.font = `${fontSize * 4}px sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    const c = fill ?? { r: 1, g: 1, b: 1, a: 1 }
    ctx.fillStyle = `rgba(${Math.round(c.r * 255)},${Math.round(c.g * 255)},${Math.round(c.b * 255)},${c.a})`
    ctx.fillText(text, w / 2, h / 2)
    const tex = new THREE.CanvasTexture(canvas)
    tex.needsUpdate = true
    tex.colorSpace = THREE.SRGBColorSpace
    return tex
  } catch {
    return null
  }
}

function materialFor(prim: ResolvedPrimitive): THREE.Material | null {
  const { shape, opacity } = prim
  if (shape.type === 'line') {
    return strokeMaterial(shape.style, opacity)
  }
  if (shape.type === 'path') {
    // Fill present → fill material, else stroke
    if (shape.style.fill) return fillMaterial(shape.type, shape.style, opacity)
    return strokeMaterial(shape.style, opacity)
  }
  if (shape.type === 'mesh') {
    const src = shape.style.fill ?? shape.style.stroke
    const a = (src?.a ?? 1) * prim.opacity
    return new THREE.MeshStandardMaterial({
      color: src ? color(src) : new THREE.Color(0xff00ff),
      side: THREE.DoubleSide,
      wireframe: true,
      transparent: a < 1,
      opacity: a,
      roughness: 0.8,
      metalness: 0,
    })
  }
  if (shape.type === 'text') {
    const src = shape.style.fill ?? shape.style.stroke
    const a = (src?.a ?? 1) * opacity
    const tex = tryMakeTextTexture(shape.content, shape.fontSize, src)
    if (tex) {
      return new THREE.MeshBasicMaterial({
        map: tex,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: a,
      })
    }
    return fillMaterial(shape.type, shape.style, opacity)
  }
  return fillMaterial(shape.type, shape.style, opacity)
}

/** Build a three.js Object3D for one resolved primitive, with its world transform applied. */
export function objectFor(prim: ResolvedPrimitive): THREE.Object3D | null {
  const geo = geometryFor(prim)
  if (!geo) return null
  const mat = materialFor(prim)
  if (!mat) return null
  const m = new THREE.Matrix4().fromArray(prim.worldMatrix)

  let obj: THREE.Object3D
  if (prim.shape.type === 'line') {
    obj = new THREE.Line(geo, mat as THREE.LineBasicMaterial)
  } else if (prim.shape.type === 'path' && !prim.shape.style.fill) {
    obj = new THREE.LineSegments(geo, mat as THREE.LineBasicMaterial)
  } else {
    obj = new THREE.Mesh(geo, mat)
    if (prim.shape.type === 'text') {
      ;(obj as THREE.Mesh).renderOrder = 1
    }
    if (prim.shape.type === 'mesh') {
      obj.userData.asset = prim.shape.asset
    }
  }
  m.decompose(obj.position, obj.quaternion, obj.scale)
  obj.name = prim.id
  obj.userData.word = prim.word
  obj.userData.shapeType = prim.shape.type
  if (prim.shape.type === 'text') {
    obj.userData.textContent = prim.shape.content
    obj.userData.textAlign = prim.shape.align
  }
  return obj
}

function buildCamera(cam: ResolvedCamera, aspect: number): THREE.Camera {
  let camera: THREE.Camera
  if (cam.projection.type === 'orthographic') {
    const h = cam.projection.height
    camera = new THREE.OrthographicCamera((-h * aspect) / 2, (h * aspect) / 2, h / 2, -h / 2, -100000, 100000)
  } else {
    camera = new THREE.PerspectiveCamera(cam.projection.fovY, aspect, cam.projection.near, cam.projection.far)
  }
  new THREE.Matrix4().fromArray(cam.worldMatrix).decompose(camera.position, camera.quaternion, camera.scale)
  return camera
}

export interface ThreeSceneResult {
  scene: THREE.Scene
  camera: THREE.Camera
}

/** Map a ResolvedScene → three.js Scene + Camera. */
/** A resolved light → its three.js counterpart, placed at the entity's world position. */
export function lightFor(l: ResolvedLight): THREE.Light {
  const c = l.light.color
  const color = new THREE.Color(c.r, c.g, c.b)
  const p = l.worldMatrix
  const place = (obj: THREE.Light): THREE.Light => {
    obj.position.set(p[12]!, p[13]!, p[14]!)
    return obj
  }
  switch (l.light.type) {
    case 'ambient':
      return new THREE.AmbientLight(color, l.light.intensity)
    case 'directional': {
      const d = new THREE.DirectionalLight(color, l.light.intensity)
      place(d)
      if (l.light.direction) d.target.position.set(-l.light.direction.x, -l.light.direction.y, -l.light.direction.z)
      return d
    }
    case 'point':
      return place(new THREE.PointLight(color, l.light.intensity, l.light.range ?? 0, l.light.decay ?? 2))
    case 'spot':
      return place(new THREE.SpotLight(color, l.light.intensity, l.light.range ?? 0, l.light.angle, l.light.penumbra ?? 0))
    default:
      return new THREE.AmbientLight(color, 1)
  }
}

export function buildThreeScene(resolved: ResolvedScene): ThreeSceneResult {
  const scene = new THREE.Scene()
  if (resolved.canvas.background) scene.background = color(resolved.canvas.background)

  for (const prim of resolved.primitives) {
    const obj = objectFor(prim)
    if (obj) scene.add(obj)
  }

  // Lights the SCENE declares win; the defaults below are only a fallback so volumetric shapes
  // aren't pitch black. Adding the defaults unconditionally would make `light` a component you can
  // write and never observe.
  if (resolved.lights.length > 0) {
    for (const l of resolved.lights) scene.add(lightFor(l))
  } else {
    scene.add(new THREE.AmbientLight(0xffffff, 0.6))
    const key = new THREE.DirectionalLight(0xffffff, 0.9)
    key.position.set(1, 2, 3)
    scene.add(key)
  }

  const aspect = resolved.canvas.width / resolved.canvas.height
  return { scene, camera: buildCamera(resolved.camera, aspect) }
}
