/**
 * Hit-testing for the three.js scene — raycaster-based picking.
 * Pure/THREE-only, no WebGLRenderer needed, so it's unit-testable in Node.
 * Mirrors the role of @scenelab/canvas-preview/src/hit.ts for the 2D pipeline:
 * that module does point-in-shape tests over projected ScreenShapes; this one
 * does raycasts over the built THREE.Scene. View owns the scene/camera lifecycle
 * and delegates to these helpers so all selection math lives in one place.
 */
import * as THREE from 'three'

export const SELECTION_HIGHLIGHT_NAME = '__selectionHighlight'

/**
 * Raycast from NDC coords (-1..1) into a built THREE.Scene and return the
 * first hit node id, if any. Walks up the parent chain to find the object
 * with a non-empty `name` (which `buildThreeScene` sets to the node's id).
 * Skips the selection highlight helper itself so it never occludes the real hit.
 */
export function hitTest(scene: THREE.Scene | null, camera: THREE.Camera | null, ndcX: number, ndcY: number): string | null {
  if (!scene || !camera) return null
  // Ensure world matrices are up to date for accurate raycasting. The editor
  // camera applies its position/quaternion directly via `applyToCamera`, so the
  // matrix may be stale until updated.
  scene.updateMatrixWorld(true)
  camera.updateMatrixWorld(true)

  const raycaster = new THREE.Raycaster()
  raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), camera)
  const intersects = raycaster.intersectObjects(scene.children, true)
  for (const hit of intersects) {
    let obj: THREE.Object3D | null = hit.object
    while (obj) {
      if (obj.name && obj.name !== SELECTION_HIGHLIGHT_NAME) return obj.name
      obj = obj.parent
    }
  }
  return null
}

/**
 * Add viewport highlight for the selected node. Called during `ThreeView.render`
 * after the scene has been built and the camera override applied. Adds a
 * `BoxHelper` wireframe only — no emissive/material fill. The scene is rebuilt
 * each frame, so the highlight is transient and re-applied on the next render.
 */
export function applySelectionHighlight(scene: THREE.Scene, selectedId: string | null): void {
  if (!selectedId) return
  const target = scene.getObjectByName(selectedId)
  if (!target) return

  try {
    const helper = new THREE.BoxHelper(target, 0x00e5ff)
    helper.name = SELECTION_HIGHLIGHT_NAME
    helper.update()
    scene.add(helper)
  } catch {
    // ignore highlight failures (e.g., object without geometry)
  }
}

/**
 * Convert a client pixel point to Normalized Device Coordinates (-1..1) for
 * the given canvas bounding rect. Y is flipped (client Y-down → NDC Y-up).
 */
export function clientToNdc(clientX: number, clientY: number, rect: DOMRect): { ndcX: number; ndcY: number } {
  const ndcX = ((clientX - rect.left) / rect.width) * 2 - 1
  const ndcY = -(((clientY - rect.top) / rect.height) * 2 - 1)
  return { ndcX, ndcY }
}
