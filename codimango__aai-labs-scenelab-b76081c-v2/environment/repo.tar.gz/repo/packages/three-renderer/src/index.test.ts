
import { describe, it, expect } from 'vitest'
import * as THREE from 'three'
import { constant, identityTransform, resolveScene, type Entity, type Scene } from '@scenelab/scene-ir'
import { buildThreeScene } from './index'

const prim = (id: string, word: string, pos: { x: number; y: number; z: number }, shape: any): Entity => ({
  id,
  word,
  transform: { ...identityTransform(), position: constant(pos) },
  components: {
    [shape.type]: constant({
      ...(shape.type === 'rect' ? { size: shape.size.value ?? { x: 100, y: 60 } } : {}),
      ...(shape.type === 'circle' ? { radius: shape.radius.value ?? 20 } : {}),
      ...(shape.type === 'box' ? { size: shape.size.value ?? { x: 2, y: 2, z: 2 } } : {}),
      ...(shape.type === 'sphere' ? { radius: shape.radius.value ?? 1 } : {}),
      ...(shape.type === 'text' ? { content: shape.content, fontSize: shape.fontSize.value ?? 48, align: shape.align ?? 'center' } : {}),
      ...(shape.type === 'mesh' ? { asset: shape.asset } : {}),
      style: shape.style,
    }),
  } as any,
  children: [],
})

const scene = (children: Entity[], cam?: Scene['camera'], canvas?: Partial<Scene['canvas']>): Scene => ({
  schemaVersion: '0.1.0',
  id: 's',
  space: '3d',
  canvas: { width: 1920, height: 1080, background: { r: 0, g: 0, b: 0, a: 1 }, ...canvas },
  camera: cam ?? { id: 'camera', transform: identityTransform(), projection: { type: 'orthographic', height: constant(1080) } },
  root: { id: 'root', word: 'scene', transform: identityTransform(), children },
})

const meshes = (r: THREE.Scene): THREE.Mesh[] => r.children.filter((c): c is THREE.Mesh => (c as THREE.Mesh).isMesh)

describe('buildThreeScene', () => {
  it('maps shapes to the right three geometries (including 3D vocab)', () => {
    const s = scene([
      prim('r', 'rect', { x: 0, y: 0, z: 0 }, { type: 'rect', size: constant({ x: 100, y: 60 }), style: { fill: constant({ r: 1, g: 0, b: 0, a: 1 }) } }),
      prim('c', 'circle', { x: 0, y: 0, z: 0 }, { type: 'circle', radius: constant(20), style: { fill: constant({ r: 0, g: 1, b: 0, a: 1 }) } }),
      prim('b', 'box', { x: 0, y: 0, z: 0 }, { type: 'box', size: constant({ x: 2, y: 2, z: 2 }), style: { fill: constant({ r: 0, g: 0, b: 1, a: 1 }) } }),
      prim('sp', 'sphere', { x: 0, y: 0, z: 0 }, { type: 'sphere', radius: constant(1), style: { fill: constant({ r: 1, g: 1, b: 1, a: 1 }) } }),
    ])
    const { scene: three } = buildThreeScene(resolveScene(s, 0))
    const types = meshes(three).map((m) => m.geometry.type).sort()
    expect(types).toEqual(['BoxGeometry', 'CircleGeometry', 'PlaneGeometry', 'SphereGeometry'])
  })
})

describe('declared lights (A2)', () => {
  const lit = (...lights: unknown[]): Scene =>
    ({
      schemaVersion: '0.1.0', id: 'lit', space: '3d', canvas: { width: 100, height: 100 },
      camera: { id: 'camera', transform: identityTransform(), projection: { type: 'perspective', fovY: constant(50), near: 0.1, far: 100 } },
      root: { id: 'root', word: 's', transform: identityTransform(), children: [
        { id: 'box', word: 'box', transform: identityTransform(),
          components: { box: constant({ size: { x: 1, y: 1, z: 1 }, style: { fill: constant({ r: 1, g: 1, b: 1, a: 1 }) } }) }, children: [] },
        ...lights.map((l, i) => ({
          id: `l${i}`, word: 'light',
          transform: { ...identityTransform(), position: constant({ x: 5, y: 6, z: 7 }) },
          components: { light: constant(l) }, children: [],
        })),
      ] },
    }) as Scene

  const lightsIn = (s: Scene) => buildThreeScene(resolveScene(s, 0)).scene.children.filter((c) => (c as { isLight?: boolean }).isLight)

  it('surfaces lights through resolve even though they draw nothing', () => {
    const r = resolveScene(lit({ type: 'ambient', color: { r: 1, g: 1, b: 1, a: 1 }, intensity: 0.4 }), 0)
    expect(r.lights).toHaveLength(1)
    expect(r.primitives.map((p) => p.id)).toEqual(['box']) // the light entity itself is not drawable
  })

  it('uses the scene\'s lights when it declares any', () => {
    const ls = lightsIn(lit({ type: 'ambient', color: { r: 1, g: 0, b: 0, a: 1 }, intensity: 0.4 }))
    expect(ls).toHaveLength(1)
    expect((ls[0] as unknown as { intensity: number }).intensity).toBe(0.4)
  })

  it('places a point light at the entity world position', () => {
    const ls = lightsIn(lit({ type: 'point', color: { r: 1, g: 1, b: 1, a: 1 }, intensity: 2 }))
    expect((ls[0] as unknown as { position: { x: number; y: number; z: number } }).position).toMatchObject({ x: 5, y: 6, z: 7 })
  })

  it('falls back to defaults when the scene declares none, so 3D is never pitch black', () => {
    expect(lightsIn(lit()).length).toBeGreaterThan(0)
  })
})
