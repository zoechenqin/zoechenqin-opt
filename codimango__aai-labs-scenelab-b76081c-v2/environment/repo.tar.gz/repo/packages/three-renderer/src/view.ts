/**
 * ThreeView — browser render wrapper around buildThreeScene. Owns a WebGLRenderer bound to a
 * <canvas>; `render(resolved)` rebuilds and draws the scene at a given time. Rebuild-per-frame is
 * simple and correct for scrubbing (previous scene's GPU resources are disposed to avoid leaks);
 * incremental diffing is a later optimization. Browser-only (needs a real WebGL2 context).
 */
import * as THREE from 'three'
import type { ResolvedScene } from '@scenelab/scene-ir'
import { buildThreeScene } from './index'
import { applySelectionHighlight, hitTest as hitTestScene } from './hit'

export class ThreeView {
  private readonly renderer: THREE.WebGLRenderer
  private current: THREE.Scene | null = null
  private lastCamera: THREE.Camera | null = null

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true })
  }

  /** Internal draw-buffer size in device pixels (CSS size is controlled by the host element). */
  setSize(width: number, height: number): void {
    this.renderer.setSize(width, height, false)
  }

  get scene(): THREE.Scene | null {
    return this.current
  }

  get camera(): THREE.Camera | null {
    return this.lastCamera
  }

  render(
    resolved: ResolvedScene,
    selectedIdOrOverride?: string | null | ((camera: THREE.Camera) => void),
    maybeOverride?: (camera: THREE.Camera) => void,
  ): void {
    this.disposeCurrent()
    const { scene, camera } = buildThreeScene(resolved)

    let selectedId: string | null = null
    let applyCameraOverride: ((camera: THREE.Camera) => void) | undefined
    if (typeof selectedIdOrOverride === 'function') {
      applyCameraOverride = selectedIdOrOverride
    } else if (typeof selectedIdOrOverride === 'string' || selectedIdOrOverride === null) {
      selectedId = selectedIdOrOverride ?? null
      if (typeof maybeOverride === 'function') applyCameraOverride = maybeOverride
    }

    if (applyCameraOverride) applyCameraOverride(camera)
    this.current = scene
    this.lastCamera = camera

    applySelectionHighlight(scene, selectedId)

    this.renderer.render(scene, camera)
  }

  /** Raycast from NDC coords (-1..1) into the current scene and return first hit node id, if any. Delegates to hit.ts. */
  hitTest(ndcX: number, ndcY: number): string | null {
    return hitTestScene(this.current, this.lastCamera, ndcX, ndcY)
  }

  private disposeCurrent(): void {
    if (!this.current) return
    this.current.traverse((o) => {
      const mesh = o as THREE.Mesh
      mesh.geometry?.dispose?.()
      const mat = (mesh as { material?: THREE.Material | THREE.Material[] }).material
      if (mat) (Array.isArray(mat) ? mat : [mat]).forEach((x) => x.dispose())
    })
    this.current = null
    this.lastCamera = null
  }

  dispose(): void {
    this.disposeCurrent()
    this.renderer.dispose()
  }
}
