/**
 * The scene server: one canonical Scene plus its correction log, shared by the browser editor and
 * whatever agent is working alongside it.
 *
 * The agent here is MetaCode/Avocado, which already has its own model access, so nothing in this
 * path talks to an LLM. Both clients are peers that submit correction events and differ only in
 * `source` — which is what makes an agent edit and a human drag the same thing, and what makes the
 * editor a collection instrument for correction pairs rather than only a viewer.
 *
 * The server owns the scene. An agent that edited scene.json directly would bypass the log and
 * produce no correction data, so writes go through `POST /api/events`.
 *
 * Extended for projects: a gitignored `/projects/` root at repo root is the sandbox for user content.
 * All project FS access is gated to stay inside that root (path traversal blocked).
 */
import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync, rmSync, renameSync } from 'node:fs'
import { join, resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { applyEvent, emptyScene, parseScene, resolveScene, sampleScene, sampleScene3D, sceneTimeline, type CorrectionEvent, type EventEnvelope, type Scene } from '@scenelab/scene-ir'
import { append, emptyLog, replay, retract, toCorrectionPair, toJsonl, type CorrectionLog } from '@scenelab/correction-log'
import { AcpSession } from './acp'

export interface SceneServer {
  port: number
  close: () => Promise<void>
  /** Current scene, for tests and for the launcher's summary line. */
  current: () => Scene
  /** Open editor windows, counted by live SSE connections. */
  viewers: () => number
  /** Seconds since the last request of any kind. */
  idleFor: () => number
}

interface State {
  base: Scene
  scene: Scene
  log: CorrectionLog
  /** Bumped on every change; the browser polls or streams against it. */
  revision: number
  /** Current file on disk that autosaves on changed() — null when ephemeral. */
  savePath: string | null
}

// UI layout — separate IR for dynamic widget spawning in web interfaces
export type WidgetType = 'project' | 'scene' | 'outliner' | 'scene-view' | 'preview' | 'properties' | 'timeline' | 'trace'
export interface UIPanel {
  id: string
  type: WidgetType
  position?: 'left' | 'center' | 'right' | 'floating'
  props?: Record<string, unknown>
}
export interface UILayout {
  revision: number
  panels: UIPanel[]
}

interface UIState {
  layout: UILayout
}

const json = (res: ServerResponse, code: number, body: unknown): void => {
  const text = JSON.stringify(body)
  res.writeHead(code, {
    'content-type': 'application/json',
    'access-control-allow-origin': '*',
    'access-control-allow-headers': 'content-type',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
  })
  res.end(text)
}

const readBody = async (req: IncomingMessage): Promise<unknown> => {
  const chunks: Buffer[] = []
  for await (const c of req) chunks.push(c as Buffer)
  const raw = Buffer.concat(chunks).toString('utf-8')
  return raw.length > 0 ? JSON.parse(raw) : {}
}

/** A one-line summary an agent can read without fetching the whole scene. */
function summary(scene: Scene): Record<string, unknown> {
  const frame = resolveScene(scene, 0)
  const tl = sceneTimeline(scene)
  return {
    id: scene.id,
    space: scene.space,
    primitives: frame.primitives.length,
    duration: Number(tl.duration.toFixed(2)),
    entities: frame.primitives.map((p) => ({ id: p.id, word: p.word })),
  }
}

// --- projects FS sandbox --------------------------------------------------

function getProjectsRoot(): string {
  const cwd = process.cwd()
  try {
    if (existsSync(join(cwd, 'packages', 'scene-ir', 'src', 'index.ts')) || existsSync(join(cwd, 'skills', 'editor', 'server.ts'))) {
      return join(cwd, 'projects')
    }
  } catch {}
  try {
    const thisDir = dirname(fileURLToPath(import.meta.url))
    const repoRoot = resolve(thisDir, '../..')
    return join(repoRoot, 'projects')
  } catch {
    return join(cwd, 'projects')
  }
}

const PROJECTS_ROOT = getProjectsRoot()

function safeResolve(relPath: string): string {
  const raw = (relPath ?? '').toString()
  const stripped = raw.replace(/^\/+/, '').replace(/\0/g, '')
  const target = stripped === '' ? PROJECTS_ROOT : resolve(PROJECTS_ROOT, stripped)
  const rootResolved = resolve(PROJECTS_ROOT)
  const targetResolved = resolve(target)
  if (targetResolved !== rootResolved && !targetResolved.startsWith(rootResolved + '/')) {
    throw new Error(`path traversal blocked: ${relPath}`)
  }
  return targetResolved
}

function toRelative(absPath: string | null): string | null {
  if (!absPath) return null
  const root = resolve(PROJECTS_ROOT)
  const abs = resolve(absPath)
  if (abs === root) return ''
  if (abs.startsWith(root + '/')) return abs.slice(root.length + 1)
  // outside sandbox — return absolute for visibility but flag
  return abs
}

function listDir(relativeDir: string): { path: string; absolutePath: string; entries: Array<{ name: string; type: 'dir' | 'file'; path: string; isDir: boolean }> } {
  const absDir = safeResolve(relativeDir)
  if (!existsSync(absDir)) {
    throw new Error(`not found: ${relativeDir || '.'}`)
  }
  const st = statSync(absDir)
  if (!st.isDirectory()) {
    throw new Error(`not a directory: ${relativeDir}`)
  }
  const dirents = readdirSync(absDir, { withFileTypes: true })
  const entries = dirents
    .filter((d) => d.name !== '.DS_Store')
    .map((d) => {
      const rel = relativeDir ? `${relativeDir}/${d.name}` : d.name
      return {
        name: d.name,
        type: (d.isDirectory() ? 'dir' : 'file') as 'dir' | 'file',
        path: rel,
        isDir: d.isDirectory(),
      }
    })
    .sort((a, b) => {
      if (a.type !== b.type) return a.type === 'dir' ? -1 : 1
      return a.name.localeCompare(b.name)
    })
  return { path: relativeDir, absolutePath: absDir, entries }
}

function ensureProjectsRoot(): void {
  try {
    mkdirSync(PROJECTS_ROOT, { recursive: true })
  } catch {}
}

function makeScene(space: '2d' | '3d' = '2d', empty = true): Scene {
  if (empty) return emptyScene({ space: space as any })
  return space === '3d' ? sampleScene3D() : sampleScene()
}

export function startSceneServer(opts: {
  scene: Scene
  port?: number
  savePath?: string
  /** Called when the editor should close itself — see the launcher for what counts as finished. */
  onShutdown?: (reason: string) => void
}): Promise<SceneServer> {
  ensureProjectsRoot()
  const state: State = { base: opts.scene, scene: opts.scene, log: emptyLog(), revision: 0, savePath: opts.savePath ?? null }
  const uiState: UIState = {
    layout: {
      revision: 0,
      panels: [
        { id: 'project', type: 'project', position: 'left' },
        { id: 'scene', type: 'scene', position: 'left' },
        { id: 'outliner', type: 'outliner', position: 'left' },
        { id: 'scene-view', type: 'scene-view', position: 'center' },
        { id: 'preview', type: 'preview', position: 'center' },
        { id: 'timeline', type: 'timeline', position: 'center' },
        { id: 'properties', type: 'properties', position: 'right' },
        { id: 'trace', type: 'trace', position: 'right' },
      ],
    },
  }
  const listeners = new Set<ServerResponse>()
  /** Agent events get their own stream: scene listeners re-fetch the scene on every message,
   *  and a token-by-token agent transcript must not drag the scene along with it. */
  const agentListeners = new Set<ServerResponse>()
  let lastActivity = Date.now()

  // The editor's own metacode session (ACP). Spawned lazily on the first prompt.
  let agentDirty = false
  const agent = new AcpSession(
    process.cwd(),
    () => {
      agentDirty = true
    },
    () => briefing(),
  )
  const flushAgent = (): void => {
    if (!agentDirty) return
    agentDirty = false
    // The model catalogue is ~16KB and never changes mid-session; sending it eight times a
    // second would dwarf the transcript. Connect frames carry it, deltas do not — the client
    // merges, so the field it already has survives.
    const { availableModels, ...rest } = agent.getState()
    void availableModels
    const payload = JSON.stringify(rest)
    for (const res of agentListeners) res.write(`data: ${payload}\n\n`)
  }
  // Reasoning streams in token-sized pieces; coalesce so the UI repaints at a readable rate.
  const agentTick = setInterval(flushAgent, 120)
  agentTick.unref?.()
  let boundPort = opts.port ?? 0

  /**
   * Sent once, ahead of the first prompt. The session remembers it, so later turns are just the
   * user's words. It tells the agent where the live scene is rather than teaching it the IR —
   * that lives in `IR_GUIDE` and would drift if restated here.
   */
  const briefing = (): string =>
    [
      'You are the scene agent inside the SceneLab editor. You are running in a checkout of the',
      'SceneLab repo (pnpm/TypeScript monorepo), and a live editor is open on the scene you build.',
      '',
      `The editor's API is http://localhost:${boundPort}. The scene shown on screen is the one the`,
      'server holds — not a file you pick. To change what the user sees:',
      `  - read it:   curl -s http://localhost:${boundPort}/api/scene`,
      `  - summary:   curl -s http://localhost:${boundPort}/api/summary`,
      `  - replace:   POST http://localhost:${boundPort}/api/scene with {"scene": <Scene>}`,
      'The preview, scene view and timeline update the moment you POST. Do not write scene.json',
      'directly — the server owns the scene and autosaves it when a file is open.',
      '',
      'Before you POST, validate: `pnpm exec tsx scripts/validate.ts <file>`. It catches the ways a',
      'scene can look fine and render nothing (a script that throws, no drawables, motion declared',
      'but never moving). Fix what it reports and run it again.',
      '',
      'The IR rules live in packages/scene-ir/src/guide.ts (IR_GUIDE) — read that first; the types',
      'are in packages/scene-ir/src/types.ts. Follow the guide over any memory of other IRs.',
      '',
      'You are talking to a human in a side panel, not a terminal: keep replies to a sentence or',
      'two saying what you changed. The scene itself is the output.',
    ].join('\n')

  const changed = (): void => {
    state.revision++
    uiState.layout.revision++
    if (state.savePath) {
      try {
        // ensure parent exists
        mkdirSync(dirname(state.savePath), { recursive: true })
        writeFileSync(state.savePath, JSON.stringify(state.scene, null, 2))
      } catch {}
    }
    for (const res of listeners) res.write(`data: ${JSON.stringify({ revision: state.revision, uiRevision: uiState.layout.revision })}\n\n`)
  }

  const uiChanged = (): void => {
    uiState.layout.revision++
    for (const res of listeners) res.write(`data: ${JSON.stringify({ revision: state.revision, uiRevision: uiState.layout.revision, ui: true })}\n\n`)
  }

  const server = createServer((req, res) => {
    const url = new URL(req.url ?? '/', 'http://localhost')
    lastActivity = Date.now()
    if (req.method === 'OPTIONS') return json(res, 204, {})

    void (async () => {
      try {
        // --- read -------------------------------------------------------
        if (req.method === 'GET' && url.pathname === '/api/scene') {
          return json(res, 200, { revision: state.revision, scene: state.scene, savePath: toRelative(state.savePath) })
        }
        if (req.method === 'GET' && url.pathname === '/api/summary') {
          return json(res, 200, { revision: state.revision, savePath: toRelative(state.savePath), projectsRoot: PROJECTS_ROOT, ...summary(state.scene) })
        }
        if (req.method === 'GET' && url.pathname === '/api/log') {
          return json(res, 200, { revision: state.revision, records: state.log.records, jsonl: toJsonl(state.log) })
        }
        if (req.method === 'GET' && url.pathname === '/api/pair') {
          const pair = toCorrectionPair(state.base, state.log, {
            id: `${state.scene.id}-${state.revision}`,
            createdAt: new Date().toISOString(),
          })
          return json(res, 200, pair)
        }
        // Server-sent events, so a human sees an agent's edit land without reloading.
        if (req.method === 'GET' && url.pathname === '/api/stream') {
          res.writeHead(200, {
            'content-type': 'text/event-stream',
            'cache-control': 'no-cache',
            connection: 'keep-alive',
            'access-control-allow-origin': '*',
          })
          res.write(`data: ${JSON.stringify({ revision: state.revision })}\n\n`)
          listeners.add(res)
          req.on('close', () => listeners.delete(res))
          return
        }

        // --- projects FS ------------------------------------------------
        // List: GET /api/projects?path=relative  or /api/projects/list?path=
        if (req.method === 'GET' && (url.pathname === '/api/projects' || url.pathname === '/api/projects/list')) {
          const rel = url.searchParams.get('path') ?? ''
          try {
            const result = listDir(rel)
            return json(res, 200, { ...result, savePath: toRelative(state.savePath), projectsRoot: PROJECTS_ROOT })
          } catch (e) {
            return json(res, 404, { error: (e as Error).message })
          }
        }

        // File content: GET /api/projects/file?path=relativeFile
        if (req.method === 'GET' && url.pathname === '/api/projects/file') {
          const rel = url.searchParams.get('path')
          if (!rel) return json(res, 400, { error: 'needs ?path=' })
          try {
            const abs = safeResolve(rel)
            if (!existsSync(abs)) return json(res, 404, { error: `not found: ${rel}` })
            const st = statSync(abs)
            if (st.isDirectory()) return json(res, 400, { error: 'path is a directory, use ?path for list' })
            const raw = readFileSync(abs, 'utf-8')
            try {
              const parsed = JSON.parse(raw)
              return json(res, 200, { path: rel, content: parsed })
            } catch {
              return json(res, 200, { path: rel, text: raw })
            }
          } catch (e) {
            return json(res, 400, { error: (e as Error).message })
          }
        }

        // --- write ------------------------------------------------------
        if (req.method === 'POST' && url.pathname === '/api/events') {
          const body = (await readBody(req)) as {
            events?: CorrectionEvent[]
            source?: 'human' | 'agent'
            agent?: string
            transactionId?: string
          }
          const events = body.events ?? []
          if (!Array.isArray(events) || events.length === 0) {
            return json(res, 400, { error: 'body must be { events: CorrectionEvent[] }' })
          }
          // Apply to a copy first: a rejected batch must not leave the scene half-edited, which is
          // what makes a multi-event structural edit safe to attempt.
          let next = state.scene
          const failures: Array<{ index: number; error: string }> = []
          events.forEach((event, i) => {
            try {
              next = applyEvent(next, event)
            } catch (err) {
              failures.push({ index: i, error: (err as Error).message })
            }
          })
          if (failures.length > 0) {
            return json(res, 422, { error: 'no events applied', failures })
          }
          const envelopes: EventEnvelope[] = events.map((event) => ({
            event,
            source: body.source ?? 'agent',
            ...(body.agent !== undefined ? { agent: body.agent } : {}),
            ...(body.transactionId !== undefined ? { transactionId: body.transactionId } : {}),
            timestamp: Date.now(),
            sessionId: 'editor',
          }))
          state.scene = next
          for (const env of envelopes) state.log = append(state.log, env)
          changed()
          return json(res, 200, { revision: state.revision, applied: events.length, summary: summary(next) })
        }

        // Let an agent close the editor when the work is done, rather than leaving it running.
        if (req.method === 'POST' && url.pathname === '/api/shutdown') {
          json(res, 200, { ok: true })
          setTimeout(() => opts.onShutdown?.('asked to close'), 50)
          return
        }

        if (req.method === 'POST' && url.pathname === '/api/retract') {
          const body = (await readBody(req)) as { retracts?: string; reason?: string }
          if (!body.retracts) return json(res, 400, { error: 'body must be { retracts: <entry id | transactionId> }' })
          state.log = retract(state.log, body.retracts, { reason: body.reason, timestamp: Date.now() })
          const r = replay(state.base, state.log)
          state.scene = r.scene
          changed()
          return json(res, 200, { revision: state.revision, applied: r.applied, retracted: r.retracted, failures: r.failures })
        }

        // Replace whole scene — lets playground Load buttons work in shared session.
        if (req.method === 'POST' && url.pathname === '/api/scene') {
          const body = (await readBody(req)) as { scene?: Scene }
          if (!body.scene) return json(res, 400, { error: 'body must be { scene: Scene }' })
          try {
            const parsed = parseScene(body.scene)
            state.base = parsed
            state.scene = parsed
            state.log = emptyLog()
            state.revision = 0
            changed()
            return json(res, 200, { revision: state.revision, summary: summary(parsed), savePath: toRelative(state.savePath) })
          } catch (e) {
            return json(res, 400, { error: `invalid scene: ${(e as Error).message}` })
          }
        }

        // Projects POST actions — simplified model:
        // - projects/ contains projects (depth 1 dirs)
        // - projects/<project>/ contains scene subfolders (depth 2)
        // - each scene subfolder contains at most one fixed scene.json (name not user-configurable)
        // - project cannot be subfolder of another project
        if (req.method === 'POST' && url.pathname === '/api/projects') {
          const body = (await readBody(req)) as {
            action?: string
            path?: string
            newPath?: string
            space?: '2d' | '3d'
            empty?: boolean
            scene?: Scene
          }
          const action = body.action
          if (!action) return json(res, 400, { error: 'body must be { action, ... }' })
          try {
            const segments = (p: string): string[] => p.split('/').filter(Boolean)

            switch (action) {
              case 'create-dir': {
                // generic folder creation — now restricted to asset folders inside a scene (depth >=3)
                // For project/scene creation use dedicated actions.
                if (!body.path) return json(res, 400, { error: 'create-dir needs { path }' })
                const rel = body.path.trim().replace(/^\/+/, '').replace(/\0/g, '')
                const segs = segments(rel)
                if (segs.length === 0) return json(res, 400, { error: 'path required' })
                if (segs.length === 1) {
                  return json(res, 400, { error: 'use create-project for top-level projects' })
                }
                if (segs.length === 2) {
                  return json(res, 400, { error: 'use create-scene for scene folders (project/scene)' })
                }
                // depth >=3 — asset folder inside a scene
                const abs = safeResolve(rel)
                mkdirSync(abs, { recursive: true })
                return json(res, 200, { ok: true, path: rel, savePath: toRelative(state.savePath) })
              }
              case 'create-project': {
                // project = direct subfolder of projects/ — no nesting
                if (!body.path) return json(res, 400, { error: 'create-project needs { path }' })
                let rel = body.path.trim().replace(/^\/+/, '').replace(/\0/g, '')
                // take only basename to prevent nesting
                if (rel.includes('/') || rel.includes('\\')) {
                  return json(res, 400, { error: 'project cannot be subfolder of another project — projects must be direct subfolders of projects/' })
                }
                if (!rel) return json(res, 400, { error: 'project name required' })
                const absDir = safeResolve(rel)
                if (existsSync(absDir)) return json(res, 400, { error: `already exists: ${rel}` })
                mkdirSync(absDir, { recursive: true })
                // No scene.json at project root — scenes live in subfolders
                return json(res, 200, { ok: true, dir: rel, path: rel, savePath: toRelative(state.savePath) })
              }
              case 'create-scene': {
                // scene subfolder inside a project: <project>/<sceneName> -> <project>/<sceneName>/scene.json (fixed name)
                if (!body.path) return json(res, 400, { error: 'create-scene needs { path } as <project>/<sceneName>' })
                let rel = body.path.trim().replace(/^\/+/, '').replace(/\0/g, '')
                const segs = segments(rel)
                if (segs.length !== 2) {
                  return json(res, 400, { error: 'scene path must be <project>/<sceneName> (exactly two segments) — e.g. myProject/shot01' })
                }
                const [proj, sceneName] = segs as [string, string]
                const absProj = safeResolve(proj)
                if (!existsSync(absProj) || !statSync(absProj).isDirectory()) {
                  return json(res, 404, { error: `project not found: ${proj}` })
                }
                // ensure project is top-level (its parent is projects root)
                const projParent = resolve(dirname(absProj))
                if (projParent !== resolve(PROJECTS_ROOT)) {
                  return json(res, 400, { error: 'project must be direct subfolder of projects/' })
                }
                const absSceneDir = safeResolve(rel)
                if (existsSync(absSceneDir)) return json(res, 400, { error: `already exists: ${rel}` })
                mkdirSync(absSceneDir, { recursive: true })
                const scene = body.scene ? parseScene(body.scene) : makeScene('2d', true)
                const sceneFile = join(absSceneDir, 'scene.json')
                writeFileSync(sceneFile, JSON.stringify(scene, null, 2))
                // switch to this new scene
                state.base = scene
                state.scene = scene
                state.log = emptyLog()
                state.revision = 0
                state.savePath = sceneFile
                changed()
                return json(res, 200, {
                  ok: true,
                  path: toRelative(sceneFile),
                  dir: rel,
                  summary: summary(scene),
                  savePath: toRelative(state.savePath),
                  revision: state.revision,
                })
              }
              case 'create-file':
              case 'create-asset': {
                // generic asset file — not scene.json (fixed name). For saving extra files inside a scene folder.
                // path must be inside a scene folder (depth >=3) or inside project (depth 2 as asset, not scene.json)
                if (!body.path) return json(res, 400, { error: 'create-file needs { path }' })
                let rel = body.path.trim().replace(/^\/+/, '').replace(/\0/g, '')
                if (rel.endsWith('/')) rel = rel.slice(0, -1)
                const baseName = rel.split('/').pop() ?? ''
                if (baseName === 'scene.json') {
                  return json(res, 400, { error: 'scene.json name is fixed — use create-scene to create a scene subfolder which auto-creates scene.json' })
                }
                const abs = safeResolve(rel)
                // prevent creating at project root level as file (projects/<file> would be mistaken for project)
                const segs = segments(rel)
                if (segs.length < 2) return json(res, 400, { error: 'assets must be inside a project (path must include project/)' })
                mkdirSync(dirname(abs), { recursive: true })
                if (body.scene) {
                  const scene = parseScene(body.scene)
                  writeFileSync(abs, JSON.stringify(scene, null, 2))
                  return json(res, 200, { ok: true, path: rel, summary: summary(scene) })
                }
                // empty asset file placeholder
                writeFileSync(abs, '')
                return json(res, 200, { ok: true, path: rel })
              }
              case 'delete': {
                if (!body.path) return json(res, 400, { error: 'delete needs { path }' })
                const abs = safeResolve(body.path)
                if (!existsSync(abs)) return json(res, 404, { error: `not found: ${body.path}` })
                if (resolve(abs) === resolve(PROJECTS_ROOT)) return json(res, 400, { error: 'refuse to delete projects root' })
                rmSync(abs, { recursive: true, force: true })
                if (state.savePath && resolve(abs) === resolve(state.savePath)) {
                  state.savePath = null
                }
                if (state.savePath && resolve(state.savePath).startsWith(resolve(abs) + '/')) {
                  state.savePath = null
                }
                return json(res, 200, { ok: true, deleted: body.path, savePath: toRelative(state.savePath) })
              }
              case 'rename': {
                if (!body.path || !body.newPath) return json(res, 400, { error: 'rename needs { path, newPath }' })
                let rel = body.path.trim().replace(/^\/+/, '')
                let relNew = body.newPath.trim().replace(/^\/+/, '')
                // enforce rules: renaming must preserve depth and fixed scene.json name
                if (rel.endsWith('scene.json') || relNew.endsWith('scene.json')) {
                  return json(res, 400, { error: 'scene.json cannot be renamed — rename its parent folder instead' })
                }
                const segs = segments(rel)
                const segsNew = segments(relNew)
                if (segs.length !== segsNew.length) {
                  return json(res, 400, { error: 'rename must keep same depth (project or scene folder)' })
                }
                // project depth 1 rename ok, scene depth 2 rename ok, asset depth >=3 rename ok
                if (segs.length === 1 || segs.length === 2) {
                  // ensure not trying to move into another project
                  // for project rename, both old and new must be top-level
                  if (segs.length === 1 && (rel.includes('/') || relNew.includes('/'))) {
                    return json(res, 400, { error: 'project rename must stay at top level' })
                  }
                }
                const abs = safeResolve(rel)
                const absNew = safeResolve(relNew)
                if (!existsSync(abs)) return json(res, 404, { error: `not found: ${body.path}` })
                if (existsSync(absNew)) return json(res, 400, { error: `destination exists: ${body.newPath}` })
                mkdirSync(dirname(absNew), { recursive: true })
                renameSync(abs, absNew)
                if (state.savePath) {
                  const cur = resolve(state.savePath)
                  const oldRes = resolve(abs)
                  if (cur === oldRes) {
                    state.savePath = absNew
                  } else if (cur.startsWith(oldRes + '/')) {
                    state.savePath = join(absNew, cur.slice(oldRes.length + 1))
                  }
                }
                return json(res, 200, { ok: true, from: rel, to: relNew, savePath: toRelative(state.savePath) })
              }
              case 'open': {
                if (!body.path) return json(res, 400, { error: 'open needs { path }' })
                let abs = safeResolve(body.path)
                if (!existsSync(abs)) return json(res, 404, { error: `not found: ${body.path}` })
                let st = statSync(abs)
                if (st.isDirectory()) {
                  const candidate = join(abs, 'scene.json')
                  if (!existsSync(candidate)) return json(res, 404, { error: `no scene.json in ${body.path} (scene subfolder must contain scene.json)` })
                  abs = candidate
                  st = statSync(abs)
                }
                if (!st.isFile()) return json(res, 400, { error: 'open target not a file' })
                // enforce fixed name scene.json
                if (abs.split('/').pop() !== 'scene.json' && abs.split('\\').pop() !== 'scene.json') {
                  // allow opening any json? but spec says at most one scene.json per scene folder, main file.
                  // For now only allow scene.json as scene.
                  const base = abs.split('/').pop() ?? ''
                  if (base !== 'scene.json') {
                    // if it's not scene.json, return its raw content but don't set as current scene unless it's scene.json
                    // To keep simple, only scene.json can be opened as current scene.
                    return json(res, 400, { error: 'only scene.json can be opened as active scene (fixed name)' })
                  }
                }
                const raw = readFileSync(abs, 'utf-8')
                let parsed: Scene
                try {
                  parsed = parseScene(JSON.parse(raw))
                } catch (e) {
                  return json(res, 400, { error: `invalid scene in ${body.path}: ${(e as Error).message}` })
                }
                state.base = parsed
                state.scene = parsed
                state.log = emptyLog()
                state.revision = 0
                state.savePath = abs
                changed()
                return json(res, 200, { ok: true, path: toRelative(abs), summary: summary(parsed), revision: state.revision, savePath: toRelative(state.savePath) })
              }
              case 'save':
              case 'save-as': {
                // save current scene to its existing savePath, or to a scene folder (fixed name scene.json, not user-named)
                let targetAbs: string | null = null
                if (body.path) {
                  let rel = body.path.trim().replace(/^\/+/, '').replace(/\0/g, '')
                  // disallow custom scene.json naming
                  if (rel.endsWith('.json') && !rel.endsWith('scene.json')) {
                    return json(res, 400, { error: 'scene.json name is fixed — provide folder path like myProject/myScene, not custom file name' })
                  }
                  let abs = safeResolve(rel)
                  try {
                    const s = statSync(abs)
                    if (s.isDirectory()) abs = join(abs, 'scene.json')
                  } catch {
                    // if path doesn't exist, treat as scene folder (or asset dir) -> always scene.json inside
                    if (rel.endsWith('scene.json')) {
                      // ok use as is
                    } else {
                      const hasExt = abs.includes('.') && abs.lastIndexOf('.') > abs.lastIndexOf('/')
                      if (!hasExt) abs = join(abs, 'scene.json')
                      else if (!abs.endsWith('scene.json')) {
                        return json(res, 400, { error: 'scene.json name is fixed' })
                      }
                    }
                  }
                  // ensure not trying to write scene.json at project root or projects root
                  const segs = segments(toRelative(abs) ?? '')
                  // toRelative on abs that is scene.json will give path like proj/scene/scene.json => segments 3
                  // disallow saving directly at projects/ or projects/proj/scene.json? Actually depth 2 file projects/proj/scene.json would be project root scene.json which is not allowed in new model (scenes must be subfolders)
                  // So enforce depth >=3 for scene.json (project/scene/scene.json)
                  if (segs && segs.length > 0) {
                    if (segs[segs.length - 1] === 'scene.json') {
                      if (segs.length < 3) {
                        return json(res, 400, { error: 'scene.json must live in a scene subfolder: <project>/<sceneName>/scene.json, not at project root' })
                      }
                    }
                  }
                  targetAbs = abs
                } else {
                  if (!state.savePath) return json(res, 400, { error: 'no current scene file — open a scene first or provide { path } as <project>/<sceneName>' })
                  targetAbs = state.savePath
                }
                const sceneToSave = body.scene ? parseScene(body.scene) : state.scene
                mkdirSync(dirname(targetAbs), { recursive: true })
                writeFileSync(targetAbs, JSON.stringify(sceneToSave, null, 2))
                if (action === 'save-as' || !state.savePath) state.savePath = targetAbs
                state.revision++
                for (const resL of listeners) resL.write(`data: ${JSON.stringify({ revision: state.revision, uiRevision: uiState.layout.revision })}\n\n`)
                return json(res, 200, { ok: true, path: toRelative(targetAbs), savePath: toRelative(state.savePath), revision: state.revision })
              }
              default:
                return json(res, 400, { error: `unknown action ${action}` })
            }
          } catch (e) {
            return json(res, 500, { error: (e as Error).message })
          }
        }

        // --- Agent — the editor's own metacode session over ACP -----------------
        if (req.method === 'GET' && url.pathname === '/api/agent/state') {
          return json(res, 200, agent.getState())
        }
        // Separate from /api/stream on purpose: see agentListeners.
        if (req.method === 'GET' && url.pathname === '/api/agent/stream') {
          res.writeHead(200, {
            'content-type': 'text/event-stream',
            'cache-control': 'no-cache',
            connection: 'keep-alive',
            'access-control-allow-origin': '*',
          })
          res.write(`data: ${JSON.stringify(agent.getState())}\n\n`)
          agentListeners.add(res)
          req.on('close', () => agentListeners.delete(res))
          return
        }
        if (req.method === 'POST' && url.pathname === '/api/agent/prompt') {
          const body = (await readBody(req)) as { prompt?: string }
          const prompt = (body.prompt ?? '').toString().trim()
          if (!prompt) return json(res, 400, { error: 'prompt required' })
          if (prompt.length > 8000) return json(res, 400, { error: 'prompt too long (max 8000 chars)' })
          if (agent.getState().busy) return json(res, 409, { error: 'a turn is already in flight' })

          // Fire and forget: the turn streams over /api/agent/stream. Awaiting here would hold
          // the request open for the whole generation. The session briefs itself on first use.
          void agent
            .prompt(prompt)
            .catch(() => {}) // surfaced via state.lastError
            .finally(() => flushAgent())
          return json(res, 202, { ok: true, state: agent.getState() })
        }
        if (req.method === 'POST' && url.pathname === '/api/agent/reset') {
          try {
            await agent.reset()
            return json(res, 200, { ok: true, state: agent.getState() })
          } catch (e) {
            return json(res, 500, { error: (e as Error).message, state: agent.getState() })
          }
        }
        if (req.method === 'POST' && url.pathname === '/api/agent/cancel') {
          await agent.cancel()
          return json(res, 200, { ok: true, state: agent.getState() })
        }

        // --- UI layout — dynamic widget spawning for web interfaces ---
        if (req.method === 'GET' && url.pathname === '/api/ui') {
          return json(res, 200, uiState.layout)
        }
        if (req.method === 'POST' && url.pathname === '/api/ui') {
          const body = (await readBody(req)) as {
            action?: 'spawn' | 'remove' | 'replace' | 'clear'
            panel?: UIPanel
            panels?: UIPanel[]
            id?: string
          }
          if (!body.action) return json(res, 400, { error: 'body must be { action, ... }' })
          switch (body.action) {
            case 'spawn': {
              if (!body.panel || !body.panel.type) return json(res, 400, { error: 'spawn needs { panel: { id?, type } }' })
              const p: UIPanel = {
                id: body.panel.id ?? `${body.panel.type}-${Date.now()}`,
                type: body.panel.type,
                position: body.panel.position ?? 'floating',
                props: body.panel.props ?? {},
              }
              uiState.layout.panels.push(p)
              uiChanged()
              return json(res, 200, { ok: true, layout: uiState.layout })
            }
            case 'remove': {
              if (!body.id) return json(res, 400, { error: 'remove needs { id }' })
              uiState.layout.panels = uiState.layout.panels.filter((p) => p.id !== body.id)
              uiChanged()
              return json(res, 200, { ok: true, layout: uiState.layout })
            }
            case 'replace': {
              if (!body.panels || !Array.isArray(body.panels)) return json(res, 400, { error: 'replace needs { panels: UIPanel[] }' })
              uiState.layout.panels = body.panels as UIPanel[]
              uiChanged()
              return json(res, 200, { ok: true, layout: uiState.layout })
            }
            case 'clear': {
              uiState.layout.panels = []
              uiChanged()
              return json(res, 200, { ok: true, layout: uiState.layout })
            }
            default:
              return json(res, 400, { error: `unknown action ${body.action}` })
          }
        }

        return json(res, 404, { error: `no route for ${req.method} ${url.pathname}` })
      } catch (err) {
        return json(res, 500, { error: (err as Error).message })
      }
    })()
  })

  return new Promise((resolvePromise, reject) => {
    server.on('error', (err: any) => reject(err))
    server.listen(opts.port ?? 0, () => {
      const addr = server.address()
      const port = typeof addr === 'object' && addr ? addr.port : (opts.port ?? 0)
      boundPort = port
      resolvePromise({
        port,
        current: () => state.scene,
        viewers: () => listeners.size,
        idleFor: () => (Date.now() - lastActivity) / 1000,
        close: () =>
          new Promise((done) => {
            // Without this the metacode child outlives the editor.
            clearInterval(agentTick)
            agent.stop()
            for (const res of listeners) res.end()
            for (const res of agentListeners) res.end()
            server.close(() => done())
          }),
      })
    })
  })
}

/**
 * Load a scene from disk, start empty, or start from the built-in sample.
 *
 * Empty is the interesting one: building a scene up from nothing puts the WHOLE construction in
 * the correction log, not just the edits made after some first draft existed.
 */
export function loadScene(path?: string, opts: { empty?: boolean; space?: '2d' | '3d' } = {}): Scene {
  if (path) return parseScene(JSON.parse(readFileSync(path, 'utf-8')))
  if (opts.empty) return emptyScene({ ...(opts.space ? { space: opts.space } : {}) })
  return sampleScene()
}
