import { existsSync, readFileSync, rmSync } from 'node:fs'

const FILE = '.metacode/scenelab-editor.json'

async function main() {
  if (!existsSync(FILE)) {
    console.log('No session file — nothing running (also trying ports 7317-7322)')
    for (let port = 7317; port <= 7322; port++) {
      try {
        await fetch(`http://localhost:${port}/api/shutdown`, { method: 'POST', signal: AbortSignal.timeout(800) })
        console.log(`Shutdown via :${port}/api/shutdown`)
      } catch {}
    }
    // Safety pkill for orphaned processes from previous crashed launches
    try {
      const { spawn } = await import('node:child_process')
      spawn('pkill', ['-f', 'scenelab'], { stdio: 'ignore' }).unref()
    } catch {}
    return
  }
  try {
    const s = JSON.parse(readFileSync(FILE, 'utf-8')) as { api?: string | null; pid?: number; vitePid?: number; electronPid?: number; ui?: string | null }
    if (s.api) {
      try {
        await fetch(`${s.api}/api/shutdown`, { method: 'POST', signal: AbortSignal.timeout(1000) })
        console.log(`Shutdown via ${s.api}/api/shutdown`)
      } catch {}
    }
    // Also try fallback ports in case api is stale
    for (let port = 7317; port <= 7322; port++) {
      try {
        await fetch(`http://localhost:${port}/api/shutdown`, { method: 'POST', signal: AbortSignal.timeout(500) })
      } catch {}
    }
    if (s.pid) {
      try { process.kill(s.pid, 'SIGTERM'); console.log(`Killed main pid ${s.pid}`) } catch {}
    }
    if (s.vitePid) {
      try { process.kill(s.vitePid, 'SIGTERM'); console.log(`Killed vite pid ${s.vitePid}`) } catch {}
    }
    if (s.electronPid) {
      try { process.kill(s.electronPid, 'SIGTERM'); console.log(`Killed electron pid ${s.electronPid}`) } catch {}
    }
    const { spawn } = await import('node:child_process')
    // Kill orphaned playground vite (more specific than plain vite)
    spawn('pkill', ['-f', 'playground.*vite'], { stdio: 'ignore' }).unref()
    rmSync(FILE, { force: true })
    console.log('Cleaned session file')
  } catch (e) {
    console.error(`stop failed: ${(e as Error).message}`)
    try { rmSync(FILE, { force: true }) } catch {}
  }
}
void main()
