---
name: scenelab-editor
description: "Launch the SceneLab editor on a scene and edit it alongside a human. Starts a scene server (canonical Scene + correction log) plus the browser editor; the agent reads and edits the SAME scene over HTTP while the human drags, and every edit from either side is logged as a correction with its source. Use when authoring or fixing one scene interactively, or when collecting correction pairs."
---

# SceneLab Editor (Shared Session)

Opens a scene in the browser editor and puts an HTTP API in front of it, so you and a human are
editing **one** scene. Your edits appear in their viewport; theirs appear in the scene you read.
Every edit — from either side — is appended to a correction log tagged with its `source`, which is
what turns an editing session into training data (Design §3.6).

Nothing here talks to a model. You already have model access; the editor supplies the shared scene.

## Start it

Nothing needs setting up first. This returns in about a second, with the session running behind it:

```bash
pnpm exec tsx skills/editor/editor.ts --new --detach               # EMPTY scene, built by prompting
pnpm exec tsx skills/editor/editor.ts --new --space=3d --detach    # empty, perspective camera
pnpm exec tsx skills/editor/editor.ts --detach                     # built-in sample scene
pnpm exec tsx skills/editor/editor.ts path/to/scene.json --detach  # an existing scene
pnpm exec tsx skills/editor/editor.ts scene.json --save --detach   # write edits back to that file
pnpm exec tsx skills/editor/editor.ts --no-ui --detach             # API only, no browser
```

It opens the browser window itself and prints the API url, the UI url, and the pid.
Without `--detach` it runs in the foreground until Ctrl-C, which is for a human, not for you.

**It closes itself when the work is done**, like any editor program:

| it ends when | |
|---|---|
| the human closes the editor window | after a few seconds' grace, so a reload does not count |
| you call `POST /api/shutdown` | do this when the human says they are finished |
| nobody opens a window within 5 minutes | a launch nobody used should not linger |
| an hour passes with no activity | backstop for a forgotten tab |

`--keep-alive` opts out of all of that, and `--no-open` skips opening the browser.

Every run starts its **own** session. Session is recorded in `.metacode/scenelab-editor.json` as `{ api, ui, scene, pid, vitePid, electronPid }`.

Use `pnpm exec tsx skills/editor/stop.ts` for shutdown.

> **Dedicated Electron app:** Browser editor (`skills/editor/editor.ts --detach`) auto-launches via agent and works inside Claude Code sandbox. Electron native window (`apps/editor-electron/src/main.ts`) requires a separate terminal outside Claude Code on macOS due to Mach bootstrap (`bootstrap_check_in Permission denied`). In `--detach` mode it starts server+vitel (API works) and prints the command to open native window: `pnpm --filter @scenelab/editor-electron exec electron --no-sandbox dist/main.cjs --window --api=http://localhost:7317`. Foreground `pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new` works when run in your own terminal.

> **Agent UX:** When you launch, include API URL and browser URL in final answer:
> ```
> SceneLab editor session is live:
>   API: http://localhost:7317
>   Scene: sample - 3 primitives
>
> What should we build?
> http://localhost:5173
> ```

Everything below is run BY YOU, in this session — the human works in the browser and asks for
changes in chat. They should not need a terminal.

## Building from empty

`--new` opens a valid but empty scene: a root group, a camera, no content. Add nodes with
`node.add`, one per thing, and the whole construction lands in the correction log rather than only
the edits made after some first draft existed.

```bash
curl -s -X POST localhost:7317/api/events -H 'content-type: application/json' -d '{
  "source":"agent",
  "events":[{"type":"node.add","parent":"root","index":0,"node":{
    "id":"sun","kind":"group","word":"sun",
    "transform":{"position":{"kind":"const","value":{"x":0,"y":120,"z":0}},
                 "rotation":{"kind":"const","value":{"axis":{"x":0,"y":0,"z":1},"angle":0}},
                 "scale":{"kind":"const","value":{"x":1,"y":1,"z":1}},"anchor":{"x":0,"y":0,"z":0}},
    "children":[],
    "components":{"circle":{"kind":"const","value":{"radius":140,
      "style":{"fill":{"kind":"const","value":{"r":1,"g":0.42,"b":0.53,"a":1}}}}}}}}]}'
```

A node needs a full `transform` (all four fields) and at most one drawable component. Build the
whole thing this way for a small scene; for anything repetitive, add one `arrangement` or
`behavior` node carrying the program rather than many siblings.

## Read the scene

```bash
curl -s localhost:7317/api/summary   # ids, words, primitive count, duration — start here
#          ^ use the api url the launcher printed; 7317 is only the default
curl -s localhost:7317/api/scene     # the whole scene graph
curl -s localhost:7317/api/log       # correction log, as records and as JSONL
curl -s localhost:7317/api/pair      # before/after + events, ready to keep
```

`/api/summary` is the cheap one: it tells you which node ids exist and what they are called, which
is what you need before composing an edit.

## Edit the scene

```bash
curl -s -X POST localhost:7317/api/events \
  -H 'content-type: application/json' \
  -d '{
        "source": "agent",
        "agent": "avocado",
        "events": [
          {"type":"node.translate","target":"circle_1",
           "from":{"x":0,"y":0,"z":0},"to":{"x":120,"y":40,"z":0}}
        ]
      }'
```

Events are `CorrectionEvent`s from `packages/scene-ir/src/types.ts` — the same vocabulary the
widgets emit when a human drags something. Useful ones:

| intent | event |
|---|---|
| move / resize / turn | `node.translate`, `node.scale`, `node.rotate` |
| show / hide | `node.setEnabled` |
| restyle, or any component field | `component.upsert`, `component.setProp` |
| structure | `node.add`, `node.remove`, `node.reparent`, `node.group`, `node.ungroup` |
| one stamped instance | `override.set`, `override.remove` |
| **the program itself** | `behavior.setParams`, `behavior.setDuration`, `forEach.setOverride` |

That last row is the one worth reaching for on a procedural scene: editing an action inside a
`forEach` template changes every row at once, so "make the moves slower" is one event rather than
one per move.

Send several events in one request to make them a unit, and pass a `transactionId` if they should
also **retract** as a unit.

## Undo

```bash
curl -s -X POST localhost:7317/api/retract \
  -H 'content-type: application/json' \
  -d '{"retracts":"e3","reason":"overshot"}'
```

`retracts` takes an entry id from `/api/log` or a `transactionId`. Undo is a retraction, not an
inverse edit: the original stays in the log, marked as no longer counting, because "tried it and
backed it out" is different evidence from "never tried it" (Design §3.6).

## Finishing

When the human says they are done, close it rather than leaving it running:

```bash
curl -s -X POST localhost:7317/api/pair > correction-pair.json   # keep the session's work first
curl -s -X POST localhost:7317/api/shutdown
```

## Rules

- **Go through the API, not the file.** Writing `scene.json` directly bypasses the log, so the edit
  produces no correction data and the human's browser never sees it.
- **A rejected batch changes nothing.** Events are applied to a copy first; if any fails you get
  `422` with the failing index and the scene is untouched.
- **Read before you write.** Targets are node ids, not words: `/api/summary` lists both.

## When not to use

- Generating a scene from a prompt — that is `scripts/generate.ts`.
- Comparing models across many trials — that is `skills/batch-compare`.
- Checking a scene is sound without editing it — that is `scripts/validate.ts`.
