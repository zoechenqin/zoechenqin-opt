# SceneLab Editor Skill

Opens a scene in the browser editor with an HTTP API in front of it, so an agent and a human edit
the **same** scene. Every edit from either side is logged as a correction tagged with its source.
See `SKILL.md` for the agent-facing reference.

## Quick Start

```bash
# from the repo root
pnpm exec tsx skills/editor/editor.ts                     # sample scene
pnpm exec tsx skills/editor/editor.ts my-scene.json --save
```

Then open http://localhost:5173. The terminal prints the API URL and the curl commands an agent
needs.

## What it is for

Authoring or fixing one scene interactively, and collecting correction pairs while you do. The
agent has its own model access; this only supplies the shared scene, so there is no API key, no
proxy to a model gateway, and nothing to configure.

## Layout

| file | role |
|---|---|
| `editor.ts` | launcher — starts the scene server and the vite UI, prints the agent's commands |
| `server.ts` | the scene server: canonical `Scene` + `CorrectionLog`, HTTP + SSE |
| `SKILL.md` | agent-facing reference: endpoints, event vocabulary, rules |
