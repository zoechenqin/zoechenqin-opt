/**
 * ACP client — the editor's own metacode session.
 *
 * metacode speaks the Agent Client Protocol (`metacode acp`): JSON-RPC over stdio, where the
 * agent pushes `session/update` notifications as it thinks, calls tools, and replies. That is the
 * same event stream the terminal TUI renders, so nothing is lost by hosting the session here —
 * the editor is simply a different renderer over it.
 *
 * Why this and not a one-shot `metacode run` per prompt: iteration needs the model to remember
 * what it built. ACP sessions are long-lived and addressable, so turn two can say "make it
 * faster" and mean the thing on screen. Resetting is `session/new`, not process management.
 *
 * The process is spawned lazily on the first prompt and stays warm until reset or shutdown.
 */

import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process'

/** Matches metacode's own sandbox failing to apply — happens when it is launched from inside
 *  another sandbox (a metacode session, Claude Code). Same detection batch-compare uses. */
const isSandboxApplyError = (text: string): boolean =>
  /sandbox_apply|sandbox-exec|Operation not permitted/i.test(text)

export type ToolCallStatus = 'pending' | 'in_progress' | 'completed' | 'failed'

export interface ToolCall {
  id: string
  title: string
  /** ACP's coarse classification: 'edit' | 'read' | 'execute' | 'think' | 'other'. */
  kind: string
  status: ToolCallStatus
  /** Files the call touched, when it reports any. */
  locations: string[]
}

export interface Turn {
  id: number
  role: 'user' | 'agent'
  /** The visible reply, accumulated from `agent_message_chunk`. */
  text: string
  /** Reasoning, accumulated from `agent_thought_chunk`. Verbose; the UI collapses it. */
  thought: string
  toolCalls: ToolCall[]
  startedAt: number
  finishedAt: number | null
  /** Set once the turn ends: 'end_turn' | 'cancelled' | 'max_tokens' | … */
  stopReason: string | null
  error: string | null
}

export interface AgentSessionState {
  /** Null until the first prompt spawns the process. */
  sessionId: string | null
  running: boolean
  /** True while a prompt turn is in flight. */
  busy: boolean
  model: string | null
  availableModels: Array<{ modelId: string; name: string }>
  turns: Turn[]
  /** Cumulative context usage reported by `usage_update`. */
  usage: { used: number; size: number } | null
  lastError: string | null
}

interface Pending {
  resolve: (v: unknown) => void
  reject: (e: Error) => void
}

const MAX_TURNS = 200

export class AcpSession {
  private child: ChildProcessWithoutNullStreams | null = null
  private buf = ''
  private nextId = 1
  private pending = new Map<number, Pending>()
  private turnSeq = 0
  private sandboxBypass = false
  private stderrTail = ''

  private state: AgentSessionState = {
    sessionId: null,
    running: false,
    busy: false,
    model: null,
    availableModels: [],
    turns: [],
    usage: null,
    lastError: null,
  }

  /** Session this briefing has already been delivered to; null when it still needs one. */
  private briefedSession: string | null = null

  constructor(
    private readonly cwd: string,
    /** Called on every state change so the server can push SSE. */
    private readonly onChange: () => void,
    /** Prepended to the first prompt of each session — see prompt(). */
    private readonly briefing: () => string,
  ) {}

  getState(): AgentSessionState {
    return this.state
  }

  private touch(): void {
    this.onChange()
  }

  private currentTurn(): Turn | null {
    for (let i = this.state.turns.length - 1; i >= 0; i--) {
      const t = this.state.turns[i]
      if (t && t.role === 'agent' && t.finishedAt === null) return t
    }
    return null
  }

  // --- process ---------------------------------------------------------------

  private spawnChild(bypassSandbox: boolean): ChildProcessWithoutNullStreams {
    const args = ['acp', '--pure', '--yolo']
    if (bypassSandbox) args.unshift('--dangerously-disable-osx-sandbox')
    const child = spawn('metacode', args, {
      cwd: this.cwd,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, NO_COLOR: '1', METACODE_NON_META_ALLOWED: 'true' },
    })
    // Claim it immediately so the handlers below can tell "my child" from a predecessor's. The
    // sandbox retry means two children can briefly overlap, and a dead one's late `exit` must not
    // tear down its replacement's session.
    this.child = child
    this.buf = ''

    child.stdout.setEncoding('utf-8')
    child.stdout.on('data', (d: string) => {
      if (this.child !== child) return
      this.onStdout(d)
    })
    child.stderr.setEncoding('utf-8')
    child.stderr.on('data', (d: string) => {
      if (this.child !== child) return
      this.stderrTail = (this.stderrTail + d).slice(-4000)
    })
    child.on('exit', (code) => {
      if (this.child !== child) return // superseded (sandbox retry, or an explicit stop)
      // Dying before a session exists is a startup failure: ensureStarted() will either retry
      // without the sandbox or reject, so leave the in-flight turn alone and let it decide.
      const hadSession = this.state.sessionId !== null
      this.child = null
      this.state.running = false
      this.state.sessionId = null
      for (const [, p] of this.pending) p.reject(new Error(`metacode acp exited (code ${code})`))
      this.pending.clear()
      if (hadSession) {
        this.state.busy = false
        const turn = this.currentTurn()
        if (turn) {
          turn.finishedAt = Date.now()
          turn.error = `agent exited (code ${code})`
        }
      }
      this.touch()
    })
    return child
  }

  /** Start the process and open a session. Safe to call when one is already live. */
  async ensureStarted(): Promise<void> {
    if (this.child && this.state.sessionId) return

    const attempt = async (bypass: boolean): Promise<void> => {
      this.stderrTail = ''
      this.spawnChild(bypass) // claims this.child itself
      this.state.running = true
      await this.request('initialize', {
        protocolVersion: 1,
        // The agent has its own file tools; we do not offer ours, which keeps this client small.
        clientCapabilities: { fs: { readTextFile: false, writeTextFile: false } },
      })
      const created = (await this.request('session/new', {
        cwd: this.cwd,
        mcpServers: [],
      })) as {
        sessionId?: string
        models?: { currentModelId?: string; availableModels?: Array<{ modelId: string; name: string }> }
      }
      this.state.sessionId = created.sessionId ?? null
      this.state.model = created.models?.currentModelId ?? null
      this.state.availableModels = created.models?.availableModels ?? []
    }

    try {
      await attempt(this.sandboxBypass)
    } catch (e) {
      // metacode's sandbox cannot nest. Detect, bypass, and remember for later restarts.
      if (!this.sandboxBypass && isSandboxApplyError(this.stderrTail + (e as Error).message)) {
        this.sandboxBypass = true
        this.stop()
        await attempt(true)
      } else {
        this.state.lastError = (e as Error).message
        this.stop()
        throw e
      }
    }
    this.state.lastError = null
    this.touch()
  }

  /**
   * Kill the process. The next prompt starts a fresh session.
   *
   * Deliberately does not clear `busy`: this is also how the sandbox retry discards a failed
   * child, and that happens mid-turn. prompt()'s `finally` owns `busy`.
   */
  stop(): void {
    if (this.child) {
      try {
        this.child.kill('SIGTERM')
      } catch {}
    }
    this.child = null
    this.state.running = false
    this.state.sessionId = null
  }

  /** Discard this session and its transcript, then open a new one. */
  async reset(): Promise<void> {
    this.stop()
    this.state.busy = false
    this.state.turns = []
    this.state.usage = null
    this.state.lastError = null
    this.turnSeq = 0
    this.briefedSession = null
    this.touch()
    await this.ensureStarted()
  }

  // --- JSON-RPC --------------------------------------------------------------

  private write(obj: unknown): void {
    if (!this.child) throw new Error('agent not running')
    this.child.stdin.write(JSON.stringify(obj) + '\n')
  }

  private request(method: string, params: unknown): Promise<unknown> {
    const id = this.nextId++
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject })
      try {
        this.write({ jsonrpc: '2.0', id, method, params })
      } catch (e) {
        this.pending.delete(id)
        reject(e as Error)
      }
    })
  }

  private onStdout(chunk: string): void {
    this.buf += chunk
    let i: number
    while ((i = this.buf.indexOf('\n')) !== -1) {
      const line = this.buf.slice(0, i).trim()
      this.buf = this.buf.slice(i + 1)
      if (!line) continue
      let msg: Record<string, unknown>
      try {
        msg = JSON.parse(line) as Record<string, unknown>
      } catch {
        continue // metacode prints a banner before the protocol starts
      }
      this.dispatch(msg)
    }
  }

  private dispatch(msg: Record<string, unknown>): void {
    const id = msg.id as number | undefined
    const method = msg.method as string | undefined

    // A reply to something we sent.
    if (id !== undefined && method === undefined) {
      const p = this.pending.get(id)
      if (!p) return
      this.pending.delete(id)
      if (msg.error) p.reject(new Error(JSON.stringify(msg.error)))
      else p.resolve(msg.result)
      return
    }

    // A request FROM the agent. --yolo suppresses permission prompts, but answer anyway so a
    // policy change upstream cannot deadlock a turn.
    if (id !== undefined && method !== undefined) {
      if (/permission/i.test(method)) {
        const params = (msg.params ?? {}) as { options?: Array<{ optionId?: string }> }
        const optionId = params.options?.[0]?.optionId ?? 'allow'
        this.write({ jsonrpc: '2.0', id, result: { outcome: { outcome: 'selected', optionId } } })
      } else {
        this.write({ jsonrpc: '2.0', id, error: { code: -32601, message: `unsupported: ${method}` } })
      }
      return
    }

    if (method === 'session/update') this.onSessionUpdate(msg.params as Record<string, unknown>)
  }

  private onSessionUpdate(params: Record<string, unknown>): void {
    const update = (params?.update ?? {}) as Record<string, unknown>
    const kind = update.sessionUpdate as string
    const turn = this.currentTurn()

    switch (kind) {
      case 'agent_message_chunk': {
        const content = update.content as { text?: string } | undefined
        if (turn && content?.text) turn.text += content.text
        break
      }
      case 'agent_thought_chunk': {
        const content = update.content as { text?: string } | undefined
        if (turn && content?.text) turn.thought += content.text
        break
      }
      case 'tool_call': {
        if (!turn) break
        turn.toolCalls.push({
          id: (update.toolCallId as string) ?? `call_${turn.toolCalls.length}`,
          title: (update.title as string) ?? 'tool',
          kind: (update.kind as string) ?? 'other',
          status: ((update.status as ToolCallStatus) ?? 'pending'),
          locations: ((update.locations ?? []) as Array<{ path?: string }>).map((l) => l.path ?? '').filter(Boolean),
        })
        break
      }
      case 'tool_call_update': {
        if (!turn) break
        const callId = update.toolCallId as string
        const call = turn.toolCalls.find((c) => c.id === callId)
        if (!call) break
        if (update.status) call.status = update.status as ToolCallStatus
        const locs = ((update.locations ?? []) as Array<{ path?: string }>).map((l) => l.path ?? '').filter(Boolean)
        if (locs.length > 0) call.locations = locs
        break
      }
      case 'usage_update': {
        this.state.usage = { used: (update.used as number) ?? 0, size: (update.size as number) ?? 0 }
        break
      }
      default:
        break // available_commands_update, plan updates, anything metacode adds later
    }
    this.touch()
  }

  // --- prompting -------------------------------------------------------------

  /**
   * Send a prompt and resolve when the turn ends. The transcript updates as events arrive, so
   * callers that only want to stream can ignore the promise.
   */
  async prompt(text: string): Promise<Turn> {
    if (this.state.busy) throw new Error('a turn is already in flight')

    // Record the turn and go busy BEFORE starting the process. Spawning metacode and opening a
    // session takes seconds, and a UI showing "idle, no turns" for that window looks broken.
    this.state.turns.push({
      id: ++this.turnSeq,
      role: 'user',
      text,
      thought: '',
      toolCalls: [],
      startedAt: Date.now(),
      finishedAt: Date.now(),
      stopReason: null,
      error: null,
    })
    const turn: Turn = {
      id: ++this.turnSeq,
      role: 'agent',
      text: '',
      thought: '',
      toolCalls: [],
      startedAt: Date.now(),
      finishedAt: null,
      stopReason: null,
      error: null,
    }
    this.state.turns.push(turn)
    if (this.state.turns.length > MAX_TURNS) this.state.turns = this.state.turns.slice(-MAX_TURNS)
    this.state.busy = true
    this.touch()

    try {
      await this.ensureStarted()
      // Brief the session, not the transcript. A session that died and respawned needs telling
      // again, and the transcript may already be long by then. The user turn above records the
      // raw prompt, so the panel shows what was typed rather than the briefing.
      const briefed = this.briefedSession !== this.state.sessionId
      const message = briefed ? `${this.briefing()}\n\n---\n\n${text}` : text
      this.briefedSession = this.state.sessionId

      const result = (await this.request('session/prompt', {
        sessionId: this.state.sessionId,
        prompt: [{ type: 'text', text: message }],
      })) as { stopReason?: string }
      turn.stopReason = result?.stopReason ?? 'end_turn'
    } catch (e) {
      turn.error = (e as Error).message
      this.state.lastError = turn.error
    } finally {
      turn.finishedAt = Date.now()
      this.state.busy = false
      this.touch()
    }
    return turn
  }

  /** Best-effort interrupt of the in-flight turn. */
  async cancel(): Promise<void> {
    if (!this.child || !this.state.busy) return
    try {
      this.write({ jsonrpc: '2.0', method: 'session/cancel', params: { sessionId: this.state.sessionId } })
    } catch {
      this.stop()
    }
    this.touch()
  }
}
