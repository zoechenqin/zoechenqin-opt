/**
 * Launch SceneLab editor with a scene an agent can edit alongside you.
 *
 * Starts: scene server (canonical Scene + log + UI layout) + playground vite dev.
 * Browser is one client, MetaCode is another, both submit correction events.
 *
 * Usage:
 *   pnpm exec tsx skills/editor/editor.ts --new                 # empty
 *   pnpm exec tsx skills/editor/editor.ts                       # sample
 *   pnpm exec tsx skills/editor/editor.ts --detach              # return once up (agents)
 *   pnpm exec tsx skills/editor/editor.ts --port=7400
 */
import { spawn } from 'node:child_process'
import { createServer } from 'node:net'
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, openSync } from 'node:fs'
import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadScene, startSceneServer } from './server'

const DEFAULT_PORT = 7317
const CLOSE_GRACE_S = 8
const OPEN_TIMEOUT_S = 300
const IDLE_TIMEOUT_S = 3600
const SESSION_FILE = fileURLToPath(new URL('../../.metacode/scenelab-editor.json', import.meta.url))
const UI_LOG = fileURLToPath(new URL('../../.metacode/scenelab-editor-ui.log', import.meta.url))
const MAIN_LOG = fileURLToPath(new URL('../../.metacode/scenelab-editor.log', import.meta.url))

async function freePort(from: number): Promise<number> {
  for (let p = from; p < from + 50; p++) {
    const open = await new Promise<boolean>((resolve) => {
      const s = createServer()
      s.once('error', () => resolve(false))
      s.once('listening', () => s.close(() => resolve(true)))
      s.listen(p, '127.0.0.1')
    })
    if (open) return p
  }
  throw new Error(`editor: no free port in ${from}..${from + 50}`)
}

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms))

async function shutdownPrevious(): Promise<void> {
  if (!existsSync(SESSION_FILE)) return
  try {
    const raw = readFileSync(SESSION_FILE, 'utf-8')
    const s = JSON.parse(raw) as { api?: string | null; pid?: number; vitePid?: number; launching?: boolean }
    if (s.launching) {
      // Placeholder from detach wrapper — don't kill its pid (that's us or our parent)
      return
    }
    if (s.api) {
      try {
        await fetch(`${s.api}/api/shutdown`, { method: 'POST', signal: AbortSignal.timeout(1000) })
      } catch {}
    }
    if (s.pid && s.pid !== process.pid) {
      try { process.kill(s.pid, 'SIGTERM') } catch {}
    }
    if (s.vitePid) {
      try { process.kill(s.vitePid, 'SIGTERM') } catch {}
    }
  } catch {}
  // Wait briefly for ports to free
  for (let i = 0; i < 10; i++) {
    await sleep(200)
    const p = await freePort(DEFAULT_PORT).catch(() => null)
    if (p === DEFAULT_PORT) break
  }
}

async function detach(argv: string[]): Promise<void> {
  mkdirSync(dirname(SESSION_FILE), { recursive: true })
  writeFileSync(MAIN_LOG, `[${new Date().toISOString()}] detach requested: ${argv.join(' ')}\n`, { flag: 'w' })
  try { ensureClickableLaunchers() } catch {}
  await shutdownPrevious()
  rmSync(SESSION_FILE, { force: true })
  try {
    writeFileSync(SESSION_FILE, JSON.stringify({ api: null, ui: null, launching: true, pid: process.pid }, null, 2))
  } catch {}

  const self = fileURLToPath(import.meta.url)
  const logFd = openSync(MAIN_LOG, 'a')
  const child = spawn('pnpm', ['exec', 'tsx', self, ...argv.filter((a) => a !== '--detach')], {
    detached: true,
    stdio: ['ignore', logFd, logFd],
    env: process.env,
  })
  child.unref()

  for (let i = 0; i < 50; i++) {
    await sleep(500)
    if (!existsSync(SESSION_FILE)) continue
    let s: { api: string | null; ui: string | null }
    try { s = JSON.parse(readFileSync(SESSION_FILE, 'utf-8')) as { api: string | null; ui: string | null } }
    catch { continue }
    if (!s.api) continue
    if (s.ui === null && !argv.includes('--no-ui')) continue
    try {
      const res = await fetch(`${s.api}/api/summary`, { signal: AbortSignal.timeout(700) })
      if (res.ok) {
        const sum = (await res.json()) as { id: string; primitives: number }
        const electronLauncher = fileURLToPath(new URL('../../.metacode/open-electron.command', import.meta.url))
        const fileUrl = `file://${electronLauncher}`
        const osc = (url: string, label?: string) => `\x1b]8;;${url}\x1b\\${label ?? url}\x1b]8;;\x1b\\`
        console.log(`\n  Welcome to SceneLab — dedicated editor is live.\n`)
        console.log(`  ● Connected · API ${s.api} · UI ${s.ui!} (cmd+double click)`)
        console.log(`\n  Blank canvas ready — tell me what to build.\n`)
        return
      }
    } catch {}
    // Detect early child death
    try {
      process.kill(child.pid!, 0)
    } catch {
      console.error(`editor: child died. Tail ${MAIN_LOG}:`)
      try { console.error(readFileSync(MAIN_LOG, 'utf-8').slice(-3000)) } catch {}
      process.exit(1)
    }
  }
  console.error(`editor: the session did not come up within 25s; see ${MAIN_LOG} and ${UI_LOG}`)
  try { console.error(readFileSync(MAIN_LOG, 'utf-8').slice(-3000)) } catch {}
  process.exit(1)
}

function ensureClickableLaunchers(): void {
  try {
    const root = fileURLToPath(new URL('../../', import.meta.url))
    const electronScript = `#!/bin/bash
cd "${root}"
./apps/editor-electron/node_modules/.bin/electron --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=http://localhost:7317
`
    const serverScript = `#!/bin/bash
set -e
cd "${root}"
rm -f .metacode/scenelab-electron.log
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo "server pid $!"
sleep 3
for i in 1 2 3 4 5 6 7 8 9 10; do curl -s http://localhost:5173 > /dev/null && echo "vite up at http://localhost:5173" && break; sleep 0.5; done
curl -s http://localhost:7317/api/summary
`
    // Electron only
    writeFileSync(fileURLToPath(new URL('../../Electron.command', import.meta.url)), electronScript, { mode: 0o755 })
    // Server only
    writeFileSync(fileURLToPath(new URL('../../Server.command', import.meta.url)), serverScript, { mode: 0o755 })
    // Note: SceneLab.command (main combined) is generated by editor-electron main.ts ensureClickableLaunchers
  } catch {}
}

async function main(): Promise<void> {
  const argv = process.argv.slice(2)
  const scenePath = argv.find((a) => !a.startsWith('--'))
  const flag = (name: string): string | undefined => argv.find((a) => a.startsWith(`--${name}=`))?.split('=')[1]
  const save = argv.includes('--save')
  const headless = argv.includes('--no-ui')

  if (scenePath && !existsSync(scenePath)) {
    console.error(`editor: no such scene file: ${scenePath}`)
    process.exit(1)
  }
  if (argv.includes('--detach')) return detach(argv)

  ensureClickableLaunchers()
  // Clean previous stale before starting new (foreground path also)
  await shutdownPrevious()

  const port = await freePort(Number(flag('port') ?? DEFAULT_PORT))
  const isNew = argv.includes('--new')
  const space = flag('space') === '3d' ? '3d' : '2d'
  const scene = loadScene(scenePath, { empty: isNew, space })
  const keepAlive = argv.includes('--keep-alive')

  let ui: ReturnType<typeof spawn> | undefined
  let stopping = false
  const stop = async (reason: string): Promise<void> => {
    if (stopping) return
    stopping = true
    console.log(`\n  Editor closed — ${reason}.`)
    try { ui?.kill() } catch {}
    // Kill vite process tree — ui.kill() may leave pnpm wrapper
    try {
      if (ui?.pid) {
        // Best effort kill its children via pkill -P on mac
        spawn('pkill', ['-P', String(ui.pid)], { stdio: 'ignore' }).unref()
      }
    } catch {}
    rmSync(SESSION_FILE, { force: true })
    await server.close()
    process.exit(0)
  }

  const server = await startSceneServer({
    scene,
    port,
    ...(save && scenePath ? { savePath: scenePath } : {}),
    onShutdown: (reason) => void stop(reason),
  })
  const api = `http://localhost:${server.port}`

  let uiUrl: string | null = null
  const announce = (): void => {
    writeFileSync(
      SESSION_FILE,
      JSON.stringify({ api, ui: uiUrl, scene: scenePath ?? null, pid: process.pid, vitePid: ui?.pid ?? null }, null, 2),
    )
  }

  if (!headless) {
    mkdirSync(dirname(UI_LOG), { recursive: true })
    writeFileSync(UI_LOG, '')
    ui = spawn('pnpm', ['--filter', '@scenelab/playground', 'dev'], {
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, SCENELAB_API: api },
    })
    const onOut = (buf: Buffer): void => {
      const text = String(buf)
      writeFileSync(UI_LOG, text, { flag: 'a' })
      const m = /(http:\/\/localhost:\d+)\//.exec(text)
      if (m && !uiUrl) {
        uiUrl = m[1] as string
        announce()
      }
      process.stdout.write(text)
    }
    ui.stdout?.on('data', onOut)
    ui.stderr?.on('data', onOut)
    ui.on('error', (e) => console.error(`editor: could not start UI — ${e.message}`))
  }

  announce()
  console.log(`\n  Welcome to SceneLab — dedicated editor is live.\n`)
  console.log(`  ● Connected · API ${api} · UI ${uiUrl ?? '(waiting)'} (cmd+double click)`)
  console.log(`\n  Blank canvas ready — tell me what to build.\n`)

  process.on('SIGINT', () => void stop('interrupted'))
  process.on('SIGTERM', () => void stop('terminated'))

  if (!keepAlive && !headless) {
    let everOpened = false
    let emptySince: number | null = null
    setInterval(() => {
      const viewers = server.viewers()
      if (viewers > 0) {
        everOpened = true
        emptySince = null
        return
      }
      if (!everOpened) {
        if (server.idleFor() > OPEN_TIMEOUT_S) void stop('no editor window opened')
        return
      }
      emptySince ??= Date.now()
      if ((Date.now() - emptySince) / 1000 > CLOSE_GRACE_S) void stop('editor window closed')
    }, 1000).unref?.()

    setInterval(() => {
      if (server.idleFor() > IDLE_TIMEOUT_S) void stop('idle')
    }, 30_000).unref?.()
  }
}

void main()
