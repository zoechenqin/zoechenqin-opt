/**
 * SceneLab Batch Compare — AGENT MODE.
 *
 * Runs each model as an interactive MetaCode agent with full access to an isolated copy
 * of the SceneLab source (SWE-bench style): the model reads the Scene IR types/schema and
 * the foundation spec, then WRITES a scene-graph JSON. We then validate it with parseScene,
 * render it to a Manim video, and score consistency across n trials per model.
 *
 * This deliberately mirrors real usage (an agent generating a scene against the codebase)
 * rather than a one-shot API completion. The reference/prior outputs (trials/, scripts/) are
 * NOT copied into the agent's scratch dir, so there is nothing to plagiarize.
 *
 * Usage (from repo root):
 *   export METACODE_NON_META_ALLOWED=true      # needed for anthropic/* models
 *   pnpm exec tsx skills/batch-compare/batch-compare.ts trials/hanoi --trials=2
 *
 * Flags:
 *   --trials=N            runs per model (default 1)
 *   --models=a,b          override models.txt (keys from MODELS below)
 *   --model-timeout=SEC   per-agent-run wall clock (default 600)
 *   --no-render           skip Docker/Manim render (scene.json only)
 */

import { execFileSync } from 'node:child_process'
import {
  mkdirSync,
  writeFileSync,
  readFileSync,
  cpSync,
  rmSync,
  existsSync,
  readdirSync,
  statSync,
  mkdtempSync,
} from 'node:fs'
import { join, basename } from 'node:path'
import { tmpdir } from 'node:os'

import { IR_RULES, behaviorOf, parseScene, safeParseScene, simulate, type BTNode, type Scene, type Entity } from '@scenelab/scene-ir'
import { toManim, manimTimeMap } from '@scenelab/manim-adapter'
import { renderToMp4, compositeOverlay } from '@scenelab/canvas-render'
import { renderSceneToMp4 as threeRenderToMp4 } from '@scenelab/three-export'

const MODELS: Record<string, { id: string; name: string }> = {
  avocado: { id: 'meta/avocado-tester', name: 'Avocado (tester)' },
  gpt: { id: 'openai/gpt-5.5', name: 'GPT-5.5' },
  opus: { id: 'anthropic/claude-opus-4-8', name: 'Claude Opus 4' },
}

const REPO_ROOT = process.cwd()

interface TrialResult {
  model: string
  modelName: string
  run: number
  success: boolean
  entityCount?: number
  curveCount?: number
  actionCount?: number
  durationSec?: number
  rendered?: boolean
  canvasRendered?: boolean
  threeRendered?: boolean
  /** Schedule entries the behavior trees produced. 0 with a tree present means nothing moves. */
  scheduleCount?: number
  /** Anything simulation could not resolve — a script that threw lands here. */
  unresolved?: string[]
  error?: string
  /** Why manim failed, when it did. Kept apart from `error`, which means the trial failed. */
  renderError?: string
}

// ----------------------------------------------------------------------------
// scratch: an isolated, contamination-free copy of the SceneLab source
// ----------------------------------------------------------------------------

/**
 * Populate `scratch` with a RUNNABLE copy of the SceneLab repo — full source plus a symlinked
 * node_modules — so the agent runs under the SAME conditions codimango gives it: it can read the
 * codebase AND write + execute generator code (`pnpm exec tsx …`) to produce the scene. This is
 * what makes batch-compare a faithful preview of a SWE-bench submission; an unrunnable scratch
 * would artificially force one-shot generation and overstate difficulty. `trials/`, `.git`, and
 * build output are excluded (nothing to plagiarize, keep it light).
 */
function setupScratch(scratch: string): void {
  const skip = new Set(['node_modules', '.git', 'trials', 'dist', 'coverage', 'media', '.turbo'])
  cpSync(REPO_ROOT, scratch, {
    recursive: true,
    filter: (p) => !p.split('/').some((seg) => skip.has(seg)),
  })
  // Install deps so the agent can write & run generators (`pnpm exec tsx`, import @scenelab/*).
  // ~1-2s with a warm pnpm store; a symlinked node_modules does NOT resolve workspace packages.
  // `--ignore-scripts`: the agent needs none of the render deps' postinstalls — critically it skips
  // ffmpeg-static's ~80MB binary download (pulled in transitively via @scenelab/canvas-render),
  // which would otherwise run on every scratch. The host process (not the scratch) does rendering.
  execFileSync('pnpm', ['install', '--frozen-lockfile', '--ignore-scripts'], { cwd: scratch, stdio: 'pipe' })
}

function buildInstruction(prompt: string): string {
  return [
    'You are working in a checkout of the SceneLab repo (a pnpm/TypeScript monorepo). Produce a',
    'SceneLab "scene graph": a renderer-agnostic JSON description validated by the zod schema in',
    'packages/scene-ir and rendered to video (canvas / manim / three.js).',
    '',
    'Request:',
    `  "${prompt}"`,
    '',
    'Use the repo however you like — read packages/scene-ir/src (types.ts, schema.ts, builders,',
    'animatable, resolve) and, if helpful, WRITE AND RUN code to generate the scene (e.g. write a',
    'generator and run `pnpm exec tsx yourgen.ts`). node_modules is installed, so tsx and',
    '@scenelab/* work.',
    '',
    'HARD REQUIREMENTS:',
    ...IR_RULES,
    '',
    'Write the final scene graph as pretty-printed JSON to a file named exactly scene.json in the',
    'repo root (the bare Scene object: schemaVersion, id, space, canvas, camera, root — not wrapped).',
    '',
    'THEN VALIDATE IT, and do not stop until it passes:',
    '    pnpm exec tsx scripts/validate.ts scene.json',
    'It parses the scene, resolves it, runs the behavior trees, and fails on the ways a scene can',
    'look fine and render nothing: a script that throws (so the schedule is empty and the video is a',
    'still frame), a scene that resolves to no drawables, templates nothing stamps, or motion that',
    'is declared but never changes a position. It also WARNS about motion that stops early (leaving',
    'a frozen tail) and about components no renderer reads — note that light/rigidbody/collider/',
    'constraint/link/skeleton are accepted by the schema but currently draw NOTHING, so do not rely',
    'on them for anything that must be visible. A scene graph that renders is NOT evidence it works.',
    'Fix whatever it reports and run it again. Passing validation is part of the task.',
    '',
    'When done, reply with only: DONE.',
  ].join('\n')
}

// ----------------------------------------------------------------------------
// run one agent trial
// ----------------------------------------------------------------------------

// metacode confines the agent with its own macOS sandbox (sandbox-exec). That fails to apply when
// metacode is launched from INSIDE another managed sandbox — i.e. when this skill runs under
// another agent (Avocado/MetaCode) or Claude Code: `sandbox_apply: Operation not permitted`. We
// keep the sandbox ON by default and AUTO-FALL-BACK to --dangerously-disable-osx-sandbox only when
// we detect that failure (then remember it so later runs skip the wasted first attempt).
// SCENELAB_METACODE_UNSANDBOXED=1 forces the bypass up front (skips the probe).
let metacodeUnsandboxed = !!process.env.SCENELAB_METACODE_UNSANDBOXED
const isSandboxApplyError = (e: unknown): boolean => {
  const err = e as { stderr?: string; message?: string }
  return /sandbox_apply|Operation not permitted|mach_port|sandbox-exec/i.test(`${err?.stderr ?? ''}${err?.message ?? ''}`)
}

function runAgent(
  modelId: string,
  scratch: string,
  instruction: string,
  timeoutSec: number,
  variant?: string,
): string {
  // --pure avoids the (network-failing) external plugin install; --yolo bypasses tool
  // permission prompts; --dir scopes the agent to the scratch copy; --format text keeps
  // stdout clean (the scene lands in scene.json, not stdout). --variant caps reasoning
  // effort (e.g. "low"/"minimal") so thorough models don't over-deliberate on a bounded task.
  const attempt = (disableSandbox: boolean): string => {
    const args = ['run', '-m', modelId, '--pure', '--dir', scratch, '--yolo', '--format', 'text', '--timeout', String(timeoutSec)]
    if (variant) args.push('--variant', variant)
    if (disableSandbox) args.push('--dangerously-disable-osx-sandbox')
    args.push(instruction)
    return execFileSync('metacode', args, {
      encoding: 'utf-8',
      maxBuffer: 32 * 1024 * 1024,
      timeout: (timeoutSec + 60) * 1000, // grace over metacode's own timeout
      env: { ...process.env, METACODE_NON_META_ALLOWED: 'true', NO_COLOR: '1' },
    })
  }
  try {
    return attempt(metacodeUnsandboxed)
  } catch (e) {
    if (!metacodeUnsandboxed && isSandboxApplyError(e)) {
      metacodeUnsandboxed = true // nested sandbox → bypass metacode's own sandbox for the rest of the batch
      return attempt(true)
    }
    throw e
  }
}

/** Pull a JSON object out of model stdout as a fallback when scene.json wasn't written. */
function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i)
  const candidate = fenced?.[1] ?? text
  const start = candidate.indexOf('{')
  const end = candidate.lastIndexOf('}')
  if (start === -1 || end === -1 || end < start) throw new Error('no JSON object in output')
  return JSON.parse(candidate.slice(start, end + 1))
}

/** Accept a bare Scene or a {scene} wrapper. */
function coerceScene(raw: unknown): Scene {
  const obj = raw as Record<string, unknown>
  const candidate = obj && typeof obj === 'object' && 'scene' in obj ? (obj.scene as unknown) : raw
  return parseScene(candidate)
}

function countEntities(entity: Entity): number {
  return 1 + entity.children.reduce((n, c) => n + countEntities(c), 0)
}

/**
 * Count the executable animation leaves in every behavior tree.
 */
function countLeaves(scene: Scene): { curves: number; actions: number } {
  let curves = 0
  let actions = 0
  const walkBT = (n: BTNode): void => {
    if (n.type === 'curve') curves++
    if (n.type === 'action') actions++
    const any1 = n as unknown as Record<string, unknown>
    for (const c of (any1['children'] as BTNode[] | undefined) ?? []) walkBT(c)
    for (const key of ['child', 'template'] as const) if (any1[key]) walkBT(any1[key] as BTNode)
  }
  const walk = (e: Entity): void => {
    const bt = behaviorOf(e)
    if (bt) walkBT(bt)
    for (const c of e.children) walk(c as Entity)
  }
  walk(scene.root as Entity)
  return { curves, actions }
}

/**
 * Returns the reason a render failed, or undefined on success. It used to return a bare boolean,
 * which made a deterministic adapter bug and a Docker hiccup indistinguishable in results.md — an
 * empty Error column either way. That cost a full reproduction to diagnose `weight="700"`, which
 * manim had reported in its own stderr all along.
 */
function render(scene: Scene, runDir: string): string | undefined {
  const manimDir = join(runDir, 'manim')
  mkdirSync(manimDir, { recursive: true })
  const py = toManim(scene)
  writeFileSync(join(manimDir, 'scene.py'), py)
  // Render in an ephemeral dir so media/ + __pycache__ don't pollute the clean output.
  const work = mkdtempSync(join(tmpdir(), 'sl-render-'))
  // Public Manim image by default so anyone with Docker can render (auto-pulled on first
  // run; no Code Video / internal image needed). Override with SCENELAB_MANIM_IMAGE.
  // `--entrypoint bash` normalizes across images (works for both manimcommunity/manim,
  // whose entrypoint is empty, and manim-starter, whose entrypoint is /bin/bash).
  const image = process.env.SCENELAB_MANIM_IMAGE ?? 'manimcommunity/manim:latest'
  try {
    writeFileSync(join(work, 'scene.py'), py)
    execFileSync(
      'docker',
      [
        'run',
        '--rm',
        '-v',
        `${work}:/work`,
        '--entrypoint',
        'bash',
        image,
        '-c',
        'cd /work && manim render -ql --format=mp4 --media_dir /work/media /work/scene.py',
      ],
      { stdio: 'pipe', timeout: 300_000 },
    )
    const mp4 = findFirst(join(work, 'media'), (f) => f.endsWith('.mp4'))
    if (!mp4) return 'manim exited 0 but produced no mp4'
    cpSync(mp4, join(manimDir, 'video.mp4'))
    return undefined
  } catch (e) {
    // The useful line is manim's own exception, near the end of its stderr.
    const err = e as { stderr?: Buffer | string; stdout?: Buffer | string; message?: string }
    const text = String(err.stderr ?? '') + String(err.stdout ?? '')
    const blame =
      text
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => /Error|Exception|error:/i.test(l))
        .pop() ?? err.message ?? 'unknown render failure'
    writeFileSync(join(manimDir, 'render-error.log'), text || blame)
    return blame.slice(0, 300)
  } finally {
    // Best-effort temp cleanup — a cleanup hiccup (e.g. macOS ENOTEMPTY on Manim's
    // partial_movie_files) must never fail an otherwise-successful trial.
    try {
      rmSync(work, { recursive: true, force: true, maxRetries: 3, retryDelay: 200 })
    } catch {
      /* leave the temp dir; the OS will reclaim it */
    }
  }
}

/**
 * Unified three.js render (headless Chromium → WebGL2 → mp4). The 3D-capable path — renders 2D and
 * 3D scenes with the same engine as the browser preview. Best-effort: needs headless Chromium, which
 * is blocked inside sandboxes (e.g. Claude Code), so it silently no-ops there and works in a normal
 * terminal (where batch-compare's agents also run).
 */
async function threeRender(scene: Scene, runDir: string): Promise<boolean> {
  const dir = join(runDir, 'three')
  mkdirSync(dir, { recursive: true })
  try {
    await threeRenderToMp4(scene, { out: join(dir, 'video.mp4') })
    return true
  } catch {
    return false
  }
}

/**
 * Manim-less debug render (no Docker/Python): the same scene through the canvas engine → mp4.
 * Fast and reliable (works even when the manim/Docker render fails), and it renders exactly what
 * the interactive scrubber shows. Emits a plain render plus a debug-overlay variant.
 */
async function canvasRender(scene: Scene, runDir: string): Promise<boolean> {
  const dir = join(runDir, 'canvas')
  mkdirSync(dir, { recursive: true })
  try {
    await renderToMp4(scene, { out: join(dir, 'video.mp4') })
    await renderToMp4(scene, { out: join(dir, 'video.overlay.mp4'), overlay: true })
    return true
  } catch {
    return false
  }
}

function findFirst(dir: string, pred: (f: string) => boolean): string | null {
  if (!existsSync(dir)) return null
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry)
    const st = statSync(p)
    if (st.isDirectory()) {
      const found = findFirst(p, pred)
      if (found) return found
    } else if (pred(entry)) {
      return p
    }
  }
  return null
}

// ----------------------------------------------------------------------------
// main
// ----------------------------------------------------------------------------

async function main(): Promise<void> {
  const argv = process.argv.slice(2)
  const targetPath = argv.find((a) => !a.startsWith('--')) ?? 'trials/hanoi'
  const flag = (name: string): string | undefined =>
    argv.find((a) => a.startsWith(`--${name}=`))?.split('=')[1]
  const numTrials = Math.max(1, parseInt(flag('trials') ?? '1', 10))
  const modelTimeout = Math.max(60, parseInt(flag('model-timeout') ?? '600', 10))
  const variant = flag('variant') // reasoning effort, e.g. low | minimal | high | max
  const doRender = !argv.includes('--no-render')

  const prompt = readFileSync(join(targetPath, 'prompt.txt'), 'utf-8').trim()
  const modelKeys = (flag('models') ?? readFileSync(join(targetPath, 'models.txt'), 'utf-8'))
    .trim()
    .split(',')
    .map((m) => m.trim())
    .filter(Boolean)

  const ts = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0] + '-' + Date.now()
  const outputBase = join(targetPath, 'batches', ts)
  mkdirSync(outputBase, { recursive: true })

  console.log(`Batch compare (AGENT MODE)`)
  console.log(`  prompt : ${prompt}`)
  console.log(`  models : ${modelKeys.join(', ')}`)
  console.log(`  trials : ${numTrials}   render: ${doRender}   timeout: ${modelTimeout}s   variant: ${variant ?? '(default)'}`)
  console.log(`  output : ${outputBase}\n`)

  const results: TrialResult[] = []

  for (let run = 1; run <= numTrials; run++) {
    for (const key of modelKeys) {
      const model = MODELS[key]
      if (!model) {
        console.log(`  [run ${run}] unknown model "${key}" — skipping`)
        continue
      }
      const label = `[run ${run}][${model.name}]`
      const runDir = join(outputBase, key, `run${run}`)
      const scratch = mkdtempSync(join(tmpdir(), `sl-agent-${key}-`))
      const started = Date.now()
      try {
        const scenePath = join(scratch, 'scene.json')
        // Run the agent, but don't let a timeout throw away a scene.json it may have written
        // just before being killed — salvage the file first, only surface the error if there's
        // nothing to salvage. Retry once on a transient empty result (agent returned nothing
        // and wrote nothing), which happens occasionally on gateway hiccups.
        let stdout = ''
        let agentError: Error | undefined
        for (let attempt = 1; attempt <= 2; attempt++) {
          rmSync(scratch, { recursive: true, force: true })
          mkdirSync(scratch, { recursive: true })
          setupScratch(scratch)
          agentError = undefined
          try {
            stdout = runAgent(model.id, scratch, buildInstruction(prompt), modelTimeout, variant)
          } catch (e) {
            agentError = e instanceof Error ? e : new Error(String(e))
          }
          if (existsSync(scenePath) || stdout.trim()) break
          if (attempt === 1) console.log(`${label} empty result; retrying once`)
        }

        let raw: unknown
        if (existsSync(scenePath)) {
          if (agentError) console.log(`${label} agent errored but wrote scene.json — salvaging`)
          raw = JSON.parse(readFileSync(scenePath, 'utf-8'))
        } else if (stdout.trim()) {
          console.log(`${label} no scene.json written; falling back to stdout JSON`)
          raw = extractJson(stdout)
        } else {
          throw agentError ?? new Error('agent produced no scene.json and no stdout')
        }

        const scene = coerceScene(raw)
        const sceneJson = JSON.stringify(scene, null, 2)
        const entityCount = countEntities(scene.root)
        const { curves: curveCount, actions: actionCount } = countLeaves(scene)
        // Parsing and rendering do not guarantee executable motion; report unresolved simulation entries.
        const sim = simulate(scene)
        const unresolved = sim.unresolved.map((u) => `${u.btId ?? u.reason}: ${u.detail}`)
        if (unresolved.length > 0) console.log(`${label} ⚠ ${unresolved.length} unresolved: ${unresolved[0]}`)

        mkdirSync(join(runDir, 'scenegraph'), { recursive: true })
        writeFileSync(join(runDir, 'scenegraph', 'scene.json'), sceneJson)

        const renderError = doRender ? render(scene, runDir) : undefined
        const rendered = doRender && renderError === undefined
        if (renderError) console.log(`${label} ⚠ manim render failed: ${renderError}`)
        // Debug overlay composited over the manim render — for judging whether manim places
        // things (esp. text) where the scene graph says. Best-effort; text is static so it aligns
        // even though manim's HOLD lead-in offsets moving elements.
        if (rendered) {
          try {
            await compositeOverlay(scene, {
              baseVideo: join(runDir, 'manim', 'video.mp4'),
              out: join(runDir, 'manim', 'video.overlay.mp4'),
              timeMap: manimTimeMap(scene),
            })
          } catch {
            /* overlay is a debug extra — never fail a trial over it */
          }
        }
        const canvasRendered = doRender ? await canvasRender(scene, runDir) : false
        const threeRendered = doRender ? await threeRender(scene, runDir) : false
        const durationSec = Math.round((Date.now() - started) / 1000)
        results.push({
          model: key,
          modelName: model.name,
          run,
          success: true,
          entityCount,
          curveCount,
          actionCount,
          durationSec,
          rendered,
          ...(renderError !== undefined ? { renderError } : {}),
          canvasRendered,
          threeRendered,
          scheduleCount: sim.schedule.length,
          ...(unresolved.length > 0 ? { unresolved } : {}),
        })
        console.log(
          `${label} ok — ${entityCount} entities, ${curveCount} curves, ${actionCount} actions, ${durationSec}s` +
            `${rendered ? ', manim' : ''}${canvasRendered ? ', canvas' : ''}${threeRendered ? ', three' : ''}`,
        )
      } catch (e) {
        const durationSec = Math.round((Date.now() - started) / 1000)
        const error = e instanceof Error ? e.message : String(e)
        results.push({ model: key, modelName: model.name, run, success: false, durationSec, error })
        console.log(`${label} FAILED (${durationSec}s): ${error.split('\n')[0]}`)
      } finally {
        rmSync(scratch, { recursive: true, force: true })
      }
      // flush after every trial so a long batch is inspectable mid-run
      writeResults(outputBase, prompt, modelKeys, numTrials, results)
    }
  }

  console.log(`\nDone. Results: ${outputBase}/results.md`)
}

function writeResults(
  outputBase: string,
  prompt: string,
  modelKeys: string[],
  numTrials: number,
  results: TrialResult[],
): void {
  writeFileSync(join(outputBase, 'results.json'), JSON.stringify({ prompt, results }, null, 2))

  const lines: string[] = []
  lines.push(`# Batch Compare — Agent Mode`)
  lines.push('')
  lines.push(`**Prompt:** ${prompt}`)
  lines.push('')
  lines.push(`| Model | Run | OK | Entities | Curves/Actions | Sched | Manim | Canvas | 3D | Time | Error |`)
  lines.push(`|---|---|---|---|---|---|---|---|---|---|---|`)
  for (const r of results) {
    lines.push(
      `| ${r.modelName} | ${r.run} | ${r.success ? '✅' : '❌'} | ${r.entityCount ?? '-'} | ` +
        `${r.curveCount ?? '-'}/${r.actionCount ?? '-'} | ${r.scheduleCount ?? '-'}${r.unresolved ? ' ⚠' : ''} | ${r.rendered ? '🎬' : '-'} | ${r.canvasRendered ? '🖼️' : '-'} | ${r.threeRendered ? '🧊' : '-'} | ` +
        `${r.durationSec ?? '-'}s | ${((r.error ?? r.renderError ?? r.unresolved?.[0] ?? '').split('\n')[0] ?? '').slice(0, 60)} |`,
    )
  }
  lines.push('')
  lines.push(`## Consistency`)
  lines.push('')
  for (const key of modelKeys) {
    const rs = results.filter((r) => r.model === key)
    if (rs.length === 0) continue
    const ok = rs.filter((r) => r.success)
    const entities = ok.map((r) => r.entityCount ?? 0)
    const leaves = ok.map((r) => `${r.curveCount ?? 0}c/${r.actionCount ?? 0}a`)
    const name = MODELS[key]?.name ?? key
    lines.push(
      `- **${name}**: ${ok.length}/${rs.length} valid · entities [${entities.join(', ') || '-'}] · ` +
        `leaves [${leaves.join(', ') || '-'}]`,
    )
  }
  writeFileSync(join(outputBase, 'results.md'), lines.join('\n'))
}

main().catch((e) => {
  console.error(e)
  process.exit(1)
})
