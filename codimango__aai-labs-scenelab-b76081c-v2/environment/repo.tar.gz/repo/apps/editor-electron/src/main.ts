import { spawn, type ChildProcess } from 'node:child_process'
import { existsSync, mkdirSync, writeFileSync, rmSync, readFileSync, openSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { createServer } from 'node:net'

import { emptyScene, sampleScene } from '@scenelab/scene-ir'
import { startSceneServer } from '../../../skills/editor/server'

const SESSION_FILE = join(resolve(__dirname, '../..', '..'), '.metacode', 'scenelab-editor.json')
const LOG_FILE = join(resolve(__dirname, '../..', '..'), '.metacode', 'scenelab-electron.log')
const PLAYGROUND_URL = process.env.SCENELAB_URL ?? 'http://localhost:5173'

let playgroundProc: ChildProcess | null = null

const isElectronRuntime = !!process.versions.electron

function ensureCustomElectronBundle(): string | null {
  try {
    const root = resolve(__dirname, '../..', '..')
    const electronAppSrc = join(root, 'apps/editor-electron/node_modules/electron/dist/Electron.app')
    const customAppDst = join(root, 'apps/editor-electron/dist/SceneLab.app')
    const iconSrc = join(root, 'assets/SceneLabIcon.icns')
    if (!existsSync(electronAppSrc)) return null

    // Refresh the custom bundle when it is missing or its icon changes.
    const { cpSync, rmSync } = require('node:fs') as typeof import('node:fs')
    const needsCopy = !existsSync(customAppDst) || (() => {
      try {
        const dstIcon = join(customAppDst, 'Contents/Resources/appIcon.icns')
        return !existsSync(dstIcon) || require('node:fs').statSync(iconSrc).mtimeMs > require('node:fs').statSync(dstIcon).mtimeMs
      } catch { return true }
    })()
    if (needsCopy) {
      console.log('Creating custom Electron bundle dist/SceneLab.app with black lab icon (first run copies ~200MB, may take a few sec)...')
      try { rmSync(customAppDst, { recursive: true, force: true }) } catch {}
      cpSync(electronAppSrc, customAppDst, { recursive: true })
      console.log('✓ custom bundle created at', customAppDst)
    }

    // Apply SceneLab metadata to the copied Electron bundle.
    try {
      const plistPath = join(customAppDst, 'Contents/Info.plist')
      let plist = readFileSync(plistPath, 'utf-8')
      plist = plist.replace(/<key>CFBundleDisplayName<\/key>\s*<string>Electron<\/string>/, '<key>CFBundleDisplayName</key>\n\t<string>SceneLab</string>')
      plist = plist.replace(/<key>CFBundleName<\/key>\s*<string>Electron<\/string>/, '<key>CFBundleName</key>\n\t<string>SceneLab</string>')
      // Ensure identifier is ours
      if (!plist.includes('com.scenelab.editor')) {
        plist = plist.replace(/<key>CFBundleIdentifier<\/key>\s*<string>[^<]+<\/string>/, '<key>CFBundleIdentifier</key>\n\t<string>com.scenelab.editor</string>')
      }
      // Point to our icon file
      if (!plist.includes('appIcon')) {
        plist = plist.replace('</dict>', '\t<key>CFBundleIconFile</key>\n\t<string>appIcon</string>\n</dict>')
      } else {
        plist = plist.replace(/<key>CFBundleIconFile<\/key>\s*<string>[^<]+<\/string>/, '<key>CFBundleIconFile</key>\n\t<string>appIcon</string>')
      }
      writeFileSync(plistPath, plist)
    } catch {}

    // Copy the SceneLab icon into the bundle.
    try {
      if (existsSync(iconSrc)) {
        const dstIcon = join(customAppDst, 'Contents/Resources/appIcon.icns')
        const { copyFileSync } = require('node:fs') as typeof import('node:fs')
        copyFileSync(iconSrc, dstIcon)
        // Also keep electron.icns for fallback
        try { copyFileSync(iconSrc, join(customAppDst, 'Contents/Resources/electron.icns')) } catch {}
      }
    } catch {}

    return customAppDst
  } catch {
    return null
  }
}

function ensureClickableLaunchers(): void {
  try {
    const root = resolve(__dirname, '../..', '..')
    mkdirSync(join(root, '.metacode'), { recursive: true })

    const customApp = ensureCustomElectronBundle()
    const electronBinary = customApp ? `${customApp}/Contents/MacOS/Electron` : './apps/editor-electron/node_modules/.bin/electron'

    // Main launcher — server + the SceneLab-branded Electron window. The agent is NOT launched
    // here: the editor's Agent tab owns its own metacode session over ACP, so there is no paired
    // terminal to prime and no context file to write.
    const combinedScript = `#!/bin/bash
set -e
cd "${root}"
echo "=== SceneLab ==="
echo "[1/3] Stopping previous..."
pnpm exec tsx skills/editor/stop.ts 2>&1 | head -3 || true
pkill -9 -f vite 2>&1 | head -1 || true
rm -f .metacode/scenelab-editor.json /tmp/scenelab-electron-window.log
sleep 0.5
if [ ! -f apps/editor-electron/dist/main.cjs ]; then
  pnpm --filter @scenelab/editor-electron build
fi
echo "[2/3] Starting server (API 7317 + vite 5173)..."
rm -f .metacode/scenelab-electron.log
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo "server pid $!"
for i in $(seq 1 20); do curl -s http://localhost:5173 > /dev/null && break; sleep 0.5; done
API_URL="http://localhost:7317"
echo "[3/3] Opening SceneLab window..."
rm -f /tmp/scenelab-electron-window.log
CUSTOM_APP="${customApp ?? ''}"
if [ -n "$CUSTOM_APP" ] && [ -x "$CUSTOM_APP/Contents/MacOS/Electron" ]; then
  nohup "$CUSTOM_APP/Contents/MacOS/Electron" --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=$API_URL > /tmp/scenelab-electron-window.log 2>&1 & ELECTRON_PID=$!
else
  nohup ${electronBinary} --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=$API_URL > /tmp/scenelab-electron-window.log 2>&1 & ELECTRON_PID=$!
fi
sleep 2
# Record the window pid so stop.ts can close it. The wrapper pid is the fallback when the
# real Electron process cannot be identified.
REAL_ELECTRON_PID=$(pgrep -f "main.cjs --window --api=$API_URL" | head -1)
node -e "
const fs=require('fs'); const f='.metacode/scenelab-editor.json';
try{ const d=JSON.parse(fs.readFileSync(f,'utf-8'));
  d.electronPid=Number(process.argv[1]||process.argv[2])||null; d.launcher='SceneLab.command';
  fs.writeFileSync(f,JSON.stringify(d,null,2)); }catch(e){}
" "$REAL_ELECTRON_PID" "$ELECTRON_PID" 2>/dev/null || true
echo ""
echo "SceneLab is live — API $API_URL · UI http://localhost:5173"
echo "Ask the agent for a scene in the editor's Agent tab."
`

    const serverScript = `#!/bin/bash
set -e
cd "${root}"
echo "=== SceneLab Server ==="
rm -f .metacode/scenelab-electron.log
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo "server pid $!"
sleep 3
for i in 1 2 3 4 5 6 7 8 9 10; do curl -s http://localhost:5173 > /dev/null && echo "vite up at http://localhost:5173" && break; sleep 0.5; done
curl -s http://localhost:7317/api/summary
echo ""
echo "Server live — API http://localhost:7317 · UI http://localhost:5173"
`

    const electronScript = `#!/bin/bash
cd "${root}"
# Prefer custom bundle with SceneLab name + icon so Dock shows SceneLab not Electron
if [ -x "apps/editor-electron/dist/SceneLab.app/Contents/MacOS/Electron" ]; then
  exec "apps/editor-electron/dist/SceneLab.app/Contents/MacOS/Electron" --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=http://localhost:7317
else
  exec ${electronBinary} --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=http://localhost:7317
fi
`

    writeFileSync(join(root, 'SceneLab.command'), combinedScript, { mode: 0o755 })
    writeFileSync(join(root, 'Server.command'), serverScript, { mode: 0o755 })
    writeFileSync(join(root, 'Electron.command'), electronScript, { mode: 0o755 })
  } catch {}
}

async function freePort(from: number): Promise<number> {
  for (let p = from; p < from + 50; p++) {
    const open = await new Promise<boolean>((resolve) => {
      const s = createServer()
      s.once('error', () => resolve(false))
      s.once('listening', () => s.close(() => resolve(true)))
      s.listen(p, '127.0.0.1')
    })
    if (open) return p
  }
  throw new Error(`no free port in ${from}..${from + 50}`)
}

async function ensurePlayground(): Promise<void> {
  try {
    const res = await fetch(PLAYGROUND_URL, { signal: AbortSignal.timeout(800) } as any)
    if (res.ok) return
  } catch {}
  console.log('Starting playground vite dev (http://localhost:5173)...')
  playgroundProc = spawn('pnpm', ['--filter', '@scenelab/playground', 'dev'], {
    stdio: isElectronRuntime ? 'inherit' : 'pipe',
    env: process.env,
  })
  let lastLogAt = Date.now()
  // Mirror Vite output to the session log and surface readiness or errors in the console.
  if (!isElectronRuntime && playgroundProc.stdout) {
    playgroundProc.stdout.on('data', (d) => {
      const text = d.toString()
      try { writeFileSync(LOG_FILE, d, { flag: 'a' }) } catch {}
      // Keep routine build chatter in the log.
      if (text.includes('ready') || text.includes('VITE') || text.includes('Local:') || text.toLowerCase().includes('error')) {
        process.stdout.write(text)
        lastLogAt = Date.now()
      }
    })
    playgroundProc.stderr?.on('data', (d) => {
      const text = d.toString()
      try { writeFileSync(LOG_FILE, d, { flag: 'a' }) } catch {}
      process.stderr.write(text)
      lastLogAt = Date.now()
    })
  }
  playgroundProc.on('error', (e) => {
    console.error(`playground spawn failed: ${e.message}`)
  })
  playgroundProc.on('close', (code) => {
    if (code !== 0 && code !== null) console.error(`playground vite exited ${code} — check ${LOG_FILE}`)
  })

  for (let i = 0; i < 60; i++) {
    await new Promise((r) => setTimeout(r, 1000))
    try {
      const r = await fetch(PLAYGROUND_URL, { signal: AbortSignal.timeout(800) } as any)
      if (r.ok) {
        console.log(`✓ vite up at ${PLAYGROUND_URL} (${i + 1}s)`)
        return
      }
    } catch {}
    if (i > 0 && i % 5 === 0) {
      const idle = Math.round((Date.now() - lastLogAt) / 1000)
      console.log(`  ... still waiting for vite (${i}s elapsed, last vite log ${idle}s ago) — check ${LOG_FILE} — pnpm --filter @scenelab/playground dev`)
    }
  }
  try { playgroundProc.kill() } catch {}
  const logTail = (() => { try { return readFileSync(LOG_FILE, 'utf-8').slice(-2000) } catch { return '(no log)' } })()
  throw new Error(`playground vite did not start at ${PLAYGROUND_URL} after 60s\nLast log tail:\n${logTail}`)
}

async function buildElectronMain(): Promise<string> {
  const distPath = join(resolve(__dirname, '..'), 'dist', 'main.cjs')
  if (existsSync(distPath)) return distPath
  console.log('Building electron main bundle...')
  const build = spawn('pnpm', ['--filter', '@scenelab/editor-electron', 'build'], {
    stdio: 'inherit',
    env: process.env,
  })
  await new Promise<void>((resolve, reject) => {
    build.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`build failed ${code}`))))
    build.on('error', reject)
  })
  return distPath
}

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms))

async function shutdownPrevious(): Promise<void> {
  for (let port = 7317; port < 7325; port++) {
    try {
      await fetch(`http://localhost:${port}/api/shutdown`, { method: 'POST', signal: AbortSignal.timeout(800) } as any)
    } catch {}
  }
  if (!existsSync(SESSION_FILE)) return
  try {
    const raw = readFileSync(SESSION_FILE, 'utf-8')
    const s = JSON.parse(raw) as { api?: string | null; pid?: number; vitePid?: number; electronPid?: number; launching?: boolean }
    if (s.launching) return
    if (s.pid && s.pid !== process.pid) {
      try { process.kill(s.pid, 'SIGTERM') } catch {}
    }
    if (s.vitePid) {
      try { process.kill(s.vitePid, 'SIGTERM') } catch {}
    }
    if (s.electronPid) {
      try { process.kill(s.electronPid, 'SIGTERM') } catch {}
    }
  } catch {}
  await sleep(600)
}

async function detach(argv: string[]): Promise<void> {
  mkdirSync(dirname(SESSION_FILE), { recursive: true })
  mkdirSync(dirname(LOG_FILE), { recursive: true })
  writeFileSync(LOG_FILE, `[${new Date().toISOString()}] detach requested: ${argv.join(' ')}\n`, { flag: 'w' })
  ensureClickableLaunchers()
  await shutdownPrevious()
  rmSync(SESSION_FILE, { force: true })
  try {
    writeFileSync(SESSION_FILE, JSON.stringify({ api: null, ui: null, launching: true, pid: process.pid }, null, 2))
  } catch {}

  const self = __filename
  // Launch through a shell so the detached server retains the macOS process context Electron needs.
  const serverArgs = [...argv.filter((a) => a !== '--detach'), '--no-window']
  const serverCmd = `nohup pnpm exec tsx ${self} ${serverArgs.join(' ')} > ${LOG_FILE} 2>&1 & echo $!`
  let childPid: number | null = null
  try {
    const { execSync } = await import('node:child_process')
    const pidStr = execSync(`bash -c '${serverCmd.replace(/'/g, "'\\''")}'`, { encoding: 'utf-8' }).trim()
    childPid = parseInt(pidStr, 10)
  } catch (e) {
    // Fall back to a detached child process if the shell launch fails.
    const logFd = openSync(LOG_FILE, 'a')
    const childFallback = spawn('pnpm', ['exec', 'tsx', self, ...serverArgs], {
      detached: true,
      stdio: ['ignore', logFd, logFd],
      env: process.env,
    })
    childFallback.unref()
    childPid = childFallback.pid ?? null
  }
  let apiUrl: string | null = null
  let session: { api: string | null; ui: string | null } | null = null

  for (let i = 0; i < 50; i++) {
    await sleep(500)
    if (!existsSync(SESSION_FILE)) continue
    try { session = JSON.parse(readFileSync(SESSION_FILE, 'utf-8')) as { api: string | null; ui: string | null } }
    catch { continue }
    if (session.ui === null) continue
    if (!session.api) continue
    try {
      const res = await fetch(`${session.api}/api/summary`, { signal: AbortSignal.timeout(700) } as any)
      if (res.ok) {
        apiUrl = session.api
        break
      }
    } catch {}
    try { process.kill(childPid!, 0) } catch {
      console.error(`Electron launcher child died. Tail log:`)
      try { console.error(readFileSync(LOG_FILE, 'utf-8').slice(-3000)) } catch {}
      process.exit(1)
    }
  }

  if (!apiUrl || !session) {
    console.error(`Electron launcher timed out — see ${LOG_FILE}`)
    try { console.error(readFileSync(LOG_FILE, 'utf-8').slice(-4000)) } catch {}
    process.exit(1)
  }

  // macOS blocks Electron's bootstrap registration inside the MetaCode sandbox, so detach mode
  // starts the server here and leaves the native window to an external launcher.
  await buildElectronMain()
  const oscLink = (url: string, label?: string) => `\x1b]8;;${url}\x1b\\${label ?? url}\x1b]8;;\x1b\\`
  const electronPid: number | null = null
  if (!argv.includes('--no-window')) {
    console.log(`  Native window auto-launch skipped inside MetaCode sandbox`)
    console.log(`  Launch native outside: pnpm scenelab / pnpm native`)
    console.log(`  Or combined launcher (server+window, drag to Desktop): Start SceneLab.command / pnpm start`)
  }

  console.log(`\n  Welcome to SceneLab — dedicated editor is live.\n`)
  console.log(`  ● Connected · API ${apiUrl} · UI ${session.ui!} (cmd+double click)`)
  console.log(`\n  Blank canvas ready — tell me what to build.\n`)
}

async function runElectronWindowMode(apiFlag: string | undefined): Promise<void> {
  const { app, BrowserWindow, shell, nativeImage } = await import('electron')
  try { app.setName('SceneLab') } catch {}
  try { (app as any).name = 'SceneLab' } catch {}
  try { process.title = 'SceneLab' } catch {}
  try { (app as any).setAboutPanelOptions?.({ applicationName: 'SceneLab' }) } catch {}
  await app.whenReady()

  // Apply SceneLab branding to the native app.
  try {
    const root = resolve(__dirname, '../../..')
    const pngIcon = join(root, 'assets/SceneLabIcon.png')
    const icnsIcon = join(root, 'assets/SceneLabIcon.icns')
    const iconPath = existsSync(pngIcon) ? pngIcon : existsSync(icnsIcon) ? icnsIcon : undefined
    if (iconPath && existsSync(iconPath)) {
      if (process.platform === 'darwin' && app.dock) {
        const dockImg = nativeImage.createFromPath(iconPath)
        if (!dockImg.isEmpty()) app.dock.setIcon(dockImg)
      }
    }
  } catch {}

  let apiUrl = apiFlag ?? process.env.SCENELAB_API ?? 'http://localhost:7317'
  // If no existing server, start one now (fallback for electron:dev path)
  let server: any = null
  if (!existsSync(SESSION_FILE)) {
    const isNew = process.argv.includes('--new')
    const space = process.argv.includes('--space=3d') ? '3d' : '2d'
    const scene = isNew ? emptyScene({ space: space as any }) : sampleScene()
    const apiPort = await freePort(7317)
    server = await startSceneServer({ scene, port: apiPort })
    apiUrl = `http://localhost:${apiPort}`
    mkdirSync(dirname(SESSION_FILE), { recursive: true })
    writeFileSync(SESSION_FILE, JSON.stringify({ api: apiUrl, ui: PLAYGROUND_URL, scene: null, pid: process.pid, vitePid: null, electronPid: process.pid, electron: true }, null, 2))
    await ensurePlayground()
  }

  const createWindow = async (url: string, title?: string): Promise<InstanceType<typeof BrowserWindow>> => {
    let windowIcon: string | undefined
    try {
      const root = resolve(__dirname, '../../..')
      const pngIcon = join(root, 'assets/SceneLabIcon.png')
      const icnsIcon = join(root, 'assets/SceneLabIcon.icns')
      windowIcon = existsSync(pngIcon) ? pngIcon : existsSync(icnsIcon) ? icnsIcon : undefined
    } catch {}
    const bw = new BrowserWindow({
      width: title ? 900 : 1600,
      height: title ? 700 : 1000,
      title: title ?? 'SceneLab — Dedicated Editor',
      backgroundColor: '#121214',
      icon: windowIcon,
      webPreferences: { contextIsolation: true, nodeIntegration: false },
    })
    // Pop-outs: if same origin and ?view=, open as native child window (keeps same app, live sync via /api + BroadcastChannel)
    // External URLs: open in system browser
    bw.webContents.setWindowOpenHandler(({ url: popUrl }: { url: string }) => {
      try {
        const u = new URL(popUrl)
        const playgroundOrigin = new URL(PLAYGROUND_URL).origin
        if (u.origin === playgroundOrigin && u.searchParams.has('view')) {
          void createWindow(popUrl, `SceneLab — ${u.searchParams.get('view')}`)
          return { action: 'deny' }
        }
      } catch {}
      shell.openExternal(popUrl)
      return { action: 'deny' }
    })
    await bw.loadURL(url)
    return bw
  }

  const win = await createWindow(PLAYGROUND_URL)
  console.log(`\n  SceneLab Dedicated Editor — native window\n  API: ${apiUrl}\n  UI: ${PLAYGROUND_URL} (Electron)\n`)

  app.on('window-all-closed', async () => {
    try { rmSync(SESSION_FILE, { force: true }) } catch {}
    if (server) await server.close()
    if (playgroundProc) playgroundProc.kill()
    app.quit()
  })
}

async function runNodeServerMode(_opts: { noWindow?: boolean } = {}): Promise<void> {
  const argv = process.argv.slice(2)
  const isNew = argv.includes('--new')
  const space = argv.includes('--space=3d') ? '3d' : '2d'
  const scene = isNew ? emptyScene({ space: space as any }) : sampleScene()

  mkdirSync(dirname(SESSION_FILE), { recursive: true })
  mkdirSync(dirname(LOG_FILE), { recursive: true })
  ensureClickableLaunchers()
  await shutdownPrevious()
  rmSync(SESSION_FILE, { force: true })

  const apiPort = await freePort(7317)
  const server = await startSceneServer({ scene, port: apiPort })

  const apiUrl = `http://localhost:${apiPort}`
  writeFileSync(SESSION_FILE, JSON.stringify({ api: apiUrl, ui: PLAYGROUND_URL, scene: null, pid: process.pid, vitePid: playgroundProc?.pid ?? null, electronPid: null, electron: true }, null, 2))

  await ensurePlayground()

  try {
    const raw = JSON.parse(readFileSync(SESSION_FILE, 'utf-8'))
    raw.vitePid = playgroundProc?.pid ?? raw.vitePid
    raw.api = apiUrl
    writeFileSync(SESSION_FILE, JSON.stringify(raw, null, 2))
  } catch {}

  console.log(`\n  Welcome to SceneLab — dedicated editor is live.\n`)
  console.log(`  ● Connected · API ${apiUrl} · UI ${PLAYGROUND_URL} (cmd+double click)`)
  console.log(`\n  Blank canvas ready — tell me what to build.\n`)

  const stop = async (reason: string): Promise<void> => {
    console.log(`\n  Shutting down — ${reason}`)
    try { playgroundProc?.kill() } catch {}
    try { rmSync(SESSION_FILE, { force: true }) } catch {}
    await server.close()
    process.exit(0)
  }
  process.on('SIGINT', () => void stop('interrupted'))
  process.on('SIGTERM', () => void stop('terminated'))

  await new Promise(() => {})
}

async function main() {
  const argv = process.argv.slice(2)

  // Internal flag: running inside Electron as window host
  if (isElectronRuntime && argv.includes('--window')) {
    const apiFlag = argv.find((a) => a.startsWith('--api='))?.split('=')[1]
    await runElectronWindowMode(apiFlag)
    return
  }

  if (argv.includes('--detach')) {
    await detach(argv)
    return
  }

  if (isElectronRuntime) {
    await runElectronWindowMode(undefined)
    return
  }

  const noWindow = argv.includes('--no-window')
  await runNodeServerMode({ noWindow })
}

void main().catch((e) => {
  console.error(e)
  try { writeFileSync(LOG_FILE, `\n[CRASH ${new Date().toISOString()}] ${e?.stack ?? e}\n`, { flag: 'a' }) } catch {}
  process.exit(1)
})
