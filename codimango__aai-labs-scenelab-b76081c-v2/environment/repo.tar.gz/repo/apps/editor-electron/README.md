# SceneLab Dedicated Editor (Electron)

Dedicated editor view not constrained to a browser link — spawns a native window that directly renders the same widgets.

**Keeps web interfaces:** `packages/widgets` + `useSharedScene` + `useSharedUI` still work for end users in browsers. Agents can `POST /api/ui` to spawn widgets that appear inside this Electron window (live `t` scrub stays in sync because all widgets share same React state, not cross-window).

## Launch flows (updated)

### 1. Browser editor — auto-launches via agent (fully works inside Claude Code/MetaCode)

`/scenelab --new --detach` or `pnpm exec tsx skills/editor/editor.ts --new --detach`

- Agent runs this via Bash tool with `--detach`
- Server on 7317, vite on 5173, both detached and logged to `.metacode/scenelab-editor.log`
- Works reliably even inside Claude Code sandbox — no separate terminal needed

### 2. Dedicated Electron app — server auto-launches, native window needs external terminal on macOS

Due to macOS Mach bootstrap (`bootstrap_check_in Permission denied`) when spawning Electron from a detached Node process or from inside Claude Code's Bash sandbox, the native window cannot reliably be spawned from the agent's `--detach` flow.

**What works:**

```bash
# Agent does this automatically via /scenelab --electron --new --detach:
# - starts scene server on 7317 + vite on 5173 (API live)
# - browser fallback at http://localhost:5173 works immediately

# Then in a separate terminal OUTSIDE Claude Code, run to get native window:
pnpm --filter @scenelab/editor-electron exec electron --no-sandbox dist/main.cjs --window --api=http://localhost:7317

# Or foreground (blocks, opens window directly — works when run in your own terminal):
pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new
```

**Dev scripts:**

```bash
# From repo root
pnpm --filter @scenelab/editor-electron dev
# or full electron with playground vite auto-started:
pnpm --filter @scenelab/editor-electron electron:dev
```

### Why not just call open?

`open -a Electron.app` fails with `-54` sandbox error when invoked from inside Claude Code. Electron main process can open windows outside the browser sandbox, but still needs `ELECTRON_DISABLE_SANDBOX=1` + `--no-sandbox` when spawned from a detached context.

### What the server does

- Starts scene server on first free port from 7317 (same as `skills/editor`)
- Writes `.metacode/scenelab-editor.json` so `/scenelab` skill and playground vite proxy find it
- Ensures `apps/playground` vite dev is running at http://localhost:5173 (spawns if not)
- Attempts native BrowserWindow — succeeds when run in your own terminal outside Claude Code sandbox, falls back to browser UI when run via agent `--detach`

## Widget spawning (for end users)

Any process (agent or end-user web UI) can:

```bash
curl -X POST http://localhost:7317/api/ui -H 'content-type: application/json' -d '{"action":"spawn","panel":{"type":"preview","position":"floating"}}'
curl -s http://localhost:7317/api/ui | python3 -m json.tool
```

`WidgetHost` in `packages/widgets/src/WidgetHost.tsx` renders layout from server. Because it lives in same Electron window, scrub/play (`t`) is continuous and frame-accurate — unlike separate browser windows which would need BroadcastChannel and would lag.

## Why not just separate browser windows?

Separate windows need `t` synced at 60fps via BroadcastChannel/postMessage → 1 frame lag, jitter, drift. Single-window dockable tabs (Project/Scene/Outliner left, Scene View + Preview middle, Properties/Trace right) keeps `t` in one React tree, both canvases render same `t` synchronously. Pop-out to second monitor is possible as opt-in but not primary.
