import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

/**
 * `/api` is proxied to the scene server the editor skill starts, so the browser talks to its own
 * origin: no CORS, and no env var has to survive into client code. Standalone `pnpm dev` has no
 * server behind the proxy, the first fetch fails, and the app falls back to its local samples.
 */
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': {
        target: process.env['SCENELAB_API'] ?? 'http://localhost:7317',
        changeOrigin: true,
      },
    },
  },
})
