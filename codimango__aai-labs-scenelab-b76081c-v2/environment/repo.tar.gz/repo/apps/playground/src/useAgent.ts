/**
 * useAgent — client for the editor's own metacode session.
 *
 * The server hosts the session over ACP and streams its transcript on /api/agent/stream, so this
 * hook holds no timers: state arrives as the agent thinks. Sending a prompt returns immediately;
 * what happens next shows up on the stream.
 */

import { useCallback, useEffect, useState } from 'react'

const API = '/api'

export interface ToolCall {
  id: string
  title: string
  kind: string
  status: 'pending' | 'in_progress' | 'completed' | 'failed'
  locations: string[]
}

export interface Turn {
  id: number
  role: 'user' | 'agent'
  text: string
  thought: string
  toolCalls: ToolCall[]
  startedAt: number
  finishedAt: number | null
  stopReason: string | null
  error: string | null
}

export interface AgentState {
  sessionId: string | null
  running: boolean
  busy: boolean
  model: string | null
  availableModels: Array<{ modelId: string; name: string }>
  turns: Turn[]
  usage: { used: number; size: number } | null
  lastError: string | null
}

const EMPTY: AgentState = {
  sessionId: null,
  running: false,
  busy: false,
  model: null,
  availableModels: [],
  turns: [],
  usage: null,
  lastError: null,
}

export interface UseAgentReturn {
  state: AgentState
  prompt: string
  setPrompt: (v: string) => void
  send: () => Promise<void>
  reset: () => Promise<void>
  cancel: () => Promise<void>
  /** Transport-level failure (server unreachable, 4xx) — distinct from state.lastError. */
  error: string | null
  connected: boolean
}

export function useAgent(): UseAgentReturn {
  const [state, setState] = useState<AgentState>(EMPTY)
  const [prompt, setPrompt] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [connected, setConnected] = useState(false)

  useEffect(() => {
    const es = new EventSource(`${API}/agent/stream`)
    es.onopen = () => setConnected(true)
    es.onerror = () => setConnected(false)
    es.onmessage = (e: MessageEvent) => {
      try {
        // Merge, don't replace: delta frames omit availableModels to keep them small.
        const incoming = JSON.parse(e.data as string) as Partial<AgentState>
        setState((prev) => ({ ...prev, ...incoming }))
      } catch {
        // a partial frame; the next one carries full state
      }
    }
    return () => es.close()
  }, [])

  const post = useCallback(async (path: string, body?: unknown): Promise<void> => {
    setError(null)
    try {
      const res = await fetch(`${API}${path}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(body ?? {}),
      })
      const data = (await res.json()) as { error?: string; state?: AgentState }
      if (!res.ok) throw new Error(data.error ?? `status ${res.status}`)
      if (data.state) setState(data.state)
    } catch (e) {
      setError((e as Error).message)
    }
  }, [])

  const send = useCallback(async () => {
    const trimmed = prompt.trim()
    if (!trimmed) return
    setPrompt('')
    await post('/agent/prompt', { prompt: trimmed })
  }, [prompt, post])

  const reset = useCallback(async () => {
    await post('/agent/reset')
  }, [post])

  const cancel = useCallback(async () => {
    await post('/agent/cancel')
  }, [post])

  return { state, prompt, setPrompt, send, reset, cancel, error, connected }
}
