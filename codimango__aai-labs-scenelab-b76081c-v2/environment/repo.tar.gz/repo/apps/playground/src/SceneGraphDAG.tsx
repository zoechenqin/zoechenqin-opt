import { useMemo, useState, useRef, useCallback, useEffect } from 'react'
import type { Entity as SceneEntity, Scene } from '@scenelab/scene-ir'
import { arrangementOf, collectRefEdges, validateSceneGraph, findCycles } from '@scenelab/scene-ir'
import type { RefEdge } from '@scenelab/scene-ir'

interface Props {
  scene: Scene
  selectedId?: string | null
  onSelect?: (id: string | null) => void
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------
/**
 * There is no `kind` field any more — an entity's role is whatever it carries (scene-ir types.ts).
 * An entity with both structural components reports as an arrangement, since that is the one that
 * changes what exists.
 */
function entityRole(entity: SceneEntity): string {
  if (entity.components?.arrangement) return 'arrangement'
  if (entity.components?.behavior) return 'behavior'
  return 'group'
}

function kindIcon(kind: string): string {
  switch (kind) {
    case 'group': return '📁'
    case 'arrangement': return '◈'
    case 'behavior': return '⚡'
    default: return '●'
  }
}
function kindBg(kind: string): string {
  switch (kind) {
    case 'group': return '#1e1e22'
    case 'arrangement': return '#1e2a3a'
    case 'behavior': return '#2a1e2e'
    default: return '#1a1a1e'
  }
}
function kindBorder(kind: string): string {
  switch (kind) {
    case 'group': return '#2a2a34'
    case 'arrangement': return '#2a3a52'
    case 'behavior': return '#4a2a3a'
    default: return '#2a2a2e'
  }
}
function edgeKindColor(kind: string): string {
  switch (kind) {
    case 'contains': return '#666'
    case 'instantiates': return '#c5ff8e'
    case 'constrains': return '#8ec7ff'
    default: return '#888'
  }
}
function edgeDash(kind: string): string | undefined {
  if (kind === 'instantiates') return '6 4'
  if (kind === 'constrains') return '3 5'
  return undefined
}

type FlatEntity = {
  entity: SceneEntity
  parentId: string | null
  depth: number
  childrenIds: string[]
}

function collectFlat(root: SceneEntity): { list: FlatEntity[]; byId: Map<string, FlatEntity> } {
  const list: FlatEntity[] = []
  const byId = new Map<string, FlatEntity>()
  const walk = (e: SceneEntity, parentId: string | null, depth: number) => {
    const fe: FlatEntity = {
      entity: e,
      parentId,
      depth,
      childrenIds: (e.children as SceneEntity[]).map((c) => c.id),
    }
    list.push(fe)
    byId.set(e.id, fe)
    for (const ch of e.children as SceneEntity[]) walk(ch, e.id, depth + 1)
  }
  walk(root, null, 0)
  return { list, byId }
}

type LayoutNode = {
  id: string
  x: number
  y: number
  depth: number
  parentId: string | null
  entity: SceneEntity
}

const NODE_W = 168
const NODE_H = 62
const LEVEL_H = 132
const SIBLING_GAP = 28
const PADDING = 48

function computeTreeLayout(root: SceneEntity): { nodes: Map<string, LayoutNode>; width: number; height: number; minX: number; minY: number; maxX: number; maxY: number } {
  const pos = new Map<string, LayoutNode>()
  let nextX = 0

  const layoutRec = (e: SceneEntity, parentId: string | null, depth: number): { id: string; x: number; min: number; max: number } => {
    const children = e.children as SceneEntity[]
    if (children.length === 0) {
      const x = nextX * (NODE_W + SIBLING_GAP)
      nextX++
      pos.set(e.id, { id: e.id, x, y: depth * LEVEL_H, depth, parentId, entity: e })
      return { id: e.id, x, min: x, max: x }
    }
    const childInfos: Array<{ id: string; x: number; min: number; max: number }> = []
    for (const ch of children) childInfos.push(layoutRec(ch, e.id, depth + 1))
    const min = Math.min(...childInfos.map((c) => c.min))
    const max = Math.max(...childInfos.map((c) => c.max))
    const avg = (childInfos[0]!.x + childInfos[childInfos.length - 1]!.x) / 2
    // alternative: avg of all
    const mid = (min + max) / 2
    const x = childInfos.length === 1 ? childInfos[0]!.x : mid ?? avg
    pos.set(e.id, { id: e.id, x, y: depth * LEVEL_H, depth, parentId, entity: e })
    return { id: e.id, x, min, max }
  }

  layoutRec(root, null, 0)

  // shift to positive
  let minX = Infinity
  let maxX = -Infinity
  let maxY = -Infinity
  for (const n of pos.values()) {
    minX = Math.min(minX, n.x)
    maxX = Math.max(maxX, n.x)
    maxY = Math.max(maxY, n.y)
  }
  if (!isFinite(minX)) { minX = 0; maxX = NODE_W; maxY = LEVEL_H }
  // Normalize so minX -> PADDING
  const shiftX = -minX + PADDING
  for (const n of pos.values()) n.x += shiftX
  maxX += shiftX
  const width = maxX - PADDING + NODE_W + PADDING
  const height = maxY + NODE_H + PADDING * 2
  return { nodes: pos, width, height, minX: PADDING, minY: 0, maxX, maxY }
}

function getAnchor(source: LayoutNode, target: LayoutNode) {
  const sx = source.x + NODE_W / 2
  const sy = source.y + NODE_H / 2
  const tx = target.x + NODE_W / 2
  const ty = target.y + NODE_H / 2
  const dy = ty - sy
  const dx = tx - sx

  // choose side based on dominant direction
  if (Math.abs(dy) >= Math.abs(dx)) {
    if (dy >= 0) {
      // source bottom -> target top
      return { sx: sx, sy: source.y + NODE_H, tx: tx, ty: target.y, down: true }
    } else {
      return { sx: sx, sy: source.y, tx: tx, ty: target.y + NODE_H, down: false }
    }
  } else {
    if (dx >= 0) {
      return { sx: source.x + NODE_W, sy: sy, tx: target.x, ty: ty, down: dy >= 0 }
    } else {
      return { sx: source.x, sy: sy, tx: target.x + NODE_W, ty: ty, down: dy >= 0 }
    }
  }
}

function edgePath(a: ReturnType<typeof getAnchor>) {
  const { sx, sy, tx, ty } = a
  const dy = ty - sy
  const dx = tx - sx
  const c1y = sy + dy * 0.35
  const c2y = ty - dy * 0.35
  // for horizontal dominance use x as well
  if (Math.abs(dx) > Math.abs(dy) * 1.2) {
    const c1x = sx + dx * 0.35
    const c2x = tx - dx * 0.35
    return `M ${sx} ${sy} C ${c1x} ${sy} ${c2x} ${ty} ${tx} ${ty}`
  }
  return `M ${sx} ${sy} C ${sx} ${c1y} ${tx} ${c2y} ${tx} ${ty}`
}

// ---------------------------------------------------------------------------
// Component
// ---------------------------------------------------------------------------
export function SceneGraphDAG({ scene, selectedId, onSelect }: Props): JSX.Element {
  const { refEdges, diagnostics, arrangementOpEdges, cycles, cycleEdgeSet, flatMap } = useMemo(() => {
    const ref = collectRefEdges(scene)
    const diags = validateSceneGraph(scene)
    let opEdges = 0
    const { byId: flatMapInner } = collectFlat(scene.root as any)
    const walkOp = (n: SceneEntity) => {
      opEdges += arrangementOf(n)?.edges.length ?? 0
      n.children.forEach(walkOp as any)
    }
    walkOp(scene.root as any)
    const cyc = findCycles(ref)
    const cycleSet = new Set<string>()
    for (const c of cyc) for (const e of c.edges) cycleSet.add(`${e.from}->${e.to}`)
    return { refEdges: ref, diagnostics: diags, arrangementOpEdges: opEdges, cycles: cyc, cycleEdgeSet: cycleSet, flatMap: flatMapInner }
  }, [scene])

  const layoutInfo = useMemo(() => computeTreeLayout(scene.root as any), [scene.root])

  // view state
  const viewportRef = useRef<HTMLDivElement>(null)
  const [pan, setPan] = useState({ x: 24, y: 16 })
  const [scale, setScale] = useState(0.85)
  const [isPanning, setIsPanning] = useState(false)
  const panStart = useRef<{ x: number; y: number; panX: number; panY: number } | null>(null)
  const [draggingId, setDraggingId] = useState<string | null>(null)
  const dragOffset = useRef<{ x: number; y: number } | null>(null)
  const [nodeOverrides, setNodeOverrides] = useState<Map<string, { x: number; y: number }>>(new Map())
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const [hoveredEdgeIdx, setHoveredEdgeIdx] = useState<number | null>(null)
  const [filter, setFilter] = useState({ contains: true, instantiates: true, constrains: true })
  const [showCyclesOnly, setShowCyclesOnly] = useState(false)
  const [search, setSearch] = useState('')
  const [showLabels, setShowLabels] = useState(true)

  // reset overrides on scene change
  useEffect(() => { setNodeOverrides(new Map()) }, [scene.id, scene.root.id])

  const nodesWithOverrides = useMemo(() => {
    const out = new Map<string, LayoutNode>()
    for (const [id, n] of layoutInfo.nodes) {
      const ov = nodeOverrides.get(id)
      out.set(id, ov ? { ...n, x: ov.x, y: ov.y } : n)
    }
    return out
  }, [layoutInfo.nodes, nodeOverrides])

  const filteredEdges = useMemo(() => {
    let edges = refEdges.filter(e => {
      if (e.kind === 'contains' && !filter.contains) return false
      if (e.kind === 'instantiates' && !filter.instantiates) return false
      if (e.kind === 'constrains' && !filter.constrains) return false
      if (showCyclesOnly && !cycleEdgeSet.has(`${e.from}->${e.to}`)) return false
      return true
    })
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      // keep edges where either endpoint matches search; still show all nodes dimmed logic elsewhere
      edges = edges.filter(e => e.from.toLowerCase().includes(q) || e.to.toLowerCase().includes(q) || e.via.toLowerCase().includes(q))
    }
    return edges
  }, [refEdges, filter, showCyclesOnly, cycleEdgeSet, search])

  const byKind = useMemo(() => ({
    contains: refEdges.filter(e => e.kind === 'contains'),
    instantiates: refEdges.filter(e => e.kind === 'instantiates'),
    constrains: refEdges.filter(e => e.kind === 'constrains'),
  }), [refEdges])

  const selectedRelated = useMemo(() => {
    if (!selectedId) return { incoming: [] as RefEdge[], outgoing: [] as RefEdge[] }
    return {
      incoming: refEdges.filter(e => e.to === selectedId),
      outgoing: refEdges.filter(e => e.from === selectedId),
    }
  }, [refEdges, selectedId])

  const fitView = useCallback(() => {
    const vp = viewportRef.current
    if (!vp) return
    const vpW = vp.clientWidth
    const vpH = vp.clientHeight
    const w = layoutInfo.width
    const h = layoutInfo.height
    const sx = vpW / (w + PADDING * 2)
    const sy = vpH / (h + PADDING * 2)
    const newScale = Math.min(sx, sy, 1.1) * 0.92
    const cx = (vpW - w * newScale) / 2
    const cy = (vpH - h * newScale) / 2
    setScale(newScale)
    setPan({ x: cx, y: cy })
  }, [layoutInfo.width, layoutInfo.height])

  useEffect(() => { fitView() }, [fitView])

  // mouse helpers
  const getContentPoint = useCallback((clientX: number, clientY: number) => {
    const vp = viewportRef.current
    if (!vp) return { x: 0, y: 0, vx: 0, vy: 0 }
    const r = vp.getBoundingClientRect()
    const vx = clientX - r.left
    const vy = clientY - r.top
    const cx = (vx - pan.x) / scale
    const cy = (vy - pan.y) / scale
    return { x: cx, y: cy, vx, vy }
  }, [pan, scale])

  const onWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault()
    const { x: cx, y: cy, vx, vy } = getContentPoint(e.clientX, e.clientY)
    const factor = e.deltaY < 0 ? 1.08 : 0.92
    const newScale = Math.max(0.12, Math.min(3.5, scale * factor))
    setPan({ x: vx - cx * newScale, y: vy - cy * newScale })
    setScale(newScale)
  }, [getContentPoint, scale])

  const onMouseDownViewport = useCallback((e: React.MouseEvent) => {
    if (e.button !== 0) return
    const target = e.target as HTMLElement
    // if clicking on node, node handler will stop propagation
    if (target.closest('[data-node]')) return
    setIsPanning(true)
    panStart.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y }
  }, [pan])

  const onMouseMoveWin = useCallback((e: MouseEvent) => {
    if (isPanning && panStart.current) {
      const dx = e.clientX - panStart.current.x
      const dy = e.clientY - panStart.current.y
      setPan({ x: panStart.current.panX + dx, y: panStart.current.panY + dy })
    }
    if (draggingId) {
      const { x, y } = getContentPoint(e.clientX, e.clientY)
      const off = dragOffset.current
      if (!off) return
      const nx = x - off.x
      const ny = y - off.y
      setNodeOverrides(prev => {
        const m = new Map(prev)
        m.set(draggingId, { x: nx, y: ny })
        return m
      })
    }
  }, [isPanning, draggingId, getContentPoint])

  const onMouseUpWin = useCallback(() => {
    setIsPanning(false)
    panStart.current = null
    setDraggingId(null)
    dragOffset.current = null
  }, [])

  useEffect(() => {
    if (isPanning || draggingId) {
      window.addEventListener('mousemove', onMouseMoveWin)
      window.addEventListener('mouseup', onMouseUpWin)
      return () => {
        window.removeEventListener('mousemove', onMouseMoveWin)
        window.removeEventListener('mouseup', onMouseUpWin)
      }
    }
  }, [isPanning, draggingId, onMouseMoveWin, onMouseUpWin])

  const selectedEntity = useMemo(() => {
    if (!selectedId) return null
    return flatMap.get(selectedId)?.entity as SceneEntity | undefined ?? null
  }, [selectedId, flatMap])

  // render helpers
  const totalEntities = flatMap.size

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', fontSize: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
      {/* header stats */}
      <div style={{ display: 'flex', gap: 12, fontSize: 10, color: '#777', flexWrap: 'wrap', alignItems: 'center' }}>
        <span>Entities: {totalEntities}</span>
        <span>Edges: {filteredEdges.length}/{refEdges.length} (contains {byKind.contains.length} / instantiates {byKind.instantiates.length} / constrains {byKind.constrains.length})</span>
        <span>Op edges: {arrangementOpEdges}</span>
        {cycles.length > 0 && <span style={{ color: '#ff6b6b' }}>{cycles.length} cycles</span>}
        {diagnostics.length > 0 && <span style={{ color: diagnostics.some(d => d.level === 'error') ? '#ff6b6b' : '#d4a000' }}>{diagnostics.length} diagnostics</span>}
        <span style={{ marginLeft: 'auto', color: '#666' }}>Entity Graph DAG — nodes=entities, directed edges: contains / instantiates / constrains. Pan drag, wheel zoom, drag nodes.</span>
      </div>

      {diagnostics.length > 0 && (
        <div style={{ border: '1px solid #4a2a2a', borderRadius: 6, background: '#1e1212', padding: 8 }}>
          <div style={{ fontWeight: 600, fontSize: 10, color: '#ff8888', marginBottom: 4, textTransform: 'uppercase' }}>Diagnostics</div>
          {diagnostics.map((d, i) => (
            <div key={i} style={{ fontSize: 10, color: d.level === 'error' ? '#ff6b6b' : '#d4a000', marginBottom: 2 }}>{d.level}: [{d.code}] {d.message}</div>
          ))}
          {cycles.length > 0 && (
            <div style={{ marginTop: 6, fontSize: 10, color: '#ff8888' }}>
              {cycles.map((c, i) => (
                <div key={i}>cycle {i + 1}: {c.path.join(' → ')} → {c.path[0]}</div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* controls */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap', background: '#1a1a1e', border: '1px solid #2a2a2e', borderRadius: 6, padding: '6px 8px' }}>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          {(['contains','instantiates','constrains'] as const).map(k => (
            <label key={k} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: filter[k] ? edgeKindColor(k) : '#555', cursor: 'pointer' }}>
              <input type="checkbox" checked={filter[k as keyof typeof filter]} onChange={e => setFilter(s => ({ ...s, [k]: e.target.checked }))} style={{ accentColor: edgeKindColor(k) }} />
              <span style={{ width: 10, height: 10, borderRadius: 2, background: edgeKindColor(k), display: 'inline-block', opacity: filter[k] ? 1 : 0.2 }} />
              {k}
            </label>
          ))}
        </div>
        <label style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: showCyclesOnly ? '#ff6b6b' : '#777' }}>
          <input type="checkbox" checked={showCyclesOnly} onChange={e => setShowCyclesOnly(e.target.checked)} />
          cycles only {cycles.length > 0 ? `(${cycles.length})` : ''}
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#777' }}>
          <input type="checkbox" checked={showLabels} onChange={e => setShowLabels(e.target.checked)} />
          labels
        </label>
        <input
          placeholder="search id/word/via…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ marginLeft: 8, background: '#121214', border: '1px solid #2a2a2e', borderRadius: 4, color: '#ccc', fontSize: 11, padding: '3px 6px', width: 160 }}
        />
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
          <button onClick={fitView} style={{ fontSize: 11, padding: '3px 8px', background: '#232326', border: '1px solid #333', borderRadius: 4, color: '#ccc', cursor: 'pointer' }}>◎ Fit</button>
          <button onClick={() => { setPan({ x: 24, y: 16 }); setScale(0.85) }} style={{ fontSize: 11, padding: '3px 8px', background: '#232326', border: '1px solid #333', borderRadius: 4, color: '#ccc', cursor: 'pointer' }}>Reset</button>
          <button onClick={() => setNodeOverrides(new Map())} style={{ fontSize: 11, padding: '3px 8px', background: '#232326', border: '1px solid #333', borderRadius: 4, color: '#888', cursor: 'pointer' }}>Unpin nodes</button>
          <span style={{ fontSize: 10, color: '#555', alignSelf: 'center' }}>{Math.round(scale * 100)}% pan {Math.round(pan.x)},{Math.round(pan.y)}</span>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start', minHeight: 420 }}>
        {/* DAG canvas */}
        <div
          ref={viewportRef}
          onMouseDown={onMouseDownViewport}
          onWheel={onWheel}
          style={{
            flex: 1,
            height: 520,
            border: '1px solid #2a2a2e',
            borderRadius: 8,
            background: '#0e0e10',
            overflow: 'hidden',
            position: 'relative',
            cursor: isPanning ? 'grabbing' : draggingId ? 'grabbing' : 'grab',
            minWidth: 0,
          }}
        >
          {/* transform container */}
          <div
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: layoutInfo.width,
              height: layoutInfo.height,
              transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
              transformOrigin: '0 0',
            }}
          >
            <svg
              width={layoutInfo.width}
              height={layoutInfo.height}
              style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', pointerEvents: 'none' }}
            >
              <defs>
                {(['contains','instantiates','constrains'] as const).map(k => (
                  <marker key={k} id={`arrow-${k}`} viewBox="0 0 10 8" refX={8} refY={4} markerWidth={8} markerHeight={8} orient="auto-start-reverse">
                    <path d="M 0 0 L 10 4 L 0 8 z" fill={edgeKindColor(k)} />
                  </marker>
                ))}
                <marker id="arrow-cycle" viewBox="0 0 10 8" refX={8} refY={4} markerWidth={8} markerHeight={8} orient="auto-start-reverse">
                  <path d="M 0 0 L 10 4 L 0 8 z" fill="#ff6b6b" />
                </marker>
                <marker id="arrow-hover" viewBox="0 0 10 8" refX={8} refY={4} markerWidth={10} markerHeight={10} orient="auto-start-reverse">
                  <path d="M 0 0 L 10 4 L 0 8 z" fill="#fff" />
                </marker>
              </defs>
              {filteredEdges.map((e, i) => {
                const s = nodesWithOverrides.get(e.from)
                const t = nodesWithOverrides.get(e.to)
                if (!s || !t) return null
                const anchor = getAnchor(s, t)
                const d = edgePath(anchor)
                const isCycle = cycleEdgeSet.has(`${e.from}->${e.to}`)
                const isHovered = hoveredEdgeIdx === i
                const isSelectedRelated = selectedId && (e.from === selectedId || e.to === selectedId)
                const isDim = selectedId ? !isSelectedRelated : false
                const color = isCycle ? '#ff6b6b' : edgeKindColor(e.kind)
                const opacity = isHovered ? 1 : isDim ? 0.12 : isSelectedRelated ? 0.95 : 0.55
                const width = isHovered ? 3.5 : isSelectedRelated ? 2.6 : isCycle ? 2.4 : e.kind === 'contains' ? 1.2 : 1.8
                return (
                  <g key={i} style={{ pointerEvents: 'auto' }} onMouseEnter={() => setHoveredEdgeIdx(i)} onMouseLeave={() => setHoveredEdgeIdx(null)}>
                    {/* hit area */}
                    <path d={d} stroke="transparent" strokeWidth={12} fill="none" style={{ pointerEvents: 'stroke' }} />
                    <path
                      d={d}
                      stroke={color}
                      strokeWidth={width}
                      strokeDasharray={isHovered ? undefined : edgeDash(e.kind)}
                      fill="none"
                      opacity={opacity}
                      markerEnd={isHovered ? 'url(#arrow-hover)' : isCycle ? 'url(#arrow-cycle)' : `url(#arrow-${e.kind})`}
                    />
                    {showLabels && (isSelectedRelated || isHovered || e.kind !== 'contains') && (
                      <text
                        x={(anchor.sx + anchor.tx) / 2}
                        y={(anchor.sy + anchor.ty) / 2 - 4}
                        fontSize={9}
                        fill={isHovered ? '#fff' : color}
                        opacity={isDim ? 0.2 : 0.9}
                        textAnchor="middle"
                        style={{ pointerEvents: 'none', userSelect: 'none' }}
                      >
                        {e.kind === 'contains' ? '' : e.kind[0]}
                      </text>
                    )}
                  </g>
                )
              })}
            </svg>

            {/* nodes */}
            {Array.from(nodesWithOverrides.values()).map(n => {
              const isSel = selectedId === n.id
              const isHovered = hoveredId === n.id
              const searchActive = search.trim().length > 0
              const matchesSearch = !searchActive || n.entity.word.toLowerCase().includes(search.toLowerCase()) || n.id.toLowerCase().includes(search.toLowerCase())
              const isDim = (selectedId && !isSel && !(selectedRelated.incoming.some(e => e.from === n.id) || selectedRelated.outgoing.some(e => e.to === n.id))) || (searchActive && !matchesSearch)
              const isRelated = selectedId && (selectedRelated.incoming.some(e => e.from === n.id) || selectedRelated.outgoing.some(e => e.to === n.id))
              const ops = arrangementOf(n.entity)?.ops ?? []
              const edgesInner = arrangementOf(n.entity)?.edges ?? []

              return (
                <div
                  key={n.id}
                  data-node={n.id}
                  onMouseDown={e => {
                    e.stopPropagation()
                    const { x: cx, y: cy } = getContentPoint(e.clientX, e.clientY)
                    dragOffset.current = { x: cx - n.x, y: cy - n.y }
                    setDraggingId(n.id)
                  }}
                  onMouseEnter={() => setHoveredId(n.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  onClick={e => { e.stopPropagation(); onSelect?.(n.id) }}
                  style={{
                    position: 'absolute',
                    left: n.x,
                    top: n.y,
                    width: NODE_W,
                    height: NODE_H,
                    background: kindBg(entityRole(n.entity)),
                    border: `${isSel ? 2 : 1}px solid ${isSel ? '#8ec7ff' : isHovered ? '#aaa' : kindBorder(entityRole(n.entity))}`,
                    borderRadius: 8,
                    boxShadow: isSel ? '0 0 0 2px rgba(142,199,255,0.2), 0 2px 12px rgba(0,0,0,0.4)' : isHovered ? '0 2px 8px rgba(0,0,0,0.5)' : '0 1px 3px rgba(0,0,0,0.3)',
                    opacity: isDim ? 0.22 : 1,
                    transform: isRelated ? 'scale(1.04)' : undefined,
                    transition: draggingId === n.id ? 'none' : 'transform 0.12s, opacity 0.12s, border-color 0.12s',
                    display: 'flex',
                    flexDirection: 'column',
                    padding: '5px 7px',
                    cursor: 'pointer',
                    userSelect: 'none',
                    zIndex: isSel ? 3 : isHovered ? 2 : 1,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 5, minWidth: 0 }}>
                    <span style={{ fontSize: 12, lineHeight: 1 }}>{kindIcon(entityRole(n.entity))}</span>
                    <span style={{ fontWeight: 700, fontSize: 11, color: isSel ? '#8ec7ff' : '#ddd', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{n.entity.word}</span>
                    <span style={{ fontSize: 8, color: '#777', marginLeft: 'auto', whiteSpace: 'nowrap' }}>{entityRole(n.entity)}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 2, minWidth: 0 }}>
                    <span style={{ fontSize: 9, color: '#666', fontFamily: 'monospace', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{n.id}</span>
                    {(n.entity as any).template && <span style={{ fontSize: 7, background: '#c5a000', color: '#000', padding: '0 3px', borderRadius: 2, marginLeft: 'auto' }}>T</span>}
                    {n.entity.enabled === false && <span style={{ fontSize: 7, background: '#444', color: '#888', padding: '0 3px', borderRadius: 2 }}>OFF</span>}
                  </div>
                  <div style={{ display: 'flex', gap: 6, marginTop: 'auto', fontSize: 8, color: '#555', alignItems: 'center' }}>
                    <span>{flatMap.get(n.id)?.childrenIds.length ?? 0} ch</span>
                    {(n.entity as any).template === undefined && n.parentId === null && <span style={{ color: '#666' }}>root</span>}
                    {arrangementOf(n.entity) && <span style={{ color: '#8ec7ff' }}>{ops.length}o/{edgesInner.length}e</span>}
                    {n.depth > 0 && <span style={{ marginLeft: 'auto', color: '#444' }}>d{n.depth}</span>}
                  </div>
                </div>
              )
            })}
          </div>

          {/* overlay info when empty */}
          {nodesWithOverrides.size === 0 && (
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#555', fontStyle: 'italic' }}>Empty scene</div>
          )}
        </div>

        {/* side detail */}
        <div style={{ width: 360, display: 'flex', flexDirection: 'column', gap: 8, maxHeight: 520 }}>
          <div style={{ border: '1px solid #2a2a2e', borderRadius: 8, background: '#121214', padding: 8, overflow: 'auto', flex: 1 }}>
            <div style={{ fontWeight: 600, fontSize: 10, color: '#aaa', marginBottom: 6, textTransform: 'uppercase', display: 'flex', justifyContent: 'space-between' }}>
              <span>Selection</span>
              {selectedId && <button onClick={() => onSelect?.(null)} style={{ background: 'none', border: 'none', color: '#777', cursor: 'pointer', fontSize: 10 }}>clear</button>}
            </div>
            {!selectedEntity ? (
              <div style={{ color: '#666', fontStyle: 'italic', fontSize: 11 }}>Click a node to inspect. Drag to reposition, wheel to zoom, drag background to pan.</div>
            ) : (
              <div style={{ fontSize: 11, display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span style={{ fontSize: 16 }}>{kindIcon(entityRole(selectedEntity))}</span>
                  <div>
                    <div style={{ fontWeight: 700, color: '#ccc' }}>{selectedEntity.word} <span style={{ color: '#666', fontWeight: 400 }}>{selectedEntity.id}</span></div>
                    <div style={{ fontSize: 10, color: '#777' }}>{entityRole(selectedEntity)} depth {flatMap.get(selectedId!)?.depth ?? '?'} parent {flatMap.get(selectedId!)?.parentId ?? 'root'}</div>
                  </div>
                </div>
                {(selectedEntity as any).template && <div style={{ fontSize: 10, background: '#c5a000', color: '#000', padding: '2px 6px', borderRadius: 3, alignSelf: 'flex-start' }}>TEMPLATE</div>}
                <div style={{ display: 'flex', gap: 12, fontSize: 10, color: '#777' }}>
                  <span>{(selectedEntity.children?.length ?? 0)} children</span>
                  <span>{selectedRelated.incoming.length} in</span>
                  <span>{selectedRelated.outgoing.length} out</span>
                </div>

                {arrangementOf(selectedEntity) && (
                  <div style={{ background: '#1a1a1e', border: '1px solid #2a2a2e', borderRadius: 6, padding: 6 }}>
                    <div style={{ fontSize: 10, color: '#8ec7ff', fontWeight: 600, marginBottom: 4 }}>arrangement DAG — internal ops</div>
                    {((selectedEntity as any).arrangement?.ops ?? []).map((op: any) => (
                      <div key={op.id} style={{ fontSize: 10, color: '#aaa', display: 'flex', gap: 6, padding: '2px 0' }}>
                        <span style={{ color: op.type === 'points' ? '#8ec7ff' : '#c5ff8e' }}>● {op.type}</span>
                        <span style={{ color: '#ccc' }}>{op.id}</span>
                        <span style={{ color: '#666', marginLeft: 'auto', maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {op.type === 'points' ? `${op.generator?.type} ${op.generator?.countX ? `${op.generator.countX}×${op.generator.countY}` : op.generator?.count ?? ''}` : `${op.templates?.join(',')} @ ${op.points}`}
                        </span>
                      </div>
                    ))}
                    {((selectedEntity as any).arrangement?.edges?.length ?? 0) > 0 && (
                      <div style={{ marginTop: 6, borderTop: '1px solid #222', paddingTop: 4 }}>
                        {((selectedEntity as any).arrangement.edges as any[]).map((ed: any, i: number) => (
                          <div key={i} style={{ fontSize: 9, color: '#666' }}>{ed.from} → {ed.to}</div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <div>
                  <div style={{ fontSize: 10, color: '#aaa', fontWeight: 600, marginBottom: 4 }}>Outgoing ({selectedRelated.outgoing.length})</div>
                  {selectedRelated.outgoing.length === 0 ? <div style={{ color: '#555', fontSize: 10, fontStyle: 'italic' }}>none</div> : selectedRelated.outgoing.map((e, i) => (
                    <div key={i} style={{ display: 'flex', gap: 6, padding: '2px 0', borderBottom: '1px solid #1a1a1e', fontSize: 10 }}>
                      <span style={{ color: edgeKindColor(e.kind), fontWeight: 600, minWidth: 66 }}>{e.kind}</span>
                      <span style={{ color: '#555' }}>→</span>
                      <button onClick={() => onSelect?.(e.to)} style={{ background: 'none', border: 'none', color: e.to === selectedId ? '#8ec7ff' : '#ccc', cursor: 'pointer', fontSize: 10, textAlign: 'left' }}>{e.to}</button>
                      <span style={{ color: '#555', fontSize: 9, marginLeft: 'auto' }}>{e.via}</span>
                    </div>
                  ))}
                </div>
                <div>
                  <div style={{ fontSize: 10, color: '#aaa', fontWeight: 600, marginBottom: 4 }}>Incoming ({selectedRelated.incoming.length})</div>
                  {selectedRelated.incoming.length === 0 ? <div style={{ color: '#555', fontSize: 10, fontStyle: 'italic' }}>none (root or orphan)</div> : selectedRelated.incoming.map((e, i) => (
                    <div key={i} style={{ display: 'flex', gap: 6, padding: '2px 0', borderBottom: '1px solid #1a1a1e', fontSize: 10 }}>
                      <span style={{ color: edgeKindColor(e.kind), fontWeight: 600, minWidth: 66 }}>{e.kind}</span>
                      <button onClick={() => onSelect?.(e.from)} style={{ background: 'none', border: 'none', color: '#aaa', cursor: 'pointer', fontSize: 10, textAlign: 'left' }}>{e.from}</button>
                      <span style={{ color: '#555' }}>→ {selectedId}</span>
                      <span style={{ color: '#555', fontSize: 9, marginLeft: 'auto' }}>{e.via}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div style={{ border: '1px solid #2a2a2e', borderRadius: 8, background: '#121214', padding: 8, maxHeight: 220, overflow: 'auto' }}>
            <div style={{ fontWeight: 600, fontSize: 10, color: '#aaa', marginBottom: 6, textTransform: 'uppercase' }}>
              Reference Edges ({filteredEdges.length}/{refEdges.length}) {showCyclesOnly ? '— cycles only' : ''}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
              {filteredEdges.length === 0 ? <div style={{ color: '#666', fontStyle: 'italic', fontSize: 10 }}>No edges match filters</div> : filteredEdges.slice(0, 200).map((e, i) => {
                const isCycle = cycleEdgeSet.has(`${e.from}->${e.to}`)
                const isHover = hoveredEdgeIdx === i
                const isRel = selectedId && (e.from === selectedId || e.to === selectedId)
                return (
                  <div key={i} onMouseEnter={() => setHoveredEdgeIdx(i)} onMouseLeave={() => setHoveredEdgeIdx(null)} style={{ display: 'flex', gap: 6, padding: '3px 4px', borderBottom: '1px solid #1e1e20', background: isHover ? '#1e1e20' : isRel ? '#1e2a3a' : isCycle ? '#1e1212' : 'transparent', borderRadius: 3 }}>
                    <span style={{ color: isCycle ? '#ff6b6b' : edgeKindColor(e.kind), fontWeight: 600, minWidth: 62, fontSize: 10 }}>{e.kind}{isCycle ? ' ↻' : ''}</span>
                    <button onClick={() => onSelect?.(e.from)} style={{ background: 'none', border: 'none', color: selectedId === e.from ? '#8ec7ff' : '#999', cursor: 'pointer', fontSize: 10 }}>{e.from}</button>
                    <span style={{ color: '#555' }}>→</span>
                    <button onClick={() => onSelect?.(e.to)} style={{ background: 'none', border: 'none', color: selectedId === e.to ? '#8ec7ff' : '#ccc', cursor: 'pointer', fontSize: 10 }}>{e.to}</button>
                    <span style={{ color: '#555', fontSize: 8, marginLeft: 'auto', maxWidth: 80, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={e.via}>{e.via}</span>
                  </div>
                )
              })}
              {filteredEdges.length > 200 && <div style={{ fontSize: 10, color: '#666' }}>… +{filteredEdges.length - 200} more</div>}
            </div>
            <div style={{ marginTop: 6, fontSize: 9, color: '#555', lineHeight: 1.3 }}>
              Reference DAG: contains=children (spanning tree), instantiates=arrangement ops[].templates, constrains=constraint/link/BT/pathFollow/skinnedMesh. Cycles in red. Dashed: instantiates (6 4), constrains (3 5).
            </div>
          </div>
        </div>
      </div>

      <div style={{ fontSize: 10, color: '#555' }}>
        DAG viewer: containment gives initial tree layout (leaf-order), all ref edges drawn as directed beziers with arrow markers. Select highlights incident edges, dimming others. Search dims non-matching nodes. Pan background, drag nodes to pin (Unpin resets).
      </div>
    </div>
  )
}

export const EntityGraph = SceneGraphDAG
export const ReferenceGraph = SceneGraphDAG
