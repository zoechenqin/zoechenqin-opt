/**
 * Playground App — 3D-editor layout:
 * Left: Project / Scene / Outliner tabs (Project holds 2D/3D base spawn)
 * Middle: Video/preview (viewport) with timeline directly below
 * Right: Properties / Trace tabs
 */
import { useCallback, useEffect, useRef, useState } from 'react'
import type { EventEnvelope, Scene } from '@scenelab/scene-ir'
import { applyEvent, findEntity, sampleScene, sampleScene3D } from '@scenelab/scene-ir'
import { PropertiesPanel, SpatialCanvas, ThreeCanvas, Timeline, WidgetHost } from '@scenelab/widgets'
import { useSharedScene } from './useSharedScene'
import { useSharedUI } from './useSharedUI'
import { SceneGraphDAG } from './SceneGraphDAG'
import { BehaviorTreeView } from './BehaviorTreeView'
import { AgentPanel } from './AgentPanel'

type LeftTab = 'project' | 'scene' | 'outliner' | 'widgets' | 'agent'
type RightTab = 'properties' | 'trace'
type BottomTab = 'entity-graph' | 'behavior'

function getPopoutView(): string | null {
  if (typeof window === 'undefined') return null
  return new URLSearchParams(window.location.search).get('view')
}

export function App(): JSX.Element {
  const popoutView = getPopoutView()
  const shared = useSharedScene()
  const ui = useSharedUI()
  const [scene, setScene] = useState<Scene>(() => sampleScene())
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [trace, setTrace] = useState<EventEnvelope[]>([])
  const [t, setT] = useState(0)
  const [leftTab, setLeftTab] = useState<LeftTab>('project')
  const [rightTab, setRightTab] = useState<RightTab>('properties')
  const [bottomTab, setBottomTab] = useState<BottomTab>('entity-graph')

  // --- projects FS state ---
  const [projectPath, setProjectPath] = useState<string>('')
  const [projectEntries, setProjectEntries] = useState<Array<{ name: string; type: 'dir' | 'file'; path: string; isDir: boolean }>>([])
  const [projectSavePath, setProjectSavePath] = useState<string | null>(null)
  const [projectError, setProjectError] = useState<string | null>(null)
  const [newItemName, setNewItemName] = useState<string>('')
  const [projectLoading, setProjectLoading] = useState(false)

  const bcRef = useRef<BroadcastChannel | null>(null)
  useEffect(() => {
    const bc = new BroadcastChannel('scenelab-ui')
    bcRef.current = bc
    bc.onmessage = (e: MessageEvent) => {
      const msg = e.data as { type?: string; id?: string | null; t?: number }
      if (msg.type === 'select') setSelectedId(msg.id ?? null)
      if (msg.type === 'time') setT(msg.t ?? 0)
    }
    return () => bc.close()
  }, [])

  const broadcastSelect = useCallback((id: string | null) => {
    setSelectedId(id)
    bcRef.current?.postMessage({ type: 'select', id })
  }, [])

  const broadcastTime = useCallback((newT: number) => {
    setT(newT)
    bcRef.current?.postMessage({ type: 'time', t: newT })
  }, [])

  const popOut = useCallback((type: string) => {
    const id = `${type}-${Date.now()}`
    void ui.spawn({ id, type: type as any, position: 'floating' })
  }, [])

  const popOutWindow = useCallback((type: string) => {
    window.open(`${window.location.origin}${window.location.pathname}?view=${type}`, `scenelab-${type}`, 'width=900,height=700')
  }, [])

  const applyEnvelopes = useCallback(
    (events: EventEnvelope[]): void => {
      if (shared.connected) {
        void shared.submit(events)
        return
      }
      setScene((prev) => events.reduce((s, env) => applyEvent(s, env.event), prev))
      setTrace((prev) => [...prev, ...events])
    },
    [shared],
  )

  const agentNudgeLabel = (): void => {
    const active = shared.connected && shared.scene ? shared.scene : scene
    const entity = findEntity(active.root, selectedId ?? '') ?? findEntity(active.root, 'label_1') ?? findEntity(active.root, 'box') ?? findEntity(active.root, 'sphere') ?? findEntity(active.root, 'circle_1')
    if (!entity || entity.transform.position.kind !== 'const') return
    const from = entity.transform.position.value
    applyEnvelopes([
      {
        event: { type: 'entity.translate', target: entity.id, from, to: { ...from, x: from.x + 40 } },
        source: 'agent',
        agent: 'demo-agent',
        timestamp: Date.now(),
        sessionId: 'demo',
      },
    ])
  }

  const load2D = (): void => {
    const s2d = sampleScene()
    if (shared.connected) {
      void fetch('/api/scene', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ scene: s2d }),
      })
    }
    setScene(s2d)
    setSelectedId(null)
    setTrace([])
    setT(0)
  }
  const load3D = (): void => {
    const s3d = sampleScene3D()
    if (shared.connected) {
      void fetch('/api/scene', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ scene: s3d }),
      })
    }
    setScene(s3d)
    setSelectedId(null)
    setTrace([])
    setT(0)
  }

  // --- projects FS actions ---
  const fetchProjects = useCallback(async (path: string): Promise<void> => {
    setProjectLoading(true)
    setProjectError(null)
    try {
      const res = await fetch(`/api/projects?path=${encodeURIComponent(path)}`)
      if (!res.ok) {
        const body = (await res.json()) as { error?: string }
        throw new Error(body.error ?? `status ${res.status}`)
      }
      const data = (await res.json()) as { path: string; entries: Array<{ name: string; type: 'dir' | 'file'; path: string; isDir: boolean }>; savePath: string | null }
      setProjectEntries(data.entries)
      setProjectSavePath(data.savePath ?? null)
    } catch (e) {
      setProjectError((e as Error).message)
      setProjectEntries([])
    } finally {
      setProjectLoading(false)
    }
  }, [])

  const [createModal, setCreateModal] = useState<null | { type: 'project' | 'scene' | 'folder' | 'save-as-scene'; name: string }>(null)

  const handleSave = useCallback(async (): Promise<void> => {
    if (!projectSavePath) {
      setProjectError('no scene loaded — open a scene to save')
      return
    }
    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ action: 'save' }),
      })
      if (!res.ok) {
        const b = (await res.json()) as { error?: string }
        throw new Error(b.error ?? `status ${res.status}`)
      }
      setProjectError(null)
      await fetchProjects(projectPath)
    } catch (e) {
      setProjectError((e as Error).message)
    }
  }, [projectSavePath, projectPath, fetchProjects])

  const handleCreateDir = useCallback(
    async (rawName: string): Promise<void> => {
      // asset folder inside a scene (depth >=2) — project/scene/<newFolder>
      const name = rawName.trim()
      if (!name) {
        setProjectError('name required')
        return
      }
      if (name.includes('/') || name.includes('\\')) {
        setProjectError('name cannot contain path separators — use single segment')
        return
      }
      const segs = projectPath.split('/').filter(Boolean)
      if (segs.length < 2) {
        setProjectError('asset folders can only be created inside a scene folder')
        return
      }
      const target = `${projectPath}/${name}`
      try {
        const res = await fetch('/api/projects', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action: 'create-dir', path: target }),
        })
        if (!res.ok) {
          const b = (await res.json()) as { error?: string }
          throw new Error(b.error ?? `status ${res.status}`)
        }
        setNewItemName('')
        setCreateModal(null)
        await fetchProjects(projectPath)
      } catch (e) {
        setProjectError((e as Error).message)
      }
    },
    [projectPath, fetchProjects],
  )

  const handleCreateProject = useCallback(
    async (rawName: string): Promise<void> => {
      // Projects are always top-level: projects/<name>/ — cannot be nested
      let name = rawName.trim()
      if (!name) {
        name = `project-${Date.now().toString(36)}`
      }
      if (name.includes('/') || name.includes('\\')) {
        setProjectError('project name cannot contain subfolders — projects live directly under projects/')
        return
      }
      const target = name // always at root, not projectPath-prefixed
      try {
        const res = await fetch('/api/projects', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action: 'create-project', path: target }),
        })
        if (!res.ok) {
          const b = (await res.json()) as { error?: string }
          throw new Error(b.error ?? `status ${res.status}`)
        }
        setNewItemName('')
        setCreateModal(null)
        await fetchProjects(projectPath)
        // navigate into new project
        setProjectPath(target)
      } catch (e) {
        setProjectError((e as Error).message)
      }
    },
    [projectPath, fetchProjects],
  )

  const handleCreateScene = useCallback(
    async (rawName: string): Promise<void> => {
      // Scenes are subfolders of a project: <project>/<sceneName>/scene.json (fixed name)
      let name = rawName.trim()
      if (!name) {
        name = `scene-${Date.now().toString(36)}`
      }
      if (name.includes('/') || name.includes('\\')) {
        setProjectError('scene name cannot contain subfolders')
        return
      }
      const segs = projectPath.split('/').filter(Boolean)
      if (segs.length === 0) {
        setProjectError('select a project first — scenes live inside a project')
        return
      }
      const projectName = segs[0]
      const target = `${projectName}/${name}` // always <project>/<scene>, not nested deeper
      try {
        const res = await fetch('/api/projects', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action: 'create-scene', path: target }),
        })
        if (!res.ok) {
          const b = (await res.json()) as { error?: string }
          throw new Error(b.error ?? `status ${res.status}`)
        }
        const data = (await res.json()) as { savePath: string }
        setNewItemName('')
        setCreateModal(null)
        setProjectSavePath(data.savePath)
        await fetchProjects(projectPath)
      } catch (e) {
        setProjectError((e as Error).message)
      }
    },
    [projectPath, fetchProjects],
  )

  const handleOpenPath = useCallback(
    async (entryPath: string): Promise<void> => {
      try {
        const res = await fetch('/api/projects', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action: 'open', path: entryPath }),
        })
        if (!res.ok) {
          const b = (await res.json()) as { error?: string }
          throw new Error(b.error ?? `status ${res.status}`)
        }
        const data = (await res.json()) as { savePath: string }
        setProjectSavePath(data.savePath)
      } catch (e) {
        setProjectError((e as Error).message)
      }
    },
    [],
  )

  const handleDelete = useCallback(
    async (entryPath: string): Promise<void> => {
      if (!confirm(`Delete ${entryPath}?`)) return
      try {
        const res = await fetch('/api/projects', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action: 'delete', path: entryPath }),
        })
        if (!res.ok) {
          const b = (await res.json()) as { error?: string }
          throw new Error(b.error ?? `status ${res.status}`)
        }
        await fetchProjects(projectPath)
      } catch (e) {
        setProjectError((e as Error).message)
      }
    },
    [projectPath, fetchProjects],
  )

  const handleSaveAs = useCallback(
    async (rawName?: string): Promise<void> => {
      // Save current scene as a new scene subfolder: <project>/<newScene>/scene.json (fixed name)
      const name = (rawName ?? newItemName).trim()
      if (!name) {
        setProjectError('enter scene name for Save As')
        return
      }
      if (name.includes('/') || name.includes('\\')) {
        setProjectError('scene name cannot contain subfolders')
        return
      }
      const segs = projectPath.split('/').filter(Boolean)
      if (segs.length === 0) {
        setProjectError('select a project first — Save As creates a scene inside a project')
        return
      }
      const projectName = segs[0]
      const target = `${projectName}/${name}`
      try {
        const res = await fetch('/api/projects', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ action: 'save-as', path: target }),
        })
        if (!res.ok) {
          const b = (await res.json()) as { error?: string }
          throw new Error(b.error ?? `status ${res.status}`)
        }
        const data = (await res.json()) as { savePath: string }
        setProjectSavePath(data.savePath)
        setNewItemName('')
        setCreateModal(null)
        await fetchProjects(projectPath)
      } catch (e) {
        setProjectError((e as Error).message)
      }
    },
    [newItemName, projectPath, fetchProjects],
  )

  useEffect(() => {
    void fetchProjects(projectPath)
  }, [projectPath, fetchProjects])

  useEffect(() => {
    if (shared.connected) {
      void fetchProjects(projectPath)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shared.connected])

  // Manual refresh only — projects list updates via ↻ button, not auto-polling.
  // Scene itself still live-refreshes via shared /api/stream revision.
  useEffect(() => {
    if (!shared.connected) return
    // Keep projects list in sync when connection first established, not polled.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shared.connected])

  const active = shared.connected && shared.scene ? shared.scene : scene
  const is3D = active.space === '3d' || active.camera.projection.type === 'perspective'

  const tabStyle = (activeTab: boolean): React.CSSProperties => ({
    padding: '6px 12px',
    fontSize: 12,
    fontWeight: activeTab ? 700 : 400,
    background: activeTab ? '#2d2d2d' : 'transparent',
    color: activeTab ? '#fff' : '#aaa',
    border: 'none',
    borderBottom: activeTab ? '2px solid #4a9eff' : '2px solid transparent',
    cursor: 'pointer',
  })

  const panelStyle: React.CSSProperties = {
    padding: 12,
    fontSize: 12,
    overflow: 'auto',
    flex: 1,
  }

  if (popoutView) {
    return (
      <div style={{ padding: 12, background: '#121214', color: '#ddd', fontFamily: 'system-ui, sans-serif', height: '100vh', overflow: 'auto' }}>
        <div style={{ fontSize: 11, color: '#888', marginBottom: 8 }}>Pop-out: {popoutView} — shares scene via /api, t/selection via BroadcastChannel</div>
        {popoutView === 'preview' && <ThreeCanvas scene={active} t={t} width={800} editableCamera={false} selectedId={selectedId} onSelect={broadcastSelect} config={{ sessionId: 'demo' }} />}
        {popoutView === 'scene-view' && (is3D ? <ThreeCanvas scene={active} t={t} width={800} editableCamera={true} selectedId={selectedId} onSelect={broadcastSelect} config={{ sessionId: 'demo' }} /> : <SpatialCanvas scene={active} selectedId={selectedId} onSelect={broadcastSelect} onEdit={applyEnvelopes} width={800} t={t} config={{ sessionId: 'demo' }} />)}
        {popoutView === 'scene' && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Scene Info</div>
              <pre style={{ fontSize: 11, background: '#232326', padding: 8, borderRadius: 4, margin: 0, whiteSpace: 'pre-wrap', color: '#ccc' }}>
                {`id: ${active.id}
space: ${active.space}
camera: ${active.camera.projection.type}
canvas: ${active.canvas.width}x${active.canvas.height}
fps: ${active.fps ?? 30}
duration: ${active.duration ?? 0}s
primitives: ${active.root.children.length}`}
              </pre>
            </div>
            <div>
              <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Primitives</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                {active.root.children.length === 0 ? (
                  <div style={{ color: '#666', fontStyle: 'italic' }}>(empty)</div>
                ) : (
                  active.root.children.map((c: any) => (
                    <button
                      key={c.id}
                      onClick={() => broadcastSelect(c.id)}
                      style={{ textAlign: 'left', padding: '4px 6px', background: selectedId === c.id ? '#2d4a6a' : '#232326', border: '1px solid #333', borderRadius: 3, color: selectedId === c.id ? '#8ec7ff' : '#bbb', fontSize: 11, cursor: 'pointer' }}
                    >
                      <b>{c.word}</b> <span style={{ color: '#777' }}>{c.id}</span>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
        {popoutView === 'outliner' && (
          <div style={{ fontSize: 12 }}>
            {active.root.children.map((c: any) => (
              <div key={c.id}><button onClick={() => broadcastSelect(c.id)} style={{ background: selectedId === c.id ? '#2d4a6a' : 'none', border: 'none', color: '#ccc', cursor: 'pointer' }}>{c.word} ({c.id})</button></div>
            ))}
          </div>
        )}
        {popoutView === 'properties' && <PropertiesPanel scene={active} selectedId={selectedId} onEdit={applyEnvelopes} config={{ sessionId: 'demo' }} />}
        {popoutView === 'timeline' && <Timeline scene={active} t={t} onChange={broadcastTime} width={800} onEdit={applyEnvelopes} config={{ sessionId: 'demo' }} />}
        {popoutView === 'trace' && (
          <div style={{ fontSize: 12 }}>
            <div style={{ fontWeight: 600, marginBottom: 8, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Trace</div>
            <div style={{ color: '#666', fontStyle: 'italic' }}>Trace lives in main window — shared via BroadcastChannel for selection sync</div>
          </div>
        )}
        {(['dag','scene-graph','entity-graph','reference-graph','reference','graph'].includes(popoutView)) && (
          <SceneGraphDAG scene={active} selectedId={selectedId} onSelect={broadcastSelect} />
        )}
        {(popoutView === 'behavior' || popoutView === 'behavior-tree') && (
          <BehaviorTreeView scene={active} selectedId={selectedId} onSelect={broadcastSelect} />
        )}
        {popoutView === 'project' && (
          <div style={{ fontSize: 12 }}>
            <div>Project — spawn base scenes</div>
            <button onClick={load2D}>Load 2D</button> <button onClick={load3D}>Load 3D</button>
          </div>
        )}
        {popoutView === 'agent' && (
          <AgentPanel />
        )}
        {!['preview','scene-view','scene','outliner','properties','timeline','trace','project','widgets','agent','dag','scene-graph','entity-graph','reference-graph','reference','graph','behavior','behavior-tree'].includes(popoutView) && (
          <div style={{ fontSize: 12, color: '#888' }}>Unknown view: {popoutView}</div>
        )}
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', fontFamily: 'system-ui, sans-serif', background: '#121214', color: '#ddd' }}>
      {/* Top bar with cream lab icon */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '8px 16px', background: '#1e1e20', borderBottom: '1px solid #2a2a2e' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <img src="/SceneLabCreamIcon.png" alt="SceneLab black lab cream" style={{ width: 28, height: 28, objectFit: 'contain', filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.4))' }} />
          <h2 style={{ margin: 0, fontSize: 14, letterSpacing: 0.5 }}>SceneLab — {is3D ? '3D' : '2D'} Editor</h2>
        </div>
        <div style={{ fontSize: 11, color: shared.error ? '#ff6b6b' : '#888' }}>
          {shared.error ? shared.error : shared.connected ? '● shared session (edits logged)' : '○ standalone'}
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8 }}>
          <button
            onClick={() => {
              void fetchProjects(projectPath)
              void ui.refresh()
              void fetch('/api/scene').then((r) => (r.ok ? r.json() : null)).then(() => void fetch('/api/summary'))
            }}
            title="Manual refresh all widgets"
            style={{ fontSize: 11, padding: '4px 8px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 4, color: '#8ec7ff', cursor: 'pointer' }}
          >
            ↻ Refresh
          </button>
          <button onClick={agentNudgeLabel} style={{ fontSize: 11, padding: '4px 8px' }}>Agent: nudge →</button>
        </div>
      </div>

      {/* Main 3-column */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <div style={{ width: 320, display: 'flex', flexDirection: 'column', background: '#1a1a1e', borderRight: '1px solid #2a2a2e' }}>
          <div style={{ display: 'flex', borderBottom: '1px solid #2a2a2e', overflowX: 'auto', alignItems: 'center' }}>
            <button onClick={() => setLeftTab('project')} style={tabStyle(leftTab === 'project')}>Project</button>
            <button onClick={() => setLeftTab('agent')} style={tabStyle(leftTab === 'agent')}>Agent</button>
            <button onClick={() => setLeftTab('scene')} style={tabStyle(leftTab === 'scene')}>Scene</button>
            <button onClick={() => setLeftTab('outliner')} style={tabStyle(leftTab === 'outliner')}>Outliner</button>
            <button onClick={() => setLeftTab('widgets')} style={tabStyle(leftTab === 'widgets')}>Widgets</button>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
              <button onClick={() => popOut(leftTab)} title="Float inside same window (drag header)" style={{ fontSize: 10, padding: '2px 6px', background: '#2a2a2e', border: '1px solid #333', borderRadius: 3, color: '#888', cursor: 'pointer' }}>Float</button>
              <button onClick={() => popOutWindow(leftTab)} title="Pop out to separate window — drag away from main window, live sync" style={{ fontSize: 10, padding: '2px 6px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>↗</button>
            </div>
          </div>
          {leftTab === 'project' ? (
            <div style={panelStyle}>
              <div style={{ fontWeight: 600, marginBottom: 8, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Projects</div>

              {projectSavePath ? (
                <div style={{ fontSize: 11, background: '#1e2a3a', border: '1px solid #2a4a6a', borderRadius: 4, padding: '6px 8px', marginBottom: 10, color: '#8ec7ff' }}>
                  <div style={{ fontSize: 10, color: '#6a8ab0', textTransform: 'uppercase' }}>Loaded</div>
                  <div style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>{projectSavePath}</div>
                </div>
              ) : (
                <div style={{ fontSize: 11, background: '#232326', border: '1px solid #333', borderRadius: 4, padding: '6px 8px', marginBottom: 10, color: '#666' }}>No scene loaded — create or open a project, then a scene.</div>
              )}

              {(() => {
                const segs = projectPath.split('/').filter(Boolean)
                const depth = segs.length
                if (depth === 0) {
                  // Root — projects flat list
                  return (
                    <>
                      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
                        <button onClick={() => setCreateModal({ type: 'project', name: '' })} style={{ flex: 1, fontSize: 12, padding: '8px 10px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 4, color: '#8ec7ff', cursor: 'pointer', fontWeight: 700 }}>
                          + New Project
                        </button>
                      </div>
                      <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Projects</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 16, maxHeight: 300, overflow: 'auto', background: '#121214', border: '1px solid #2a2a2e', borderRadius: 4, padding: 4 }}>
                        {projectEntries.filter((e) => e.isDir).length === 0 ? (
                          <div style={{ fontSize: 11, color: '#555', fontStyle: 'italic', padding: 8, textAlign: 'center' }}>(no projects — click + New Project)</div>
                        ) : (
                          projectEntries
                            .filter((e) => e.isDir)
                            .map((entry) => (
                              <div key={entry.path} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 8px', background: '#1a1a1e', border: '1px solid #2a2a2e', borderRadius: 4 }}>
                                <span style={{ fontSize: 13 }}>📁</span>
                                <button onClick={() => setProjectPath(entry.path)} style={{ flex: 1, textAlign: 'left', background: 'none', border: 'none', color: '#ccc', fontSize: 12, cursor: 'pointer', fontWeight: 600 }} title={entry.path}>
                                  {entry.name}
                                </button>
                                <button onClick={() => setProjectPath(entry.path)} style={{ fontSize: 10, padding: '4px 8px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>
                                  Open
                                </button>
                                <button onClick={() => void handleDelete(entry.path)} style={{ fontSize: 10, padding: '2px 6px', background: 'none', border: '1px solid #333', borderRadius: 3, color: '#6a4444', cursor: 'pointer' }} title={`Delete ${entry.path}`}>×</button>
                              </div>
                            ))
                        )}
                      </div>
                    </>
                  )
                } else {
                  // Inside project — scenes
                  const projectName = segs[0]
                  const scenes = projectEntries.filter((e) => e.isDir)
                  return (
                    <>
                      <div style={{ display: 'flex', gap: 6, marginBottom: 10, alignItems: 'center' }}>
                        <button onClick={() => setProjectPath('')} style={{ fontSize: 11, padding: '5px 10px', background: '#232326', border: '1px solid #333', borderRadius: 4, color: '#aaa', cursor: 'pointer' }}>← Projects</button>
                        <div style={{ fontSize: 12, fontWeight: 600, color: '#ccc' }}>{projectName}</div>
                      </div>
                      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
                        <button onClick={() => setCreateModal({ type: 'scene', name: '' })} style={{ flex: 1, fontSize: 12, padding: '8px 10px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 4, color: '#8ec7ff', cursor: 'pointer', fontWeight: 700 }}>
                          + New Scene
                        </button>
                      </div>
                      <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Scenes in {projectName}/</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: 12, maxHeight: 300, overflow: 'auto', background: '#121214', border: '1px solid #2a2a2e', borderRadius: 4, padding: 4 }}>
                        {scenes.length === 0 ? (
                          <div style={{ fontSize: 11, color: '#555', fontStyle: 'italic', padding: 8, textAlign: 'center' }}>(no scenes — click + New Scene)</div>
                        ) : (
                          scenes.map((entry) => (
                            <div key={entry.path} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 8px', background: projectSavePath?.startsWith(entry.path + '/') ? '#1e2a3a' : '#1a1a1e', border: '1px solid #2a2a2e', borderRadius: 4 }}>
                              <span style={{ fontSize: 13 }}>🎬</span>
                              <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                                <span style={{ fontSize: 12, color: '#ccc', fontWeight: 500 }}>{entry.name}</span>
                                <span style={{ fontSize: 9, color: '#555' }}>{entry.path}/scene.json</span>
                              </div>
                              <button onClick={() => void handleOpenPath(entry.path)} style={{ fontSize: 10, padding: '4px 8px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>Load</button>
                              <button onClick={() => void handleDelete(entry.path)} style={{ fontSize: 10, padding: '2px 6px', background: 'none', border: '1px solid #333', borderRadius: 3, color: '#6a4444', cursor: 'pointer' }} title={`Delete ${entry.path}`}>×</button>
                            </div>
                          ))
                        )}
                      </div>
                      <div style={{ display: 'flex', gap: 6, marginBottom: 12 }}>
                        <button
                          onClick={() => void handleSave()}
                          disabled={!projectSavePath}
                          style={{
                            flex: 1,
                            fontSize: 11,
                            padding: '6px 10px',
                            background: projectSavePath ? '#233326' : '#232326',
                            border: '1px solid #333',
                            borderRadius: 4,
                            color: projectSavePath ? '#8a8' : '#555',
                            cursor: projectSavePath ? 'pointer' : 'not-allowed',
                          }}
                          title={projectSavePath ? `Save to ${projectSavePath}` : 'Open a scene first'}
                        >
                          💾 Save
                        </button>
                        <button
                          onClick={() => setCreateModal({ type: 'save-as-scene', name: '' })}
                          style={{ flex: 1, fontSize: 11, padding: '6px 10px', background: '#232326', border: '1px solid #333', borderRadius: 4, color: '#ccc', cursor: 'pointer' }}
                        >
                          💾 Save As…
                        </button>
                      </div>
                    </>
                  )
                }
              })()}

              {createModal && (
                <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000 }} onClick={() => setCreateModal(null)}>
                  <div style={{ background: '#1e1e20', border: '1px solid #333', borderRadius: 8, padding: 16, width: 320, boxShadow: '0 8px 24px rgba(0,0,0,0.6)' }} onClick={(e) => e.stopPropagation()}>
                    <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 12, color: '#ddd' }}>
                      {createModal.type === 'project' ? 'New Project' : createModal.type === 'scene' ? 'New Scene' : createModal.type === 'save-as-scene' ? 'Save As New Scene' : 'New Folder'}
                    </div>
                    <input
                      autoFocus
                      value={createModal.name}
                      onChange={(e) => setCreateModal({ ...createModal, name: e.target.value })}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          if (createModal.type === 'project') void handleCreateProject(createModal.name)
                          else if (createModal.type === 'scene') void handleCreateScene(createModal.name)
                          else if (createModal.type === 'save-as-scene') void handleSaveAs(createModal.name)
                          else void handleCreateDir(createModal.name)
                        }
                        if (e.key === 'Escape') setCreateModal(null)
                      }}
                      placeholder={createModal.type === 'project' ? 'my-project' : createModal.type === 'save-as-scene' ? 'my-scene-copy' : 'my-scene'}
                      style={{ width: '100%', fontSize: 12, padding: '7px 10px', background: '#121214', border: '1px solid #333', borderRadius: 4, color: '#ddd', outline: 'none', marginBottom: 12 }}
                    />
                    <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                      <button onClick={() => setCreateModal(null)} style={{ fontSize: 11, padding: '5px 12px', background: '#232326', border: '1px solid #333', borderRadius: 4, color: '#aaa', cursor: 'pointer' }}>Cancel</button>
                      <button
                        onClick={() => {
                          if (createModal.type === 'project') void handleCreateProject(createModal.name)
                          else if (createModal.type === 'scene') void handleCreateScene(createModal.name)
                          else if (createModal.type === 'save-as-scene') void handleSaveAs(createModal.name)
                          else void handleCreateDir(createModal.name)
                        }}
                        style={{ fontSize: 11, padding: '6px 14px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 4, color: '#8ec7ff', cursor: 'pointer', fontWeight: 600 }}
                      >
                        {createModal.type === 'project' ? 'Create' : createModal.type === 'scene' ? 'Create Scene' : createModal.type === 'save-as-scene' ? 'Save As' : 'Create'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {projectError && <div style={{ fontSize: 11, color: '#ff6b6b', background: '#2a1a1a', border: '1px solid #4a2a2a', borderRadius: 4, padding: '6px 8px', marginBottom: 8, whiteSpace: 'pre-wrap' }}>{projectError}</div>}

              <div style={{ height: 1, background: '#2a2a2e', margin: '12px 0' }} />

              <div style={{ fontWeight: 600, marginBottom: 8, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Scene Content (dimension in scene, not project)</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ fontSize: 11, color: '#777', marginBottom: 4 }}>
                  Create or replace the main scene. If a project file is open, this overwrites <code>scene.json</code> and autosaves. Otherwise ephemeral. Use Properties to flip 2D↔3D later.
                </div>
                <button onClick={load2D} style={{ padding: '8px', background: !is3D ? '#2d4a6a' : '#232326', border: '1px solid #333', borderRadius: 4, color: '#ccc', cursor: 'pointer', textAlign: 'left' }}>
                  <div style={{ fontWeight: 600, fontSize: 12 }}>📄 2D Base Scene</div>
                  <div style={{ fontSize: 10, color: '#888' }}>Orthographic, 1920×1080, circle + label — replaces current scene</div>
                </button>
                <button onClick={load3D} style={{ padding: '8px', background: is3D ? '#2d4a6a' : '#232326', border: '1px solid #333', borderRadius: 4, color: '#ccc', cursor: 'pointer', textAlign: 'left' }}>
                  <div style={{ fontWeight: 600, fontSize: 12 }}>🧊 3D Base Scene</div>
                  <div style={{ fontSize: 10, color: '#888' }}>Perspective, lit box/sphere/cone + floor — replaces current scene</div>
                </button>
                <div style={{ height: 1, background: '#2a2a2e', margin: '12px 0' }} />
                <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Spawn Widget (web interface)</div>
                <div style={{ fontSize: 10, color: '#777', marginBottom: 6 }}>Agent can POST /api/ui to spawn. Demo buttons below use same API. Widgets share t so live scrub stays in sync.</div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                  {(['preview', 'scene-view', 'outliner', 'properties', 'timeline'] as const).map((type) => (
                    <button key={type} onClick={() => void ui.spawn({ id: `${type}-${Date.now()}`, type, position: 'floating' })} style={{ fontSize: 10, padding: '4px 6px', background: '#232326', border: '1px solid #333', borderRadius: 3, color: '#aaa', cursor: 'pointer' }}>
                      + {type}
                    </button>
                  ))}
                </div>
                {ui.layout && (
                  <div style={{ marginTop: 8 }}>
                    <div style={{ fontSize: 10, color: '#888' }}>Active panels: {ui.layout.panels.length}</div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginTop: 4 }}>
                      {ui.layout.panels.map((p) => (
                        <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, background: '#232326', padding: '2px 4px', borderRadius: 2 }}>
                          <span>{p.type} ({p.position})</span>
                          <button onClick={() => void ui.remove(p.id)} style={{ background: 'none', border: 'none', color: '#ff6b6b', cursor: 'pointer' }}>x</button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                <div style={{ height: 1, background: '#2a2a2e', margin: '12px 0' }} />
                <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Meta</div>
                <div style={{ fontSize: 11, color: '#777' }}>
                  <div>Connection: {shared.connected ? 'shared (correction log active)' : 'standalone'} • UI: {ui.connected ? `connected rev ${ui.layout?.revision}` : 'standalone'}</div>
                  {shared.error && <div style={{ color: '#ff6b6b' }}>{shared.error}</div>}
                  <div style={{ marginTop: 8 }}>Use <code>/scenelab --new</code> for empty, <code>--space=3d</code> for 3D empty.</div>
                </div>
              </div>
            </div>
          ) : leftTab === 'scene' ? (
            <div style={panelStyle}>
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Scene Info</div>
                <pre style={{ fontSize: 11, background: '#232326', padding: 8, borderRadius: 4, margin: 0, whiteSpace: 'pre-wrap', color: '#ccc' }}>
                  {`id: ${active.id}
space: ${active.space}
camera: ${active.camera.projection.type}
canvas: ${active.canvas.width}x${active.canvas.height}
fps: ${active.fps ?? 30}
duration: ${active.duration ?? 0}s`}
                </pre>
              </div>
              <div>
                <div style={{ fontWeight: 600, marginBottom: 6, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Primitives</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {active.root.children.length === 0 ? (
                    <div style={{ color: '#666', fontStyle: 'italic' }}>(empty — --new)</div>
                  ) : (
                    active.root.children.map((c: any) => (
                      <button
                        key={c.id}
                        onClick={() => broadcastSelect(c.id)}
                        style={{
                          textAlign: 'left',
                          padding: '4px 6px',
                          background: selectedId === c.id ? '#2d4a6a' : '#232326',
                          border: '1px solid #333',
                          borderRadius: 3,
                          color: selectedId === c.id ? '#8ec7ff' : '#bbb',
                          fontSize: 11,
                          cursor: 'pointer',
                        }}
                      >
                        <b>{c.word}</b> <span style={{ color: '#777' }}>{c.id}</span> <span style={{ color: '#666' }}>{c.kind}</span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>
          ) : leftTab === 'outliner' ? (
            <div style={panelStyle}>
              <div style={{ fontWeight: 600, marginBottom: 8, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Outliner (Resolved)</div>
              <div style={{ color: '#777', fontSize: 11, marginBottom: 8 }}>Resolved primitives — selectable, overridable. Templates badged ƒ.</div>
              {active.root.children.map((child: any) => (
                <div key={child.id} style={{ padding: '3px 0', borderBottom: '1px solid #222' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span style={{ color: child.template ? '#c5a000' : '#888', fontSize: 10 }}>{child.template ? 'ƒ' : '●'}</span>
                    <button
                      onClick={() => broadcastSelect(child.id)}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: selectedId === child.id ? '#8ec7ff' : '#ccc',
                        fontSize: 12,
                        cursor: 'pointer',
                        textAlign: 'left',
                      }}
                    >
                      {child.word} <span style={{ color: '#666' }}>({child.id})</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : leftTab === 'agent' ? (
            <AgentPanel />
          ) : (
            <div style={panelStyle}>
              <div style={{ fontWeight: 600, marginBottom: 8, color: '#aaa', textTransform: 'uppercase', fontSize: 10 }}>Widgets — Dynamic Spawning</div>
              <div style={{ fontSize: 11, color: '#777', marginBottom: 8 }}>Agent can POST /api/ui to spawn widgets for end users. These share t so scrub stays live in same window.</div>
              <div style={{ marginBottom: 12 }}>
                <WidgetHost layout={ui.layout} scene={active} t={t} selectedId={selectedId} onSelect={broadcastSelect} onEdit={applyEnvelopes} onRemovePanel={ui.remove} width={280} />
              </div>
              <div style={{ fontSize: 10, color: '#666' }}>
                Try: <code>curl -X POST /api/ui -H 'content-type: application/json' -d '&#123;&quot;action&quot;:&quot;spawn&quot;,&quot;panel&quot;:&#123;&quot;type&quot;:&quot;preview&quot;,&quot;position&quot;:&quot;floating&quot;&#125;&#125;'</code>
              </div>
            </div>
          )}
        </div>

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: '#121214', overflow: 'hidden' }}>
          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12, background: '#0e0e10', overflow: 'auto', padding: 12 }}>
            <div style={{ background: '#1a1a1e', borderRadius: 6, border: '1px solid #2a2a2e', overflow: 'hidden' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 10px', background: '#1e1e20', borderBottom: '1px solid #2a2a2e' }}>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#aaa', textTransform: 'uppercase', letterSpacing: 0.5 }}>Scene View</span>
                <div style={{ display: 'flex', gap: 4 }}>
                  <button onClick={() => popOut('scene-view')} title="Float inside main window" style={{ fontSize: 10, padding: '2px 6px', background: '#2a2a2e', border: '1px solid #333', borderRadius: 3, color: '#888', cursor: 'pointer' }}>Float</button>
                  <button onClick={() => popOutWindow('scene-view')} title="Pop out to separate window — drag away, live sync via BroadcastChannel" style={{ fontSize: 10, padding: '2px 6px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>↗ Pop-out</button>
                </div>
              </div>
              <div style={{ padding: 8, display: 'flex', justifyContent: 'center', background: '#121214' }}>
                {is3D ? (
                  <ThreeCanvas scene={active} t={t} width={640} editableCamera={true} selectedId={selectedId} onSelect={broadcastSelect} config={{ sessionId: 'demo' }} />
                ) : (
                  <SpatialCanvas scene={active} selectedId={selectedId} onSelect={broadcastSelect} onEdit={applyEnvelopes} width={640} t={t} config={{ sessionId: 'demo' }} />
                )}
              </div>
            </div>

            <div style={{ background: '#1a1a1e', borderRadius: 6, border: '1px solid #2a2a2e', overflow: 'hidden' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 10px', background: '#1e1e20', borderBottom: '1px solid #2a2a2e' }}>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#aaa', textTransform: 'uppercase', letterSpacing: 0.5 }}>Preview</span>
                <div style={{ display: 'flex', gap: 4 }}>
                  <button onClick={() => popOut('preview')} title="Float inside main window" style={{ fontSize: 10, padding: '2px 6px', background: '#2a2a2e', border: '1px solid #333', borderRadius: 3, color: '#888', cursor: 'pointer' }}>Float</button>
                  <button onClick={() => popOutWindow('preview')} title="Pop out to separate window — drag away, live sync" style={{ fontSize: 10, padding: '2px 6px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>↗ Pop-out</button>
                </div>
              </div>
              <div style={{ padding: 8, display: 'flex', justifyContent: 'center', background: '#0e0e10' }}>
                <ThreeCanvas scene={active} t={t} width={640} editableCamera={false} selectedId={selectedId} onSelect={broadcastSelect} config={{ sessionId: 'demo' }} />
              </div>
            </div>

            {ui.layout && ui.layout.panels.filter((p) => p.position === 'floating').length > 0 && (
              <WidgetHost layout={{ revision: ui.layout.revision, panels: ui.layout.panels.filter((p) => p.position === 'floating') } as any} scene={active} t={t} selectedId={selectedId} onSelect={broadcastSelect} onEdit={applyEnvelopes} onRemovePanel={ui.remove} width={320} />
            )}
          </div>

          <div style={{ background: '#1e1e20', borderTop: '1px solid #2a2a2e', padding: '8px 16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
              <span style={{ fontSize: 10, color: '#888', textTransform: 'uppercase', letterSpacing: 0.5 }}>Timeline — playable video</span>
              <div style={{ display: 'flex', gap: 4 }}>
                <button onClick={() => popOut('timeline')} title="Float inside main window" style={{ fontSize: 10, padding: '2px 6px', background: '#2a2a2e', border: '1px solid #333', borderRadius: 3, color: '#888', cursor: 'pointer' }}>Float</button>
                <button onClick={() => popOutWindow('timeline')} title="Pop out to separate window — drag away, live sync" style={{ fontSize: 10, padding: '2px 6px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>↗ Pop-out</button>
              </div>
            </div>
            <Timeline scene={active} t={t} onChange={broadcastTime} width={640} onEdit={applyEnvelopes} config={{ sessionId: 'demo' }} />
          </div>
        </div>

        <div style={{ width: 340, display: 'flex', flexDirection: 'column', background: '#1a1a1e', borderLeft: '1px solid #2a2a2e' }}>
          <div style={{ display: 'flex', borderBottom: '1px solid #2a2a2e', alignItems: 'center' }}>
            <button onClick={() => setRightTab('properties')} style={{ padding: '6px 12px', fontSize: 12, fontWeight: rightTab === 'properties' ? 700 : 400, background: rightTab === 'properties' ? '#2d2d2d' : 'transparent', color: rightTab === 'properties' ? '#fff' : '#aaa', border: 'none', borderBottom: rightTab === 'properties' ? '2px solid #4a9eff' : '2px solid transparent', cursor: 'pointer' }}>Properties</button>
            <button onClick={() => setRightTab('trace')} style={{ padding: '6px 12px', fontSize: 12, fontWeight: rightTab === 'trace' ? 700 : 400, background: rightTab === 'trace' ? '#2d2d2d' : 'transparent', color: rightTab === 'trace' ? '#fff' : '#aaa', border: 'none', borderBottom: rightTab === 'trace' ? '2px solid #4a9eff' : '2px solid transparent', cursor: 'pointer' }}>Trace ({trace.length})</button>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
              <button onClick={() => popOut(rightTab)} title="Float inside main window" style={{ fontSize: 10, padding: '2px 6px', background: '#2a2a2e', border: '1px solid #333', borderRadius: 3, color: '#888', cursor: 'pointer' }}>Float</button>
              <button onClick={() => popOutWindow(rightTab)} title="Pop out to separate window — drag away from main window" style={{ fontSize: 10, padding: '2px 6px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>↗</button>
            </div>
          </div>
          {rightTab === 'properties' ? (
            <div style={{ padding: 12, overflow: 'auto', flex: 1 }}>
              <PropertiesPanel scene={active} selectedId={selectedId} onEdit={applyEnvelopes} config={{ sessionId: 'demo' }} />
            </div>
          ) : (
            <div style={{ padding: 12, overflow: 'auto', flex: 1, fontSize: 12 }}>
              <ol style={{ fontSize: 11, paddingLeft: 16, margin: 0 }}>
                {trace.length === 0 ? <div style={{ color: '#666', fontStyle: 'italic' }}>No edits yet.</div> : trace.map((e, i) => (
                  <li key={i} style={{ marginBottom: 4 }}>
                    <b style={{ color: e.source === 'agent' ? '#d49a00' : '#2db87a' }}>{e.source}</b> {e.event.type}{' '}
                    {'target' in e.event ? `→ ${(e.event as any).target}` : ''}
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      </div>
      {/* Bottom tabs — Entity Graph + Behavior Tree */}
      <div style={{ height: 360, display: 'flex', flexDirection: 'column', background: '#1a1a1e', borderTop: '1px solid #2a2a2e' }}>
        <div style={{ display: 'flex', borderBottom: '1px solid #2a2a2e', alignItems: 'center' }}>
          <button onClick={() => setBottomTab('entity-graph')} style={{ padding: '6px 12px', fontSize: 12, fontWeight: bottomTab === 'entity-graph' ? 700 : 400, background: bottomTab === 'entity-graph' ? '#2d2d2d' : 'transparent', color: bottomTab === 'entity-graph' ? '#fff' : '#aaa', border: 'none', borderBottom: bottomTab === 'entity-graph' ? '2px solid #4a9eff' : '2px solid transparent', cursor: 'pointer' }}>Entity Graph</button>
          <button onClick={() => setBottomTab('behavior')} style={{ padding: '6px 12px', fontSize: 12, fontWeight: bottomTab === 'behavior' ? 700 : 400, background: bottomTab === 'behavior' ? '#2d2d2d' : 'transparent', color: bottomTab === 'behavior' ? '#fff' : '#aaa', border: 'none', borderBottom: bottomTab === 'behavior' ? '2px solid #4a9eff' : '2px solid transparent', cursor: 'pointer' }}>Behavior Tree</button>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 4, padding: '4px 8px', alignItems: 'center' }}>
            <span style={{ fontSize: 10, color: '#666', marginRight: 6 }}>{bottomTab === 'entity-graph' ? '◈ Reference DAG: contains / instantiates / constrains (Entity Graph §3) + arrangements' : '⚡ BT: sequence / selector / parallel / decorator / condition / action / forEach'}</span>
            <button onClick={() => popOutWindow(bottomTab === 'entity-graph' ? 'entity-graph' : 'behavior-tree')} title="Pop out to separate native window — drag away from main window, live sync" style={{ fontSize: 10, padding: '2px 6px', background: '#2d4a6a', border: '1px solid #3a5a7a', borderRadius: 3, color: '#8ec7ff', cursor: 'pointer' }}>↗ Pop-out (drag away)</button>
          </div>
        </div>
        <div style={{ flex: 1, overflow: 'auto', padding: 8, background: '#121214' }}>
          {bottomTab === 'entity-graph' ? (
            <SceneGraphDAG scene={active} selectedId={selectedId} onSelect={broadcastSelect} />
          ) : (
            <BehaviorTreeView scene={active} selectedId={selectedId} onSelect={broadcastSelect} />
          )}
        </div>
      </div>
    </div>
  )
}
