/**
 * Agent tab — a conversation with the editor's own metacode session.
 *
 * The session lives in the server (ACP) and streams its transcript here, so this component is a
 * renderer, not a driver: it shows turns as they arrive, and posts prompts. The scene itself
 * updates through the shared-scene stream, exactly as it does when a human drags something.
 *
 * The transcript shows what the terminal would: the reply, the tools it ran, and — collapsed,
 * because it is verbose — the reasoning.
 */

import { useEffect, useRef, useState } from 'react'
import { useAgent, type ToolCall, type Turn } from './useAgent'

const STATUS_MARK: Record<ToolCall['status'], string> = {
  pending: '○',
  in_progress: '◐',
  completed: '●',
  failed: '✕',
}

const STATUS_COLOR: Record<ToolCall['status'], string> = {
  pending: '#666',
  in_progress: '#e0a030',
  completed: '#4a9eff',
  failed: '#ff6b6b',
}

function ToolCallRow({ call }: { call: ToolCall }): JSX.Element {
  const file = call.locations[0]?.split('/').pop()
  return (
    <div style={{ display: 'flex', gap: 6, alignItems: 'baseline', fontSize: 11, color: '#999' }}>
      <span style={{ color: STATUS_COLOR[call.status] }}>{STATUS_MARK[call.status]}</span>
      <span style={{ color: '#bbb' }}>{call.title}</span>
      {file && <span style={{ color: '#666', fontFamily: 'ui-monospace, monospace', fontSize: 10 }}>{file}</span>}
    </div>
  )
}

function TurnView({ turn }: { turn: Turn }): JSX.Element {
  const [showThought, setShowThought] = useState(false)
  const isUser = turn.role === 'user'
  const running = turn.role === 'agent' && turn.finishedAt === null

  return (
    <div
      style={{
        padding: '8px 10px',
        borderRadius: 6,
        background: isUser ? '#1e2a38' : '#1a1a1e',
        border: `1px solid ${isUser ? '#2a3f55' : '#2a2a2e'}`,
      }}
    >
      <div style={{ fontSize: 9, textTransform: 'uppercase', letterSpacing: 0.5, color: isUser ? '#6aa9e0' : '#888', marginBottom: 4 }}>
        {isUser ? 'You' : 'Agent'}
        {running && <span style={{ color: '#e0a030', marginLeft: 6 }}>working…</span>}
        {turn.stopReason && turn.stopReason !== 'end_turn' && (
          <span style={{ color: '#e0a030', marginLeft: 6 }}>{turn.stopReason}</span>
        )}
      </div>

      {turn.toolCalls.length > 0 && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginBottom: turn.text ? 6 : 0 }}>
          {turn.toolCalls.map((c) => (
            <ToolCallRow key={c.id} call={c} />
          ))}
        </div>
      )}

      {turn.text && (
        <div style={{ fontSize: 12, color: '#ddd', whiteSpace: 'pre-wrap', lineHeight: 1.45 }}>{turn.text}</div>
      )}

      {!turn.text && running && turn.toolCalls.length === 0 && (
        <div style={{ fontSize: 11, color: '#666', fontStyle: 'italic' }}>thinking…</div>
      )}

      {turn.error && <div style={{ fontSize: 11, color: '#ff6b6b', marginTop: 4 }}>{turn.error}</div>}

      {turn.thought.length > 0 && (
        <div style={{ marginTop: 6 }}>
          <button
            onClick={() => setShowThought((v) => !v)}
            style={{ fontSize: 10, background: 'none', border: 'none', color: '#666', cursor: 'pointer', padding: 0 }}
          >
            {showThought ? '▾' : '▸'} reasoning ({turn.thought.length} chars)
          </button>
          {showThought && (
            <pre
              style={{
                fontSize: 10,
                color: '#777',
                whiteSpace: 'pre-wrap',
                margin: '4px 0 0',
                maxHeight: 200,
                overflow: 'auto',
                background: '#141416',
                padding: 6,
                borderRadius: 4,
              }}
            >
              {turn.thought}
            </pre>
          )}
        </div>
      )}
    </div>
  )
}

export function AgentPanel(): JSX.Element {
  const { state, prompt, setPrompt, send, reset, cancel, error, connected } = useAgent()
  const endRef = useRef<HTMLDivElement | null>(null)

  // Follow the tail as the agent writes, the way a terminal does.
  useEffect(() => {
    endRef.current?.scrollIntoView({ block: 'end' })
  }, [state.turns])

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>): void => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
      e.preventDefault()
      void send()
    }
  }

  const pct = state.usage && state.usage.size > 0 ? Math.round((state.usage.used / state.usage.size) * 100) : null

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', fontSize: 12, overflow: 'hidden' }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '6px 10px',
          borderBottom: '1px solid #2a2a2e',
          gap: 8,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
          <span
            title={state.running ? 'session live' : 'no session yet'}
            style={{ width: 7, height: 7, borderRadius: '50%', background: state.running ? '#4ade80' : '#555', flexShrink: 0 }}
          />
          <span style={{ fontSize: 10, color: '#888', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {state.model ?? 'metacode'}
            {pct !== null && <span style={{ color: '#666' }}> · ctx {pct}%</span>}
          </span>
        </div>
        <div style={{ display: 'flex', gap: 4, flexShrink: 0 }}>
          {state.busy && (
            <button onClick={() => void cancel()} style={btn('#3a2a2a', '#c88')}>
              Stop
            </button>
          )}
          <button onClick={() => void reset()} disabled={state.busy} style={btn('#2a2a2e', '#999', state.busy)}>
            New session
          </button>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: 10, display: 'flex', flexDirection: 'column', gap: 8 }}>
        {state.turns.length === 0 && (
          <div style={{ color: '#666', fontSize: 11, lineHeight: 1.5 }}>
            Ask for a scene and the agent builds it into the live editor — preview, scene view and timeline
            update as it works. Then keep going: "make it slower", "add a floor", "use warmer colours".
            <div style={{ marginTop: 8, color: '#555' }}>
              The session starts on your first message and remembers the whole conversation. "New session"
              forgets it and starts clean.
            </div>
          </div>
        )}
        {state.turns.map((t) => (
          <TurnView key={t.id} turn={t} />
        ))}
        <div ref={endRef} />
      </div>

      {(error ?? state.lastError) && (
        <div style={{ padding: '6px 10px', fontSize: 11, color: '#ff6b6b', borderTop: '1px solid #2a2a2e', background: '#241a1a' }}>
          {error ?? state.lastError}
        </div>
      )}

      <div style={{ borderTop: '1px solid #2a2a2e', padding: 8, display: 'flex', flexDirection: 'column', gap: 6 }}>
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={onKeyDown}
          placeholder={state.turns.length === 0 ? 'A bouncing red ball, 3 seconds…' : 'What should change?'}
          rows={3}
          style={{
            width: '100%',
            resize: 'vertical',
            minHeight: 52,
            background: '#141416',
            color: '#ddd',
            border: '1px solid #2a2a2e',
            borderRadius: 4,
            padding: 8,
            fontSize: 12,
            fontFamily: 'inherit',
          }}
        />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 10, color: '#555' }}>{connected ? '⌘↵ to send' : 'reconnecting…'}</span>
          <button onClick={() => void send()} disabled={state.busy || !prompt.trim()} style={btn('#2d4a6a', '#8ec7ff', state.busy || !prompt.trim())}>
            {state.busy ? 'Working…' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  )
}

function btn(bg: string, fg: string, disabled = false): React.CSSProperties {
  return {
    fontSize: 11,
    padding: '4px 10px',
    background: disabled ? '#232326' : bg,
    border: '1px solid #333',
    borderRadius: 3,
    color: disabled ? '#555' : fg,
    cursor: disabled ? 'default' : 'pointer',
  }
}
