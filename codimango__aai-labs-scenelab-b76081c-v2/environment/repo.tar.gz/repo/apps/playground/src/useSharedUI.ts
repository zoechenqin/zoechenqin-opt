/**
 * useSharedUI — shares UI layout for dynamic widget spawning.
 * Same SSE channel as scene server — re-fetches on any change.
 */
import { useCallback, useEffect, useState } from 'react'
import type { UILayout, UIPanel } from '@scenelab/widgets'

const API = '/api'

export function useSharedUI() {
  const [layout, setLayout] = useState<UILayout | null>(null)
  const [connected, setConnected] = useState(false)

  const refresh = useCallback(async () => {
    try {
      const res = await fetch(`${API}/ui`)
      if (!res.ok) throw new Error(`ui ${res.status}`)
      const body = (await res.json()) as UILayout
      setLayout(body)
      setConnected(true)
    } catch {
      setConnected(false)
    }
  }, [])

  useEffect(() => {
    void refresh()
    const es = new EventSource(`${API}/stream`)
    es.onmessage = () => void refresh()
    return () => es.close()
  }, [refresh])

  const spawn = useCallback(async (panel: UIPanel) => {
    await fetch(`${API}/ui`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action: 'spawn', panel }),
    })
    await refresh()
  }, [refresh])

  const remove = useCallback(async (id: string) => {
    await fetch(`${API}/ui`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action: 'remove', id }),
    })
    await refresh()
  }, [refresh])

  const replace = useCallback(async (panels: UIPanel[]) => {
    await fetch(`${API}/ui`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action: 'replace', panels }),
    })
    await refresh()
  }, [refresh])

  return { layout, connected, spawn, remove, replace, refresh }
}
