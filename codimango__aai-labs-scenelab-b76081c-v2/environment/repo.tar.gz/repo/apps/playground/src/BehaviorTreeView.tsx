import { useState, useMemo } from 'react'
import { behaviorOf } from '@scenelab/scene-ir'
import type { BTNode, Entity as SceneEntity, Scene, Animatable, Keyframe } from '@scenelab/scene-ir'

interface Props {
  scene: Scene
  selectedId?: string | null
  onSelect?: (id: string | null) => void
}

function collectBehaviorEntities(root: SceneEntity): SceneEntity[] {
  const out: SceneEntity[] = []
  const walk = (n: SceneEntity) => {
    if (behaviorOf(n)) out.push(n)
    n.children.forEach(walk)
  }
  walk(root)
  return out
}

type CurveInfo = {
  /** The curve leaf's own id — what a keyframe.* correction addresses (§4.2). */
  curveId: string
  /** The entity it drives. */
  targetId: string
  ownerId: string
  property: string
  keyframes: Keyframe<any>[]
}

/**
 * Curves are behavior-tree leaves, so they are collected by walking the trees rather than the
 * entity transforms. Value slots contain constants; curve leaves own the keyframes (§4.3).
 */
function collectCurves(root: SceneEntity): CurveInfo[] {
  const out: CurveInfo[] = []
  const walkBT = (n: BTNode, ownerId: string) => {
    const any1 = n as any
    if (n.type === 'curve') {
      const tgt = any1.target
      out.push({
        curveId: any1.id ?? '',
        targetId: typeof tgt === 'string' ? tgt : tgt?.templateId ?? String(tgt),
        ownerId,
        property: any1.property,
        keyframes: (any1.keyframes ?? []) as Keyframe<any>[],
      })
    }
    if (Array.isArray(any1.children)) any1.children.forEach((c: BTNode) => walkBT(c, ownerId))
    if (any1.child) walkBT(any1.child, ownerId)
    if (any1.template) walkBT(any1.template, ownerId)
  }
  const walk = (n: SceneEntity) => {
    const bt = behaviorOf(n)
    if (bt) walkBT(bt, n.id)
    n.children.forEach(walk)
  }
  walk(root)
  return out
}

function typeBadge(type: string): { label: string; color: string; bg: string } {
  switch (type) {
    case 'sequence': return { label: 'SEQ', color: '#8ec7ff', bg: '#2d4a6a' }
    case 'selector': return { label: 'SEL', color: '#ffb86c', bg: '#4a352d' }
    case 'parallel': return { label: 'PAR', color: '#c5ff8e', bg: '#2d4a2d' }
    case 'decorator': return { label: 'DEC', color: '#d4a0ff', bg: '#3a2d4a' }
    case 'condition': return { label: 'IF', color: '#ff8e8e', bg: '#4a2d2d' }
    case 'action': return { label: 'ACT', color: '#ffe88e', bg: '#4a442d' }
    case 'script': return { label: 'JS', color: '#8effe8', bg: '#2d4a42' }
    case 'forEach': return { label: 'FOR', color: '#8effc5', bg: '#2d4a35' }
    case 'curve': return { label: 'CRV', color: '#8ec7ff', bg: '#2d4a6a' }
    default: return { label: type.toUpperCase(), color: '#aaa', bg: '#2a2a2e' }
  }
}

function BTRow({ entity, depth, onSelect, selectedId, onSelectBehavior }: { entity: BTNode; depth: number; onSelect?: (id: string|null)=>void; selectedId?: string|null; onSelectBehavior?: (id: string) => void }) {
  const [expanded, setExpanded] = useState(depth < 2)
  const badge = typeBadge(entity.type)
  const hasChildren = 'children' in entity && (entity as any).children?.length > 0
  const hasChild = 'child' in entity && !!(entity as any).child
  const hasTemplate = 'template' in entity && !!(entity as any).template

  return (
    <div style={{ marginLeft: depth * 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '3px 4px', borderRadius: 3, background: depth === 0 ? '#1e1e20' : 'transparent', border: '1px solid transparent' }}>
        {(hasChildren || hasChild || hasTemplate) ? (
          <button onClick={() => setExpanded(!expanded)} style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: 10, width: 16 }}>{expanded ? '▼' : '▶'}</button>
        ) : <span style={{ width: 16 }} />}
        <span style={{ fontSize: 9, background: badge.bg, color: badge.color, padding: '1px 4px', borderRadius: 2, fontWeight: 700 }}>{badge.label}</span>
        <span style={{ fontSize: 11, color: '#ccc' }}>{entity.type}</span>
        {entity.id && <button onClick={() => onSelectBehavior?.(entity.id!)} style={{ background: 'none', border: 'none', color: '#777', cursor: 'pointer', fontSize: 10 }}>{entity.id}</button>}
        {/* type-specific summary */}
        {entity.type === 'action' && (
          <span style={{ fontSize: 10, color: '#aaa', marginLeft: 4, display: 'flex', gap: 6, alignItems: 'center' }}>
            <span>{(entity as any).action} → </span>
            {(() => {
              const tgt = (entity as any).target
              const label = typeof tgt === 'string' ? tgt : tgt?.templateId ?? JSON.stringify(tgt)
              const isSel = selectedId === label
              return <button onClick={() => onSelect?.(label)} style={{ background: isSel ? '#2d4a6a' : 'none', border: '1px solid transparent', color: isSel ? '#8ec7ff' : '#ffe88e', cursor: 'pointer', fontWeight: 700, fontSize: 10, borderRadius: 3, padding: '0 3px' }}>{label}</button>
            })()}
            <span>{(entity as any).duration}s</span>
            {(entity as any).params?.to ? <span style={{ color: '#666' }}> to {JSON.stringify((entity as any).params.to).slice(0, 60)}</span> : null}
            {(entity as any).params?.by ? <span style={{ color: '#666' }}> by {JSON.stringify((entity as any).params.by).slice(0, 60)}</span> : null}
          </span>
        )}
        {entity.type === 'curve' && (() => {
          const kfs = ((entity as any).keyframes ?? []) as Keyframe<any>[]
          const span = kfs.length > 0 ? kfs[kfs.length - 1]!.t : 0
          const tgt = (entity as any).target
          const label = typeof tgt === 'string' ? tgt : tgt?.templateId ?? JSON.stringify(tgt)
          const isSel = selectedId === label
          return (
            <span style={{ fontSize: 10, color: '#aaa', marginLeft: 4, display: 'flex', gap: 6, alignItems: 'center' }}>
              <button onClick={() => onSelect?.(label)} style={{ background: isSel ? '#2d4a6a' : 'none', border: '1px solid transparent', color: isSel ? '#8ec7ff' : '#ffe88e', cursor: 'pointer', fontWeight: 700, fontSize: 10, borderRadius: 3, padding: '0 3px' }}>{label}</button>
              <span style={{ color: '#777' }}>{(entity as any).property}</span>
              <span style={{ color: '#666' }}>{kfs.length} kf · {span}s local</span>
            </span>
          )
        })()}
        {entity.type === 'condition' && (
          <span style={{ fontSize: 10, color: '#aaa', marginLeft: 4 }}>
            on:{(entity as any).on} { (entity as any).threshold !== undefined ? ` thr:${(entity as any).threshold}` : ''} { (entity as any).source ? ` src:${(entity as any).source.join(',')}` : ''}
          </span>
        )}
        {entity.type === 'decorator' && (
          <span style={{ fontSize: 10, color: '#aaa', marginLeft: 4 }}>{(entity as any).decorator} {JSON.stringify((entity as any).params).slice(0, 80)}</span>
        )}
        {entity.type === 'forEach' && (
          <span style={{ fontSize: 10, color: '#aaa', marginLeft: 4 }}>
            {(entity as any).mode ?? 'sequence'} {(entity as any).source?.kind} { (entity as any).source?.kind === 'rows' ? `${(entity as any).source.rows.length} rows` : ''} { (entity as any).overrides ? `+${Object.keys((entity as any).overrides).length} overrides` : ''}
          </span>
        )}
        {(entity as any).repeat && <span style={{ fontSize: 9, background: '#2a2a2e', color: '#888', padding: '1px 4px', borderRadius: 2 }}>×{ (entity as any).repeat}</span>}
        {(entity as any).loop && <span style={{ fontSize: 9, background: '#2d4a6a', color: '#8ec7ff', padding: '1px 4px', borderRadius: 2 }}>loop</span>}
      </div>
      {expanded && (
        <div style={{ borderLeft: '1px dashed #2a2a2e', marginLeft: 8, paddingLeft: 4, marginTop: 1, display: 'flex', flexDirection: 'column', gap: 1 }}>
          {hasChildren && (entity as any).children.map((c: BTNode, i: number) => (
            <BTRow key={c.id ?? `${depth}-${i}`} entity={c} depth={depth + 1} onSelect={onSelect} selectedId={selectedId} onSelectBehavior={onSelectBehavior} />
          ))}
          {hasChild && <BTRow entity={(entity as any).child} depth={depth + 1} onSelect={onSelect} selectedId={selectedId} onSelectBehavior={onSelectBehavior} />}
          {hasTemplate && <BTRow entity={(entity as any).template} depth={depth + 1} onSelect={onSelect} selectedId={selectedId} onSelectBehavior={onSelectBehavior} />}
        </div>
      )}
    </div>
  )
}

function CurveRow({ info, onSelect, selectedId }: { info: CurveInfo; onSelect?: (id: string|null)=>void; selectedId?: string|null }) {
  const [expanded, setExpanded] = useState(true)
  const isSel = selectedId === info.targetId
  return (
    <div style={{ border: '1px solid #222', borderRadius: 6, background: isSel ? '#1e2a3a' : '#121214', padding: '6px 8px', marginBottom: 6 }}>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        <button onClick={() => setExpanded(!expanded)} style={{ background: 'none', border: 'none', color: '#888', cursor: 'pointer', fontSize: 10, width: 16 }}>{expanded ? '▼' : '▶'}</button>
        <span style={{ fontSize: 9, background: '#2d4a6a', color: '#8ec7ff', padding: '1px 4px', borderRadius: 2, fontWeight: 700 }}>CURVE</span>
        <button onClick={() => onSelect?.(info.targetId)} style={{ background: 'none', border: 'none', color: isSel ? '#8ec7ff' : '#ccc', cursor: 'pointer', fontSize: 11, fontWeight: 600, textAlign: 'left' }}>{info.targetId}</button>
        <span style={{ fontSize: 9, color: '#555' }}>{info.curveId}</span>
        <span style={{ fontSize: 10, color: '#777', marginLeft: 4 }}>{info.property}</span>
        <span style={{ fontSize: 9, color: '#666', marginLeft: 'auto' }}>{info.keyframes.length} keyframes {info.keyframes.length >=2 ? `${info.keyframes[0]!.t}s → ${info.keyframes[info.keyframes.length-1]!.t}s local` : ''}</span>
      </div>
      {expanded && (
        <div style={{ marginTop: 6, borderTop: '1px solid #1e1e20', paddingTop: 6, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <div style={{ display: 'flex', gap: 8, fontSize: 9, color: '#555', padding: '0 2px' }}>
            <span style={{ minWidth: 36 }}>t</span>
            <span style={{ minWidth: 40 }}>easing</span>
            <span>value</span>
          </div>
          {info.keyframes.map((kf, i) => (
            <div key={i} style={{ display: 'flex', gap: 8, fontSize: 10, color: '#aaa', background: i % 2 === 0 ? '#1a1a1e' : 'transparent', padding: '2px 4px', borderRadius: 3 }}>
              <span style={{ minWidth: 36, color: '#8ec7ff', fontFamily: 'monospace' }}>{kf.t.toFixed(2)}s</span>
              <span style={{ minWidth: 40, color: '#666' }}>{kf.easing ? (typeof kf.easing === 'string' ? kf.easing : 'bezier') : 'linear'}</span>
              <span style={{ color: '#bbb', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{JSON.stringify(kf.value).slice(0, 140)}</span>
            </div>
          ))}
          {/* mini bar */}
          <div style={{ marginTop: 6, height: 12, background: '#1e1e20', borderRadius: 3, position: 'relative', overflow: 'hidden' }}>
            {info.keyframes.map((kf, i) => {
              const t0 = info.keyframes[0]!.t
              const t1 = info.keyframes[info.keyframes.length-1]!.t
              const span = Math.max(1e-6, t1 - t0)
              const left = ((kf.t - t0) / span) * 100
              return <div key={i} title={`${kf.t}s`} style={{ position: 'absolute', left: `${left}%`, top: 0, bottom: 0, width: 2, background: '#8ec7ff' }} />
            })}
          </div>
        </div>
      )}
    </div>
  )
}

export function BehaviorTreeView({ scene, selectedId, onSelect }: Props): JSX.Element {
  const behaviorEntities = useMemo(() => collectBehaviorEntities(scene.root as any), [scene.root])
  const curves = useMemo(() => collectCurves(scene.root as any), [scene.root])
  const totalActions = useMemo(() => {
    let count = 0
    const walk = (n: BTNode) => {
      if (n.type === 'action') count++
      const anyN = n as any
      if (Array.isArray(anyN.children)) anyN.children.forEach(walk)
      if (anyN.child) walk(anyN.child)
      if (anyN.template) walk(anyN.template)
    }
    behaviorEntities.forEach(b => walk((b as any).behavior))
    return count
  }, [behaviorEntities])

  if (behaviorEntities.length === 0) {
    return (
      <div style={{ fontSize: 12, color: '#666', padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ fontStyle: 'italic' }}>No behavior entities in this scene — it's a static image.</div>
        <div style={{ fontSize: 11, color: '#777', lineHeight: 1.4 }}>
          <div>All time lives in the behavior tree (§4.1). Add an entity with <code style={{ background: '#1e1e20', padding: '1px 4px', borderRadius: 3 }}>kind: 'behavior'</code>, then drive things with:</div>
          <div style={{ marginTop: 4, paddingLeft: 12 }}>
            <div>• <b style={{ color: '#aaa' }}>curve</b> — a keyframe list: <code style={{ background: '#1e1e20', padding: '1px 4px', borderRadius: 3 }}>{`{ type: 'curve', target, property, keyframes }`}</code>. Times are local to the leaf. The 3D base uses two for box spin and sphere bounce.</div>
            <div style={{ marginTop: 2 }}>• <b style={{ color: '#aaa' }}>action</b> — one value over a duration, composed with sequence / parallel. See the Hanoi samples.</div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', fontSize: 12, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', gap: 12, fontSize: 10, color: '#777', flexWrap: 'wrap' }}>
        <span>Behavior containers: {behaviorEntities.length}</span>
        {behaviorEntities.length > 0 && <span>Actions: {totalActions}</span>}
        <span>Curves: {curves.length}</span>
        {scene.duration !== undefined && <span>Duration: {scene.duration}s @ {scene.fps ?? 30}fps</span>}
        <span style={{ marginLeft: 'auto' }}>⚡ the tree is the whole time model (§4.1) — actions and curves are both leaves in it</span>
      </div>

      {curves.length > 0 && (
        <div>
          <div style={{ fontWeight: 600, fontSize: 10, color: '#8ec7ff', marginBottom: 6, textTransform: 'uppercase', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>Curves — keyframes, expanded</span>
            <span style={{ fontWeight: 400, textTransform: 'none', color: '#666' }}>each is a leaf in a tree above; times shown are local to the leaf</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {curves.map((c, i) => (
              <CurveRow key={`${c.curveId}-${i}`} info={c} onSelect={onSelect} selectedId={selectedId} />
            ))}
          </div>
        </div>
      )}

      {behaviorEntities.length > 0 && (
        <div>
          <div style={{ fontWeight: 600, fontSize: 10, color: '#aaa', marginBottom: 6, textTransform: 'uppercase' }}>Behavior Trees — {totalActions} actions, {curves.length} curves</div>
          {behaviorEntities.map((bn) => (
            <div key={bn.id} style={{ border: '1px solid #2a2a2e', borderRadius: 6, background: '#121214', padding: 8, marginBottom: 8 }}>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                <span style={{ fontSize: 12 }}>⚡</span>
                <b style={{ color: '#ccc' }}>{bn.word}</b>
                <span style={{ color: '#777', fontSize: 10 }}>{bn.id}</span>
                <span style={{ fontSize: 9, color: '#666' }}>{bn.children.length} child entities</span>
                <button onClick={() => onSelect?.(bn.id)} style={{ marginLeft: 'auto', background: selectedId === bn.id ? '#2d4a6a' : '#1e1e20', border: '1px solid #2a2a2e', borderRadius: 3, color: selectedId === bn.id ? '#8ec7ff' : '#777', fontSize: 10, padding: '2px 6px', cursor: 'pointer' }}>{selectedId === bn.id ? 'selected' : 'select container'}</button>
              </div>
              <BTRow entity={behaviorOf(bn)!} depth={0} onSelect={onSelect} selectedId={selectedId} />
            </div>
          ))}
        </div>
      )}

      <div style={{ marginTop: 4, fontSize: 10, color: '#555', lineHeight: 1.4 }}>
        <div>Behavior tree: sequence runs in order until failure, selector falls back, parallel runs with all/any policy. Actions declare target + duration, conditions gate on contact/proximity/time. ForEach stamps template per row (temporal counterpart of arrangement instance).</div>
        <div style={{ marginTop: 2 }}>Curves: a <code>curve</code> leaf holds the keyframes and names the property it drives (<code>transform.position</code>, <code>components.rect.style.fill</code>). Values themselves are <code>{`{ kind: 'const' }`}</code> only — there is no track variant (foundation §4.2 / §4.3). Keyframe <code>t</code> is LOCAL to the leaf, so a curve under a sequence starts when the node before it ends; wrap it in <code>{`condition on:'time'`}</code> to pin it to an absolute moment.</div>
      </div>
    </div>
  )
}
