/**
 * Share the editor's scene with whatever agent is working alongside you.
 *
 * When the editor skill is running, this hook makes the browser a CLIENT of its scene server
 * rather than the owner of its own copy: edits are posted as correction events, and an agent's
 * edits arrive over SSE. `/api` is proxied by vite to that server. Standalone `pnpm dev` has
 * nothing behind the proxy, the first fetch fails, and the playground keeps its local samples.
 *
 * Edits go to the server rather than being applied locally first. A local apply would render
 * instantly and then have to reconcile with whatever the server decided — and the server is where
 * an event can be rejected, so optimism there means showing a change that did not happen.
 */
import { useCallback, useEffect, useState } from 'react'
import type { EventEnvelope, Scene } from '@scenelab/scene-ir'

const API = '/api'

export interface SharedScene {
  /** Null while the first fetch is in flight, or when running standalone. */
  scene: Scene | null
  /** True once a scene server has answered — decided by trying, not by configuration. */
  connected: boolean
  /** Submit edits. Resolves to the error text when the server rejects the batch. */
  submit: (events: EventEnvelope[]) => Promise<string | null>
  error: string | null
}

export function useSharedScene(): SharedScene {
  const [scene, setScene] = useState<Scene | null>(null)
  const [connected, setConnected] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const refresh = useCallback(async (): Promise<void> => {
    try {
      const res = await fetch(`${API}/scene`)
      if (!res.ok) throw new Error(`server returned ${res.status}`)
      const body = (await res.json()) as { scene: Scene }
      setScene(body.scene)
      setConnected(true)
      setError(null)
    } catch {
      // No server: standalone mode. Not an error worth showing until we have been connected.
      setConnected((was) => {
        if (was) setError('lost the connection to the scene server')
        return false
      })
    }
  }, [])

  useEffect(() => {
    void refresh()
    // The server bumps a revision on every change; re-fetch rather than diffing, since a scene is
    // small and this keeps one source of truth.
    const es = new EventSource(`${API}/stream`)
    es.onmessage = () => void refresh()
    return () => es.close()
  }, [refresh])

  const submit = useCallback(async (events: EventEnvelope[]): Promise<string | null> => {
    if (events.length === 0) return null
    try {
      const res = await fetch(`${API}/events`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ source: 'human', events: events.map((e) => e.event) }),
      })
      if (!res.ok) {
        const body = (await res.json()) as { error?: string; failures?: Array<{ error: string }> }
        return body.failures?.[0]?.error ?? body.error ?? `server returned ${res.status}`
      }
      await refresh()
      return null
    } catch (e) {
      return (e as Error).message
    }
  }, [refresh])

  return { scene, connected, submit, error }
}
