/**
 * Watches .metacode/scenelab-editor.json and auto-opens dedicated app (or browser).
 * Run once in your own Terminal.app (outside Claude sandbox):
 *   pnpm exec tsx scripts/auto-open-watcher.ts              # browser (open)
 *   pnpm exec tsx scripts/auto-open-watcher.ts --electron   # dedicated Electron app
 * Then /scenelab auto-opens the app without manual click.
 */
import { watch } from 'node:fs'
import { readFileSync, existsSync } from 'node:fs'
import { spawn } from 'node:child_process'

const FILE = '.metacode/scenelab-editor.json'
const useElectron = process.argv.includes('--electron')
let lastUi: string | null = null
let lastMtime = 0

function tryOpen() {
  if (!existsSync(FILE)) {
    lastUi = null
    lastMtime = 0
    return
  }
  try {
    const stat = require('node:fs').statSync(FILE)
    const mtime = stat.mtimeMs
    const data = JSON.parse(readFileSync(FILE, 'utf-8')) as { ui?: string | null; api?: string | null }
    if (!data.ui) return
    if (data.ui === lastUi && mtime === lastMtime) return // already opened this session
    lastUi = data.ui
    lastMtime = mtime

    if (useElectron) {
      console.log(`\n  👉 Auto-opening dedicated Electron app for ${data.ui}`)
      // Spawn Electron that reuses existing scene server (SCENELAB_API env tells vite proxy where API is)
      spawn('pnpm', ['--filter', '@scenelab/editor-electron', 'exec', 'electron', 'dist/main.js'], {
        stdio: 'ignore',
        env: { ...process.env, SCENELAB_URL: data.ui, SCENELAB_API: data.api ?? 'http://localhost:7317' },
      }).unref()
    } else {
      console.log(`\n  👉 Auto-opening browser ${data.ui}`)
      spawn('open', [data.ui], { stdio: 'ignore' }).unref()
    }
  } catch {}
}

console.log(`Watching ${FILE} — ${useElectron ? 'Electron dedicated app' : 'browser'} — once per session (Ctrl-C to stop)`)
console.log(`Run in own Terminal.app: pnpm exec tsx scripts/auto-open-watcher.ts${useElectron ? ' --electron' : ''}`)
tryOpen()
try {
  watch('.metacode', (_event, filename) => {
    if (filename?.includes('scenelab-editor.json')) tryOpen()
  })
} catch {
  setInterval(tryOpen, 2000)
}
