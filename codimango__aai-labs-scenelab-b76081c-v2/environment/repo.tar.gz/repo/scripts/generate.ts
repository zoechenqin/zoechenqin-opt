/**
 * Real agent-flow entry: prompt → Avocado → scene graph → scene.py.
 *
 * Requires an entitled Avocado (OpenAI-compatible) endpoint via env:
 *   SCENELAB_LLM_BASE_URL=<gateway base url>
 *   SCENELAB_LLM_API_KEY=<entitled key>
 *   SCENELAB_LLM_MODEL=meta/avocado-code-latest   (default)
 *
 * Run: tsx scripts/generate.ts "show solving the Tower of Hanoi"
 * Then render (public Manim image, auto-pulled by Docker on first run):
 *   docker run --rm -v /tmp/scenelab-gen:/work --entrypoint bash manimcommunity/manim:latest \
 *   -c "cd /work && manim render -ql --format=mp4 --media_dir /work/media /work/scene.py"
 */
import { mkdirSync, writeFileSync } from 'node:fs'
import { clientFromEnv, generateScene } from '@scenelab/agent'
import { toManim } from '@scenelab/manim-adapter'

const prompt = process.argv.slice(2).join(' ').trim() || 'show a red circle and a blue square'

const client = clientFromEnv(process.env)
const scene = await generateScene(prompt, client)

const out = '/tmp/scenelab-gen'
mkdirSync(out, { recursive: true })
writeFileSync(`${out}/prompt.txt`, prompt + '\n')
writeFileSync(`${out}/scene.json`, JSON.stringify(scene, null, 2))
writeFileSync(`${out}/scene.py`, toManim(scene))

console.log(`✓ prompt: ${prompt}`)
console.log(`✓ generated & validated scene "${scene.id}" (${scene.root.children.length} nodes)`)
console.log(`✓ wrote ${out}/scene.json and ${out}/scene.py`)
