/**
 * Validate a scene graph: parse, resolve, simulate, and report anything that would make the
 * scene render as nothing (Design §473 "validate", §4.3).
 *
 * A scene can be valid JSON, pass the schema, render without error and still be empty. The checks
 * here are the ways that happens: a behavior tree whose script throws leaves an empty schedule and
 * a near-instant still frame; a scene whose only drawables are templates stamps nothing; motion can
 * be declared while nothing moves, because the animation lives somewhere no renderer reads.
 *
 * "It rendered" is therefore not evidence of anything. A non-zero exit means the scene does not do
 * what it claims.
 *
 * Usage: pnpm exec tsx scripts/validate.ts <scene.json> [--quiet]
 */
import { readFileSync } from 'node:fs'
import { currentSynthesisProvider, dropReport, formatDropReport, parseScene, resolveScene, sceneTimeline, simulate, synthesize } from '@scenelab/scene-ir'
import type { Node, Scene } from '@scenelab/scene-ir'

const problems: string[] = []
const warnings: string[] = []

function walk(node: Node, visit: (n: Node) => void): void {
  visit(node)
  for (const child of node.children) walk(child as Node, visit)
}

/** World-space positions of every resolved primitive, keyed by id. */
function positions(scene: Scene, t: number): Map<string, string> {
  const out = new Map<string, string>()
  for (const p of resolveScene(scene, t).primitives) {
    out.set(p.id, `${p.worldMatrix[12]!.toFixed(3)},${p.worldMatrix[13]!.toFixed(3)},${p.worldMatrix[14]!.toFixed(3)}`)
  }
  return out
}

function main(): void {
  const args = process.argv.slice(2)
  const path = args.find((a) => !a.startsWith('--'))
  const quiet = args.includes('--quiet')
  if (!path) {
    console.error('usage: pnpm exec tsx scripts/validate.ts <scene.json> [--quiet]')
    process.exit(2)
  }

  let scene: Scene
  try {
    scene = parseScene(JSON.parse(readFileSync(path, 'utf-8')))
  } catch (err) {
    console.error(`INVALID  ${path}\n  ${(err as Error).message}`)
    process.exit(1)
  }

  // --- structure -----------------------------------------------------------
  let behaviorNodes = 0
  let templateNodes = 0
  let instancedTemplates = 0
  let authoredNodes = 0
  const templateIds = new Set<string>()
  walk(scene.root as Node, (n) => {
    if (n.id !== (scene.root as Node).id) authoredNodes++
    if (n.kind === 'behavior') behaviorNodes++
    if (n.template === true) {
      templateNodes++
      templateIds.add(n.id)
    }
    if (n.kind === 'spatial_graph') {
      for (const op of n.spatialGraph.ops) {
        if (op.type === 'instance') instancedTemplates += op.templates.length
      }
    }
  })

  const frame0 = resolveScene(scene, 0)
  if (frame0.primitives.length === 0) {
    if (authoredNodes === 0) {
      // Nothing has been authored yet. That is the state a new scene opens in, not a fault.
      if (!quiet) console.log('  empty scene — nothing authored yet')
    } else {
      // Content exists and none of it draws: templates nobody stamps, a culled subtree, a drawable
      // that failed to resolve. That is the failure this check is for.
      problems.push(
        `${authoredNodes} node(s) but zero drawable primitives at t=0 — nothing renders. Templates ` +
          `nothing stamps, a disabled subtree, or nodes with no drawable component.`,
      )
    }
  }

  // A template is not drawn where it sits, so one that nothing stamps is invisible everywhere.
  if (templateIds.size > 0 && instancedTemplates === 0) {
    warnings.push(
      `${templateIds.size} node(s) are template:true but no instance op stamps anything, so they ` +
        `will never be drawn: ${[...templateIds].join(', ')}`,
    )
  }

  // --- program -------------------------------------------------------------
  const sim = simulate(scene)
  for (const u of sim.unresolved) {
    const where = u.btId !== undefined ? `"${u.btId}"` : `a ${u.reason} node`
    // A script that threw is a hard failure: it contributes no actions at all.
    const hard = /threw|no function named|not terminating|expected|yielded|before initialization/.test(u.detail)
    ;(hard ? problems : warnings).push(`behavior ${where} unresolved (${u.reason}): ${u.detail}`)
  }

  if (behaviorNodes > 0 && sim.schedule.length === 0) {
    problems.push(
      `the scene has ${behaviorNodes} behavior node(s) but the simulated schedule is EMPTY — ` +
        `nothing will move. A script leaf or forEach source that throws produces exactly this.`,
    )
  }

  // --- motion --------------------------------------------------------------
  const timeline = sceneTimeline(scene)
  const declaresMotion = behaviorNodes > 0 || /"kind"\s*:\s*"track"/.test(JSON.stringify(scene))
  if (declaresMotion) {
    if (!(timeline.duration > 0)) {
      problems.push(`the scene declares motion but its timeline duration is ${timeline.duration}`)
    } else {
      const a = positions(scene, 0)
      const b = positions(scene, timeline.duration)
      let moved = 0
      for (const [id, p] of a) if (b.get(id) !== p) moved++
      if (moved === 0) {
        problems.push(
          `the scene declares motion but no primitive changes position between t=0 and ` +
            `t=${timeline.duration.toFixed(2)} — it will render as a still image`,
        )
      } else if (!quiet) {
        console.log(`  motion: ${moved}/${a.size} primitives move over ${timeline.duration.toFixed(2)}s`)
      }

      // Motion that stops long before the clip does leaves a frozen tail. A scene whose looping
      // ambient motion runs once still "moved", so a boolean check is not enough.
      const lastEvent = sim.schedule.reduce((m, e) => Math.max(m, e.start + e.duration), 0)
      if (sim.schedule.length > 0 && lastEvent < timeline.duration * 0.9) {
        const dead = timeline.duration - lastEvent
        warnings.push(
          `motion ends at ${lastEvent.toFixed(2)}s but the clip runs to ${timeline.duration.toFixed(2)}s — ` +
            `${dead.toFixed(2)}s of frozen frame at the end. A looping sequence needs a declared scene ` +
            `duration to repeat up to, or an explicit repeat count.`,
        )
      }
    }
  }

  // --- what the renderers will not carry (§2.9) ------------------------------
  const drops = dropReport(scene)
  const skipped = drops.filter((d) => d.outcome === 'skipped')
  if (skipped.length > 0) {
    // Not a failure: degrading is legal. Staying quiet about it is not.
    warnings.push(`renderers will SKIP ${skipped.length} component(s): ${formatDropReport(skipped)}`)
  }
  const approx = drops.filter((d) => d.outcome === 'approximated')
  if (approx.length > 0 && !quiet) {
    console.log(`  approximated: ${formatDropReport(approx)}`)
  }

  // --- descriptions (§2.7) ---------------------------------------------------
  // An un-synthesized embedding contributes nothing to any render and has nothing to grade or
  // assert on. That is legal, but it should be visible rather than looking like a specification.
  const synth = synthesize(scene)
  if (synth.skipped.length > 0) {
    const why = currentSynthesisProvider() ? 'the interpreter declined or the ref is undeclared' : 'no interpreter is registered'
    warnings.push(
      `${synth.skipped.length} description(s) are UNSYNTHESIZED (${why}): ` +
        `${synth.skipped.map((k) => `${k.nodeId}->${k.ref} (${k.reason})`).join(', ')}. ` +
        `They draw nothing and cannot be corrected until synthesized.`,
    )
  }

  // --- report --------------------------------------------------------------
  if (!quiet) {
    console.log(`  primitives: ${frame0.primitives.length} at t=0`)
    console.log(`  schedule:   ${sim.schedule.length} entries` + (behaviorNodes ? ` from ${behaviorNodes} behavior node(s)` : ''))
    if (templateNodes) console.log(`  templates:  ${templateNodes}`)
  }
  for (const w of warnings) console.warn(`WARN     ${w}`)
  for (const p of problems) console.error(`PROBLEM  ${p}`)

  if (problems.length > 0) {
    console.error(`\nFAILED   ${path} — ${problems.length} problem(s)`)
    process.exit(1)
  }
  console.log(`OK       ${path}`)
}

main()
