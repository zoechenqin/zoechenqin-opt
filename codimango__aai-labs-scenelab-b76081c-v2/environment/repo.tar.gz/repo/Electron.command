#!/bin/bash
cd "/Users/brandonsorg/SceneLab"
# Prefer custom bundle with SceneLab name + icon so Dock shows SceneLab not Electron
if [ -x "apps/editor-electron/dist/SceneLab.app/Contents/MacOS/Electron" ]; then
  exec "apps/editor-electron/dist/SceneLab.app/Contents/MacOS/Electron" --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=http://localhost:7317
else
  exec /Users/brandonsorg/SceneLab/apps/editor-electron/dist/SceneLab.app/Contents/MacOS/Electron --no-sandbox ./apps/editor-electron/dist/main.cjs --window --api=http://localhost:7317
fi
