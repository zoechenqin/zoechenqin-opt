#!/bin/bash
set -e
cd "/Users/brandonsorg/SceneLab"
echo "=== SceneLab Server ==="
rm -f .metacode/scenelab-electron.log
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo "server pid $!"
sleep 3
for i in 1 2 3 4 5 6 7 8 9 10; do curl -s http://localhost:5173 > /dev/null && echo "vite up at http://localhost:5173" && break; sleep 0.5; done
curl -s http://localhost:7317/api/summary
echo ""
echo "Server live — API http://localhost:7317 · UI http://localhost:5173"
