import { defineConfig } from 'vitest/config'

export default defineConfig({
  // Use the automatic JSX runtime so .tsx tests need no React import (matches tsconfig react-jsx).
  esbuild: { jsx: 'automatic' },
  test: {
    include: ['packages/**/src/**/*.test.{ts,tsx}', 'apps/**/src/**/*.test.{ts,tsx}'],
  },
})
