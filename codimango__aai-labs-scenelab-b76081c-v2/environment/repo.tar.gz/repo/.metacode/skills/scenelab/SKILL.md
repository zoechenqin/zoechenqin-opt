---
name: scenelab
description: "Launch SceneLab editor — main via SceneLab.command, server via Server.command, electron via Electron.command."
---

# SceneLab — launch editor

Main launcher is `SceneLab.command` (server + native window).

The editor drives its own agent: the Agent tab hosts a metacode session over ACP
(`skills/editor/acp.ts`) and streams it to the panel. There is no paired terminal session to
prime and no context file to read — a session in this repo is an ordinary one.

## Is the editor already running?

`curl -s http://localhost:7317/api/summary`. If it answers, the server and window are up; do not
relaunch. If it does not, follow Main Flow below.

## Main flow

```bash
pnpm exec tsx skills/editor/stop.ts 2>&1 || true
rm -f .metacode/scenelab-editor.json
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo $!
```

Wait vite + API.

Native:
```bash
pnpm scenelab
```

Combined launcher (main):
```bash
pnpm start
# = bash ./SceneLab.command
# Double-click in Finder → stops previous, builds if needed, starts server via nohup (API 7317 + vite 5173), opens the native window, exits
# Drag to Desktop/Dock for one-click
```

Server only:
```bash
bash ./Server.command
# = pnpm scenelab:server — API 7317 + vite 5173, no window
```

Electron only:
```bash
bash ./Electron.command
# = pnpm scenelab:electron — assumes server running, opens native window
```

## Browser fallback

```bash
pnpm exec tsx skills/editor/editor.ts --new --detach
```

`http://localhost:5173` is cmd+double click inside terminal. Use http:// for browser, or Finder double-click `SceneLab.command`.

## Slash command /scenelab

1. Shutdown: `pnpm exec tsx skills/editor/stop.ts; pkill -9 -f vite; rm -f .metacode/scenelab-editor.json`
2. Server via bash nohup: `nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo $!`
3. Read session file + curl summary
4. Native window: DO NOT auto-launch from inside sandbox, so server only inside, native via outside: `pnpm scenelab`
   Combined launcher: `SceneLab.command` double-click in Finder
5. Report: `http://localhost:5173` (cmd+double click) + welcome message

## Final answer format

```
Welcome to SceneLab — dedicated editor is live.

● Connected · API http://localhost:7317 · UI http://localhost:5173 (cmd+double click)

Blank canvas ready — tell me what to build.
```
