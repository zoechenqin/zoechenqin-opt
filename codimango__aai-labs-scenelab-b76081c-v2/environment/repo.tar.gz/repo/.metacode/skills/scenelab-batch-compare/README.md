# SceneLab Batch Compare Skill

Batched model-comparison trials for SceneLab scene generation, in **agent mode**: each model
runs as a MetaCode agent with full access to an isolated copy of the SceneLab source, reads
the Scene IR, and writes a scene graph — which is then validated and rendered to a Manim
video. See `SKILL.md` for the full reference.

## Quick Start

```bash
# 1. Define a trial
mkdir -p trials/my-trial
printf 'Show solving the Tower of Hanoi with 7 rings' > trials/my-trial/prompt.txt
printf 'avocado,gpt,opus' > trials/my-trial/models.txt

# 2. Run (from repo root)
export METACODE_NON_META_ALLOWED=true
pnpm exec tsx skills/batch-compare/batch-compare.ts trials/my-trial --trials=3

# 3. View results
cat trials/my-trial/batches/<timestamp>/results.md
open trials/my-trial/batches/<timestamp>/avocado/run1/manim/video.mp4
```

Runs are slow (MetaCode startup + agent work); run larger batches in the background and poll
`results.md`. Add `--no-render` for fast, scene-only iteration.

## Output structure

```
trials/<name>/
├── prompt.txt              # input: the prompt
├── models.txt              # input: comma-separated model keys (avocado,gpt,opus)
└── batches/<timestamp>/
    ├── results.md          # summary table + per-model consistency
    ├── results.json        # { prompt, results: [...] }
    └── <model>/run<k>/
        ├── scenegraph/scene.json    # validated Scene IR
        └── manim/{scene.py, video.mp4}
```

## Files

- **batch-compare.ts** — the runner (agent-mode; see header comment).
- **SKILL.md** — full documentation, flags, how-it-works, troubleshooting.

The `.metacode/skills/scenelab-batch-compare/` copy is for MetaCode auto-discovery; its
`run-batch-compare.sh` wrapper calls this same `skills/batch-compare/batch-compare.ts`.

## Dependencies

- SceneLab repo root (needs `packages/scene-ir` + `packages/manim-adapter`).
- Node 20+ & pnpm on PATH; `metacode` CLI; `METACODE_NON_META_ALLOWED=true` for `anthropic/*`.
- Docker for rendering only — uses the public `manimcommunity/manim:latest` image (auto-pulled on
  first run; no Code Video needed). Override via `SCENELAB_MANIM_IMAGE`.
