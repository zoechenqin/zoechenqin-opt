#!/bin/bash
# SceneLab Batch Compare — MetaCode wrapper.
# Delegates to the skill's source of truth: skills/batch-compare/batch-compare.ts
# Usage: ./run-batch-compare.sh trials/hanoi --trials=3 --variant=low
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCENELAB_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"

# Node 20+ on PATH (adjust for your local install); anthropic/* models need the flag.
export METACODE_NON_META_ALLOWED=true

cd "$SCENELAB_ROOT"
pnpm exec tsx skills/batch-compare/batch-compare.ts "$@"
