---
name: scenelab-batch-compare
description: "Run batched model-comparison trials for SceneLab scene generation in AGENT MODE: each model runs as a MetaCode agent with full access to an isolated copy of the SceneLab source, reads the Scene IR, and writes a scene graph. Outputs are validated (parseScene) and rendered to Manim video. For measuring generation reliability and comparing models."
---

# SceneLab Batch Compare (Agent Mode)

Run **N trials per model** (Avocado, Claude, Opus) for SceneLab scene generation, then
validate and render each output. Unlike a one-shot API prompt, each trial runs the model as
an **interactive MetaCode agent** with full read/write access to an isolated copy of the
SceneLab source (SWE-bench style): the model reads `packages/scene-ir/src/{types,schema}.ts`
and `docs/foundation.md`, then writes `scene.json`. This measures a model's real ability to
author against the codebase, not just recall a format from the prompt.

## When to Use

- **Measure reliability**: run n=5 to see if a model consistently produces valid, non-degenerate scenes.
- **Compare models**: same prompt through Avocado vs Claude vs Opus.
- **Regression-check the IR/spec**: after changing types/schema/foundation, confirm models still generate valid scenes.

**Do NOT use for**: authoring a single scene (`scripts/generate.ts`), or fixing one output.

## Requirements

- Run from the SceneLab repo root (needs the `packages/*` for validation + render).
- Node 20+ and pnpm on your PATH (see `.nvmrc`).
- `metacode` CLI on PATH. For non-Meta models (`anthropic/*`, `openai/*`): `METACODE_NON_META_ALLOWED=true`
  (the wrapper sets this).
- **Renderers** (each run emits what's available; none are required):
  - **canvas** (`canvas/`) — manim-less mp4 via `@napi-rs/canvas` + bundled ffmpeg. No system deps; always works.
  - **manim** (`manim/`) — needs **Docker** (public `manimcommunity/manim:latest`, auto-pulled; override
    `SCENELAB_MANIM_IMAGE`). Skipped if Docker is absent. `--no-render` skips all rendering.
  - **3D** (`three/`) — unified three.js render via headless **Chromium** (Playwright). Best-effort: it
    **no-ops under a sandbox** (headless Chromium can't launch there) and works in a normal terminal.

### Running under another agent (Avocado/MetaCode) or Claude Code
This skill spawns `metacode` per model×run, so running it *from inside* another agent means nested
metacode. metacode's own `sandbox-exec` can't apply inside a parent sandbox (`sandbox_apply: Operation
not permitted`); the runner **auto-detects that and retries with `--dangerously-disable-osx-sandbox`**
(remembering it for the rest of the batch). Set `SCENELAB_METACODE_UNSANDBOXED=1` to force the bypass
up front and skip the probe. The **3D (three) render still needs an unsandboxed environment** — inside
a sandbox it silently no-ops (manim + canvas still render).

## How to Use

### 1. Define a trial

```bash
mkdir -p trials/hanoi
printf 'Show solving the Tower of Hanoi, with 7 rings colored R,O,Y,G,B,I,V' > trials/hanoi/prompt.txt
printf 'avocado,gpt,opus' > trials/hanoi/models.txt
```

### 2. Run

```bash
cd /path/to/SceneLab
export METACODE_NON_META_ALLOWED=true

pnpm exec tsx skills/batch-compare/batch-compare.ts trials/hanoi --trials=3
```

Because each agent run is slow (MetaCode startup + agent work), run larger batches in the
background and poll `results.md`.

**Flags:**
- `--trials=N` — runs per model (default 1)
- `--models=a,b` — override `models.txt` (keys: `avocado` = `meta/avocado-tester`, `gpt` = `openai/gpt-5.5`, `opus` = `anthropic/claude-opus-4-8`)
- `--model-timeout=SEC` — per-run wall clock (default 600)
- `--variant=EFFORT` — reasoning effort passed to `metacode --variant` (`low` | `minimal` |
  `high` | `max`). **Use `low`** for this bounded authoring task — it keeps thorough models
  from over-deliberating (see Reliability below).
- `--no-render` — skip Docker/Manim, produce `scene.json` only (fast iteration)

**Recommended invocation:**
```bash
pnpm exec tsx skills/batch-compare/batch-compare.ts trials/hanoi --trials=3 --variant=low
```

### 3. Results

```
trials/hanoi/batches/<timestamp>/
├── results.md            # summary table + per-model consistency
├── results.json          # { prompt, results: [...] }
├── avocado/run1/
│   ├── scenegraph/scene.json           # validated Scene IR
│   ├── manim/{scene.py, video.mp4}     # manim render (Docker)
│   └── canvas/{video.mp4, video.overlay.mp4}  # manim-less render + debug-overlay variant
├── claude/run1/...
└── opus/run1/...
```

`results.md` reports, per (model, run): valid?, node count, track count, **Manim** rendered?,
**Canvas** rendered?, time. The **Consistency** section lists node/track counts across runs so you
can spot flakiness (e.g. Opus producing `[1, 11]` nodes = unreliable).

The **canvas** render is the manim-less path (`@scenelab/canvas-render`: @napi-rs/canvas + ffmpeg,
no Docker/Python) — fast and reliable even when the manim/Docker render fails, and it shows exactly
what the interactive scrubber shows. `video.overlay.mp4` adds debug annotations (bounding boxes,
node origins, id labels, world axes).

## How it works (for maintainers)

`batch-compare.ts`, per (model × run):
1. `setupScratch()` copies the **full repo source** into a temp dir (excludes `node_modules`,
   `.git`, `trials/`, build output) and runs `pnpm install --frozen-lockfile` (~1–2s, warm store)
   → a **RUNNABLE** checkout. This matches how codimango runs a SWE-bench agent: it can read the
   codebase AND **write & execute generator code** (`pnpm exec tsx …`) to produce the scene.
2. `runAgent()` invokes `metacode run -m <id> --pure --dir <scratch> --yolo --format text
   --timeout <T> [--variant <effort>]` with an instruction to produce the scene (codegen allowed).
   - `--pure` avoids the network-failing external plugin install (which otherwise hangs).
   - `--yolo` bypasses tool-permission prompts (required in a non-TTY pipe).
   - The instruction lets the model choose **2D** (`space:"2d"`, orthographic) or **3D**
     (`space:"3d"`, perspective camera + volumetric shapes) to fit the prompt — the three.js
     renderer draws both; a scene like "vaporwave" can author a real perspective grid in 3D.
3. Reads `<scratch>/scene.json` — **salvaged even if the agent process timed out/errored**, as
   long as the file was written. Falls back to extracting JSON from stdout. Validates with
   `parseScene` (accepts a bare Scene or `{scene}` wrapper), counts nodes/tracks.
4. `render()` runs `toManim(scene)` → `scene.py` → Docker Manim (`manimcommunity/manim` by
   default) → `video.mp4` in an ephemeral dir so `media/`/`__pycache__` never pollute the output.

## Why a RUNNABLE repo (matches codimango)

The whole point is to **preview a real SWE-bench submission**: on codimango the agent has tools +
a runnable repo, so it typically **writes a generator and runs it** — which is why textbook
subjects (Tower of Hanoi) come out *easy*. An earlier version of this skill gave the agent an
**unrunnable** 2-file scratch; that made the agent effectively do *one-shot* generation and
**overstated difficulty** (results didn't match codimango). Lesson: to judge whether a scene idea
is genuinely hard, the agent must be able to code — pick subjects with **no trivial algorithm** if
you want real spatial-reasoning difficulty.

Trade-off: a runnable repo means agents explore + codegen, so runs are **slower and more variable**
(≈100s–many minutes) than the old minimal scratch. Use `--variant low` and a generous
`--model-timeout`. Prior net (with the old unrunnable scratch, kept for history):
valid, non-degenerate Hanoi scenes (~12–16 nodes, 7 tracks).

## Troubleshooting

- **Hangs at 0% CPU** — missing `--pure`: the external plugin install fails on the network
  and blocks. The harness always passes `--pure`.
- **anthropic model "not allowed"** — `export METACODE_NON_META_ALLOWED=true`.
- **Render fails** — check `docker info`. The default `manimcommunity/manim:latest` image is
  auto-pulled on first run (needs internet once). Rendering is optional; `scene.json` is still
  produced. Use `--no-render` to skip entirely.
- **Model IDs** — `meta/avocado-code-latest`, `anthropic/claude-sonnet-4-6`, `anthropic/claude-opus-4-8`.
