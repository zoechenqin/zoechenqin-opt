#!/bin/bash
# SceneLab Editor — MetaCode wrapper.
# Delegates to the skill's source of truth: skills/editor/editor.ts
# Usage: ./run-editor.sh [scene.json] [--save] [--no-ui] [--port=7317]
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SCENELAB_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"

cd "$SCENELAB_ROOT"
pnpm exec tsx skills/editor/editor.ts "$@"
