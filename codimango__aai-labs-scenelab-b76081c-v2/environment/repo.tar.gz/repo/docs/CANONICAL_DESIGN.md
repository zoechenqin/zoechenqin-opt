# SceneLab — Design Reference

The complete design. If you are new to the project, read the [SceneLab Overview](https://docs.google.com/document/d/1VLrYw17VSqEI5O_MNBMKT7qcyRvvmN3n8f-TqofbyCU/edit) first, kept in the repository as `docs/OVERVIEW.md`. It covers the same ideas in plain language, and adds the delivery context and the workstreams. Section references written as "Overview §x.y" point into it.

## 1. Orientation

How the parts relate, where the design comes from, and the terms used throughout.

### 1.1 How The Pieces Fit

The pipeline. **Artifacts in bold**, *operations in italic*:

**source scene** → *resolve* → **resolved scene** → *simulate* → **timeline**

- **source scene** (§2): what an AI writes and what gets saved. Small and *procedural*: it says "an 8×8 grid of this one square" rather than listing 64 squares.
- **resolved scene**: concrete structure. *Resolve* runs the generators, stamps out the 64 squares, gives each a unique id and wires up cross-references. None of it depends on time.
- **timeline**: what *simulate* produces by walking the behavior tree without drawing. Durations and emergent moments, plus resolved values for anything a consumer downstream cannot work out for itself (§2.8).

What happens next depends on what the consumer is capable of, and there are two shapes:

- **Sampling.** Evaluate the resolved scene at one moment to get a **drawable state**, and draw that. The editor works this way, and so does any renderer we drive frame by frame.
- **Translation.** Hand the structure to a target that runs the animation itself, such as Manim or a game engine, mapping our constructs onto its own as far as they reach and substituting resolved values where they do not (§1.9).

Alongside all of it, *edit* on any of the four surfaces in §3 produces **correction events**, which append to the **log** (Overview §5.5). Those events are the product; everything else exists to generate them.

Nearly every rule in this document exists to protect one property: **editing must never force you to discard the source scene and keep only the resolved one.** A system that expands the board to 64 squares the first time you nudge one has thrown away the thing that made the representation worth having.

Two examples recur throughout. A **chessboard**: one `square` template, an 8×8 grid of points, 64 instances. And a **Tower of Hanoi** solve: 7 disks, so 2⁷−1 = 127 moves, each move being lift / slide / lower, which is 381 individual motions. Both are things you want to state as a short program rather than as 64 objects and 381 keyframes.

### 1.2 Architectural Inspiration

Three bodies of work, in the order they matter here.

**ControlNet.** The premise SceneLab is built on: structure and content are separable, and the human should hold the structure. ControlNet conditions image generation on an explicit spatial input — a pose, a depth map, an edge map, so composition stops being something you re-roll the prompt and hope for. SceneLab takes that and pushes on the weak point: ControlNet's control input is a raster hint, authored once and thrown away. Here the control signal is a typed semantic scene graph, it is the thing you edit, and every edit to it is captured. The structure is not a means of steering the output; it *is* the artifact, and correcting it is what produces the data.

- [ControlNet](https://arxiv.org/abs/2302.05543) (Zhang et al., 2023), and a [video explanation](https://www.youtube.com/watch?v=WZg3e6B2yPQ&t=420s)

**The Scene Language paper.** Where the format comes from: a scene as Φ(s) = (W, P, Z) — words for what things are, a program for how many and how they move, embeddings for everything a name cannot carry. §2 follows it directly. The adaptation is that each of the three has to be reachable by a single typed event, because a representation you can only regenerate is not one a human can fix.

- [The Scene Language](https://arxiv.org/abs/2410.16770) (Wu et al., 2024)

**Procedural editor tools — Houdini above all, with Blender's geometry entities and Unreal's PCG.** Where the spatial model comes from, and the proof that people already work this way. Houdini's Copy to Points is precisely the points-and-instance split in §2.4: generate locations, stamp templates onto them, keep the graph as the source of truth and treat the output as a view of it. These tools also settled the interaction questions long before we reached them — how to nudge one instance without destroying the arrangement, when an edit means the template and when it means the copy, and why baking is a deliberate act rather than a side effect.

- [How to use Houdini in level design](https://www.youtube.com/watch?v=iiHCNpoMZq0&t=40s)
- [Blender Tutorial: Geometry Entities for Beginners - Part 1](https://www.youtube.com/watch?v=vqOZONo5DmY&t=269s)
- [UE5 Series: PCG for Beginners | 01 Level Setup & First PCG Graph](https://www.youtube.com/watch?v=SpulPoSmHJs&t=1720s)

Where SceneLab departs from all three is authorship. A Houdini graph is built by an artist over hours in a visual editor. Ours has to be emitted by a model in one pass and then corrected by typed events, so it must stay small, typed and addressable rather than growing into an entity-graph authoring environment.

### 1.3 Vocabulary

Terms used throughout, defined once here.

- **Entity**: one thing in the scene. Has an id, a transform, and components.
- **Component**: a named bag of properties attached to an entity: its shape, its light, its collision box. Components are the only extension point; everything modular lives in one.
- **Source scene** / **resolved scene** / **drawable state**: what is authored and saved; the concrete structure resolve produces from it; and that structure evaluated at one moment, which is what actually gets drawn.
- **Resolve**: the structural pass from source scene to resolved scene, in two steps: **expand** (run the generators, stamp instances, assign ids) then **link** (wire the structured references). Time-independent (Overview §5.5).
- **Sample**: evaluate a resolved scene at a time `t`, producing the drawable state. This is the only time-dependent step, and what the renderer consumes (§3.2).
- **Simulate**: walk the behavior tree without drawing, to discover durations and emergent moments. Produces a timeline, not a scene (§2.8).
- *Note:* the existing code's `resolveScene(t)` is the **sample** operation, not resolve in the sense used here. The doc's names are the intended ones; the code has not been renamed.
- **Procedural**: described as a program with parameters rather than as explicit content. "Grid 8×8 of `square`" is procedural; 64 listed squares is not.
- **Bake**: the opposite of procedural: replacing a program with its expanded output. Baking a board turns one template and a generator into 64 independent squares. It always costs you the ability to edit the arrangement *as* an arrangement, so in SceneLab baking is only ever explicit and user-requested.
- **Template**: an entity flagged `template: true`. Not drawn where it sits; it exists to be stamped out at generated points. Unity calls this a *prefab*, Blender an *instanced collection*.
- **Instance**: one stamped copy of a template, with a generated id like `square:0,0`.
- **Override**: a small per-instance change recorded against the program rather than replacing it: "instance (0,0) sits 10 units right of wherever the grid put it."
- **Transform**: position, rotation, scale, anchor. Composes down the tree: `world(child) = world(parent) ∘ local(child)`. Opacity is deliberately not part of it (§2.2).
- **Vec3**: an (x, y, z) triple.
- **IR**: *intermediate representation*: the typed data model in `packages/scene-ir` that everything else reads and writes. "The IR" and "the scene format" mean the same thing here.
- **DAG**: *directed acyclic graph*: things point at other things, and no cycles are allowed. Space uses a DAG rather than a tree because one template can feed several arrangements, which a tree cannot express.
- **BT**: *behavior tree*: a standard game-AI structure of sequences, selectors and conditions, used here to describe time.
- **W, P, Z**: the three parts of the scene format, from the Scene Language paper (§2).
- **Embedding**: appearance or motion given as a *description* rather than as values, for things the format cannot specify neutrally. Declared once in a scene-level table and referenced by name (§2.7).
- **Correction event**: one typed edit (`entity.translate`, `component.setProp`, …). The unit of training data.
- **Emergent**: a value not knowable until the scene is simulated: when two things collide, how many moves a script produces, how many points a random scatter yields.

## 2. Scene Language Format (W, P, Z)

The format follows the Scene Language paper, which represents a scene as Φ(s) = (W, P, Z), meaning words, plus a program, plus embeddings:

- **W — Words.** What something *is*. Every entity has a `word` like `board`, `square`, `character`, `chair`, `arrow`, `curve`.
- **P — Program.** How to make many from one, and how they move over time. Here that is an arrangement with per-instance overrides, plus a behavior tree with TypeScript script leaves.
- **Z — Embeddings.** What something looks like beyond its name, and how it moves beyond its positions.

SceneLab's format is a superset of that: the same three parts, adapted so every part can be changed by a typed event rather than by rewriting a program.

### 2.1 Scene

The root object. Entities hang off it, and the things that are true of a whole scene live here rather than being implied:

```
scene {
  root:        Entity
  embeddings:  { <name>: EmbeddingDecl }   // §2.7
  space:       "2d" | "3d"                 // which camera the editor opens in (§3.1)
  duration?:   seconds                     // explicit total; absent means emergent (§2.8)
  fps?:        number                      // export rate
}
```

`space` is a default rather than a restriction. A 2D scene is still 3D content viewed head-on (§3.1), and nothing stops an entity from leaving the `z = 0` plane. `duration` is the override for the estimate simulation produces; most scenes omit it.

### 2.2 Entity

Every entity inherits from a common base:

- **id**: stable reference like `left_foot`, `board`, `square`, `circle_1`. Allowed characters are letters, digits, `_` and `.` (`A-Za-z0-9_.`). Colon is reserved for generated ids (below). Hyphen is excluded so an id stays identifier-safe in generated code; kebab-case belongs in `word` and `name`, which are free-form.
- **word**: the semantic class, W.
- **name**: optional human label.
- **transform**: position, rotation (axis plus angle), scale, anchor. Composes as `world(child) = world(parent) ∘ local(child)`. Opacity is *not* here: it is not part of an affine transform, and it belongs with the other subtree-wide visual properties below.
- **locked**: if true, still drawn but not interactive. Locking a group locks its children. Default false.
- **enabled**: whether the entity participates at all — drawn, hit-tested, and simulated. False culls the whole subtree, so disabling a group disables its children. This is the GameObject-level flag, Unity's `SetActive`, rather than a renderer's `enabled`: it lives on the entity because groups, arrangements and behavior entities have nothing to draw and still need it. Default true.
- **template**: if true, the entity is not drawn or clickable where it sits; it exists to be stamped out by `instance` operators that reference its id. Its own transform is the per-copy offset applied at each point (§3.7), and its children are stamped along with it. This differs from `enabled: false`, which removes a subtree everywhere — a template *is* drawn, just only at its instantiation points. Default false.
- **opacity** (a component, `components.opacity`): a multiplier that compounds down the subtree, so fading a group fades its children. This is the continuous counterpart to `enabled`, which is a hard cull. It is a component rather than a base field because it is an appearance property, and rather than part of `style` because `style` attaches to a single drawable while opacity has to reach a whole subtree. Default 1.
- **components**: the bag of modular properties. This is the single extension point, and the canonical way to give an entity a shape.

Three entity kinds inherit from that base, one per relationship the scene needs to express:

- **`group`**: plain spatial grouping.

  ```
  kind: "group", children: Entity[]
  ```

- **`arrangement`**: an arrangement, expressed as a small dataflow graph rather than as content.

  ```
  kind: "arrangement",
  children: Entity[],
  arrangement: {
    ops: [
      pointsA:   points   { generator: grid | line | radial | poisson | pathFollow | script },
      instanceA: instance { templates: [square], points: pointsA, overrides? }
    ],
    edges: [ { from: pointsA, to: instanceA } ]
  }
  ```

  A `points` op generates locations; an `instance` op stamps templates onto them. `children` here is ordinary containment as everywhere else — authored entities belonging to the arrangement, such as a board's frame or a label, and generated instances attach under the op that produced them, inheriting this entity's transform. Templates are **not** children — they are ordinary entities flagged `template: true`, living anywhere in the tree and referenced by id, which is what lets `boardA` and `boardB` stamp the same `square` without duplicating it. The `ops` are graph operators, not scene entities, and `edges` are dataflow between operators. Neither end of an edge is anyone's child. This is a DAG, not a tree.

- **`behavior`**: a behavior tree describing time.

  ```
  kind: "behavior", children: Entity[], behavior: BTNode
  ```

  Here `children` is ordinary spatial containment; the behavior tree reaches whatever it animates *by id*, not by ownership. This is the usual game-engine pattern, where a cinematic or timeline entity simulates as the scene runs instead of owning the objects it moves.

One word, one meaning: **`children` is spatial containment on every entity kind and nothing else.** Definition scope is the `template` flag. Dataflow is `arrangement.edges` between `ops`. Three different relationships, three different words.

**One drawable per entity.** An entity has at most one shape component, so you cannot put both `circle` and `rect` on the same entity. For several drawables, use several child entities, each with its own single shape.

**Generated ids.** Source ids never contain a colon; expansion reserves it. Expansion appends a colon suffix carrying the parent chain:

| Case | Generated id |
|---|---|
| grid | `board:square:0,0` … `board:square:7,7` |
| linear | `board:square:0` … `board:square:63` |
| radial | `board:square:r0` |
| nested | `board:square:0,0:leg:0` |

The arrangement's id always prefixes, and that is load-bearing rather than decorative: fan-out means `boardA` and `boardB` can stamp the same `square`, and without the prefix both would generate `square:0,0`.

Uniqueness is enforced against the set of ids already used. Each resolved entity also stores `templateId`, `repeatParentId` and `repeatIndex`, so tools can map an instance back to the program that made it without parsing its id string.

### 2.3 Spatial Hierarchy

The tree is spatial. An entity's world position is its parent's world position composed with its own local transform. Dragging a group moves its children. `locked` and `enabled` inherit.

### 2.4 Spatial Graph — Arrangements As Programs

An arrangement is a small DAG of `points` and `instance` operators rather than a subtree of content.

**Points operators** say *where*:

| Generator | Parameters |
|---|---|
| `grid` | rows × cols, spacing |
| `line` | count, step |
| `radial` | count, radius |
| `poisson` | count, minDist, bounds, **seed** |
| `pathFollow` | pathId, count, spacing |
| `script` | TypeScript returning `Vec3[]` or `Transform[]` |

Poisson-disc sampling scatters points randomly while keeping them at least `minDist` apart, which is useful for natural-looking scatter. Being genuinely random, it carries a `seed` as part of its own definition so the same scene resolves the same way twice.

**Instance operators** say *what* and *how placed*:

```
instance { templates: [square], points: pointsA, overrides?: map }
```

producing `square:0,0`, `square:0,1`, and so on. `templates` is a list of id references to entities flagged `template: true`. Fan-out is therefore just two instance operators naming the same id: `boardA` and `boardB` stamp one `square`, with no duplication and no question of which graph owns it.

**Identity per stamp.** A points op says where each stamp goes; an instance op can also say *which identity* each one gets, as a reference into the embedding table (§2.7) chosen by an explicit list or by a rule over the index. Alternating light and dark squares is `i % 2` across two entries — one structure, two identities, rather than two templates.

**Edges** are dataflow between operators (`pointsA → instanceA`). They are not containment; an operator is not a scene entity and has no children.

**Per-instance variation without giving up the program.** An override map keys index → a sparse patch over the stamped copy: a transform delta, or component values, including which embedding it references (§2.7). "Instance (0,0) is nudged 10 right" is one map entry sitting beside an intact 8×8 program. Nothing bakes unless a bake is explicitly requested.

### 2.5 Shapes And Paths Are Component Types

A shape is a component, not a special field. Each is its own component type:

- **Flat and volumetric shapes:** `circle {radius, style}`, `rect {size, cornerRadius?, style}`, `polygon {points, style}`, `line {from, to, style}`, `text {content, fontSize, align?, style}`, `box`, `sphere`, `cylinder`, `cone`, `torus {radius, tube, style}`, `mesh`.
- **Style:** every shape takes a `style`: the shared appearance vocabulary each adapter maps into its own parameters. `fill`, `stroke`, `strokeWidth` for vector work; `roughness`, `metalness`, `emissive` for surfaces, following the physically-based shading model most renderers assume. Anything unset falls back to the adapter's default. That vocabulary is itself a commitment, since `roughness` only means anything to a renderer that shades that way, and it is why §2.7 exists for what it cannot reach.
- **Path:** `path {segments, closed?, style}`: a list of segments, each one of: *move* to a point, *line* to a point, *cubic bezier* to a point with two control handles `cp1` and `cp2` (the familiar pen-tool curve), or *quadratic bezier* with one handle `cp`. All points are Vec3.

Because an entity has at most one *shape* component, it cannot have both `rect` and `path`; several drawables means several child entities. Non-drawable components — `link`, `embedding`, `light`, `collider`: coexist freely, which is how an arrow carries both a `path` and a `link` (§2.6).

### 2.6 Object References

Sometimes one object must point at another without becoming its child: an arrow from a label to a box, or an arrow to one specific generated square on the chessboard, which should keep pointing at it when the board moves.

That relationship lives in a `link` component:

```
components.link { from: EntityRef, to: EntityRef, … }
```

A `EntityRef` is either a direct id (`box_1`, or a generated one like `square:0,0`, or a nested one like `board:square:0,0:leg:0`) or a structured reference:

```
{ parentId: "board", index: "0,0", templateId: "square", anchor: "center", offset? }
```

The structured form is what makes references to *generated* entities survive regeneration: it names the program and the slot rather than an id string that a different grid size would invalidate.

**Resolve is expand then link.** *Expand* runs each arrangement's generators and stamps out instances, enforcing id uniqueness. *Link* then finds each reference target by parent, index and template, and rewrites the arrow's endpoints into its own local space. Linking is why an arrow follows its target when the board's spacing changes, instead of being left behind at a stale coordinate. Both steps are structural; neither depends on time.

### 2.7 Embeddings — Describing What Values Cannot

Appearance is normally `style`: concrete values a renderer reads directly:

```
rect { size: [2,1], style: { fill: "#8B5A2B", roughness: 0.8 } }
```

That works whenever you can name the numbers. An **embedding** covers the cases where you cannot:

```
rect { size: [2,1], embedding: oak }
```

`style` is a specification, binding on every adapter. An embedding is a request: best-effort, and an adapter is free to ignore it.

**When to reach for one.** The test is not "is this hard to draw" but: *would specifying it force me to import some particular renderer's model?* Write out the neutral spec you are contemplating; if it turns out to be one engine's parameterisation with the names filed off, describe the thing instead. Three cases pass that test:

- **Perceptual qualities.** "Weathered oak with visible grain" only becomes enumerable once you commit to a texture pipeline and a shader model.
- **Permanently deferred features.** Particle effects. Every system models emission, forces and blending differently, so a neutral spec would be enormous and still wrong everywhere. "A burst of orange sparks on impact" is *more* portable, not less.
- **Features not specified yet.** Skeletal animation, before we design a real one. Here the description is scaffolding, and the feature graduates to a typed spec once its shape is clear, with scenes migrating as the boundary moves. Embeddings are the staging area for the IR's growth, which is what keeps the format small without making it a ceiling.

**What it costs.** Not portability, since every adapter can accept the scene. **Agreement.** Two adapters given the same `oak` produce two different oaks, because interpretation differs per renderer even though the description does not. It also costs deterministic grading (§4.3), and editability until synthesized. Anything descriptive is marked as such, so tooling knows its guarantees degrade there instead of discovering it silently.

Which gives the rule for how much to use them:

> Z is where you put what you have decided not to control.

Anything held as structure or values is draggable, assertable, and yields a clean correction pair. Anything pushed into a description leaves that régime. Keep as much as possible in W and P, and treat reaching for an embedding as a decision with a cost.

**Declaration.** Embeddings are declared once in a scene-level table and referenced by name:

```
embeddings:
  oak:    { phrase: "weathered oak, visible grain" }
  chrome: { phrase: "polished chrome, mirror finish" }
```

An entry stores **how to obtain** the value (a phrase, or the inputs to a textual-inversion run) never a raw vector. Which text encoder turns that phrase into a vector is the interpreter's business, not the scene's, and is pinned along with the interpreter at synthesis. The one exception is an inversion-derived identity: a learned token only means anything inside the space it was trained in, so that entry kind necessarily names its model. A phrase can be read in a diff, reviewed, and edited by a correction event; a thousand floats can be none of those. The vector is a build artifact. Declaring once also keeps a scene compact when many entities share an identity, and makes "restyle everything oak" one edit rather than a mass edit.

**Composition with templates.** Templates and embeddings are the same pattern (a named table, referenced from entities) applied to orthogonal axes: a template is *which structure*, an embedding is *which identity*. Keeping them apart is what avoids one entry per combination. They compose without a third mechanism: a template whose root references `oak` is the bound pair, and overriding that reference on a single stamp is a per-instance identity override (§2.4).

**Synthesis.** `(word, embedding) → style, and possibly structure`. This is a separate operation from *expand*, which is what an arrangement does (§2.4). Running synthesis is explicit and per-entity, never part of resolve, because it commits one interpreter's answer — expand in mechanism, bake in consequence. It is pinned by interpreter version and seed and cached by content hash, so it reproduces. Two destinations:

- **Written into the scene**, when you want to correct the interpretation. The result is ordinary entities and values, marked synthesized, with the description still attached.
- **Computed in the pipeline**, when you only need every adapter to agree. Transient and cached.

An un-synthesized embedding is fine for a quick look in one renderer. Synthesize when two renderers have to match, or when a human needs to fix what the interpreter did.

**Motion.** `motionEmbedding` is the same mechanism for movement: the same walk, careful or hurried. Everything above applies unchanged, and §2.8 covers how identity varies across a behavior tree.

**Relation to the paper.** Scene Language keeps Z separate from P deliberately: `g_reparam` lives in the renderer, so one representation serves many renderers and each interprets for itself. We keep that. What we add is the explicit expansion above, because their editing story is re-prompting and ours is direct manipulation, which requires that anything a human can see be reachable in the IR.

### 2.8 Behavior Tree — Time As A Program

Spatial hierarchy says where things are. The behavior tree says when and how they move. Together they are P: space as a DAG, time as a BT.

**Status.** Every entity, when ticked, returns **running**, **success** or **failure**. That is what makes the composites mean anything: a condition fails when its predicate does not hold, an action fails when its target cannot be resolved or its script throws, and everything else propagates.

**Building blocks:**

- **Sequence**: run children in order, stopping on the first failure; succeeds when all succeed. Has a speed multiplier and an optional `loop`. The Hanoi solve is a sequence of 127 moves, and each move is itself a sequence of lift / slide / lower. Editing the top-level speed scales the whole solve.
- **Selector**: fallback: run children in order until one does not fail. Fails only if all of them do.
- **Parallel**: run children at the same time. `all` succeeds when every child does and fails if any child does; `any` succeeds on the first success. A contact triggering particles, a flash and a sound is one parallel, so all three share a single moment rather than three keyframes that must be kept in sync.
- **Decorator**: wraps exactly one child to modify it: `timeScale`, `enabled`, `locked`, `invert`, `motionStyle` (which draws on the motion embedding), or a script.
- **Condition**: gates on `contact`, `collision`, `proximity`, `time`, `always`, `beat` or a script, naming the objects involved.
- **Action**: `translate`, `scale`, `rotate`, `setVisible`, `setLocked`, `upsertComponent`, `emitParticles`, or a script. Each carries a `duration` in seconds and reports **running** until it elapses; state changes like `setVisible` use zero. Enclosing `speed` and `timeScale` scale it, which is what makes the durations in the simulation step below well-defined.
- **Script leaf**: a TypeScript function, such as a recursive `function* hanoi`, embedded directly in the tree. This makes the behavior tree Turing-complete, so animations nobody anticipated are still expressible as a program rather than as baked keyframes.

**Motion identity across the tree** works the same three ways space does (§2.4). A `motionStyle` decorator scopes an identity to a branch, so everything under it moves that way. One awkward step out of 127 takes a per-step override entry. And because the space is continuous, style can drift across a sequence (careful easing into hurried) as interpolation driven by progress, rather than two hand-authored clips.

**Duration is often not knowable up front.** Some durations are emergent: when a physical contact happens, where the beats of a piece of music fall, how many moves `hanoi(disks=7)` produces, how many points a Poisson scatter yields at a given `minDist`. You cannot ask the author for a total length.

So the scene is simulated before it is drawn. This is a distinct step from resolve, and it produces a timeline rather than a scene:

1. **Expand.** Run the point generators: grid 8×8 gives exactly 64, Poisson with `count: 200` might give 187, a script generator returns whatever it returns. This yields concrete counts, unique ids, and the back-mapping from each instance to its template and index.
2. **Walk the behavior tree without rendering,** accumulating real durations:
   - an action with a fixed duration contributes that duration;
   - a `contact` condition contributes distance ÷ speed, using link references to locate both objects;
   - a script leaf contributes whatever it produces, so `hanoi(7)` is 127 moves and knowable from the parameter, but a script looping `while (!contact)` has to actually run in the sandbox.
3. **Collect the emergent moments**: contact at 1.23s, beats at 0.5s and 1.0s, move boundaries at 0.0, 1.0, 2.0 … through the end of move 127.

The estimated total is the last event's end plus anything still running at that point (a particle effect's lifetime, say), or an explicit `scene.duration` if the scene declares one.

**What a static walk can and cannot settle.** Durations that follow from the program — action durations, sequence order, parallel policy, `speed` and `timeScale`, a `time` condition — are computed. Anything depending on runtime state is not: a `contact` or `beat` condition, a script leaf's output, which branch a selector takes, how many times a `loop` runs. Those are reported as unresolved points rather than given invented numbers, and the duration is then a **lower bound** rather than an estimate. Work gated behind an unresolved condition is still scheduled, so the bound is useful rather than empty.

Duration is not the only output worth keeping. Simulation also resolves everything that depended on runtime state: when the contact happened, what the script emitted, which branch a selector took, how many iterations a loop ran. Those resolved values are what an adapter substitutes for any construct its target cannot evaluate for itself (§1.9). Retaining them is what stops every adapter re-implementing the simulation and disagreeing both with each other and with the editor.

### 2.9 What Consuming A Scene Obliges You To Do

Anything that reads a scene (a renderer, an exporter, a diagram backend) owes it four things:

- **Read `style`; treat descriptions as optional.** A `style` is binding. An embedding is a request, and ignoring one is legitimate (§2.7).
- **Degrade, never fail.** Unknown component types, descriptive components, and features you do not implement are skipped or placeholdered. A scene using particles must still render everything else.
- **Report what was dropped.** "Three descriptive components: two placeholdered, one skipped." The promise that export matches the editor (Overview §5.2) is only honest if an adapter can say where it does not.
- **Never require synthesis.** An un-synthesized scene must render. If you can interpret a description natively, that is an optimisation, not a precondition.
- **Decide how you consume time, and say which.** Some renderers take one frame at a time; others run the animation themselves. If yours does, translate the structure as far as it reaches — a loop as a loop, a parallel as a parallel, a condition as a condition wherever you can evaluate it — and substitute the value simulation computed only where you cannot. A construct translated keeps its meaning; a construct flattened keeps only its timing, so the mix is worth reporting.

## 3. Editor Tools

Section 1 describes the format. This section describes the four surfaces that edit it: the 3D view, the timeline, chat, and the inspector/outliner pair. All four emit the same typed events.

### 3.1 3D Editor View

3D is the default, and there is only one viewport. It swaps to a 2D orthographic front view when that is more useful, the way Unity toggles between Persp and Iso. There is no separate 2D canvas editor.

- **Perspective mode (default).** Perspective camera with orbit, pan and zoom. Shows volumetric shapes and characters with skeletons, and treats a flat diagram as the `z = 0` plane in 3D. For quick looks it offers modes that skip lighting entirely — flat unlit, wireframe, bounding box, which are fast enough for chat and answer "what shape, and where" without waiting on shading.
- **Orthographic mode.** Camera looking down −Z at the `z = 0` plane, used when a scene declares itself 2D or when the user toggles. Same renderer, same handles, same code; only the camera changes. Dragging is constrained to the XY plane.

A diagram, then, is simply the 3D view seen head-on. Chat spawns this real editor rather than a rough 2D approximation of it, and the final export runs the same renderer headlessly, so what you export matches what you edited. That guarantee belongs to this path alone: an export through a different engine, Manim for instance, is subject to that engine's own interpolation and will not match frame for frame (§1.9).

### 3.2 Timeline And Behavior Tree Viewer

The timeline shows a controlled time `t`, tick marks for known moments, and a play loop. Beside it, a behavior tree viewer highlights which branch is active at `t`.

Because duration is often emergent (§2.8), the timeline works in two phases.

**Estimate phase: simulate, then show the timeline.** Expansion runs the point generators and simulation walks the behavior tree without rendering, exactly as described in §2.8, producing concrete counts and a list of emergent moments. The estimated total is the last event's end plus anything still running, or an explicit duration if the scene declares one. A looping scene has no finite total and is marked as such.

**Scrub phase: the estimate is a starting point, not a ceiling.**

- Ticks come from explicit keyframe times plus everything the behavior tree implies: sequence boundaries, condition trigger times, per-instance indices.
- Scrubbing to `t = 5.3s` walks the tree from the start, accumulating real durations and re-evaluating conditions along the way, until it passes 5.3 — landing on, say, move 6 at 30% through its *slide* sub-step. Actions grouped under one condition share that condition's moment rather than drifting apart.
- Scrubbing past the estimate simply continues the simulation and extends the timeline. A looping walk cycle has an indeterminate length and plays back to the start.
- Clicking an entity in the tree viewer jumps the timeline to its start; scrubbing the timeline highlights the active branch in the viewer.

This keeps time procedural in the same way space is. The model emits `hanoi disks=7, pegs=[…], speed=1` with a motion style, which is compact rather than 381 keyframes. Peg in the wrong place is one edit to a program parameter. Whole thing too fast is one edit to `speed`. One awkward move out of 127 is a single override entry against that move, with the other 126 still driven by the program.

### 3.3 AI Chat Interface

Before you touch a number field or a drag handle, you can edit by typing. Chat produces exactly the same typed events a drag produces. The only difference recorded is who authored it.

**Move.** *"move the left square 10 to the right"* → `entity.translate`. If `square` is a template stamped 8×8, you can name an instance: *"move the square at board 0,0 ten right"* → `override.set target=board index=0,0 …`, which leaves the 8×8 program intact and adds one override entry rather than expanding to 64 squares.

**Scale and rotate.** *"make disk_1 20% bigger"* → `entity.scale`. *"spin the box 90° around Y"* → `entity.rotate`.

**Lock and hide.** *"lock the floor so I don't drag it"* → `entity.setLocked` (still drawn, no longer draggable, inherited by children). *"disable peg_A"* → `entity.setEnabled` (subtree removed from drawing and hit-testing).

**Path handles.** *"pull the S-curve's first handle 20 down"* → `component.setProp` on `path.segments.0.cp1`.

**References without parenting.** *"make the arrow point from label_1 to the square at board 0,0"* → a `link` component whose target is the structured reference `{ parentId: board, index: 0,0, templateId: square }`. Nested targets use the parent chain, `{ parentId: "board:square:0,0", index: "0", templateId: "leg" }`. Colons appear here because these are *generated* ids; the strict source-id charset applies to ids a human or model authors, not to references resolve produces. When the board's spacing changes the arrow follows, because linking recomputes the endpoint (§2.6).

**Appearance and motion (W and Z).** *"make this chair look more like oak"* → `component.setProp` on the chair's `embedding`: same word `chair`, different fingerprint. *"make the walk more careful"* → a `motionEmbedding` or a `motionStyle` decorator: same motion, different style, and still one procedure rather than a re-timed keyframe set.

**Grouped events.** *"when the hand touches the table, emit particles and flash"* → a condition on contact wrapping a parallel of all three actions, so they share one emergent moment instead of being pinned at 1.0s, 1.1s and 1.2s and drifting the moment anything upstream changes.

**Beat alignment.** *"land the disk placements on beat 8"* → a `beat` condition plus a quantize decorator, so the whole solve stays on the beat when the tempo changes.

**Structure.** *"group the legs under the chair"* → `entity.group`. *"the arrow doesn't belong on the board"* → `entity.reparent`. *"ungroup that"* → `entity.ungroup`. Restructuring is one of the most common corrections a human makes to AI-generated scenes, so it is part of the vocabulary rather than a separate mode. Grouping is also how you introduce a new procedural level without baking (§3.6).

**How chat becomes events.** The model parses natural language into a list of `CorrectionEvent`s, the same types the viewport emits: translate, scale, rotate, setLocked, setVisible, component upsert / remove / setProp, override set / remove, group / ungroup / reparent, and behavior tree actions. Each is wrapped in an envelope recording the event, whether a human or an agent authored it, which surface it came from, and when. That envelope is what makes a session reconstructable, and what makes human and agent edits directly comparable — the demo nudge button in the playground emits the very same translate event, attributed to an agent.

The point of all this is that generation stays procedural: the model emits "grid 8×8" and "127-move sequence", not 64 squares and 381 keyframes, and editing stays cheap, because every edit lands on a program parameter or a single override entry.

### 3.4 Inspector

The inspector, chat (§3.3), the viewport handles (§3.5) and the outliner (§3.6) are four surfaces emitting one vocabulary. The event envelope records `source` (human or agent) for *who* and `surface` (chat, inspector, viewport, outliner) for *through what*, so a typed number and a drag are the same event with different provenance.

**Most values are not literals**, and the inspector has to say so. Every row is a label, an editor and a state badge, and the badge tells you where the value came from and what typing into it will do:

- **literal**: stored on the entity. Edits it directly.
- **derived** ƒ: produced by expansion rather than stored. An instance's position reading (240, 0, 80) is a *readout of the program*, not a number on the entity. Typing there records an override for that one instance; the program stays intact.
- **driven** ◷: read by sampling the behavior tree at the current time, with the badge naming the step ("driven by move-47"). Typing there rewrites that step's parameter, never a keyframe.
- **mixed**: a multi-selection disagrees. Typing writes to all of them, as one event per target under a single transaction.

Without these states the inspector is a bake button: the first person to type into a derived position field silently destroys the 8×8.

A **synthesized** entity, one produced by synthesising a description (§2.7), is a further kind of derived. Editing one records an override against the synthesis rather than freezing the output, exactly as with an instance.

**Sections, in order:** Identity → Transform → Drawable → Components → Procedural → Behavior.

**Identity.** Word, read-only id, name, kind, and the Locked and Enabled toggles. A generated id is shown as template-and-index chips, *instance of `square` in `board` [0,0]*, rather than as the raw string `board:square:0,0:leg:0`.

**Transform.** Position, rotation (shown in degrees, stored as axis-and-angle), scale, anchor. Opacity sits under Components, since that is where it lives (§2.2).

**Drawable.** One section rather than a list, because an entity has at most one shape component: a type chip and a control to swap type. "Add another shape" is offered as *add as a child entity*, so the inspector enforces the one-drawable rule by construction instead of letting validation fail later. A path gets a segment list, with per-segment points and handles, mirrored-or-broken handle mode, and a closed flag; selecting a segment row highlights that handle in the viewport, and vice versa.

**Components.** Embeddings are not numeric rows, because the source holds a phrase rather than a vector (§2.7). The row edits that phrase, names the table entry referenced, and says how many other entities share it, so the blast radius is visible before you change anything. Alongside it: a swatch, a nearest-word readout, and an eyedropper to copy an identity off another entity ("make this chair look like that one"). Identities that no phrase can reach come from *textual inversion* — optimizing a new token against example images until it means that specific thing. Motion embeddings get the same, plus a small looping preview. Then the rest — skeleton bones, light intensity and color, collider size, and link pickers offering a direct id, a structured reference, or an eyedropper.

**Unknown components** get a generic typed-tree editor. Components are the single extension point, so the inspector must never dead-end on a type it has no purpose-built UI for.

**Procedural** (on a `arrangement`). Generator parameters, the instance's template list, and the override map with a count ("3 of 64 overridden") each entry listed and individually clearable.

**Behavior** (on a `behavior` entity). The tree viewer shared with §3.2. Selecting a tree entity shows its parameters; a script leaf opens its TypeScript in a code editor.

### 3.5 Manipulators — Viewport Handles

Conventional wherever it can be, so that nothing has to be learned.

**Gizmos**, the on-screen drag handles, cover translate, rotate and scale, stay a constant size on screen regardless of zoom, and can operate in local, parent or world space. In orthographic mode dragging is constrained to the XY plane. A multi-selection pivots around its bounding-box center, or optionally around the last-clicked entity's origin.

**Selection.** Click selects the outermost unlocked group; double-click drills into it; shift-click adds; a marquee (rubber-band box) takes everything it touches. Double-clicking a generated instance selects all of its siblings from the same instance operator — the "I meant the whole board" gesture. A template is not clickable where it sits (§2.2), so it is reached by ⌥-clicking any of its instances, or from the outliner. Selecting a template highlights every instance it reaches, across every operator that stamps it, and **that highlight is the blast-radius display**: the reach of a template edit is something you see rather than something you are warned about.

**Locked and disabled diverge here.** A locked entity can still be clicked, so you can select it and unlock it, but its gizmo is greyed and will not drag. A disabled entity is culled, so it cannot be clicked at all and is reachable only from the outliner (§3.6).

**Beyond transforms:** pen handles on paths, light direction and cone, collider boxes, bones and IK targets. Dragging an arrow's endpoint onto another entity rewrites the link's reference rather than the endpoint coordinate, so the arrow keeps following its target (§2.6) instead of freezing where you dropped it.

**Snapping is semantic as well as grid-based.** Snapping to a generated point offers to write the *reference* rather than the coordinate — a coordinate copied off a point silently stops tracking the moment the generator changes.

**One event per drag, emitted when you let go.** The motion during a drag is preview only; a 60fps stream of micro-translates is not correction data.

**Undo retracts rather than inverts.** A fumbled drag and its undo should leave no training pair behind, so log entries are retractable and undo marks the original retracted instead of appending an inverse. This makes the correction log mutable-once rather than append-only (Overview §5.5). A batch (a multi-selection edit, a structural change) retracts as a unit.

### 3.6 Outliner

A tree panel is necessary because disabled entities cannot be clicked, templates are not in the viewport as themselves, and behavior and arrangement structure has no spatial position to click at all.

The outliner shows the **resolved** tree, not the source tree. Generated instances appear as real entities, badged as derived, nested under the operator that produced them, with the template above as the authoring layer — flagged `template: true`, shown where it actually lives in the tree, and drawn only at its instantiation points. Unity shows prefab instances in its hierarchy; Blender hides its instanced geometry. We follow Unity, because ours are selectable and overridable: if you can click it in the viewport, it belongs in the tree. Large expansions collapse by default and render lazily — a 5000-point scatter is a list-rendering problem, not a reason to hide the objects.

Structure is edited here: drag to reparent, group, ungroup. Reparenting keeps world position, so nothing jumps when its parent chain changes.

**Grouping is also how you introduce a new procedural level.** If one template feeds `boardA` and `boardB` and you want an offset on boardA's copies only, you group: a wrapper entity carrying the offset, the template beneath it, boardA pointing at the wrapper while boardB still points at the template. This is a prefab variant in engine terms, and an inserted transform in Scene Language terms. It needs no new field — the hierarchy already expresses it.

### 3.7 Working With Generated Instances

Scope is not a mode you set. It follows from what you selected:

| Selection | Result |
|---|---|
| one instance | one override entry: 8×8 program plus a delta, not baked |
| N instances | N override entries, one transaction |
| the template | one event, reaching every instance everywhere it is stamped |
| the `arrangement` entity | one event on its transform, moving the arrangement rigidly |
| something in between | group it (§3.6), do not bake |

Forty override entries is simply what a sparse edit of forty instances costs, not a mistake to warn about.

**Three transforms already sit in the chain and do three different things,** exactly as in a game engine: the arrangement's own transform moves the board; the template's transform shifts every copy within its own point's frame; an override entry moves one copy. These coincide for an axis-aligned grid and diverge for a radial arrangement whose points carry orientation.

**Baking stays available as an explicit escape**: drop the arrangement and expand to 64 independent entities with fixed positions. Never implicit.

**References to generated entities** use the structured form rather than a copied coordinate, resolving by parent, index and template, with nested cases carrying the parent chain. The one place SceneLab differs from an engine is the key: Unity keys overrides per instance object, while we key by generated index, which is exactly why each resolved entity carries its template id, parent and index for back-mapping.

## 4. Skills, Benchmarking And Internal Testing

Section 2 covers the surfaces a human uses. This section covers the surfaces an *agent* uses, and how we measure whether any of it works. Agent-facing docs stay agent-neutral — `AGENTS.md`, not a vendor-specific filename, because the agent driving SceneLab is not fixed.

### 4.1 Skills — The Agent-Facing Surface

A skill is to an agent what the editor is to a human: a packaged, discoverable procedure, so a workflow does not have to be re-explained every session. Skills live in `skills/<name>/SKILL.md` with their executable beside them.

One exists today, `scenelab-batch-compare`. It runs N trials per model, and each trial runs the model as an interactive agent with read/write access to an isolated copy of the source — the way SWE-bench evaluates a model against a real repository, rather than as a single prompt. That distinction matters: it measures whether a model can author against this codebase, not whether it can recall a format from a prompt. Every output is parsed for validity and rendered with whichever renderers are available.

Worth adding, on the product side: **generate** (one scene from one prompt, currently a loose script), **render** (scene to any of the renderers), **validate** (parse plus the checks in §4.3), and **correction replay** (take a correction log, replay it against its scene, confirm the pair reconstructs).

And on the delivery side (Overview §4), where the aim is to run well above the baseline rather than merely meet it. For tasks: **scaffold** one from the harness template with tags and taxonomy fields prefilled, **gate** it through the local oracle and pre-push checks before anything is pushed, and **track** cloud validation, surfacing the failure signals that matter. The largest win is **drafting a task from an existing video-generation prompt**: a corpus of prompts is a supply of human-authored subjects, which turns Overview §4's bottleneck into throughput. The skill drafts the scene graph and the spatial assertions; the annotator still judges whether the subject's demands bite, and still writes the instruction. Because the human owns subject selection and the instruction text, these should make everything downstream of a named subject close to automatic — that is where task throughput is won. For corrections: **capture and package** one from a session already underway, since they arise from ordinary work rather than separate effort. Official skills already cover most of the task workflow, so anything added here wraps them rather than reimplementing the CLI, and none of it may flip a task from draft to submitted, which stays a human decision.

Convention: no per-task scripts in the shared `scripts/` directory. Anything specific to one trial, prompt or video belongs in that trial's own directory or in its hidden test. `scripts/` holds only entry points that generalize.

### 4.2 Launching Tools From Chat — Commands Are Not Corrections

Chat (§3.3) turns sentences into correction events. It should also launch the heavier tools from the same box: *"render this at 1080p"*, *"batch compare this prompt across two models, five trials each"*, *"export an mp4"*, *"validate the scene"*.

Those are **commands, not corrections**, and they belong on a separate channel. There are three channels, and only one of them is training data:

- **Scene edits** → correction events. Logged, retractable, become training pairs (Overview §5.5).
- **View state**: camera, current time, selection, preview mode. Never logged. Moving the camera is not a correction.
- **Tool commands**: render, export, batch compare, validate. Not logged as corrections, but recorded with their arguments and a digest of their output so any result can be reproduced.

Keeping these apart is the same discipline as undo-retracts-rather-than-inverts (§3.5): the correction log should contain only things that are actually corrections, or the signal is diluted by camera moves and render invocations.

### 4.3 Benchmarking

**Two layers, scored separately.** *Is this a good benchmark item?* and *how well did a model solve it?* are different questions, and one number cannot answer both: a model can score well on a weak or ambiguous task, and a strong task can expose a good model. The Code Video track separates them for exactly this reason and we follow it.

*Task quality* asks whether the prompt is self-contained, whether the subject has a code-generation shortcut, whether the task is deterministic, whether a reference answer exists and actually passes, whether the assertions check rendered state, and how difficult it is. *Model quality* is everything below.

**The headline comparison.** Same model, same prompt, two arms:

- **status quo** — the model writes renderer code directly
- **SceneLab** — the model writes a scene graph, and an adapter produces the renderer code

Both produce a video, so both are scored by the **Code Video track's own model-eval rubric**: correctness, step coverage, explainability, instruction adherence, visual clarity, text and layout legibility, pacing, render quality, reproducibility, creative fit. Report the per-dimension deltas, not only the aggregate, because which dimensions move is the finding.

Using their measure rather than ours is deliberate. It is the currency the track already accepts, the tasks are theirs and have already passed task-quality scoring so we are not choosing favourable ones, and the judge is calibrated. A gain in someone else's measure is worth considerably more than a gain in one we minted.

Two conditions or the result means nothing: the judge must be blind to which arm produced a video, and there must be enough runs per task for a difference to survive judge variance.

**What this puts on trial is the adapter, not only the representation.** Pacing and render quality are two of the ten dimensions, so clumsy output loses on grounds that have nothing to do with the format. It is also why translation beats flattening (§2.9): several hundred mechanical instructions in a row score badly on precisely those dimensions. Some dimensions may be things the format cannot express well yet, and losing there is a finding rather than an embarrassment.

**Our own measures are the mechanism, not the headline.** Validity is the floor rather than the metric: a model that emits 64 explicit squares instead of one template and a grid generator has produced a perfectly valid scene that fails the entire point.

- **Validity**: the scene parses, ids match the charset, no collisions between authored and generated ids, one drawable per entity, all links resolve.
- **Procedurality**, the distinctive metric: the ratio of resolved entities to source entities. One template plus an 8×8 grid scores 64:1; the same board baked scores 1:1. Likewise in time: one `hanoi disks=7` script leaf against 127 spelled-out children. This measures the third goal in Overview §1 directly, and costs almost nothing, because expansion already produces both counts. See the normalisation note below: the raw ratio is not comparable across tasks.
- **Non-degeneracy**: not everything at the origin, not a single entity, procedural constructs actually exercised rather than merely declared.
- **Editability**: apply a known correction and count the events required. "Move the board 10 right" is one event against a procedural scene and 64 against a baked one.
- **Render completeness**: the scene survives every renderer available in that environment, and the run says which ones actually executed (§4.4). Not every environment has all of them, so this is a per-run figure rather than a fixed bar.
- **Model comparison**: the same prompt across models on all of the above, several trials each, because reliability is the question and one sample cannot answer it.

Never grade an un-synthesized description (§2.7); there is nothing there to assert on yet. Grade structure and values.

**Procedurality is comparative, and must be normalised.** A raw ratio is dominated by what the task asked for rather than by how well the model did it: a task involving a 5,000-point scatter yields a huge ratio for any correct answer, and a task with three objects yields about 1:1 for a perfect one. So score it against the reference solution's ratio for that task. Matching the reference is 1.0; 1:1 against a reference of 64:1 is 0.016 and means the model baked. Never average the raw ratio across tasks, because that measures the composition of the suite.

**A result worth looking for.** If the deterministic checks turn out to predict the judged scores, that is evidence for something the Code Video track has publicly named as unsolved: whether an agent can evaluate quality rather than leaving it to human reviewers. A computable check that tracks a judged dimension is a contribution to their problem, not only ours.

**What has to be recorded, or none of it is interpretable.** Per run: model and version, IR commit, prompt-template version, adapter version, harness version, seed, and task version. Structured records rather than logs. A released task is superseded, never edited. Several of these move at once in normal work, and without the record no change can be attributed to anything.

**What makes a task worth setting.** Two rules, both learned from the Tower of Hanoi task:

- **Difficulty lives in the spatial result, not the logical one.** An agent with tools and a runnable repo will write and run a generator, so any textbook algorithm's *sequence* comes out correct. That is not the hard part. Producing a scene that is physically right — rings resting as valid stacks throughout, sizes ordered, colours mapped as the spec says rather than as convention suggests — is, and models fail there. Hanoi bears this out: one model scored 0 out of 5, and runs from both models under test produced legal move sequences attached to visually broken scenes. A familiar subject is not a disqualifier.
- **Assert the rendered state, not the sequence.** The Hanoi gate at first checked only move legality, and passed a run whose rings floated and inverted. Spatial tasks need assertions on coordinates, resting contact, ordering and scale relationships. Logic-only checks pass scenes that are plainly wrong on screen.

**Measuring the representation, not the model.** Everything above scores a model's output. Nothing scores the format itself, and the sharpest available test is to take video submissions that already exist and re-express them as scene graphs. Can this format hold what people actually built? Where a port cannot be expressed at all, or falls back on a description where a specification should have served (§2.7), that is the priority list for §2, and a side effect is a corpus of real scene graphs, each a candidate task with a known-good answer.

### 4.4 Internal Testing

Per-package unit tests, plus stored reference scenes used as fixtures for resolve, sampling, the timeline and each output adapter.

Emergent duration (§2.8) makes part of this harder than usual: you cannot store a reference result for a scene whose length is unknown until simulated, unless the simulation is deterministic. Almost everything already is — grid, line, radial and pathFollow are pure functions of their parameters, and `hanoi(7)` returns the same 127 moves every time. Only two things can be random, and neither is a general property of the model:

- **Poisson is a random distribution**, so its `seed` belongs in that generator's own definition (§2.4), not as a field on everything that generates.
- **Scripts are nondeterministic only if their author makes them so**, which is a property of the execution sandbox rather than the format: the sandbox does not expose an ambient random function, and a script that wants randomness is handed a seeded one. This folds into the open sandbox question in Overview §5.6.

Synthesising a description (§2.7) is the other non-pure step, and it is handled the same way: pinned by interpreter version and seed, cached by content hash, so it reproduces. Fixtures either require the pure subset or snapshot the pinned result.

The rest of reproducibility (stable ordering, stable number formatting) is implementation hygiene, not schema.

Environment differences are real and already known from batch-compare: the canvas renderer has no system dependencies and always works; the Manim renderer needs Docker and is skipped without it; the three.js renderer needs a real headless browser and quietly does nothing inside a restricted sandbox. Tests degrade rather than fail on whatever is unavailable, and a run reports which renderers actually executed.

## 5. Open Questions

Known gaps and unresolved decisions, listed rather than settled prematurely. Several are load-bearing enough that the answer would change the architecture.

**Representation**

- Should paths support arc segments? What anchor types should a `link` offer beyond `center`?
- How is layout represented? Alignment, edge routing and constraint-based placement have no expression today, and diagram work would force the question first.
- **What bounds a script leaf?** The behavior tree and the point generator both admit Turing-complete TypeScript, which is what makes the format expressive, and also what weakens the claim that a graph beats code. If everything interesting bottoms out in a script, the claim is empty. The value presumably lies in the ratio of addressable structure to opaque script, but nothing states a bound or measures one.

**Execution and performance**

- **How is sandboxed TypeScript executed deterministically?** This gates the script leaf, the script generator, and the determinism story in §4.4. It is among the hardest pieces in the design and currently sits as a footnote.
- **What makes resolve and sampling incremental?** An internal caching question, separate from what adapters consume. Scrubbing re-walks the behavior tree from the start and resolve re-runs generators. Fine for Hanoi; unusable for a 5,000-point scatter with contact conditions. Caching is specified only for synthesis.
- **Where does any of this run?** The design specifies data structures and surfaces and says nothing about deployment: whether the editor is a browser component or a service, where the correction log is collected and stored, what executes synthesis and holds its cache, and how render jobs run given that two renderers need Docker or a headless browser. For a project whose product is collected data, where the data goes is not a detail.
- When a rotate or scale drag lands on an instance whose point carries orientation, which of the three chained transforms (§3.7) does it edit? Selection scope answers *whose* transform, not *which*.

**Correction data**

- **What is the training objective?** "Before, after, what changed" describes the artifact, not what a model would learn from it: predict the edit, produce the corrected scene from the prompt, or score a candidate. Each implies a different thing to collect. This is the most consequential open question here: the answer determines whether the data being gathered is the right data.
- **Should intent be captured, and on every surface?** A chat edit arrives with a rationale in natural language. A drag arrives as from-and-to with no *why*. The design treats them as equivalent, which they are structurally and are not informationally.
- How much correction data is enough? At roughly five per engineer per week the volume is small by any ML standard, and no estimate exists of what would make the second goal pay.
- What are agent-authored corrections worth? They are cheap and effectively unlimited; human ones are neither. If most of the log ends up agent-authored, the signal is different in kind.

**Measurement**

- Can format-compliance failures be reported separately from spatial ones? A task is pass/fail against a hidden test today, so "does not know the notation" and "cannot reason about the space" are indistinguishable, and only the second is interesting.
- **Is the generalisation thesis true?** The task strategy rests on the claim that training against one consistent representation transfers across output surfaces where renderer-specific code does not. It is plausible, it is the reason to prefer scene graphs over Manim, and it is untested.
- What denominator would make procedurality meaningful as an absolute rather than comparative (§4.3)?

**Scope and sequencing**

- **What is the smallest end-to-end path that produces one correction pair?** Neither document distinguishes what is needed first from what is deferrable. The most fully specified subsystem — embeddings and synthesis (§2.7) — is also the least load-bearing for any current goal.

---

**Appendix: the format in one paragraph.** A scene is words (`word` on every entity), a program, and embeddings. The program has two halves: space is a DAG of point generators and instance operators, with templates referenced by id and per-instance overrides that keep the program intact; time is a behavior tree of sequences, selectors, parallels, decorators, conditions, actions and TypeScript script leaves. Everything drawable is a component, one per entity, with paths a component type like any other. References between entities are structured rather than positional, so they survive regeneration. Entities carry a transform, locked, enabled and template flags. A scene root holds the entities, the embedding table, and whether the scene opens 2D or 3D. Any consumer must degrade rather than fail on what it cannot interpret, and say what it dropped. Ids are alphanumeric with colon reserved for generated expansion. This is a superset of the Scene Language paper's representation, chosen so that every part of it can be changed by a single typed event.
