# SceneLab — Foundation Spec

> Status: design of record for SceneLab.
> Scope: the foundation — the scene graph, the correction protocol, the
> adapter contract, and the package layout.

---

## 1. What the foundation must achieve

SceneLab carries three value propositions at once, and the foundation has to serve
all three — not optimize one at the others' expense:

1. **The editor is a real product.** A direct-manipulation tool for editing
   AI-generated spatial/temporal output is a genuine pitch in its own right — faster
   and more intuitive than describing changes in words. This is the surface users
   touch.
2. **It generates structured correction data** (a core motivation for the project).
   Every interaction can emit precise, unambiguous, renderer-agnostic correction
   pairs that feed a downstream training pipeline.
3. **It bets on the intermediate graph representation itself** — two long-term,
   high-reward bets: (a) that a structured entity graph is a *better interface for
   interacting with AI agents* than text, and (b) that *training on this
   representation* yields better results for animation, video, games, and other
   spatial domains than pixels or code alone.

These reinforce rather than compete: a good editor drives adoption, adoption
generates data, and the shared representation is what makes both the editing and the
training generalize across renderers and domains. The foundation's job is to keep all
three viable — which is exactly why the scene graph (Sections 3–4) is the crown jewel:
it is simultaneously the edit target, the data payload, and the representation under test.

The foundation is the layer everything else is built on:

1. **The scene graph** — the renderer-agnostic data structure the AI generates,
   the user edits, and the adapter renders. (The abstract scene graph.)
2. **The correction protocol** — the typed events that a user manipulation produces.
3. **The correction pair** — the training artifact (before + after + events).
4. **The adapter contract** — how the scene graph becomes renderer output (Manim first).

Two product decisions constrain this spec:

- **Nested hierarchy.** Elements can be grouped and nested, not just a flat list.
  This is what makes "keep everything except this one element" clean, and it gives
  entities a compositional structure.
- **Static core, animation as an additive layer.** The core renders
  **still images** — no timeline, no playback. Animation is an *additive* layer
  because all of time lives in one place — the behavior tree — and a scene without
  one is simply static. Section 4 is the load-bearing part of that property.

---

## 2. Design principles

| Principle | Source | Consequence in the foundation |
|---|---|---|
| Corrections are **semantic events**, not pixels | Design (Decision 2) | `CorrectionEvent` is a typed union with `from`/`to`; never raw mouse coords |
| Core is **renderer-agnostic**; adapters are thin | Design (Decision 3) | The scene graph knows nothing about Manim/Canvas; adapters are the only renderer-aware code |
| **Hierarchy + repetition** beat a flat graph | Compositional structure | Groups compose transforms down the graph; "keep everything except this" is a local edit |
| A **semantic class ("word")** per element | Interpretable corrections | Every entity carries a `word` so corrections are interpretable and cross-domain |
| **Explicit typed params**, not neural embeddings | SceneLab needs determinism | Every value is a concrete, machine-checkable field, not a neural vector (Section 3.4) |
| **Widgets are self-contained** | Design (Decision 1) | The scene graph and correction protocol live in a React-free core package |
| **3D-native, degrades to 2D** | games/3D scenes need depth; diagrams are 2D | All spatial quantities are `Vec3`; 2D content is the `z = 0` plane viewed orthographically (§3.5) |

---

## 3. The entity graph (static core)

### 3.1 Overview

A `Scene` is a **directed acyclic graph of `Entity`s** under a single root (the world frame).
The world is **3D**; 2D content is simply the `z = 0` plane viewed through an orthographic
camera (see §3.5). Every entity carries:

- an `id` (stable identity, referenced by correction events),
- a `word` (semantic class — `"triangle"`, `"label"`, `"square"`),
- a `transform` (its pose *relative to its parent*),
- `children`, and
- `components` — what it has, including whatever it draws (§3.2).

An entity's `kind` is one of `group` (composes its children and nothing more),
`arrangement` (instantiates template entities at generated points), or `behavior` (drives
other entities over time, §4).

**Why a graph and not a tree.** `children` is one relation among several. It is the only
tree-shaped one, and it is what culls subtrees — but it is *not* by itself what composes
transforms (§3.3). Entities also *reference* each other by id — an `instance` op names the
template it stamps, a constraint aims one entity at another, a link joins two, a behavior tree
names what it drives. A template may be consumed by any number of entities, from anywhere in
the scene, which is precisely what makes the whole structure a graph rather than a hierarchy.

Three edge kinds, and the distinction is load-bearing:

| Edge | Written as | Cycle means |
|---|---|---|
| `contains` | `children` | — (a literal object tree) |
| `instantiates` | `arrangement.ops[].templates` | **error** — stamping requires having stamped |
| `constrains` | constraints, links, BT targets | warning — resolves, but order-dependent |

`validateSceneGraph` (`packages/scene-ir/src/graph.ts`) walks the full edge set and enforces
this; `resolveScene` carries an expansion guard so an unvalidated cyclic scene errors rather
than recursing forever.

### 3.2 Core types

```ts
// ----- primitives of the coordinate system -----
type EntityId = string;
interface Vec3 { x: number; y: number; z: number; }   // the spatial primitive
// Vec2 is NOT a world coordinate. It exists only for a shape's intrinsic planar
// extent (e.g. a rect's width × height in its own plane). Everything positional —
// translation, scale, anchors, vertices, camera — is Vec3.
interface Vec2 { x: number; y: number; }
// Orientation is axis-angle (§3.9): a unit axis + angle in radians. Canonical form:
// angle ∈ [0, π]; axis defaults to +Z at angle 0.
interface AxisAngle { axis: Vec3; angle: number; }
// Color is sRGB RGBA, floats 0..1 (§3.11). CSS strings are import/export only.
interface Color { r: number; g: number; b: number; a: number; }

// ----- the value slot (see §4.3) -----
// One variant. Time does not live here — it lives in the behavior tree,
// where a `curve` leaf holds keyframes and names the property it drives
// (§4.2). The wrapper is kept so `resolve(value, t)` stays the seam and so
// every field's type is stable if a per-value track is ever reintroduced.
type Animatable<T> = { kind: "const"; value: T };

// ----- transform: pose relative to parent -----
interface Transform {
  position: Animatable<Vec3>;   // translation in parent space
  rotation: Animatable<AxisAngle>; // axis-angle about `anchor` (§3.9)
                                   //   2D: axis = +Z, angle = θ
  scale:    Animatable<Vec3>;   // per-axis; uniform 2D scale is {x:s, y:s, z:1}
  anchor:   Vec3;               // pivot in local units (default origin {0,0,0})
  opacity:  Animatable<number>; // 0..1, multiplies down the tree
}

// ----- camera: first-class, editable (the design's "drag the frame tighter") -----
interface Camera {
  id: EntityId;                   // so camera edits reuse the entity.* correction events
  transform: Transform;         // position + orientation in world space
  projection:
    | { type: "orthographic"; height: Animatable<number> }  // world units across the
                                                            //   viewport; the 2D default
    | { type: "perspective"; fovY: Animatable<number>; near: number; far: number };
}

// ----- entities -----
interface BaseEntity {
  id: EntityId;
  word: string;        // semantic class, free-form (§3.12): lowercase singular kebab noun
  name?: string;       // optional human-facing instance label (e.g. "c² label")
  transform: Transform;
  locked?: boolean;    // editor hint; not rendered
}

interface GroupEntity extends BaseEntity {
  kind: "group";
  children: Entity[];
}

interface PrimitiveNode extends BaseEntity {
  kind: "primitive";
  shape: Shape;
}

type Entity = GroupEntity | PrimitiveNode;

// ----- shapes (geometry + style, all animatable) -----
interface Style {
  fill?:        Animatable<Color>;
  stroke?:      Animatable<Color>;
  strokeWidth?: Animatable<number>;
}

type Shape =
  // --- planar primitives (the 2D vocabulary; live in the local XY plane) ---
  | { type: "circle";  radius: Animatable<number>;               style: Style }
  | { type: "rect";    size: Animatable<Vec2>;   // Vec2 = planar extent, not a coord
                       cornerRadius?: Animatable<number>;         style: Style }
  | { type: "polygon"; points: Animatable<Vec3[]>;               style: Style } // usually z=0
  | { type: "line";    from: Animatable<Vec3>; to: Animatable<Vec3>; style: Style }
  | { type: "text";    content: string; fontSize: Animatable<number>; style: Style }
  // --- volumetric primitives (the 3D vocabulary; pure-2D tools ignore these) ---
  | { type: "box";      size: Animatable<Vec3>;                            style: Style }
  | { type: "sphere";   radius: Animatable<number>;                        style: Style }
  | { type: "cylinder"; radius: Animatable<number>; height: Animatable<number>; style: Style }
  | { type: "cone";     radius: Animatable<number>; height: Animatable<number>; style: Style }
  | { type: "torus";    radius: Animatable<number>; tube: Animatable<number>; style: Style }
  | { type: "mesh";     asset: string;                                     style: Style }; // asset renderers

// ----- the scene -----
interface Scene {
  schemaVersion: string;   // e.g. "0.1.0" — every artifact carries this
  id: string;
  space: "2d" | "3d";      // authoring/UI hint, NOT a data restriction. Drives the
                           //   default camera, which transform controls the tools
                           //   expose (2D hides z + x/y-rotation), and the preview
                           //   projection. A "2d" scene is still stored as full Vec3.
  canvas: {                // default render target; does NOT define coordinates (§3.10)
    width: number;         // output raster size in pixels
    height: number;
    background?: Color;
    // Time block: present but inert in the static core.
    fps?: number;          // undefined ⇒ still image
    duration?: number;     // seconds; undefined/0 ⇒ single frame
  };
  camera: Camera;          // observer; 2D default: orthographic, looking down -Z at z=0
  root: GroupEntity;         // world frame; its transform is usually identity
  units?: string;          // optional physical interpretation, e.g. "meters" (metric
                           //   opt-in, §3.10); default: neutral world units
  meta?: Record<string, unknown>;
}
```

### 3.3 Transform composition

An entity's **world transform** is composed by multiplying local transforms along the
path that reaches it — the same accumulation used to compute limb poses down a skeleton.

```
worldTransform(entity) = worldTransform(parent) ∘ localTransform(entity)
```

**Poses compose along `contains` *and* `instantiates`, not containment alone.** A template
is never posed by the entity that contains it: `resolveScene` skips a `template: true`
entity unless it is being stamped, and the stamped copy's frame comes from the instancing
entity instead — that entity's world transform, composed with the generated point, then
with the template's own local transform. Where a template *sits* determines nothing about
where it *appears*.

That makes the pose-composition path exactly the `contains ∪ instantiates` subgraph, which
is the same subgraph §3.1 marks as fatal-if-cyclic. The two facts are one fact: a cycle
there is both an expansion that never terminates and a pose defined in terms of itself,
which is why it is an error where a circular constraint is only a warning.

Composition is therefore a property of the entity graph, not a second structure beside it.
The tree only appears once the graph is evaluated: expansion mints a distinct
`ResolvedPrimitive` per stamped copy, each with one parent frame and one world matrix,
which is why occurrence identity needs `(templateId, repeatIndex)` and not a bare id.

This is what makes composition pay off: dragging a **group** moves all its children
together (one edit to the group's `position`); dragging a **child** moves only that
child (one edit to the child's `position`, in the parent's frame). The correction
event records the edit at whichever level the user grabbed — that scoping *is* the
signal.

### 3.4 Why explicit typed params

An alternative design would capture an entity's visual *identity* as an opaque neural
embedding (e.g. a learned vector) for neural renderers. SceneLab deliberately does
**not**:

- SceneLab's values must be **directly manipulable** (a drag maps to `x: 100 → 130`).
- They must be **machine-checkable** (the "automated spatial verification"
  path — you can't diff two opaque vectors for "did the label stop overlapping").
- Any renderer can reproduce them **deterministically** from concrete numbers.

So instead of an opaque identity vector, SceneLab stores concrete typed fields
(`radius`, `size`, `fill`, `position`). We keep the compositional *structure*
(program/hierarchy) and *semantics* (words); we drop the neural *identity* channel.
If neural renderers ever matter, an `embedding?` field can be added to an entity without
disturbing anything else.

### 3.5 2D as a constrained 3D scene (the elegant degradation)

There is one coordinate space — 3D — and 2D is a disciplined subset of it, not a
separate mode with its own types. The whole degradation rests on three conventions,
none of which change the stored data:

- **Geometry.** 2D content lives on the `z = 0` plane. `position.z = 0`, `rotation`
  is about the fixed axis `+Z` (`{axis:{0,0,1}, angle:θ}`), `scale.z = 1`. A pure-2D
  authoring tool simply never writes depth or an off-plane rotation axis.
- **Camera.** A 2D scene uses an **orthographic** camera looking down `-Z`, so the
  `z = 0` plane projects straight to the output raster. This *is* the diagram / 2D
  view. Promoting to
  3D is swapping the camera to `perspective` and letting entities leave the plane — no
  entity surgery.
- **Tooling.** `scene.space` tells widgets which controls to expose: `"2d"` hides the
  z field and x/y-rotation handles; `"3d"` shows the full gizmo. The data is identical
  either way, so a scene can be "promoted" from 2D to 3D by flipping the hint and the
  camera.

Ergonomics: a `vec2(x, y)` helper lifts to `{x, y, z: 0}` and a `vec3(x, y, z)` helper
exists for 3D authoring, so 2D code stays terse without a second coordinate type in the
schema. This keeps diagrams simple while game and 3D scenes get true depth from the
same graph — satisfying "fully 3D, simplifies elegantly to 2D."

### 3.6 Repetition

A declarative repeat construct (e.g. "64 squares in an 8×8 grid") is a powerful way to
express structural regularity compactly. In the core, repeated elements are authored as
**explicit sibling children** (simple, always renderable). A declarative `repeat` group
— `{ kind: "group", repeat: { count, step } }` that generates its children — is an
additive extension, and is called out in [Section 10](#10-design-extension-points).

### 3.7 Worked example — a Pythagorean scene

Nested hierarchy in action (abbreviated; every `Animatable` shown as `const`):

```jsonc
{
  "schemaVersion": "0.1.0",
  "id": "scene_pythagoras",
  "space": "2d",                                  // authored flat; still stored as Vec3
  "canvas": { "width": 1920, "height": 1080, "background": {"r":1,"g":1,"b":1,"a":1} },
  "camera": {
    "id": "camera",
    "transform": { "position": {"kind":"const","value":{"x":0,"y":0,"z":1000}}, "rotation": {"kind":"const","value":{"axis":{"x":0,"y":0,"z":1},"angle":0}}, "scale": {"kind":"const","value":{"x":1,"y":1,"z":1}}, "anchor": {"x":0,"y":0,"z":0}, "opacity": {"kind":"const","value":1} },
    // ortho height = view scale (world units across the viewport); a 2D convenience, not a unit definition
    "projection": { "type": "orthographic", "height": {"kind":"const","value":1080} }
  },
  "root": {
    "id": "root", "kind": "group", "word": "scene",
    "transform": { "position": {"kind":"const","value":{"x":0,"y":0,"z":0}}, "rotation": {"kind":"const","value":{"axis":{"x":0,"y":0,"z":1},"angle":0}}, "scale": {"kind":"const","value":{"x":1,"y":1,"z":1}}, "anchor": {"x":0,"y":0,"z":0}, "opacity": {"kind":"const","value":1} },
    "children": [
      {
        "id": "triangle", "kind": "primitive", "word": "right-triangle",
        "transform": { "position": {"kind":"const","value":{"x":-150,"y":-100,"z":0}}, "rotation": {"kind":"const","value":{"axis":{"x":0,"y":0,"z":1},"angle":0}}, "scale": {"kind":"const","value":{"x":1,"y":1,"z":1}}, "anchor": {"x":0,"y":0,"z":0}, "opacity": {"kind":"const","value":1} },
        "shape": { "type": "polygon",
          "points": {"kind":"const","value":[{"x":0,"y":0,"z":0},{"x":300,"y":0,"z":0},{"x":0,"y":200,"z":0}]},
          "style": { "stroke": {"kind":"const","value":{"r":0.07,"g":0.07,"b":0.07,"a":1}}, "strokeWidth": {"kind":"const","value":4} } }
      },
      { "id": "square-a", "kind": "primitive", "word": "square", "transform": { "...": "..." }, "shape": { "type": "rect", "size": {"kind":"const","value":{"x":300,"y":300}}, "style": {} } },
      { "id": "square-b", "kind": "primitive", "word": "square", "transform": { "...": "..." }, "shape": { "type": "rect", "...": "..." } },
      { "id": "square-c", "kind": "primitive", "word": "square", "transform": { "...": "..." }, "shape": { "type": "rect", "...": "..." } },
      { "id": "label-c", "kind": "primitive", "word": "label",
        "transform": { "position": {"kind":"const","value":{"x":120,"y":80,"z":0}}, "...": "..." },
        "shape": { "type": "text", "content": "c²", "fontSize": {"kind":"const","value":48}, "style": {} } }
    ]
  }
}
```

Correcting "the `c²` label overlaps the triangle" is a single local edit to
`label-c.transform.position` — the rest of the scene is untouched. That is the
"keep everything except this" property the design is built around.

### 3.8 Coordinate convention (decided)

The canonical scene-graph space is **right-handed, Y-up, +Z toward the viewer,
center origin**, in neutral world units (§3.10). Angles are radians, positive =
counter-clockwise about each axis (right-hand rule).

Rationale — chosen on interoperability and domain fit, **not** tied to any single
renderer:
- **Interchange standard.** glTF mandates RH Y-up; USD defaults to it. This is the
  portable 3D-asset convention and, plausibly, the one most 3D training data is
  already in — which matters for the "representation improves spatial models" bet.
- **Web-3D default.** Three.js (our likely WebGL preview path) is RH Y-up.
- **Coherent 2D degradation.** Y-up makes XY the camera-facing *drawing* plane, so
  §3.5's "z=0 plane viewed down −Z" is the natural diagram/animation view. (Z-up would
  make 2D mean a top-down floor plan — wrong for diagrams.)

Renderers that differ convert **in their adapter** — the abstract correction data
stays convention-defined and portable:

| Target | Handedness | Up | Origin | Conversion from canonical (RH, Y-up, center) |
|---|---|---|---|---|
| **Canvas 2D** (preview) | — (2D) | Y-down | top-left | flip Y, translate origin to top-left, drop z (orthographic) |
| **Manim** | RH | Y-up | center | ≈ identity (unit scale only) |
| **Three.js / WebGL** (other preview) | RH | Y-up | center | identity |
| Unity *(other target)* | LH | Y-up | — | negate one axis + flip winding & rotation sign |
| Unreal *(other target)* | LH | Z-up | — | Y↔Z remap + handedness flip + unit scale |
| Blender *(other target)* | RH | Z-up | — | Y↔Z remap (swap/negate) |

> **Note on 3D surfaces:** an immersive/3D embedding surface is an aspirational target.
> No such adapter exists yet; it does not constrain this convention.

### 3.9 Rotation encoding (decided)

Orientation is stored, authored, and edited as **axis-angle** — a unit `axis: Vec3`
plus `angle` in radians (`AxisAngle`, §3.2). Canonical form: `angle ∈ [0, π]` (flip the
axis rather than exceed π), and `axis` defaults to `+Z` when `angle = 0`.

Why axis-angle over Euler or quaternion, for SceneLab specifically:
- **The delta is the product, and a rotation delta is natively axis-angle.** "Rotate θ
  about this axis" is how both a gizmo increment and a human describe rotation, so
  correction events read as sentences and stay legible in genuine 3D — not just when
  constrained to one axis (Euler's weak spot).
- **One event shape for all rotation editing.** A constrained-handle drag and a free 3D
  trackball both produce an axis-angle change, so `entity.rotate` needs no special
  free-rotation variant.
- **Clean quaternion affinity.** `q = (cos(θ/2), sin(θ/2)·axis)` is the best-conditioned
  conversion there is — better than Euler→quat, which forces an axis-order choice. No
  gimbal lock in the representation.
- **2D degrades trivially.** Axis pinned to `+Z`, one `angle` field.

Separation of concerns (as with `Animatable`, the clever part stays internal):
- **Composition** (§3.3) happens in **matrix** space — rotation encoding never touches
  the composition math.
- **Interpolation** (when animation lands) converts each keyframe's axis-angle →
  quaternion and **slerps**, then back to a matrix. Authored data stays axis-angle;
  smoothness is solved where it matters, invisibly.

Ergonomic tradeoff: a properties panel can't offer three independent "X/Y/Z rotation"
spinboxes as naturally as Euler. In 2D this is a single `angle` field; for 3D
we expose axis + angle, and can render a *derived, display-only* Euler triple at the UI
layer if designers want the three-spinbox idiom (lossy, never stored).

> Separate concern: if a model is ever trained to **regress** orientations (not
> just consume correction deltas), a 6D continuous representation is
> preferred over any minimal form — a downstream modeling choice, independent of this
> storage decision.

### 3.10 Units (decided)

The foundation is a **camera-independent world space**. All spatial quantities are in
**neutral world units** — isotropic (same scale on X/Y/Z), with intrinsic meaning that
exists without reference to any output or observer. The screen is *derived from* the
world, never the other way around.

- **Metric is opt-in.** A scene may declare `units: "meters"` to unlock real-world
  semantics (physics, collision, real scale) for 3D/game domains. The default is
  neutral world units, so 2D content (diagrams, animation) is never forced into a
  physical scale it doesn't have. Either way the coordinate system is identical; the
  annotation only fixes *interpretation*.
- **Output resolution is a render setting, not a coordinate.** `canvas.width/height`
  is the raster a camera renders into; changing it never alters a stored coordinate.
  Render at 2× by doubling the raster — the world is untouched.
- **The camera is an observer.** It projects world → pixels (§4/§8); it does not define
  the world. There is no global unit→pixel factor in general (a perspective camera maps
  one world unit to a distance-dependent pixel count) — which is exactly why pixels
  can't be the stored unit.
- **2D pixel-precision is a view-scale, not the unit.** An orthographic camera's
  `height` sets how many world units span the viewport; pick it relative to the raster
  (e.g. `height = canvas.height`) and 2D authoring *feels* pixel-native. But what's
  stored — and what correction deltas carry — is world units, so the data is
  resolution- and view-independent.
- **One unit for everything spatial** — `position`, `size`, `radius`, `fontSize`,
  `strokeWidth`, depth, camera `near`/`far`. (Possible future exception: an opt-in
  "non-scaling" flag for screen-space UI overlays — noted, not built.)

Why this direction (the dependency matters more than abstract-vs-metric): a
world-space foundation with a pixel *view* on top is robust because world→pixels is a
clean projection, whereas defining the world in terms of a screen forces real 3D
spatial meaning to be retrofitted onto a screen-derived unit. 3D is the honest
foundation; 2D is a constrained view of it.

### 3.11 Color (decided)

Color is stored as **sRGB RGBA, floats 0..1** (`Color`, §3.2), alpha included. CSS
strings are an import/export convenience only — parsed on input, serialized (e.g. hex)
for display — never the canonical form, because string spellings are ambiguous and
non-diffable, which fails the machine-readable-delta mandate.

Why RGBA for storage rather than a perceptual space (the *inverse* of the rotation call
in §3.9): RGB is the universal rendering substrate — every renderer consumes it — *and*
RGBA round-trips exactly and stays fully editable. So here the universal rendering form
is also a good storage form, unlike rotation's matrices. Perceptual color earns its keep
at the **derived** layers, not in the schema:
- **Correction analysis.** Events store RGBA `from`/`to`; a downstream step derives a
  perceptual delta (ΔL/ΔC/ΔH in OKLCH) when "the user wanted it darker / warmer / more
  muted" is the useful training signal.
- **Interpolation** (when animation lands). The resolver lerps in **OKLab** internally
  for smooth, non-muddy fades, then back to RGBA — the same store-simple /
  interpolate-clever split as rotation.

Conventions:
- **sRGB is canonical**; convert to linear at render/lighting time (flat 2D needs
  nothing more; 3D lighting does its math in linear).
- **Fill-alpha and entity `opacity` are distinct:** per-color alpha means "this shape is
  translucent"; entity `opacity` (§3.2) multiplies down the tree to "fade this whole group."
- Perceptual work uses **OKLab/OKLCH**, not HSL — HSL isn't perceptually uniform, so its
  deltas misstate "how much darker."

### 3.12 Semantic words (decided)

`word` is the **semantic class** of an entity — orthogonal to the structural `kind`
(primitive/group) and `shape.type` (geometry). A circle with `word: "planet"` and a
circle with `word: "bullet-point"` render identically but *mean* different things. Its
value is downstream: correction interpretability ("the user moved the *label*"),
cross-domain generalization (a consistent `"label"` lets a model learn "labels avoid
overlap" transferably), and a future reuse/repeat key.

Decision: **free-form and required**, open vocabulary — consistency comes from
convention and tooling, not schema enforcement. A hard taxonomy is wrong here because
the domains are open and expanding (Decision 1), scenes are LM-generated (the LM coins
words per scene), and a closed enum would ossify the very axis the
project keeps fluid while discarding the natural-language semantics a model can exploit.

- **Soft convention:** lowercase, singular, kebab-case nouns for the semantic role
  (`"label"`, `"axis"`, `"connector"`, `"data-point"`). Free-form in the schema,
  consistent in practice — which keeps normalization easy.
- **Non-binding seed vocabulary:** a suggested per-domain list that the LM prompt and
  the editor UI *nudge* toward, so common concepts converge without a hard enum — most
  of the consistency benefit, none of the ossification cost.
- **Normalization is downstream, ML-owned:** a `word → canonical-category` map applied
  in the training pipeline, evolving independently of stored data. Clean eval classes
  come from there, not the schema.
- **Reserved:** an optional `category?` field is a non-breaking future addition (like
  `embedding?`) *if* inline canonical tags ever prove necessary — it would annotate,
  never replace, the free-form `word`.

Conventions:
- **`word` (class) vs `name` (instance):** `word: "label"`, `name: "c² label"`. Keep
  `word` a class, never a unique id.
- **Fallback:** `word` is required, but import may weakly default it to `shape.type`
  (`circle` → `word: "circle"`) rather than error when a generator omits it.

---

## 4. The animation / time model

This section is the promise that a static core does not paint us into a corner.

### 4.1 The one mechanism: the behavior tree

**All time lives in the behavior tree.** A scene's motion is a program: composites
(`sequence`, `selector`, `parallel`) for control flow, `decorator` for modulation,
`condition` for gating, `forEach` for data-driven repetition, and leaves — `action`,
`script`, and `curve` (§4.2) — for the things that actually move.

This was not always so. Motion could previously be written two ways: a behavior tree,
or a `track` keyframe list on any `Animatable` value. That split cost more than it
bought, and the evidence was that **no consumer wanted it**:

- `resolveScene` merged the two with a per-property precedence rule (tree wins).
- `timeline.ts` merged them again, unioning keyframe times with `simulate().moments`
  into a single tick set.
- Every renderer read *neither* — all of them go through `resolveScene`.

So the duality existed only in the authored types, which is the one place it hurts:
an author (usually a model) had to choose, and the guidance for choosing lived in two
documents that disagreed. One mechanism removes the choice.

A scene with no `behavior` entity is still perfectly static, so the static core keeps
its promise — animation is additive because the *tree* is optional, not because every
value carries a latent timeline.

### 4.2 Curves: keyframes as a leaf

A keyframe track is a leaf node:

```ts
interface Keyframe<T> {
  t: Seconds;        // time of this keyframe, LOCAL to the leaf (see below)
  value: T;
  easing?: Easing;   // easing of the segment LEAVING this keyframe
}

// A curve drives one property of one target over its own local timeline.
{ type: "curve"; id: string; target: BTTarget; property: string; keyframes: Keyframe<T>[] }
```

`property` is a path — a transform channel (`transform.position`) or a component path
(`components.rect.style.fill`), the same addressing `component.setProp` already uses.

**Keyframe times are local to the leaf.** `t: 0` is when the curve starts, not when the
scene starts. Three reasons:

1. **It composes.** A curve under a `sequence` begins when its predecessor ends; under
   `repeat` or `loop` it replays. Scene-absolute times would make both meaningless.
2. **Corrections survive restructuring.** Reordering a sequence does not invalidate the
   keyframe times of everything after the moved node. With absolute times, every
   structural edit would silently expire the corrections recorded against later curves —
   an expiry that would not show up as an error.
3. **It is the composable default**, and the absolute case is still one node away.

**To place a curve at an absolute scene time**, wrap it in a time condition:

```ts
{ type: "condition", on: "time", params: { at: 5 }, child: <curve> }
```

which floors the child's start at `t = 5`. Because it is a floor (`Math.max`), it can
delay a child but never pull it earlier, so it stays well-behaved inside a sequence.

### 4.3 `Animatable<T>` — the value slot

```ts
type Animatable<T> = { kind: "const"; value: T };
```

`Animatable` survives as the wrapper on every animatable-in-principle field, but it now
has exactly one variant. It is kept rather than unwrapped because it preserves the
`resolve(value, t)` seam and the type of every field in the IR; reintroducing a
per-value track later would not touch a single field declaration.

`Keyframe<T>` and `Easing` are unchanged as types — they simply live inside a `curve`
leaf now instead of inside a value.

### 4.4 Resolution: the shared engine

```ts
function resolve(value: Animatable<T>, t: Seconds): T;          // const ⇒ value
function behaviorStateAt(scene: Scene, t: Seconds): Map<EntityId, BehaviorState>;
function resolveScene(scene: Scene, t: Seconds): ResolvedScene; // world transforms + concrete props
```

`resolveScene` remains the single seam between "animated or not" and the rest of the
system: the Canvas preview, the Manim adapter, the Three renderer and the offline
exporter all go through it and none of them touch `Animatable` or the tree directly.

`BehaviorState` carries what the tree has decided for an entity at time `t`. It gains a
property map so a curve can drive component values, not just transform channels:

```ts
interface BehaviorState {
  position?: Vec3; scale?: Vec3; rotation?: AxisAngle; enabled?: boolean;
  properties?: Record<string, unknown>;  // property path -> resolved value
}
```

`timeline.ts` needs no change: it already derives ticks from `simulate().moments`, and a
curve contributes its keyframe times offset by its simulated start.

### 4.5 What the time model adds

- `canvas.fps` / `canvas.duration` become meaningful. Scene duration is whatever the
  tree simulates to.
- Timeline widget: scrub the playhead, drag keyframes in time, edit easing curves. The
  widget converts between the global playhead and a curve's local time at the edit
  boundary; the recorded event carries local time.
- Correction events: `keyframe.*` address `(curve id, index)`. Structural tree edits
  (`behavior.addNode`, `removeNode`, `reparentNode`) are correctable in the same way
  entity structure is — and are richer training signal than a nudged number, because
  they record a fix to the *procedure*.
- A moving object is the *same entity* throughout, with a curve naming it as a target,
  preserving identity across time — exactly what SceneLab wants for attributing
  corrections.

### 4.6 Behavior-tree node identity

```ts
type BTNodeId = string;   // same charset rule as EntityId; unique across the scene
```

**Every behavior-tree node carries a required, unique id.** This is not decoration: a
correction event addresses a node by id (`updateBehavior` already resolves
`behavior.setDuration` and `behavior.setParams` this way), so a node without an id
cannot be corrected at all — the event fails as if the node did not exist. An optional
id makes correctability accidental, which is unacceptable for the artifact the project
exists to produce.

The guarantee is established at the gate rather than by making the field mandatory to
write. Authoring may omit an id; `parseScene` runs `assignBehaviorIds`, so **any scene
that entered the system through the schema has an id on every node**. Authored ids are
never overwritten — they are what a human or model chose to call the node, and
corrections may already reference them.

Assigned ids are positional: owning entity, then the index path down the tree —
`hanoi.bt`, `hanoi.bt.0`, `hanoi.bt.0.1`, with `.c` for a decorator's child and `.t` for
a `forEach` template. Deriving them from the path rather than a counter makes them
stable across parses, which is what lets a correction recorded in one session apply in
the next. Positional ids do shift when the tree is restructured; that is what the
structural correction events are for, so a reorder is *recorded* rather than inferred
from ids that quietly changed meaning.

`validateSceneGraph` reports duplicates (`duplicate-bt-id`) and out-of-charset ids
(`invalid-bt-id`) as errors, for the same reason a duplicate entity id is one: they make
an address ambiguous.

---

## 5. Interaction model (agent in the loop)

SceneLab is not a standalone app — it lives **inside an agent chat**. The scene graph is
the shared artifact passed between the agent and the editor; the Canvas preview is a fast
in-chat checkpoint where human and agent verify and adjust spatial intent before an
expensive render. The standalone `playground` app exists only for development.

### 5.1 The loop

```
1. Prompt    user → agent, in chat ("explain the Pythagorean theorem…")
2. Generate  agent → Scene (the intermediate scene graph, §3)
3. Preview   SceneLab spawns as an embedded widget; Canvas renders the Scene at chat speed
4. Edit      human direct-manipulates and/or agent proposes edits → correction events
5. Return    updated Scene + events flow back to the agent
6. Render    agent runs an adapter (Scene → Manim → video, §8) = the final result
   └─ Extension: tools that edit the final result directly (post-render, §5.6)
```

Pre-render (edit the storyboard before committing to a render) and post-render (load the
result back to catch missed issues) are the same loop; post-render just re-enters at step 3.

### 5.2 Host-embedding contract

SceneLab is a **controlled component**. The host (the chat/agent surface) owns the
canonical `Scene`; the widget takes state in and emits changes out, never owning session
truth. This is what keeps it embeddable anywhere.

```ts
interface SceneLabWidgetProps {
  scene: Scene;                 // current state, owned by the host
  config?: WidgetConfig;        // which tools, read-only, 2D/3D, …
  onEdit?: (events: EventEnvelope[]) => void;                 // per interaction (streamable)
  onCommit?: (scene: Scene, trace: EventEnvelope[]) => void;  // user satisfied → render
}
```

`onCommit` is the render signal: it hands back the final `Scene` (what to render) *and* the
ordered `trace` of events (what changed — for agent reasoning and training).

### 5.3 Human/agent edit symmetry

The correction protocol (§6) is a mutation language spoken by **both** the human and the
agent. Both drive the same pure reducer in `scene-ir`:

```ts
function applyEvent(scene: Scene, event: CorrectionEvent): Scene;  // pure, deterministic
```

- The **human** produces events by dragging in the widgets.
- The **agent** produces the *same* events programmatically — to generate, to propose a fix
  ("the label overlaps; nudge it"), or to translate a text instruction ("move it left")
  into a `entity.translate`. Even text corrections thus yield structured data, though direct
  manipulation is higher-fidelity.

One mutation path, one event vocabulary, one reducer — no separate agent code path. (The
reducer is also ideal SWE-bench material: pure, deterministic, exhaustively testable.)

### 5.4 Trace correction (agent proposes, human corrects)

Because edits are authored typed events, the agent's *own* correction trajectory is
first-class — and correcting it is one of the project's two correction-data streams:

1. The agent generates a `Scene`, then is prompted to **correct it on its own** — a sequence
   of `source: "agent"` events (its spatial-correction *trace*).
2. The **human adjusts** from there — `source: "human"` events.
3. The delta between the agent's trace and the human's adjustments is the **trace-correction
   signal** (SFT-quality), reconstructable because every event carries its author.

The single before/after `CorrectionPair` (§7) is the *spatial-correction* artifact; the
ordered, authored event trace is the *trace-correction* artifact — same events, two views.

### 5.5 Rendering

The Canvas preview is the fast, in-chat checkpoint. The **full render is agent/server-side**,
triggered on `onCommit` via an adapter (§8): "preview at chat speed, commit to a render that
takes minutes."

### 5.6 Direct final-result editing (extension)

Beyond editing the intermediate scene graph, later tools may edit the **final result**
directly (e.g. region tools on a rendered frame). These are additive and should map back to
scene-graph edits **wherever possible**, so they still emit structured corrections; only
changes that genuinely can't be expressed in the graph operate on the output opaquely. The
scene-graph loop stays the core; this is a capability on top.

---

## 6. The correction protocol

Every user manipulation emits one typed, semantic event. Events are the training
signal; the corrected scene is the ground truth. Never raw pixels.

```ts
interface EventEnvelope {
  event: CorrectionEvent;
  source: "human" | "agent";   // authorship — enables trace reconstruction (§5.4)
  agent?: string;              // model id when source === "agent"
  timestamp: number;    // wall-clock ms of the interaction
  sessionId: string;
  sceneTime?: Seconds;  // playhead when edited (undefined in the static core)
}

type CorrectionEvent =
  // ---- spatial; `target` may be an entity OR the camera id ----
  | { type: "entity.translate"; target: EntityId; from: Vec3; to: Vec3 }
  | { type: "entity.scale";     target: EntityId; from: Vec3; to: Vec3 }
  | { type: "entity.rotate";    target: EntityId; from: AxisAngle; to: AxisAngle } // 2D: axis +Z
  | { type: "shape.setProp";  target: EntityId; path: string; from: unknown; to: unknown } // e.g. path "radius"
  | { type: "style.set";      target: EntityId; path: string; from: unknown; to: unknown } // e.g. path "fill"
  // ---- structural ----
  | { type: "entity.add";      parent: EntityId; entity: Entity; index: number }
  | { type: "entity.remove";   target: EntityId }
  | { type: "entity.reparent"; target: EntityId; newParent: EntityId; index: number }
  // ---- temporal: keyframes address a `curve` leaf by id, not an entity property (§4.2).
  //      Times are LOCAL to the curve, so these stay valid when the tree is restructured.
  | { type: "keyframe.add";       target: BTNodeId; keyframe: Keyframe<unknown> }
  | { type: "keyframe.move";      target: BTNodeId; index: number; from: Seconds; to: Seconds }
  | { type: "keyframe.setValue";  target: BTNodeId; index: number; from: unknown; to: unknown }
  | { type: "keyframe.setEasing"; target: BTNodeId; index: number; from: Easing; to: Easing }
  // ---- behavior-tree structure: same shape as the entity structural edits above,
  //      because both are trees of typed containers.
  | { type: "behavior.addNode";      parent: BTNodeId; node: BTNode; index: number }
  | { type: "behavior.removeNode";   target: BTNodeId }
  | { type: "behavior.reparentNode"; target: BTNodeId; newParent: BTNodeId; index: number }
  | { type: "behavior.setType";      target: BTNodeId; from: BTCompositeType; to: BTCompositeType };
```

Design notes:
- `from`/`to` on every edit makes each event a self-contained delta — the design's
  `{from:{x:100,y:200}, to:{x:130,y:200}}` example generalized.
- `target` is a `EntityId`, so events survive re-layout and are interpretable across
  renderers. This is the "semantic, not pixel" guarantee.
- The **camera** carries a `EntityId`, so "drag the frame tighter" is just
  `entity.translate`/`entity.rotate`/`entity.scale` targeting the camera; projection tweaks
  (e.g. ortho `height`, `fovY`) use `shape.setProp` with a `projection.*` path.
- **Rotation** edits carry axis-angle `from`/`to`, so a constrained-handle drag and a
  free 3D trackball produce the *same* event shape — no special-case delta variant.
- The temporal variants exist in the type now so the protocol is stable; they are
  simply never produced until the timeline ships.
- **One reducer for all edits.** Human and agent both apply events through the same pure
  `applyEvent(scene, event): Scene` in `scene-ir` (§5.3) — no separate agent path.
- **`source` makes traces attributable** (agent-authored vs human-authored) — the basis
  for the trace-correction data stream (§5.4).

---

## 7. The correction pair (the training artifact)

The unit the training pipeline consumes. One per correction session (or per commit).
Stored as **JSONL**, one pair per line.

```ts
interface CorrectionPair {
  schemaVersion: string;
  id: string;
  prompt?: string;              // the user's original request
  before: Scene;                // model output (the AI's scene graph)
  after: Scene;                 // user-corrected scene graph
  events: EventEnvelope[];      // the path from before → after
  adapter?: {                   // optional code-level view of the same correction
    renderer: "manim";
    beforeCode: string;
    afterCode: string;
  };
  provenance: {
    model?: string;             // which model produced `before`
    createdAt: string;          // ISO 8601
    stage: "pre-render" | "post-render"; // storyboard vs. post-render correction
    annotator?: string;
  };
}
```

The design is explicit that "the signal is *what the human changed and where*, not
the adapter code that encodes it" — so `before`/`after`/`events` are primary and
`adapter.*` is a secondary, derived view. This is also the **first thing to validate
**: hand a few hand-authored `CorrectionPair`s and
confirm the shape is consumable downstream *before* we build tooling that emits it.

---

## 8. The adapter contract

An adapter is the *only* renderer-aware code. It reparameterizes an abstract entity
into renderer-specific params, plus code generation.

```ts
interface RendererAdapter {
  name: string; // "manim" | "canvas" | ...
  // scene graph → renderer source code
  toCode(scene: Scene): string;
  // optional inverse, for importing existing scenes / round-trip tests
  fromCode?(code: string): Scene;
}
```

**Manim adapter (first target).** Manim is chosen because MObject positions map
almost directly onto scene-graph coordinates (design risk mitigation). A dragged
circle → `circle.move_to(RIGHT * 1.3)`; a group → a `VGroup` with a shared transform.
The adapter consumes `resolveScene` output, so it never deals with `Animatable`
directly — when animation lands, the adapter grows Manim `.animate`/`Transform`
calls but its interface is unchanged.

**Canvas preview** is itself an adapter-shaped module (`resolveScene` → 2D draw
calls + hit-testing), but for rendering to screen rather than emitting code. Keeping
it the same shape keeps the "renderer-agnostic core" honest. It applies the scene
`camera`: for a `"2d"` scene this is a trivial orthographic front view (world `z=0`
→ screen), so the core case is a plain 2D draw. When 3D content arrives, the preview
projects through the camera and resolves depth by painter's-order on projected `z`
(a light z-sort), upgrading to a real z-buffer only if/when a WebGL preview is added.
Draw order for coplanar 2D content stays child order, as today.

---

## 9. Package / repo architecture

A monorepo (pnpm workspaces) with the scene graph as a React-free crown-jewel core.
This directly serves design Decision 1 (self-contained, independently embeddable
widgets) and Decision 3 (thin adapters around an agnostic core).

```
scenelab/
├─ packages/
│  ├─ scene-ir/          # scene graph types, zod schema, resolve(), correction
│  │                     #   protocol, correction-pair schema. ZERO React deps.
│  ├─ canvas-preview/    # resolveScene → Canvas 2D draw + hit-testing
│  ├─ widgets/           # React: SpatialCanvas, PropertiesPanel (+ Timeline later)
│  │                     #   each self-contained, emits typed CorrectionEvents
│  ├─ manim-adapter/     # scene graph ↔ Manim code; builds correction pairs
│  └─ correction-log/    # EventEnvelope → JSONL CorrectionPair sink
└─ apps/
   └─ playground/        # Vite app wiring it together (internal demo surface)
```

Dependency direction: `scene-ir` depends on nothing; everything depends on `scene-ir`;
nothing depends on `widgets` except `apps/*`. Adapters depend on `scene-ir` only.

---

## 10. Design extension points

Reserved in the design so they land additively, not as retrofits:

- **Timeline + keyframes** — Section 4 (`curve` leaves, `keyframe.*` events).
- **Repetition** — declarative `repeat` group (Section 3.6).
- **Easing-curve editor** — a widget over `Keyframe.easing`.
- **Additional adapters** — Three.js / CSS / game engines behind the same
  `RendererAdapter` interface.
- **Automated spatial verification** — machine-checkable predicates over `after`
  (e.g. "label no longer intersects triangle"), enabling the RL tasks the design
  calls out. Feasible precisely because values are concrete, not neural.

---

## 11. Open questions for review

1. **Correction-pair granularity** — one pair per commit, or per individual edit?
   (Affects `events[]` length and how a trainer wants to batch.) *Needs downstream input.*

> **Resolved:** coordinate convention — right-handed, Y-up, center origin (§3.8);
> rotation encoding — axis-angle (§3.9); units — neutral world units, metric opt-in
> (§3.10); color — sRGB RGBA floats, perceptual derived (§3.11); semantic words —
> free-form, soft-normalized (§3.12); **schema versioning** — `schemaVersion` on every
> artifact + best-effort forward-compat; **no migration runner pre-v1** (add one only
> when we intentionally break compat after v1).
