# SceneLab

An embeddable, renderer-agnostic scene editor for AI assistants — direct manipulation of
AI-generated spatial/temporal output, with a structured scene graph as the shared core.

> **Design source of truth:** [`docs/foundation.md`](docs/foundation.md). Read it before
> changing the scene graph, correction protocol, or adapters.

## Monorepo layout

pnpm workspaces. The renderer-agnostic core has zero React/renderer dependencies;
everything else builds on it.

```
packages/
  scene-ir/          scene graph types + schema + resolve() + correction protocol (pure, 3D-native)
  canvas-preview/    resolveScene → Canvas 2D draw + hit-testing; now degrades gracefully for 3D (perspective)
  three-renderer/    unified 2D+3D renderer: ResolvedScene → three.js Scene (lit Standard for volumetric)
  canvas-render/     headless @napi-rs/canvas → mp4 (reuses canvas-preview engine)
  three-export/      headless Chromium (Playwright) → mp4 via three-renderer (3D-capable export)
  manim-adapter/     scene graph ↔ Manim code; builds correction pairs (2D path; 3D uses three-export)
  correction-log/    EventEnvelope → JSONL CorrectionPair sink (stub)
  agent/             prompt → Scene via LLM (with self-repair, few-shot guard)
  widgets/           embeddable React widgets (SpatialCanvas 2D, ThreeCanvas unified, PropertiesPanel 3D-aware, Timeline)
apps/
  playground/        dev/demo app — toggle 2D/3D sample, unified ThreeCanvas primary for 3D
```

Dependency direction: `scene-ir` depends on nothing; everything depends on `scene-ir`;
only `apps/*` depend on `widgets`. `three-renderer` is the unified path (2D = z=0 ortho, 3D = perspective + lit).

> Current state: core IR is 3D-native, three-renderer now handles text/mesh placeholders + Standard materials for lit volumetric.
> Canvas-preview no longer throws on perspective: perspective-projected fallback with painter sort, overlay supports axes.
> PropertiesPanel now exposes Vec3 (XYZ) for pos/scale, axis-angle rotation, and box/cylinder/cone sizes.

> Current state: the core packages have tested implementations; a few features
> (timeline, correction-log sink) are still minimal.

## Prerequisites

- Entity **20+** (see `.nvmrc`)
- **pnpm** via Corepack: `corepack enable` (the version is pinned in `package.json`)

## Commands

```bash
pnpm install       # first run generates pnpm-lock.yaml — COMMIT IT (CI uses --frozen-lockfile)
pnpm typecheck     # tsc --noEmit across the workspace
pnpm test          # vitest run
pnpm test:watch    # vitest (watch)
```

> `build` currently aliases `typecheck` (no emitted artifacts yet); a real bundle step
> arrives with the playground app.

## CI / reproducibility

`.github/workflows/ci.yml` runs install → typecheck → test on every push/PR. The
root `Dockerfile` proves the same clean-clone build+test in plain Docker, matching the
clean-clone reproducibility requirement. SWE-bench *tasks*
live in a separate tasks repo, not here.

## Notes

- Reference PDFs are
  **gitignored** — one of them contains a shared secret token and must not be committed.
