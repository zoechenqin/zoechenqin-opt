# SceneLab — Overview

The complete design (the scene format, the editor surfaces, the testing rules) is in the [SceneLab Design Reference](https://docs.google.com/document/d/1XMFb-CJpSY0jI3axwRLIhvfqNErhLK56eeo8efYPb6o/edit), kept in the repository as `docs/CANONICAL_DESIGN.md`. Section references below written as "Design §x.y" point into it.

## 1. The Idea

SceneLab is a way for an AI to make visuals that a human can directly fix, and for every fix to become training data.

When a model generates an image or a video and it comes out wrong, there are two usual options: re-prompt and hope, or take the output into some other tool and repair it by hand. Neither leaves anything behind. The re-prompt teaches nobody anything. The hand repair happens somewhere the model will never see.

SceneLab changes what the model produces. Instead of pixels, it writes a **scene**: a structured description of what is where, how it looks, and how it moves. You open that scene in an editor inside the chat, and you drag a label two units to the left. The drag is captured as a precise, typed change — `move label_1 from (100,0,0) to (130,0,0)`: and the scene before, the scene after, and the change between them make a training pair.

Three goals:

1. A real editor, not a preview.
2. Structured correction data, not screenshots or text diffs.
3. A better representation, one where a scene graph beats both pixels and code.

### 1.1 How The Pieces Fit

Before the ideas, the shape of the thing. **Artifacts in bold**, *operations in italic*:

**source scene** → *resolve* → **resolved scene** → *simulate* → **timeline**

- The **source scene** is what the model writes and what gets saved. It stays small: "an 8×8 grid of this square", not sixty-four squares.
- *Resolve* turns that into the **resolved scene**. The generators run, the sixty-four squares now exist, each with its own id, and references between objects are wired up. None of this depends on time.
- *Simulate* walks the animation without drawing anything and produces a **timeline**: how long things run, when things happen, and the values of anything that could only be worked out by running it.

What happens after that depends on what is doing the drawing, and there are two shapes:

- **Sampling.** Ask the scene what it looks like at one moment, and draw that. The editor works this way, and so does any renderer we drive a frame at a time.
- **Translation.** Hand the structure to something that runs animation itself, like Manim or a game engine, expressed in its own terms. A loop stays a loop rather than becoming a thousand separate instructions (Design §1.9).

Alongside all of it, *editing* on any surface produces **correction events** which append to a log. Those events are the product; everything else exists to generate them.

## 2. The Core Ideas

Six ideas carry most of the design. If you read nothing else here, read these.

### 2.1 A Scene Is A Program, Not A Pile Of Content

A chessboard is not sixty-four squares. It is one square, plus an instruction to place it on an 8×8 grid. A Tower of Hanoi solve with seven disks is not 381 hand-placed movements; it is one recursive procedure that happens to produce 127 moves of three steps each.

Describing scenes this way keeps them small enough for a model to emit in one pass. More importantly, it keeps them editable *at the level you actually think at*. Moving the whole board is one change. Making the solve slower is one change. Were the board sixty-four independent squares, each of those would be sixty-four changes, and nobody would make them.

### 2.2 Space Is A Graph, Not A Tree

Most 3D tools hand you a hierarchy: objects inside groups inside groups. That is a good way to say where things are and a useless way to say "make sixty-four of these." For that job the procedural tools (**Houdini**'s Copy to Points, **Blender**'s geometry entities, **Unreal**'s PCG) reach for a different structure: a small dataflow graph in which one operator generates locations and another stamps content onto them.

SceneLab borrows that split directly. A **points** operator says *where*: a grid, a ring, a random scatter, a path to follow, or a script that computes positions. An **instance** operator says *what goes there*. A chessboard is those two operators plus one square.

It is a graph rather than a tree because one template can feed several arrangements at once: the same square stamped into a 4×4 board and an 8-point ring, with nothing duplicated anywhere. A tree cannot express that, since every entity has exactly one parent. The ordinary hierarchy still exists alongside it and still does what hierarchies are good at — containment, and moving a group moves its children. Arrangement is simply a different job (Design §2.4).

### 2.3 Time Is A Behavior Tree, Not A Timeline

Animation tools give you a timeline of keyframes: this value at this moment, that value at that one, interpolate between. That is an excellent way to hand-tune six seconds of motion, and a hopeless way to express a seven-disk Tower of Hanoi — 127 moves, 381 separate motions. Editing one curve is ordinary work; editing 381 is not something anyone does.

Game engines solved this differently, and that is the model we take. A **behavior tree**, the structure **Unreal** and most game AI use, describes what happens and in what order: sequences, fallbacks, things running together, conditions that wait on an event. Timing falls out of running it rather than being drawn in advance. Hanoi becomes one recursive procedure, and the 127 moves are its output rather than its source.

The payoff appears when you edit. Too fast overall? One speed parameter. A peg in the wrong place? One parameter. One awkward move out of 127? A small note against that move, with the other 126 still driven by the procedure.

This has one consequence worth meeting early. If timing is computed rather than drawn, the total duration is not always known in advance, because nobody knows when a collision happens or how many moves a script will produce. So the scene is simulated before it is drawn, and the timeline it produces is an estimate that extends as you scrub past it (Design §2.8).

### 2.4 Editing Must Never Destroy The Program

This is the invariant everything else protects. If nudging one square caused the board to flatten into sixty-four independent squares, you would have traded the representation for a pile of content the first time you touched it.

So every edit lands in one of two places: on a parameter of the program, or in a small sparse note beside it: *instance (0,0) sits ten to the right of wherever the grid put it*. The program stays intact and the note stays tiny. Flattening is available, and it's called **baking**, but only ever when you ask for it by name.

### 2.5 People And Agents Speak One Vocabulary

There are four ways to change a scene: type in chat, drag a handle in the viewport, edit a number in the inspector, or restructure it in the outliner. All four produce the same typed events, and each event records who made it — human or agent, and which surface it came through.

That symmetry is the point. An agent's edit and a person's are directly comparable because they're the same kind of object, and a whole session can be replayed from the log. Those events are the product; everything else exists to generate them.

### 2.6 Some Things Can Only Be Described

"Weathered oak with visible grain" has no set of numbers you can type. Neither does a burst of sparks on impact, or a walk that reads as careful rather than hurried. For these the format carries a *description* alongside the concrete values.

The tradeoff is explicit. A described thing is portable, since every renderer accepts it, but two renderers will interpret it differently, and until it is turned into concrete values it cannot be dragged, tested, or graded. So the rule of thumb runs one way: whatever can be specified, specify. Reach for a description only for what genuinely resists it.

## 3. Where It Comes From

**[ControlNet](https://arxiv.org/abs/2302.05543)** (Zhang et al., 2023) is the premise. Structure and content are separable, and the human should hold the structure, so composition stops being something you re-roll the prompt and hope for. SceneLab pushes on its weak point: ControlNet's control input is a raster hint, used once and discarded. Here the structure is the artifact, and correcting it is what produces the data. Here is a [video explanation](https://www.youtube.com/watch?v=WZg3e6B2yPQ&t=420s) of some of the tools.

**[The Scene Language](https://arxiv.org/abs/2410.16770)** (Wu et al., 2024) is where the format comes from. A scene as words, plus a program, plus embeddings. Our adaptation is that each of the three must be reachable by a single typed event, because a representation you can only regenerate is not one a human can fix.

**Procedural editor tools**: Houdini above all, with Blender's geometry entities and Unreal's PCG. Where the spatial model comes from, and the proof that people already work this way: generate locations, stamp templates onto them, keep the graph as the source of truth. These tools settled the hard interaction questions decades before we reached them — how to nudge one copy without wrecking the arrangement, and why baking is a deliberate act.

- [How to use Houdini in level design](https://www.youtube.com/watch?v=iiHCNpoMZq0&t=40s)
- [Blender Tutorial: Geometry Entities for Beginners - Part 1](https://www.youtube.com/watch?v=vqOZONo5DmY&t=269s)
- [UE5 Series: PCG for Beginners | 01 Level Setup & First PCG Graph](https://www.youtube.com/watch?v=SpulPoSmHJs&t=1720s)

Where SceneLab departs from all three is authorship. A Houdini graph is built by an artist over hours in a visual editor. Ours has to be emitted by a model in one pass and then corrected by typed events, so it stays small, typed and addressable rather than becoming an entity-graph authoring environment. Design §1.2 has the longer version.

## 4. What The Project Owes

SceneLab is an AAI Labs project, and it carries a data-generation obligation separate from the product itself. Per engineer per week, after a week of ramp-up: **~5 trace corrections** and **~0.5 SWE-bench / T-bench tasks**, roughly one every two weeks. The figures come from the AAI Labs Data Generation wiki and change periodically, so treat the wiki as the live number.

**They are a floor, not a target.** That baseline applies to every AAI Labs project; it is not a plan for this one. The goal is to beat it, particularly on tasks — demonstrating that a codebase built this way yields far more useful task and trace data than the minimum is a large part of how the project differentiates.

Both come out of building SceneLab rather than being manufactured alongside it. Trace corrections accrue from working *through* the agent, correcting project work as it happens rather than as a separate errand; which model that is gets set top-down and changes, so nothing here hard-codes one. Tasks come from the codebase itself, and the working shape is repeatable rather than one-off: a prompt, the scene graph it should produce, and deterministic assertions on spatial correctness. Task generation is also the near-term priority over the correction-pair loop, since there is no ML-team contact yet.

**Subject selection is the bottleneck, not mechanics.** Judging whether a subject's spatial demands actually bite is the part that cannot be automated, and task ideas and instructions belong to the annotator in any case. So everything downstream of naming a subject should be fast enough that the human is never the one waiting. Design §4.3 covers what makes a task worth setting; Design §4.1 covers the tooling.

## 5. Workstreams

What the work is, in plain terms, grouped by the part of the system it belongs to. Each names the package that holds it.

### 5.1 The Representation

**Core Format And Validation**: `packages/scene-ir`. The fundamentals, and the part that should change slowly: the entity kinds and what `children` means on each; the arrangement's DAG of points and instance operators; the behavior tree and its status model; resolve, meaning expand then link; generated ids and their uniqueness; the sparse override map; structured references that survive regeneration. With them, the rules that keep a scene well-formed — one drawable per entity, the id charset, no collisions between authored and generated ids, links that resolve.

**Growing The Format**: the other half, and a continuing one. Several component slots exist in name with nothing specified behind them: skeletal animation, materials beyond what `style` reaches, particle systems, physics bodies and colliders. Layout is not even a slot yet, and diagram work would force it first.

The route in is deliberate rather than ad hoc. A capability usually enters as a *description* (Design §2.7), gets used that way while its shape becomes clear, and graduates to a typed specification once it is — at which point existing scenes migrate as the boundary moves. That is what keeps the core small without making it a ceiling, and it makes "we have not designed this yet" an expressible state rather than a blocker. The work in this stream is deciding which things are ready to graduate, and specifying them without importing some particular renderer's model in the process.

### 5.2 Producing Output

**Renderer And Export**: `packages/three-renderer`, `packages/three-export`. One renderer, lit for final output, with unlit / wireframe / bounding-box modes for quick looks. It draws paths as real curves, skeletons as bone hierarchies, and resolved links. Export runs the same code headlessly so exports match the editor. This requires WebGL, which is fine in a browser and rules out a few headless contexts.

**Diagram Output**: `manim-adapter`, `canvas-render`. Converting a scene into Manim (a Python animation library, rendered via Docker) or into direct canvas output. These are output adapters, not editors.

### 5.3 The Editor

**Viewport Manipulation**: `ThreeCanvas.tsx`. Gizmos in local, parent or world space; click, marquee and drill-in selection; locked greyed-but-selectable versus disabled not-selectable; template selection highlighting everything it reaches; path handle dragging; link endpoints that rewrite references instead of coordinates; snapping that prefers a reference to a coordinate; one event per drag, on release.

**Inspector, Outliner And Timeline**: `PropertiesPanel.tsx`, `Outliner.tsx`, `Timeline.tsx`. Value rows that show whether a number is stored, generated, animated or mixed, so no field is a silent bake. Toggles, the single drawable section, embedding controls that are swatches and words rather than float grids, a generic editor for unknown component types, the override map with counts, scrubbing, the tree viewer, and the resolved-tree outliner where structural edits happen.

### 5.4 Models And Datasets

**Asking The Model**: `agent`. The generation prompt has to cover the parts of the format a model will not guess: behavior tree types, arrangements, both kinds of embedding, paths as their own component type, structured references including nested ones, and worked examples of each.

**Measuring Models**: `batch-compare`, `skills/`, `trials/`. The metrics and caveats are Design §4. Run the same prompt across models, several trials each, and score validity, procedurality, non-degeneracy, editability and render completeness.

**Streamlining Task Production**: `skills/`. Turning the obligation in §4 from hand work into throughput. A benchmark task is a directory of files with a fixed shape: a problem statement, a hidden test that decides whether an attempt passed, and a container that builds the repository. Most of assembling one is mechanical, and the mechanical parts are what these tools take over. They generate the scaffolding, run the test suite locally against a known-good answer to confirm the task is solvable at all, and then watch the automated checks that run once it is submitted, surfacing whatever failed.

The largest win is drafting a task from an existing video-generation prompt. A corpus of prompts is a ready supply of subjects, which leaves the author only the two jobs that cannot be automated: judging whether the subject demands real spatial reasoning, and writing the problem statement. Tools here wrap the ones the wider team already maintains rather than rebuilding them, and none of them decide that a task is finished. A person does that. Design §4.1.

**Porting Code Video Submissions**: a pipeline rather than a package, and one that pays three ways at once. Existing submissions are programs that produce videos, so re-expressing them as scene graphs asks the sharpest available question about this format: can it hold what people actually built? Where a port cannot be expressed, or has to fall back on a description where a specification should have served, that is the priority list for §5.1. The ports themselves accumulate into a corpus of real scene graphs, and each one is a candidate benchmark task whose answer is already known. Verification is the obvious thing: render both and compare. Design §4.3.

### 5.5 Correction Data

**Saving Corrections**: `correction-log`. A pair records the scene before, the scene after, and the typed change (including embedding, behavior, arrangement, path handle and reference changes, and structural edits) always in template form rather than expanded. Each entry carries who authored it, which surface it came from, and a transaction id so multi-target and structural edits group. The log is **mutable-once rather than append-only**: undo retracts the original entry instead of appending an inverse, so a fumbled drag leaves no training pair, and a batch retracts as a unit.

### 5.6 Project Scaffolding

**Demo App**: `apps/playground`. Exercises the interesting cases end to end: the board, a character, both embeddings, the Hanoi behavior tree, bezier paths, an arrow targeting a generated square, and one template shared by two arrangements.

**Testing And CI**: `vitest` per package, plus stored reference scenes as fixtures for resolve, sampling, the timeline and each adapter. Two things shape it. Some steps are only reproducible when pinned rather than pure, so fixtures either stay in the pure subset or snapshot a pinned result (Design §4.4). And renderer availability varies — the Manim path needs Docker, the three.js path a real headless browser, so tests degrade and report which renderers actually ran rather than failing. CI additionally has to prove the repo builds and tests from a **clean clone in plain Docker**, because every SWE-bench task clones it at a pinned commit and builds from scratch; if that breaks, task production stops.

**Docs And Build**: this document and the [Design Reference](https://docs.google.com/document/d/1XMFb-CJpSY0jI3axwRLIhvfqNErhLK56eeo8efYPb6o/edit) are canonical. Known gaps and unresolved decisions are collected in Design §5, including the ones that would change the architecture: what the training objective actually is, how sandboxed script execution stays deterministic, what makes resolve incremental, and what the smallest end-to-end path to a single correction pair looks like.

### 5.7 Runtime And Storage

**Where any of this runs.** This is largely undesigned, and it is listed because the work is real rather than because it is settled. The editor is meant to sit inside a chat surface, which constrains it to a browser. The correction log is the product, and nothing yet says where it is collected, how it is stored, or how it reaches whoever consumes it. Synthesis needs something that calls interpreters and a content-addressed cache to keep results reproducible. Rendering at scale needs job execution, since two of the three renderers want Docker or a headless browser. Tracked as an open question in Design §5.
