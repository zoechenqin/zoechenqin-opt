---
allowed-tools: Read, Bash
argument-hint: [--new] [--space=3d] [scene.json] [--save] [--browser]
description: Launch SceneLab editor — main via SceneLab.command, server via Server.command, electron via Electron.command
---

# /scenelab

Main entry — `SceneLab.command` is the primary launcher (server + native window).

The editor owns its agent: the Agent tab runs a metacode session over ACP and streams it into the
panel, so nothing needs priming here.

## Is it already running?

`curl -s http://localhost:7317/api/summary` — if it answers, the editor is up; do not relaunch.

## Usage

- `/scenelab` — server + native attempt
- `/scenelab --browser` — browser only

Launchers (Finder double-clickable, drag to Dock):
- `SceneLab.command` — main: stops previous, builds if needed, starts server (API 7317 + vite 5173) via nohup, opens the native window, exits
- `Server.command` — server only: API + vite, no window
- `Electron.command` — electron only: assumes server running, opens native window

`pnpm start` = `bash ./SceneLab.command`

## Steps

1. Shutdown:
```bash
pnpm exec tsx skills/editor/stop.ts 2>&1 || true
rm -f .metacode/scenelab-editor.json
```

2. Launch server via bash nohup:
```bash
nohup pnpm --filter @scenelab/editor-electron exec tsx src/main.ts --new --no-window > .metacode/scenelab-electron.log 2>&1 & echo $!
curl -s http://localhost:7317/api/summary
```

If --browser:
```bash
pnpm exec tsx skills/editor/editor.ts --new --detach
```

3. Native cannot auto-launch from inside sandbox, so server only inside. Outside launcher `SceneLab.command` (Finder double-click) sets up server+window+metacode together.

4. Report:

```
Welcome to SceneLab — dedicated editor is live.

● Connected · API http://localhost:7317 · UI http://localhost:5173 (cmd+double click)

Blank canvas ready — tell me what to build.
```
